# M63.12 / APF rc.7 — CLI Integration Contracts

Status: ready / go for APF-process planning baseline.

## Scope

This patch changes APF only. It defines how APF consumes external Ordo CLI checks as deterministic evidence. It does not implement those CLI commands and does not modify the Ordo language package.

## Added gates

```text
CLI_CAPABILITY_DISCOVERY_GATE
RELEASE_HYGIENE_CLI_GATE
ANALYST_START_SMOKE_CLI_GATE
RENDER_SMOKE_CLI_GATE
INSPECT_RELEASE_ZIP_CLI_GATE
EXTERNAL_CHECK_EVIDENCE_GATE
```

## Readiness impact

Runtime-capable packages require concrete evidence for required checks. If language tooling is missing, APF must report `pending-language-tooling` rather than `passed`.
