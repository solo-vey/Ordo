# Terminal Output Review Package Manifest

Runtime context shift notice: derived artifact sync gate lifecycle control point.

template_file: template.md
mock_filled_example_file: mock_example.md
mapping_report: mapping_report.md
assumptions_risks_summary: assumptions.md
user_decisions_confirm_revise_defer_remove: confirm, revise, defer, remove
