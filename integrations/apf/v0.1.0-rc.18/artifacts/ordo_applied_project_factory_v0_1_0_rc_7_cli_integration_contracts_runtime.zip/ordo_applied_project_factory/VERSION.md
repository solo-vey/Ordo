# APF Version

`v0.1.0-rc.7-cli-integration-contracts`
