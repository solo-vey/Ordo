# APF Package Creation Hardening Policy

Status: applied in `v0.1.0-rc.6-apf-process-hardening`
Scope: APF package/playbook creation process only. This policy does not change the Ordo language package, compiler, runtime, or core CLI.

## Purpose

APF-generated playbook packages must be handed off as deterministic, restartable, reviewable packages. The hardening gate collects package lifecycle checks that were previously separate future improvements:

- package profile and startup consistency;
- derived artifact freshness;
- delta backlog preservation;
- prompt registry/helper prompt packaging;
- graph/SVG provenance;
- release hygiene and clean runtime readiness;
- real-module testcase generation backlog preservation;
- output-template rendering smoke checks.

## Gate

`APF_PACKAGE_CREATION_HARDENING_GATE` runs after README/startup gates and before `PACKAGE_COMPOSITION_GATE`. It is a lifecycle control-point gate, not a per-answer gate.

## Blocking rule

Final package composition and archive assembly are blocked if a generated playbook package claims readiness while any of the following is unresolved:

- package profile contradicts actual contents;
- START_PROMPT / START_HERE / README startup section is missing;
- derived artifacts are stale without explicit omission;
- delta backlog item or source delta file is dropped;
- helper prompt is unmanifested or used as a replacement for nodes/gates/routing/state;
- graph/SVG has no source or IR provenance;
- runtime-capable package contains debug/live evidence residue;
- runtime-ready is claimed without clean runtime and smoke evidence;
- templates fail render smoke or contain broken placeholders;
- attempted change targets Ordo language package rather than APF process.
