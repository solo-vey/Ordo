# APF Release Hygiene and Clean Runtime Policy

Status: applied in APF rc.6 as release/package creation gate design.

Runtime-capable APF-generated packages cannot be marked `ready/go` merely because files are assembled. They must be clean to start in a new analyst session.

Required release hygiene checks:

- no live evidence, local snapshots, smoke-test residue, or debug-only files in analyst runtime output;
- runtime state starts from the declared entry point;
- future gates do not block early intake;
- debug/evidence outputs are available only through audit/debug mode, not normal analyst mode;
- analyst-start smoke test is recorded or explicitly `not-applicable`;
- release zip inspection confirms allowed/forbidden content.
