# APF CLI Evidence Result Model

Status: accepted for APF rc.7

## Minimal JSON shape

```json
{
  "check_id": "inspect-release-zip",
  "command_contract": "ordo inspect-release-zip <archive>",
  "status": "passed",
  "tooling_status": "available",
  "package_profile": "compiled_runtime",
  "input_ref": "artifacts/<package>.zip",
  "output_ref": "reports/cli_evidence/inspect_release_zip_result.json",
  "blocking": true,
  "findings": [],
  "created_at": "<iso8601>"
}
```

Allowed `tooling_status` values:

```text
available
missing
not-required
unknown
```

If `tooling_status = missing`, the check status must be `pending-language-tooling` or `not-run`, never `passed`.
