# APF Required External Checks Model

Status: accepted for APF rc.7

## Package profile matrix

```yaml
source_authoring:
  render-smoke-test: recommended
  inspect-release-zip: required
  release-hygiene: recommended

compiled_runtime:
  clean-runtime: required
  analyst-start-smoke-test: required
  inspect-release-zip: required
  release-hygiene: required

hybrid:
  clean-runtime: required-for-runtime-side
  render-smoke-test: required-for-template-side
  analyst-start-smoke-test: required
  inspect-release-zip: required
  release-hygiene: required

handoff:
  inspect-release-zip: required
  release-hygiene: recommended

reference_only:
  inspect-release-zip: recommended
```

## Readiness semantics

Runtime-capable packages cannot be marked `ready/go` when required CLI evidence is missing, unless the package is explicitly marked as a planning/design package and the missing check is recorded as deferred evidence.

Source/design packages may use `passed-with-deferred-cli-evidence` only when the missing command belongs to future language tooling and the package is not runtime-capable.
