# APF Pending Language Tooling Policy

Status: accepted for APF rc.7

APF can depend on future Ordo CLI checks, but it must not pretend that those checks already exist.

## Rules

1. Missing external checks are recorded as `pending-language-tooling`.
2. Required missing checks block runtime-capable package readiness.
3. Design/source packages may defer such checks only when the readiness statement says so explicitly.
4. The final handoff must list all deferred checks.
5. Deferred checks must be preserved in the APF delta backlog.
