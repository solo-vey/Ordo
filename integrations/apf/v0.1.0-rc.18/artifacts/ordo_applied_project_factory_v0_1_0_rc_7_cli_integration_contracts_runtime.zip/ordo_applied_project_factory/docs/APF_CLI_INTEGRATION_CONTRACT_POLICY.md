# APF CLI Integration Contract Policy

Status: accepted for APF rc.7
Scope: APF package/playbook creation process only. This policy does not implement Ordo CLI commands and does not change the Ordo language package.

## Decision

APF may require external deterministic checks from the Ordo language tooling, but APF only defines how those checks are discovered, invoked, consumed, and recorded.

APF must not claim that a CLI check passed unless a concrete machine-readable evidence record exists. If the required language tooling is unavailable, APF records `pending-language-tooling` or `not-run`; it does not simulate the result with prose.

## Required evidence statuses

```text
passed
failed
not-run
pending-language-tooling
not-applicable
```

## Standard evidence path

```text
reports/cli_evidence/<check_id>_result.json
```

## Boundary

In scope for APF: gate placement, command contract, input/output shape, evidence retention, readiness semantics.

Out of scope for APF: implementing Ordo CLI helpers, language runtime changes, compiler changes, new Ordo primitives.
