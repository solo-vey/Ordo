# APF Graph/SVG Provenance Policy

Status: applied in APF rc.6 as package validation policy.

Graph and SVG artifacts are review/navigation artifacts, not source of truth. When APF creates or packages graph outputs, each output must declare:

- source basis: source YAML, compiled IR, or runtime manifest;
- source reference path and hash when available;
- renderer/utility and render mode;
- output path and checksum;
- whether the artifact is included in package manifest;
- whether it is current, stale, omitted, or not applicable.

A graph artifact cannot replace the source model, compiled IR, gates, routing, or validation report.
