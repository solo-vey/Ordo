# APF Prompt Registry Packaging Policy

Status: applied in APF rc.6 as an APF package validation convention.

Helper prompts may be included in APF-generated packages, but they are package artifacts only. They must never replace APF nodes, gates, routing, confirmed state, templates, or CLI evidence.

Required checks when prompts are present:

- prompt files live under a declared package path such as `prompts/`;
- manifest/checksum coverage includes every prompt file;
- each prompt has a role and usage reference;
- prompt usage does not create hidden process logic;
- prompt registry state is preserved in transfer packages.
