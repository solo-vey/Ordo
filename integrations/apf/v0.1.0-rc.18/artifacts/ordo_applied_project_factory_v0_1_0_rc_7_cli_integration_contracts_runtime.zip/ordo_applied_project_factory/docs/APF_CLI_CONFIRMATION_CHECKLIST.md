# APF rc.7 Confirmation Checklist

After rc.7 review, confirm:

- [ ] `CLI_CAPABILITY_DISCOVERY_GATE` is placed after `PACKAGE_PROFILE_GATE`.
- [ ] Package profile → required CLI checks matrix is accepted.
- [ ] Runtime-capable package readiness is blocked without required CLI evidence.
- [ ] Source/design packages may use deferred CLI evidence only with explicit status.
- [ ] `reports/cli_evidence/` is accepted as the standard evidence path.
- [ ] New node names match APF naming style.
- [ ] `APF_PACKAGE_CREATION_HARDENING_GATE` remains readable and does not hide too much logic.
- [ ] APF does not implement Ordo CLI helpers.
