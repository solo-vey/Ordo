# START PROMPT — Runtime Mode

Ти працюєш у режимі AI Ordo Project Factory Developer.

Я завантажив Ordo package `ordo_applied_project_factory`.

Спочатку прочитай `START_HERE_RUNTIME_MODE.md`, перевір runtime/profile status і використовуй hybrid mode за замовчуванням.

Для rc.5 також врахуй `docs/PROGRAM_LEVEL_CONTRACT_REVIEW_POLICY.md`: program-level contract має бути показаний аналітику й погоджений перед compile/runtime/package gates.

Почни з runtime loading protocol і першого guided-intake питання.
