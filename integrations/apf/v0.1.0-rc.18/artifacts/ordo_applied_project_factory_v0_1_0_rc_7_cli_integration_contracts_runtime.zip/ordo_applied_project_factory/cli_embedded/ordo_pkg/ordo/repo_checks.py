from __future__ import annotations

import re
from pathlib import Path
from typing import Any

PACKAGE_PATH_PATTERN = re.compile(r"packages/[A-Za-z0-9_./-]+")


def validate_workflow_paths(repo_root: str | Path) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    workflow_dir = root / ".github" / "workflows"
    issues: list[dict[str, str]] = []
    checked: list[str] = []
    if workflow_dir.exists():
        for workflow in sorted(workflow_dir.glob("*.yml")) + sorted(workflow_dir.glob("*.yaml")):
            text = workflow.read_text(encoding="utf-8")
            for match in sorted(set(PACKAGE_PATH_PATTERN.findall(text))):
                checked.append(match)
                if not (root / match).exists():
                    issues.append({
                        "code": "WORKFLOW_PATH_NOT_FOUND",
                        "path": match,
                        "workflow": str(workflow.relative_to(root)),
                        "message": f"Workflow references missing path: {match}",
                    })
    return {
        "status": "passed" if not issues else "failed",
        "checked_paths": sorted(set(checked)),
        "issues": issues,
    }


def validate_generated_metadata_absent(repo_root: str | Path) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    forbidden = []
    for pattern in ("*.egg-info", "__pycache__"):
        forbidden.extend(str(p.relative_to(root)) for p in root.rglob(pattern))
    for pattern in ("*.pyc",):
        forbidden.extend(str(p.relative_to(root)) for p in root.rglob(pattern))
    forbidden = sorted(set(forbidden))
    return {
        "status": "passed" if not forbidden else "failed",
        "forbidden_paths": forbidden,
    }



def validate_package_generated_artifacts_absent(repo_root: str | Path) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    forbidden: list[str] = []
    generated_roots = [
        "compiled",
        "reports",
        "runtime",
        "generated_outputs",
    ]
    packages_dir = root / "packages"
    if packages_dir.exists():
        for package in sorted(p for p in packages_dir.iterdir() if p.is_dir()):
            for generated_name in generated_roots:
                generated_dir = package / generated_name
                if not generated_dir.exists():
                    continue
                for path in generated_dir.rglob("*"):
                    if path.is_dir():
                        continue
                    rel = str(path.relative_to(root))
                    if path.name == ".gitkeep":
                        continue
                    if generated_name == "reports" and path.name in {"CLI_VALIDATION_SUMMARY.md", "PACKAGE_PROFILE_SUMMARY.md"}:
                        continue
                    forbidden.append(rel)
    return {
        "status": "passed" if not forbidden else "failed",
        "forbidden_paths": sorted(set(forbidden)),
        "note": "Source archive should keep generated package artifacts out of compiled/, reports/, runtime/, and generated_outputs/ except .gitkeep placeholders and reports/CLI_VALIDATION_SUMMARY.md and reports/PACKAGE_PROFILE_SUMMARY.md templates.",
    }


def run_repo_checks(repo_root: str | Path) -> dict[str, Any]:
    workflow = validate_workflow_paths(repo_root)
    generated = validate_generated_metadata_absent(repo_root)
    package_generated = validate_package_generated_artifacts_absent(repo_root)
    reports = {
        "workflow_paths": workflow,
        "generated_metadata_absent": generated,
        "package_generated_artifacts_absent": package_generated,
    }
    failed = [name for name, report in reports.items() if report.get("status") != "passed"]
    return {
        "status": "passed" if not failed else "failed",
        "failed_checks": failed,
        "reports": reports,
    }
