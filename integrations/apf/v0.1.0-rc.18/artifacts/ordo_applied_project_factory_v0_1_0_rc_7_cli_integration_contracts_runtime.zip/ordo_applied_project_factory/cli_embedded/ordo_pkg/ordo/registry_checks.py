from __future__ import annotations

import re
from pathlib import Path
from typing import Any

OPCODE_PATTERN = re.compile(r"`([A-Z][A-Z0-9_]*(?:\.[A-Z0-9_]+)+)`")


def find_repo_root(start: str | Path) -> Path | None:
    path = Path(start).resolve()
    if path.is_file():
        path = path.parent
    for candidate in [path, *path.parents]:
        if (candidate / "language" / "registry" / "OPCODE_CATALOG.md").exists():
            return candidate
    return None


def load_opcode_catalog(repo_root: str | Path) -> set[str]:
    catalog = Path(repo_root) / "language" / "registry" / "OPCODE_CATALOG.md"
    if not catalog.exists():
        return set()
    return set(OPCODE_PATTERN.findall(catalog.read_text(encoding="utf-8")))


def validate_ir_opcodes(ir: dict[str, Any], repo_root: str | Path | None) -> dict[str, Any]:
    ops = sorted({op.get("op") for op in ir.get("ops", []) if isinstance(op, dict) and op.get("op")})
    if repo_root is None:
        return {
            "status": "skipped",
            "reason": "OPCODE_CATALOG.md not found near package; registry check skipped.",
            "ops": ops,
            "missing_ops": [],
        }
    registered = load_opcode_catalog(repo_root)
    missing = sorted(op for op in ops if op not in registered)
    return {
        "status": "passed" if not missing else "failed",
        "catalog": str(Path(repo_root) / "language" / "registry" / "OPCODE_CATALOG.md"),
        "ops": ops,
        "missing_ops": missing,
    }
