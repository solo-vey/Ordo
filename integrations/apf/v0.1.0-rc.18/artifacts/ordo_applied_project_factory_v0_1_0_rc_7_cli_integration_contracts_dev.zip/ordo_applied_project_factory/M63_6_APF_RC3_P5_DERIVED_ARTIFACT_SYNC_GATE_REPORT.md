# M63.6 / APF rc.3-p5 — DERIVED_ARTIFACT_SYNC_GATE Report

Status: implemented  
Module: `ordo.applied_project_factory`  
Version: `0.1.0-rc.3-p5`

## Implemented

Added `DERIVED_ARTIFACT_SYNC_GATE` between final completion artifact generation and package composition.

The gate requires derived artifacts to be regenerated, current, or explicitly resolved after authoritative model changes.

## Non-intrusive rule

The gate does not run after every analyst answer. It runs only at lifecycle control points: after model changes, before package composition, before final archive assembly, and before release/handoff.

## Covered artifacts

- compiled runtime files
- Markdown decision tree / human-readable model
- Mermaid graph source
- SVG graph when supported or required
- template coverage
- README
- MANIFEST
- self-check / validation reports
- visual/tree export artifacts when generated/requested

## Result

Blocking issues: 0.
