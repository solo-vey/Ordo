# Packaging Profiles

This package follows the standard Ordo package profile vocabulary, but M61.1 is validated primarily as a dev/source prototype.

- `dev` — editable package with source YAML, tests, run inputs, templates, and reports.
- `runtime` — future clean guided-execution package after the factory source stabilizes.
- `evidence` — future validation/provenance reports only.

M61.1 acceptance is based on source-level checks, not runtime/evidence profile completeness.

## RC4-SVG utility packaging

The `runtime` profile includes packaged runtime-safe utilities under:

```text
utilities/ordo_visual_graph_generator/
```

This utility is an auxiliary visualization/review tool. It may render `mmd`, `svg`, and `png` outputs from Ordo YAML/IR, but it does not execute the workflow and does not replace runtime validation.

## RC4-Post-SVG compile and startup packaging

The base APF package now exposes a discoverable compile helper:

```text
tools/compile_with_bundled_ordo.py
```

Default dev/source command from the APF package root:

```text
python tools/compile_with_bundled_ordo.py . --force
```

Profile rules:

- `full-dev` / `hybrid` source package may include source YAML, compiled artifacts, tests, tools, reports, templates, and packaged utilities.
- `compiled-runtime` package must include compiled IR, runtime config, target manifest, runtime/session trace, embedded runtime CLI, templates, and runtime-safe utilities.
- Runtime-only packages do not need source YAML and must not pretend that source authoring compile is available from the runtime wrapper.
- Every full generated playbook/factory package must include a model start prompt, a human start guide, and a README startup section naming the actual files.

## Program-level contract gate requirement

Runtime-capable and handoff profiles must include the program-level contract layer introduced in `0.1.0-rc.6-apf-process-hardening`:

```text
PROGRAM_LEVEL_CONTRACT_REVIEW
PROGRAM_LEVEL_CONTRACT_APPROVAL_GATE
program metadata preserved in source YAML and compiled IR
interaction/process/conversation/hybrid summaries present in startup docs
```

