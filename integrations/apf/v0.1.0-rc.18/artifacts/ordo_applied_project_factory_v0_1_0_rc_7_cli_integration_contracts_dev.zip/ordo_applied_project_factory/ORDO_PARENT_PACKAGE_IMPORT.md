# APF parent package import — M63.0 release candidate update

APF is included in the parent Ordo language package as a standard applied module.

```text
module: ordo.applied_project_factory
version: 0.1.0-rc.1
parent_language_package: 0.12.0-preview-rc1
line: M63.0 release-candidate adaptation over M62 line closure
```

The original M62.1 import brought in APF alpha.14. This M63.0 update replaces that imported module content with the validated APF release-candidate based on alpha.21 while preserving the M62 standard-applied-module boundary.

---

# Ordo Applied Project Factory — parent package import notes

Milestone: `M62.1 — APF Package Import into Current Language Package`  
Imported module version: `0.1.0-alpha.14`  
Imported as: `packages/ordo_applied_project_factory/`  
Role: standard applied module, not companion utility and not runtime core.

## Import boundary

M62.1 preserves APF `source/program.ordo.yaml` branch logic. The import does not formalize APF language-pattern candidates as IR/opcodes and does not claim full validation.

Allowed in this milestone:

```text
copy APF alpha.14 package
refresh lint / compile / static test with current CLI
add current-package integration notes
sync high-level documentation
```

Not done in this milestone:

```text
rewrite branch 1 / branch 2 APF logic
close APF human review
implement terminal-output binding corrections
promote APF concepts to core IR/opcodes
run full validation / runtime execution / scoring / calibration
```

## Current validation expectation

APF alpha.14 is accepted into the current language package as a minimally validated standard applied module. Full validation remains deferred by APF design until a terminal/pre-handoff gate.

## Documentation note

The original APF package is preserved as much as possible. A small documentation sync records that alpha.14 includes the fourth startup mode: `Коригування існуючого процесу`.
