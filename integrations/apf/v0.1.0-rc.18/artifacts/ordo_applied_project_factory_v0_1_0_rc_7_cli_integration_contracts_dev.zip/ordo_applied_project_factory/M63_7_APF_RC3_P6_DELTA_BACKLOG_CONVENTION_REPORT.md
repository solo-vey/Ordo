# M63.7 APF RC3-P6 — Delta Backlog Convention Report

Status: passed  
Module: `ordo.applied_project_factory`  
Version: `0.1.0-rc.3-p6`  
Source version: `0.1.0-rc.3-p5`  
Date: 2026-07-09

## Scope

RC3-P6 adds a lightweight convention for improvement delta files before APF moves into the larger RC4-SVG utility work.

## Implemented changes

```text
- docs/DELTA_BACKLOG_CONVENTION_POLICY.md
- backlog/APF_DELTA_BACKLOG_REGISTER.md
- N_SHARED_TAIL_DELTA_BACKLOG_CONVENTION_GATE
- G_DELTA_BACKLOG_ITEM_CLASSIFIED
- G_DEFERRED_DELTA_ITEMS_PRESERVED_FOR_TRANSFER
- G_DELTA_BACKLOG_ORDER_PRESERVED
- G_DELTA_SOURCE_FILES_INCLUDED_IN_TRANSFER_PACKAGE
- A_DELTA_FILES_MUST_NOT_BE_LOST_BETWEEN_CHATS
- A_DELTA_ITEMS_REQUIRE_DECISION_STATUS
- A_DELTA_BACKLOG_REGISTER_IS_TRANSFER_ARTIFACT
- run_inputs/rc3_p6_delta_backlog_convention_state.yaml
```

## Gate placement

```text
FINAL_COMPLETION_ARTIFACTS_GENERATION
→ DERIVED_ARTIFACT_SYNC_GATE
→ DELTA_BACKLOG_CONVENTION_GATE
→ PACKAGE_COMPOSITION_GATE
→ FINAL_ARCHIVE_ASSEMBLY
```

## Decision status model

```text
implement-now
implement-later
defer
reject
superseded
```

## Result

The patch is non-intrusive: it does not add per-answer burden for the analyst. It runs at delta intake, backlog update, transfer package preparation, and final package lifecycle points.

## Next step

Proceed to `RC4-SVG-01 — Packaged SVG graph generator utility`.
