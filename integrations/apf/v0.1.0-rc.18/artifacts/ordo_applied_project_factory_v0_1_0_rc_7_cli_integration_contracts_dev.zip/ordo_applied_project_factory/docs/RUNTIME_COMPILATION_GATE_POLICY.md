# Runtime Compilation Gate Policy

Version: 0.1.0-rc.3-p3

## Purpose

`RUNTIME_COMPILATION_GATE` prevents APF packages from claiming `runtime-ready` when they only contain source files, incomplete compiled artifacts, or stale runtime outputs.

## Required sequence

```text
N_EXECUTION_MODE_DECLARATION
→ N_COMPILED_RUNTIME_USAGE_GATE
→ N_RUNTIME_COMPILATION_GATE
→ N_FACTORY_MODE_SELECTION
```

## Runtime-ready requirements

A package may be marked `runtime-ready` only when all of the following are true:

- the source model is adapted to compiler input schema;
- the compiler was executed;
- `compiled/program.ir.json` exists;
- `compiled/program.ordo.view` exists when supported;
- `compiled/targets.manifest.json` exists;
- `ordo.runtime.json` exists;
- runtime trace/status can be produced;
- source and compiled hashes are recorded.

## Allowed non-runtime statuses

If the gate does not pass, the package must be marked as one of:

- `source-authoring`;
- `handoff`;
- `not-runtime-ready`.

It must not be marked `runtime-ready`.
