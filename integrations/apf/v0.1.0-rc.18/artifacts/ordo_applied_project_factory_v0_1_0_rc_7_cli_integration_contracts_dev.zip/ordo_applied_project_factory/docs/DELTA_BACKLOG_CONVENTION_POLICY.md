# DELTA_BACKLOG_CONVENTION Policy

Status: accepted  
Version: APF v0.1.0-rc.3-p6  
Scope: base APF / factory package process  
Gate: `DELTA_BACKLOG_CONVENTION_GATE`

## Decision

APF adds a lightweight delta backlog convention before package composition and transfer handoff.

The policy status is `accepted` and the register path is `backlog/APF_DELTA_BACKLOG_REGISTER.md`.

## Purpose

Improvement delta files must not disappear between chats, packages, or handoff archives. Every new delta file is treated as a source artifact that must be inventoried, classified, ordered, and preserved.

## Required delta item metadata

Every item captured from a delta source must record these metadata tokens:

```text
source_file
item_id
scope
priority
version_target
decision_status
ordering_position
transfer_status
```

## Decision status model

Allowed `decision_status` values:

```text
implement-now
implement-later
defer
reject
superseded
```

## Ordering rule

The active ordering rule is:

```text
delta_backlog_order_preserved_across_chats
```

A backlog item may move only when the movement is recorded as a decision note or changelog entry. Otherwise transfer packages must preserve the current order.

## Transfer preservation rule

The active transfer preservation rule is:

```text
delta_files_included_in_transfer_package
```

A transfer package must include the source delta files, the current backlog register, and enough handoff notes for the next chat to continue without rediscovering context.

## Gate checks

`DELTA_BACKLOG_CONVENTION_GATE` verifies:

```text
G_DELTA_BACKLOG_ITEM_CLASSIFIED
G_DEFERRED_DELTA_ITEMS_PRESERVED_FOR_TRANSFER
G_DELTA_BACKLOG_ORDER_PRESERVED
G_DELTA_SOURCE_FILES_INCLUDED_IN_TRANSFER_PACKAGE
```

## Non-intrusive execution rule

This gate does not run after every analyst answer. It runs at lifecycle points:

```text
delta intake
backlog update
transfer package preparation
final package composition
new-chat handoff preparation
```

## Blocking behavior

Package or transfer assembly is blocked when a new delta file lacks a register entry, a delta item lacks required metadata, a deferred/rejected/superseded item is lost, or source delta files are omitted from transfer evidence.
