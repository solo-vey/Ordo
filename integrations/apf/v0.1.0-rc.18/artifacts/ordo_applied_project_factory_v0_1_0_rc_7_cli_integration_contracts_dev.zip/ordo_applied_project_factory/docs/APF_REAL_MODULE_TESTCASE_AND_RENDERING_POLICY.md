# APF Real-Module Testcase Generation and Rendering Hardening Policy

Status: applied in APF rc.6 as process/backlog and validation policy.

APF should support future utility mode for generating testcases from a real playbook/project YAML. The mode should create scenarios for common model confusion patterns:

- off-topic deviation and required resume;
- backtracking and dependent-state invalidation;
- trying to jump ahead before gates pass;
- wrong branch selection;
- missing required approval;
- attempting archive assembly before lifecycle gates.

Rendering hardening for APF-generated outputs is validator-level: templates should have render smoke checks, broken placeholder detection, missing-field behavior, and negative tests. This patch does not change the Ordo language renderer.
