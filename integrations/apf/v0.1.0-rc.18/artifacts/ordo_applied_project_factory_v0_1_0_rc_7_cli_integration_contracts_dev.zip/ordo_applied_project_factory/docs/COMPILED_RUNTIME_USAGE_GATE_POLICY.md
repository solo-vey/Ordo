# APF Compiled Runtime Usage Gate Policy

Version: `0.1.0-rc.3-p2`  
Scope: base APF / factory package process  
Status: accepted scoped patch

## Purpose

A package may contain compiled artifacts while the assistant still works only from source YAML, documentation, and templates. This creates ambiguity: the package looks runtime-capable, but the current run may not actually be runtime-driven.

`COMPILED_RUNTIME_USAGE_GATE` removes that ambiguity.

## Required behavior

After `N_EXECUTION_MODE_DECLARATION` and before factory mode selection, APF must record whether:

```text
compiled artifacts are present;
source YAML is present;
the selected execution mode is recorded;
compiled runtime was used for traversal/state/gate validation;
runtime was intentionally bypassed and why;
runtime state or trace exists when runtime/hybrid mode is claimed;
package status is consistent with the selected mode and runtime usage.
```

## Gate outcomes

| Outcome | Meaning |
|---|---|
| `passed` | compiled runtime exists and was used; runtime state/trace evidence is available. |
| `warning` | runtime is bypassed with a recorded reason, or no compiled runtime is available; package is source-authoring/handoff/not-runtime-ready. |
| `failed` | compiled runtime exists but is neither used nor intentionally bypassed with a reason, or package status falsely claims runtime-ready. |

## Blocking rule

If compiled runtime exists but is not used and no reason is recorded, validation must fail or the package must be marked `source-authoring-only` / `not-runtime-ready`.

## Required state fields

```yaml
compiled_runtime_usage_gate_status: passed | warning | failed | not_evaluated
compiled_runtime_usage_gate_passed_or_warning: true | false
compiled_artifacts_detected: true | false | null
source_yaml_detected: true | false | null
selected_execution_mode_recorded: true | false
compiled_runtime_used_for_traversal: true | false
compiled_runtime_bypass_reason: "<required-when-bypassed>"
reason_for_not_using_runtime_recorded: true | false
runtime_state_trace_available: true | false | null
runtime_state_trace_requirement_satisfied: true | false
compiled_runtime_usage_validated: true | false
package_runtime_status: runtime-ready | source-authoring-only | handoff | not-runtime-ready | unknown
package_status_consistent_with_mode: true | false
```

## Gates

```text
G_COMPILED_RUNTIME_USAGE_GATE_EVALUATED
G_COMPILED_RUNTIME_BYPASS_REASON_RECORDED
G_RUNTIME_TRACE_AVAILABLE_WHEN_RUNTIME_USED
G_PACKAGE_STATUS_CONSISTENT_WITH_RUNTIME_USAGE
```

## Assertions

```text
A_COMPILED_RUNTIME_USAGE_MUST_BE_RECORDED
A_COMPILED_RUNTIME_BYPASS_MUST_NOT_LOOK_RUNTIME_READY
A_RUNTIME_MODE_REQUIRES_TRACE_WHEN_RUNTIME_USED
```

## Relationship to execution mode declaration

`EXECUTION_MODE_DECLARATION` asks which mode the run uses.  
`COMPILED_RUNTIME_USAGE_GATE` verifies that the package evidence matches that answer.

This patch does not yet implement the full `RUNTIME_COMPILATION_GATE`; it only validates runtime usage/bypass/status consistency for a run.
