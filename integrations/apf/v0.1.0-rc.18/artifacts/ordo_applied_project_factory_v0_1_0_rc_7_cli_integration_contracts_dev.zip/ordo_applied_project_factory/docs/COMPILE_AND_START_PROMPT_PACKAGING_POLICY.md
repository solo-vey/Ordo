# Compile and Start-Prompt Packaging Policy

**Patch:** `v0.1.0-rc.4-post-svg`  
**Gate family:** `COMPILE_UTILITY_DISCOVERY_GATE`, `PACKAGE_PROFILE_GATE`, `START_PROMPT_PACKAGING_GATE`, `README_STARTUP_SECTION_GATE`

## Purpose

The APF base package must be able to create future playbook/factory packages that are not only structurally complete, but also restartable in a new chat and honest about their runtime/profile status.

This policy covers the base-package layer. It does not add HistoryEvent, ChangeRecord, ExternalHistoryEvent, Mongo/EDR, or other domain-specific logic.

## Compile utility discovery

Before creating a new full playbook/factory package, APF must discover and record the available compile path.

Required evidence:

```text
compile utility path
compile command
expected input files
expected compiled targets
whether compile is available through dev CLI, runtime CLI, or helper script
whether runtime-safe wrapper blocks authoring compile
compile documentation location
```

The APF package provides:

```text
tools/compile_with_bundled_ordo.py
```

Default command from the package root:

```text
python tools/compile_with_bundled_ordo.py . --force
```

The helper prefers the workspace/root Ordo CLI when available and falls back to the package-local embedded compiler modules. In runtime-only packages where source YAML is intentionally absent, it reports `not-applicable` instead of pretending compilation happened.

## Package profile gate

Every full package must declare and validate one of these profile states:

```text
source-authoring
compiled-runtime
hybrid
full-dev
handoff
```

A profile must match actual contents:

- `compiled-runtime` requires compiled IR, runtime config, target manifest, runtime status/trace evidence, and hashes.
- `hybrid` requires a clear split between runtime traversal/state/gates and source-authoring modifications.
- `source-authoring` or `handoff` must not claim runtime-ready status.
- If compile support exists but compilation was not run, the report must say so.

## Start-prompt packaging gate

Every generated full playbook/factory package must include startup material for future chats:

```text
START_PROMPT_<PACKAGE_NAME>.md
START_HERE_<PACKAGE_NAME>.md or ANALYST_START_GUIDE.md
README.md startup section
```

The start prompt must explain:

- which file to read first;
- whether to use compiled runtime, source-authoring, or hybrid mode;
- how to inspect runtime status;
- how to start guided intake;
- what not to do: skip gates, batch confirmations, invent missing contract data, or treat stale compiled artifacts as current;
- how to keep state and reports updated;
- how to distinguish source files from compiled/runtime files.

## README startup section gate

README must include a concrete section named:

```text
How to start this package in a new chat
```

The section must name actual package files and commands. Generic text like “read the start prompt” is not enough unless the real start prompt filename is provided.

## Final archive rule

Final archive assembly is blocked if any of these are false:

```text
COMPILE_UTILITY_DISCOVERY_GATE passed/warning
PACKAGE_PROFILE_GATE passed/warning
START_PROMPT_PACKAGING_GATE passed/warning
README_STARTUP_SECTION_GATE passed/warning
```

These gates are lifecycle/package gates. They do not run after every analyst answer.
