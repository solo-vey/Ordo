# DERIVED_ARTIFACT_SYNC_GATE Policy

Status: accepted  
Version: APF v0.1.0-rc.3-p5  
Scope: base APF / factory package process

## Decision

APF adds `DERIVED_ARTIFACT_SYNC_GATE` between final completion artifact generation and package composition.

The gate ensures that after an authoritative model change, all required derived artifacts are regenerated, current, or explicitly resolved before final package assembly.

## Non-intrusive execution rule

This gate must not run after every normal analyst answer. It runs only at lifecycle control points:

- after authoritative model changes;
- before package composition;
- before final archive assembly;
- before release / handoff.

Normal analyst intake answers do not trigger recompilation or derived artifact regeneration.

## Required synchronized artifacts

At minimum the gate covers:

- compiled runtime files;
- Markdown decision tree / human-readable model;
- Mermaid graph source;
- SVG graph when supported or required;
- template coverage report;
- README;
- MANIFEST;
- self-check / validation reports;
- visual or tree export artifacts when generated or requested.

## Blocking behavior

Final archive assembly is blocked if a required derived artifact is missing, stale, version-mismatched, or generated from a stale source/projection without explicit allowed omission.

Optional or unsupported artifacts may be skipped only if they are honestly marked `not_requested`, `not_applicable`, `skipped`, or `omitted`.

## Machine-readable state

```yaml
derived_artifact_sync_gate:
  status: passed | warning | failed
  authoritative_model_version_recorded: true | false
  compiled_runtime_files_current_or_resolved: true | false
  markdown_decision_tree_current_or_resolved: true | false
  mermaid_graph_current_or_resolved: true | false
  svg_graph_current_or_resolved_if_supported_or_required: true | false
  templates_coverage_current_or_resolved: true | false
  readme_current_or_resolved: true | false
  manifest_current_or_resolved: true | false
  self_check_report_current_or_resolved: true | false
  blocking_issues: []
  warnings: []
```

## Rationale

The package must not rely on README text or coverage notes to imply synchronization. Synchronization must be enforced as a gate before package composition and archive assembly.
