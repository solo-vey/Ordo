# APF Execution Mode Declaration Policy

Version: `0.1.0-rc.3`  
Scope: base APF / factory package process  
Status: accepted scoped patch

## Purpose

Every APF process run must explicitly state how it is being executed before the factory authoring mode is selected.

This prevents ambiguity between three different situations:

| Mode | Meaning |
|---|---|
| `source-authoring` | Work is based on source YAML, documentation, and templates only. Compiled runtime is not used for traversal. |
| `compiled-runtime` | Work is driven by compiled IR/runtime state and runtime gates. |
| `hybrid` | Runtime controls traversal, state updates, and gate validation; authoring mode is used only to modify or extend the process. |

## Mandatory startup rule

The first APF runtime question is now:

```text
Оголосіть режим виконання для цього запуску APF:
1 — source-authoring
2 — compiled-runtime
3 — hybrid
```

Only after that declaration may APF continue to the factory authoring mode selection.

## Runtime-ready status rule

A package must not be marked `runtime-ready` unless one of the following was actually recorded:

```text
compiled-runtime
validated hybrid
```

If the selected mode is `source-authoring`, the package may still be useful and valid as a source/design package, but it must be marked as one of:

```text
source-authoring-only
handoff
not-runtime-ready
```

## Reason recording

When compiled artifacts exist but the selected mode is `source-authoring`, the assistant/runner must record why compiled runtime was intentionally bypassed.

## Required state fields

```yaml
execution_mode: source-authoring | compiled-runtime | hybrid
execution_mode_declaration_status: declared | not_declared
execution_mode_selected_at_start: true | false
execution_mode_reason: "<reason-or-null>"
compiled_artifacts_detected: true | false | null
compiled_runtime_used_for_traversal: true | false
compiled_runtime_bypass_reason: "<required-when-bypassed>"
runtime_ready_claim_allowed_by_execution_mode: true | false
package_status_consistent_with_execution_mode: true | false
```

## Gates

```text
G_EXECUTION_MODE_DECLARED_AT_PROCESS_START
G_RUNTIME_READY_REQUIRES_RUNTIME_OR_HYBRID_MODE
```

## Assertions

```text
A_PROCESS_RUN_MUST_DECLARE_EXECUTION_MODE
A_RUNTIME_READY_STATUS_REQUIRES_COMPILED_RUNTIME_OR_VALIDATED_HYBRID
```

## Notes

This patch only implements the explicit execution-mode declaration. Runtime compilation checks, compiled runtime usage checks, derived artifact synchronization, Excel export, and graph-profile utilities are intentionally left for subsequent scoped patches.
