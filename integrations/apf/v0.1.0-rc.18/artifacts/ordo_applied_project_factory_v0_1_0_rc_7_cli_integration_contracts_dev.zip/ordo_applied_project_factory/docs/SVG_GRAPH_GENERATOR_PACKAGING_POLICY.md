# SVG Graph Generator Packaging Policy

Status: accepted
Version: 0.1.0-rc.4-svg
Gate: SVG_GRAPH_GENERATOR_PACKAGING_GATE

## Purpose

APF packages the existing Ordo visual graph generator utility as an official review and visualization utility.

## Required packaged path

```text
utilities/ordo_visual_graph_generator
```

## Required manifest

```text
utilities/ordo_visual_graph_generator/APF_RC4_SVG_PACKAGED_UTILITY_MANIFEST.json
```

## Supported formats

```text
mmd
svg
png
```

## Supported rendering modes

```text
full-tree
focused-subtree
context
path-only
```

## Supported artifact modes

```text
none
terminal
package
all
```

## Policy fields

```text
svg_graph_generator_packaging_policy_status: accepted
svg_graph_generator_packaged_path: utilities/ordo_visual_graph_generator
svg_graph_generator_manifest_path: utilities/ordo_visual_graph_generator/APF_RC4_SVG_PACKAGED_UTILITY_MANIFEST.json
svg_graph_generator_supported_formats: mmd, svg, png
svg_graph_generator_rendering_modes: full-tree, focused-subtree, context, path-only
svg_graph_generator_artifact_modes: none, terminal, package, all
svg_graph_generator_smoke_status: passed
svg_graph_generator_transfer_inclusion_status: included-in-dev-runtime-and-transfer
svg_graph_generator_gate_id: SVG_GRAPH_GENERATOR_PACKAGING_GATE
```

## Runtime boundary

The graph generator is a review/visualization aid. It must not be treated as runtime execution, business validation, QA evidence, or semantic contract validation.

It may show structure, transitions, gates and artifacts; it must not claim that the workflow was executed successfully.

## Gate checks

```text
G_SVG_GRAPH_GENERATOR_UTILITY_PACKAGED
G_SVG_GRAPH_GENERATOR_MANIFEST_PRESENT
G_SVG_GRAPH_GENERATOR_SMOKE_VERIFIED
G_SVG_GRAPH_GENERATOR_TRANSFER_INCLUDED
G_SVG_GRAPH_RENDERING_MODES_DOCUMENTED
```

## Smoke verification command

```bash
python utilities/ordo_visual_graph_generator/ordo_graph.py \
  packages/ordo_applied_project_factory/source/program.ordo.yaml \
  --format svg \
  --out generated_outputs/apf_rc4_svg_full_graph.svg
```

Expected result: return code `0`, structural validation passed, SVG output created.

## Packaging rule

Final APF transfer packages should preserve the utility through the dev package, runtime package and full workspace archive. Runtime package profile may include `utilities/` as packaged auxiliary utilities.
