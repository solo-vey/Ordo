# PROGRAM_LEVEL_CONTRACT_REVIEW Policy

## Status

```text
Patch: FUTURE-PROGRAM-CONTRACT-01
Version: v0.1.0-rc.5-program-contract
Status: applied
Scope: base APF process / package framework
```

## Purpose

APF packages must not hide top-level execution policy inside YAML only. Before final package assembly, the analyst must see and approve the program-level contract that explains how the package is supposed to run, how conversation input is interpreted, what the runtime profile is, and which checks require deterministic CLI/helper evidence.

This policy applies to the base APF process, not to a domain-specific generated playbook.

## Mandatory stage

APF now inserts this stage after final completion artifacts are prepared and before compile/runtime/package gates continue:

```text
FINAL_COMPLETION_ARTIFACTS_GENERATION
→ PROGRAM_LEVEL_CONTRACT_REVIEW
→ PROGRAM_LEVEL_CONTRACT_APPROVAL_GATE
→ COMPILE_UTILITY_DISCOVERY_GATE
→ PACKAGE_PROFILE_GATE
→ DERIVED_ARTIFACT_SYNC_GATE
→ DELTA_BACKLOG_CONVENTION_GATE
→ SVG_GRAPH_GENERATOR_PACKAGING_GATE
→ START_PROMPT_PACKAGING_GATE
→ README_STARTUP_SECTION_GATE
→ PACKAGE_COMPOSITION_GATE
→ FINAL_ARCHIVE_ASSEMBLY
```

## Required human-readable review summary

Before approval, the AI must show the analyst a concise summary covering:

```text
Program identity:
- program_id
- module_id
- version
- ordo_version

Runtime profile:
- control_level
- execution_mode
- package profile

Interaction model:
- human responsibility
- AI responsibility
- CLI/helper responsibility
- raw tool output policy

Process rail:
- state tracking
- deviation policy
- resume policy
- backtracking policy

Conversation semantics:
- answer_current_node
- clarification
- deviation
- backtrack_request
- new_requirement
- unmatched input policy

Hybrid execution:
- deterministic commands that must be run, not simulated
- human review points
- runtime/CLI evidence required

Final package startup behavior:
- START_PROMPT policy
- README startup section policy
- analyst start guide policy
```

## Source model requirements

The APF source model must preserve this contract through source YAML and compiled runtime IR:

```yaml
program_id: ordo_applied_project_factory_program
module_id: ordo.applied_project_factory
ordo_version: "0.12"
version: 0.1.0-rc.5-program-contract
control_level: standard
execution_mode: full_runtime
compatibility:
  runtime: compiled-runtime profile must be available for guided execution
  cli: deterministic checks required
  schema: Ordo v0.12 source YAML plus compiled semantic IR
```

It must also include:

```text
interaction_model
process_rail
conversation_semantics
hybrid_execution_model
program_contract
```

## Approval gate

`PROGRAM_LEVEL_CONTRACT_APPROVAL_GATE` passes only when:

```text
- program_id is set;
- ordo_version is set;
- control_level is light, standard, or strict;
- execution_mode is full_runtime, chat_internal, or freeform_only;
- module_id and version are set;
- compatibility policy is present;
- interaction roles and responsibilities are defined;
- raw tool output policy is defined;
- process rail state tracking, deviation, resume, and backtracking policies are defined;
- conversation input classes, routing rules, and unmatched input policy are defined;
- hybrid deterministic commands are listed;
- human review points are listed;
- START_PROMPT / README / analyst start guide policies are defined;
- analyst approval is recorded.
```

The gate blocks when AI narrative attempts to replace deterministic CLI/runtime evidence, or when full-runtime claims lack compiled/runtime gates.

## Deterministic validation requirements

Validation must check:

```text
program metadata completeness
allowed enum values
execution mode/profile consistency
control level/gate consistency
interaction role completeness
process rail completeness
conversation semantics completeness
hybrid execution deterministic commands present
human review points present
startup prompt/readme policies present
```

If this layer fails, final archive assembly is blocked.
