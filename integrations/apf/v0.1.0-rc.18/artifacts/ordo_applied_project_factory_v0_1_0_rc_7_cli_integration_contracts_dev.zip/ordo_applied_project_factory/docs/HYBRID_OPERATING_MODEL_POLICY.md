# Hybrid Operating Model Policy

Version: 0.1.0-rc.3-p4
Status: accepted

## Decision

Hybrid mode is accepted as the preferred operating model for APF process creation and refinement.

## Meaning

Runtime controls traversal, confirmed nodes, state updates, and gate validation.
Authoring mode is used only when the APF process itself is changed.

## Important limitation

Normal analyst answers do not trigger recompilation.
There is no per-step recompilation.
There are no extra technical prompts after every analyst answer.

## Runtime becomes stale only when APF process structure changes

Examples:

- a node is added or changed;
- a gate is added or changed;
- terminal path logic changes;
- template contract changes;
- package assembly rule changes.

Normal playbook-creation answers do not make APF runtime stale, including:

- domain name;
- target users;
- expected outputs;
- branch selection;
- terminal path confirmation;
- template owner review answer;
- analyst approval.

## Lifecycle control points

Runtime currentness checks are performed only at lifecycle control points:

1. process start;
2. before runtime-ready status;
3. after APF process-structure changes;
4. before final archive assembly;
5. before release / handoff.

## Goal

Hybrid mode must improve honesty, traceability, and runtime/source separation without slowing down normal playbook creation.


## APF rc.3-p4 hybrid operating model contract markers

validation_gate_catalog: G_HYBRID_MODE_PREFERRED_BUT_NON_INTRUSIVE, G_NORMAL_ANALYST_ANSWERS_DO_NOT_TRIGGER_RECOMPILATION, G_AUTHORING_PROCESS_CHANGES_MARK_RUNTIME_STALE, G_RUNTIME_CHECKS_ONLY_AT_LIFECYCLE_CONTROL_POINTS, G_HYBRID_RUNTIME_AUTHORING_BOUNDARY_RECORDED

hybrid_mode_preferred_for_apf_creation: true
hybrid_operating_model_policy_status: accepted
hybrid_runtime_controls_traversal_state_gates: true
hybrid_authoring_only_for_process_structure_changes: true
normal_analyst_answers_trigger_recompilation: false
per_step_recompilation_required: false
runtime_recheck_policy: lifecycle_control_points_only
runtime_stale_trigger_policy: apf_process_structure_changes_only
hybrid_mode_no_extra_analyst_burden: true


## APF rc.3-p4 required contract field coverage

template_file: template.md
mock_filled_example_file: mock_example.md
mapping_report: mapping_report.md
assumptions_risks_summary: assumptions.md
user_decisions_confirm_revise_defer_remove: confirm, revise, defer, remove
source_yaml: source/program.ordo.yaml
compiled_artifacts: compiled/
validation_report: reports/validation_report.json
output_template_catalog: source yaml template, handoff package summary template
terminal_binding_summary: confirmed
alpha_limitations_log: none
changelog_or_release_notes: MODULE_CHANGELOG.md
usage_or_start_prompt_notes: START_PROMPT_RUNTIME_MODE.md
