# M62.2 — APF Standard Module Usage Guide

Status: `stable documentation layer`  
Date: 2026-07-08

This guide explains how `ordo_applied_project_factory` fits into the current Ordo language package after M62.1 import. It is intentionally documentation-only: it does not change APF YAML branch logic, Ordo runtime semantics, IR/opcodes, scoring, calibration, or testcase execution.

## What APF is

`ordo.applied_project_factory` is a **standard applied module** for creating or improving Ordo playbooks/process packages. It is not a companion utility and not runtime core.

```text
human analyst / PM / tester
  → describes a process in human language
  → APF guides node/branch/output/template review
  → APF produces or improves source/program.ordo.yaml
  → Ordo CLI validates the package
  → companion utilities help inspect and review the result
```

## Where APF lives

```text
packages/ordo_applied_project_factory/
```

Important files:

```text
packages/ordo_applied_project_factory/README.md
packages/ordo_applied_project_factory/START_HERE_RUNTIME_MODE.md
packages/ordo_applied_project_factory/source/program.ordo.yaml
packages/ordo_applied_project_factory/compiled/program.ir.json
packages/ordo_applied_project_factory/docs/LANGUAGE_MODEL_IMPROVEMENTS_PACKAGE.md
packages/ordo_applied_project_factory/output_templates/
```

## How APF differs from companion utilities

| Layer | Purpose | Example | Can decide runtime correctness? |
|---|---|---|---|
| Ordo runtime / CLI | deterministic runtime, compile/lint/test, session trace | `python -m cli.ordo.cli compile ...` | yes, for technical checks |
| Standard applied module | reusable process/playbook shipped with language package | APF | no by itself; it is a process package |
| Companion utility | read-only/review artifacts | Visual Graph, PathWalk | no |

## Recommended APF review workflow

```text
APF source/program.ordo.yaml
  → Ordo CLI lint / compile / test
  → Visual Graph Generator: structure/context graph
  → PathWalk real-module-graph: source-level graph summary
  → PathWalk real-module-paths: terminal path enumeration
  → PathWalk clean/noise cases: artifact-only review material
  → PathWalk review cards: human QA/developer cards
```

This workflow helps reviewers understand APF. It does not mean the visual graph or review cards are the source of truth. The source YAML and compiled JSON IR remain authoritative for runtime structure.

## APF authoring modes

APF currently exposes four top-level authoring/correction modes:

```text
1. Доменна модель + дерево рішень
2. Ручне дерево рішень
3. Вільний діалог
4. Коригування існуючого процесу
```

Mode 4 is the existing-process improvement branch added in APF `v0.1.0-alpha.14`. Its valid baselines are a full workspace/dev package archive or a self-contained `source/program.ordo.yaml`.

## Validation discipline

APF documentation distinguishes several statuses that must not be collapsed:

```text
YAML parse passed
≠ Ordo lint passed
≠ compile / refresh IR passed
≠ human process review closed
≠ full validation passed
≠ handoff ready
```

M62.2 keeps APF at the imported alpha.14 state: technical minimal validation is available; human review closure and full validation remain module-level future work.

## Non-scope for M62.2

M62.2 does not perform:

```text
APF branch 1/2 rewrite
terminal output binding patch
progressive tree authoring patch
formal IR/opcode additions
runtime execution of generated testcases
scoring / calibration
watchdog/process-boundary hardening
```

## Next planned step

M62.3 should classify APF language-pattern candidates into:

```text
documentation-only pattern
APF-level reusable subflow
schema/state convention
compiler/lint candidate
future IR/runtime construct
```

No APF rewrite should begin until that classification is explicit.

## APF-specific PathWalk note

The full companion route (`graph → paths → clean/noise cases → review cards`) is the stable route for source-level packages whose terminal paths can be enumerated without unresolved cycles.

For the imported APF `v0.1.0-alpha.14` package specifically:

```text
Visual Graph Mermaid/SVG smoke: verified
PathWalk real-module-graph smoke: verified
PathWalk real-module-paths: blocked by cycle edges in current APF authoring loop
PathWalk clean/noise/review-card generation for APF itself: not used as M62.2 gate
```

This is expected for M62.2 because APF is a self-hosted authoring process with review loops. Cycle-aware terminal path handling or APF-specific graph adaptation belongs to a later APF adaptation milestone, not this documentation milestone.
