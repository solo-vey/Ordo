# M63.10 / APF RC5 — Program-Level Contract Review

## Status

```text
version: 0.1.0-rc.5-program-contract
patch: FUTURE-PROGRAM-CONTRACT-01
status: applied
blocking_issues: 0
```

## What changed

APF now has a mandatory program-level contract stage before compile/runtime/package gates:

```text
PROGRAM_LEVEL_CONTRACT_REVIEW
→ PROGRAM_LEVEL_CONTRACT_APPROVAL_GATE
```

The stage forces the AI to show the analyst a human-readable summary of top-level execution policy before the final archive can be assembled.

## Covered areas

```text
PROGRAM.DEF / top-level metadata
INTERACTION.MODEL
PROCESS_RAIL.DEF / process_rail
CONVERSATION.SEMANTICS
HYBRID_EXECUTION.MODEL
deterministic validation requirements
human review and approval points
START_PROMPT / README startup behavior
```

## Gate result

`PROGRAM_LEVEL_CONTRACT_APPROVAL_GATE` is passed for the APF rc.5 baseline.
