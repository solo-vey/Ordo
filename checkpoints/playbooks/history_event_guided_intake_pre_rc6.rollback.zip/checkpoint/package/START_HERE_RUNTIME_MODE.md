# START HERE — Ordo Runtime Mode

This file is the complete Runtime Mode instruction for this Ordo subject package.
The short prompt must only tell the AI/runner to read this file and start the runtime loading protocol.




## M66.1 startup profile note

This package declares `startup_package_profile` in `source/program.ordo.yaml`. The default startup mode is `analyst_quick_start`, whose entry file is `prompts/hp.package.quick_start.v1.md`. Full Runtime Mode still uses this file plus `START_PROMPT_RUNTIME_MODE.md` and the embedded CLI protocol. Startup profile metadata does not override Runtime Mode hard rules, gates, state, CLI evidence, or approval.

## 0. IR ACCESS PROTOCOL — HARD RULE

`compiled/program.ir.json` and every file under `compiled/` are CLI-owned runtime internals.

The AI must not open, read, view, cat, parse, quote, summarize, or use `compiled/*` directly for runtime decisions. The only legal Runtime Mode source is the output of `cli_embedded/ordo` commands: `runtime-entry`, `next-step`, `next-step --format ordo-code`, `render-runtime-view`, `verify-targets`, `check-gate`, `validate-state`, `intake --submit`, and `verify-session`.

M60.3 target rule: JSON IR decides; Ordo-code explains; session-trace proves. Runtime packages declare `runtime_view=json|ordo-code|json,ordo-code` in `ordo.runtime.json`; `next-step --format auto` follows that declaration. `compiled/program.ir.json` remains canonical. `compiled/program.ordo.view` is an AI-facing projection served only by CLI, and `runtime/session.ordo.trace` is an append-only proof program written only by CLI during `intake --submit`.

If this rule is violated, the session status becomes `DETERMINISM_VIOLATED`; every generated artifact must receive `DETERMINISM_VIOLATED` as its first line; the only recovery is a full restart of guided intake through the CLI.

Every user-facing runtime question must include the report path and first 12 characters of the SHA-256 digest from the CLI report that supplied the question. A question without `(report path + digest)` is a visible protocol violation.

If the embedded CLI cannot run, do not read IR as a fallback. Apply hard-stop fallback mode instead.

## Runtime loading protocol

1. Read `START_HERE_RUNTIME_MODE.md`.
2. Read `ordo.yml` as the package manifest / entrypoint.
3. Resolve the editable source program declared in `ordo.yml`, normally `source/program.ordo.yaml` in dev packages.
4. Resolve the compiled IR declared in `ordo.yml`, normally `compiled/program.ir.json`.
5. Locate the package-owned runtime CLI at `cli_embedded/ordo` when running a runtime package.
6. Check whether compiled IR exists and is fresh relative to source YAML when source YAML is present.
7. If IR is missing or stale and CLI is available, run the CLI command that compiles or reports the runtime state before guided execution.
8. If `cli_embedded/ordo` or another approved Ordo CLI cannot run, HARD-STOP. Do not continue silently.
9. Load compiled IR as the runtime source for guided execution only through CLI helper outputs.
10. Initialize or load `run_state.json` / report-embedded state.
11. Use `runtime-entry`, `next-step`, `check-gate`, and `validate-state` from IR + state. Do not invent next steps when a current IR exists.

## Source of truth model

```text
ordo.yml = package manifest / entrypoint
source/program.ordo.yaml = editable source of truth in dev profile
compiled/program.ir.json = runtime source for guided execution
run_state.json = current execution state
generated artifacts = rendered output
```

`source/program.ordo.yaml` is used for editing, explanation, and diagnostics in dev packages. If `compiled/program.ir.json` is current, guided question order comes from CLI helper output over the IR, not from memory and not from free reading of YAML.

## No memory mode

Do not conduct guided intake “from memory”, from old conversation context, or from general package instructions when a current compiled IR exists. Use `cli_embedded/ordo runtime-entry` or `cli_embedded/ordo next-step` before the first guided question.

## CLI pipeline

Use the real CLI syntax exposed by `cli_embedded/ordo --help` or `ordo --help`. Standard runtime pipeline:

```bash
cli_embedded/ordo runtime-status <package>
cli_embedded/ordo runtime-entry <package>
cli_embedded/ordo next-step <package> --state run_state.json
cli_embedded/ordo intake <package> --submit <NODE_ID> --answer "<answer>" --state run_state.json
cli_embedded/ordo check-gate <package> <GATE_ID> --state run_state.json
cli_embedded/ordo validate-state <package> --state run_state.json
cli_embedded/ordo intake <package> --answers <answers-file> --non-interactive
cli_embedded/ordo generate-output <package> --out <output-dir>
cli_embedded/ordo validate-output <package>
cli_embedded/ordo validate-artifacts <package> --artifacts <output-dir>
cli_embedded/ordo consistency <package> --artifacts <output-dir>
cli_embedded/ordo go-no-go <package>
cli_embedded/ordo validate-cli-status <report.json>
cli_embedded/ordo verify-session <package>
```

In dev workspaces the full `ordo` CLI may also run `lint`, `compile`, `test`, `coverage`, `package`, and other authoring commands. Runtime packages expose only runtime commands through `cli_embedded/ordo`.

## CLI truthfulness rule

Allowed statuses:

```text
CLI status: executed_cli_passed
CLI status: executed_cli_failed
CLI status: logical_self_check_only
CLI status: not_run_cli_unavailable
CLI status: not_run_user_skipped
```

Never write `CLI validation passed` unless CLI commands actually ran and the report contains evidence. Record command evidence in `reports/CLI_VALIDATION_SUMMARY.md` or a JSON validation report. A status without file evidence is not proof.

## Fallback mode — hard-stop

Hard-stop fallback mode is mandatory when the embedded CLI cannot run.

If `cli_embedded/ordo` or an approved Ordo CLI is unavailable, do not continue as if Runtime Mode is enforced. Stop and tell the user exactly:

```text
This environment cannot execute the embedded Ordo CLI. Ordo determinism guarantees for this session are NOT ENFORCED. Continuing is possible only in nondeterministic fallback mode, and every generated document must be marked DETERMINISM_NOT_ENFORCED.
```

Continue only after explicit user approval. If the user approves fallback, use `CLI status: not_run_cli_unavailable` or `CLI status: logical_self_check_only`, and insert `DETERMINISM_NOT_ENFORCED` into every generated artifact, not only into the chat.


## M59.2 incremental intake evidence discipline

Runtime guided intake must advance through CLI evidence, not through direct reading of `compiled/program.ir.json` or model memory. For each user answer, use exactly one incremental submit command:

```bash
cli_embedded/ordo intake <package> --submit <NODE_ID> --answer "<answer>" --state run_state.json
```

The command writes:

```text
reports/intake_submit_report.json
runtime/evidence/<RUN_ID>_<STEP>_<NODE_ID>_evidence.json
runtime/state_snapshots/<RUN_ID>_<STEP>_after_<NODE_ID>.json
```

Before asking the next question, the AI must show the evidence report path and SHA-256 digest emitted by the CLI. `next-step`, `check-gate`, and `validate-state` reports include their own digest and remain the only legal runtime source for next-step/gate/state decisions. Direct IR reading is prohibited in Runtime Mode. Diagnostics must also come through CLI helper reports, not through raw `compiled/*` access.


## M59.3 tamper-evident session discipline

Every incremental submit and non-interactive guided intake step writes a hash-chain snapshot under:

```text
runtime/state_snapshots/SESSION-<SEQ>_<NODE>.json
```

Each snapshot records `seq`, `node`, `answer_digest`, `prev_snapshot_hash`, `ir_hash`, `cli_version`, `timestamp_utc`, and its own `snapshot_hash`. The chain must start at `SESSION-000_000_initial.json` and continue without gaps.

Before final draft approval or analyst approval, the AI must ask the user to run exactly one verification command:

```bash
cli_embedded/ordo verify-session <package>
```

The gate is not passed until the user pastes the terminal line verbatim, for example:

```text
session-chain: intact
```

If the line is `session-chain: broken at seq N` or `session-chain: CANARY LEAK — raw IR was read`, stop and mark the session invalid.

The compiled IR contains a canary node that is never returned by the CLI. If the canary string appears in runtime-visible outputs, `verify-session` reports `CANARY LEAK`.

## Gate discipline

Do not skip required gates. Do not advance to draft output unless `validate-state` passes. Do not create a final package unless rendered output validation, artifact validation, consistency, and go/no-go are complete.

## Artifact validation discipline

`compile` is not final package validation. Generated artifacts must be checked with `validate-output`, `validate-artifacts`, `consistency`, and `go-no-go`. Confirmed contracts must appear in the required artifacts and must not disagree across outputs.

## Package workspace rule

Treat the package as one loaded runtime workspace, not as a fresh unknown zip on every step:

```text
loaded_manifest
loaded_source
loaded_ir
run_state
generated_outputs
reports
```

If the package source changes, re-run compile or mark IR stale. If the package is reloaded, reset or migrate state explicitly.

## State handling rule

Preserve `run_state.json` / report state between user answers. After each user answer, update state, call the relevant helper, and then ask only the next runtime question.

## Runtime checkpoint discipline

Runtime Mode follows strict checkpoint discipline:

```text
one node at a time
one contract at a time
one decision at a time
earliest incomplete node wins
no forward movement while mandatory checkpoint gaps remain
```

Every run state must carry or be enrichable with:

```json
{
  "current_node": "",
  "last_closed_node": "",
  "earliest_incomplete_node": "",
  "checkpoint_table": {},
  "forward_allowed": false,
  "open_required_fields": [],
  "node_merge_attempt_detected": false
}
```

If a gap is discovered, stop forward progress, return to the earliest incomplete node, ask exactly one focused question, and continue only after that node closes. Do not merge multiple runtime nodes unless the package explicitly declares `allow_batch_confirmation: true`.

## One question protocol

After each user answer, respond with exactly this short protocol and one focused question unless the current node explicitly allows batch confirmation:

```text
Крок: <runtime node/gate>
Дія: <CLI/helper/action actually used>
Результат: <passed/blocked/next>
Звіт: <report path>
Digest: <first 12 chars of SHA-256>
Рішення: <ask next runtime question / clarify / stop>
One question: <single focused runtime question>
```

## M65.2 Prompt Registry note

This package contains prompt helper files under `prompts/` and a package-local `PROMPT_MANIFEST.json`.

Use `prompts/hp.package.quick_start.v1.md` only as a tiny startup convenience. It does not weaken this Runtime Mode file, the CLI evidence protocol, session verification, gates, state rules, or explicit approval.

Node helper prompts may explain or clarify a step, but next-step selection and state transitions must still come from approved runtime evidence.

## M71.4 local prompt application and trace-evidence discipline

When the current CLI-served node, gate, or artifact contract contains `prompt_refs`, apply them only after the executable current step has been selected by CLI/JSON IR and before composing the local question, clarification, confirmation, gate-failure explanation, or artifact output named by `use`.

Application order is deterministic:

1. CLI/JSON IR selects the current executable step;
2. collect only that step's `prompt_refs`;
3. group by the controlled `use` phase;
4. preserve the list order from the executable model for refs in the same phase;
5. resolve each `prompt_id` through `PROMPT_MANIFEST.json`;
6. verify the referenced file and SHA-256 before use;
7. apply the prompt as local guidance only;
8. compose the user-visible response without exposing prompt text;
9. record prompt application evidence when the runtime surface supports it.

The recordable evidence payload is:

```json
{
  "prompt_refs_applied": [
    {
      "prompt_id": "hp.normalization.value_comparison.v1",
      "use": "before_question",
      "sha256": "<manifest checksum>",
      "ordinal": 1
    }
  ]
}
```

Evidence must not contain the prompt body, hidden reasoning, or invented navigation. A prompt may shape only local wording and checks inside the already selected step. CLI/JSON IR remains authoritative for `current_node`, `next`, state mutation, gates, approval, and output eligibility.

If a ref does not resolve, its checksum does not match, its phase is invalid, or the prompt attempts to change navigation, stop local prompt application and report a prompt-registry validation failure. Do not silently continue with guessed guidance.
