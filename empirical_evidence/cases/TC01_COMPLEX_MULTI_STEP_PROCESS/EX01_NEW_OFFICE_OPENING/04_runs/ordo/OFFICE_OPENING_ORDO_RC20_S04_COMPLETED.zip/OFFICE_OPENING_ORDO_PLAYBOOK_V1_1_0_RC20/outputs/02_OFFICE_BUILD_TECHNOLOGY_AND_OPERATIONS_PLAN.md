# Office Build, Technology & Operations Plan

**Company:** Northstar Analytics GmbH  
**Brand:** Northstar  
**Location:** Mogilska 35, 31-545 Kraków, Poland  
**Target opening:** 2027-03-15

## 1. Facility and fit-out plan

Usable area: **1 850 м²**. Technical readiness score: **82 зі 100**.

Fit-out scope: **Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні**.

Renovation budget: **740 000 EUR**. Fit-out deadline: **2027-02-12**.

Furniture standard: **Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце**.

## 2. Technology infrastructure

Network requirement: **Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання**.

A dedicated server room is required: **True**. It includes controlled access, monitoring and resilient power.

Data residency: **Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі**.

Technology owner: **Marek Zieliński, Regional IT Manager**.

## 3. Physical security and access

Security level: **Підвищений**.

Access-control model: **Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком**.

Accessibility standard: **Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця**.

## 4. Contractors and critical suppliers

General contractor: **BuildCore Polska Sp. z o.o.**.

Critical suppliers: **6**. Dependencies must be reviewed against schedule, budget and readiness.

## 5. People and operating model

Local hiring target: **65 нових працівників у перший рік**. Relocation target: **20 працівників із Німеччини, Чехії та України**.

HR owner: **Anna Kowalska, Head of People Poland**. IT owner: **Marek Zieliński, Regional IT Manager**. Facilities owner: **Katarzyna Nowak, Workplace Operations Lead**.

## 6. Delivery controls

- Fit-out complete by **2027-02-12**.
- Spend within **740 000 EUR**.
- Network, server-room and security controls ready before testing.
- Supplier dependencies reviewed regularly.
- Blocking defects routed to the responsible workstream.

Readiness test date: **None**.

## 7. Operational readiness summary

The plan is aligned with the corrected capacity and location assumptions, selected facility, approved fit-out, technology requirements, supplier dependencies and named operational owners.

Canonical readiness_test_date: 2027-02-22
