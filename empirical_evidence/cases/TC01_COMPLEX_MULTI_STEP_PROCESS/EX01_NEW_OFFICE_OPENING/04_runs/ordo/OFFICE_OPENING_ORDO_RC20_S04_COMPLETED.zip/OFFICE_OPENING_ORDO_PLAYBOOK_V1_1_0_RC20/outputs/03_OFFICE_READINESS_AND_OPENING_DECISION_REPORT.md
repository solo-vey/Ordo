# Office Readiness & Opening Decision Report

**Company:** Northstar Analytics GmbH  
**Brand:** Northstar  
**Office:** Mogilska 35, 31-545 Kraków, Poland  
**Target opening date:** 2027-03-15  
**Final decision:** **conditional open**

## 1. Executive readiness assessment

Business objective: **Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі**. Budget envelope: **2 400 000 EUR**. Technical readiness score: **82 зі 100**.

> **conditional open**

## 2. Facility and delivery readiness

Primary: **Mogilska 35, 31-545 Kraków, Poland**. Backup: **Pawia 23, 31-154 Kraków, Poland**.

Renovation budget: **740 000 EUR**. Fit-out deadline: **2027-02-12**. Contractor: **BuildCore Polska Sp. z o.o.**. Critical suppliers: **6**.

Readiness test: **2027-02-22**.

## 3. Technology and security readiness

Network: **Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання**. Server room required: **True**.

Security level: **Підвищений**. Access control: **Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком**.

IT owner: **Marek Zieliński, Regional IT Manager**. Facilities owner: **Katarzyna Nowak, Workplace Operations Lead**.

## 4. People and operating readiness

Local hiring: **65 нових працівників у перший рік**. Relocation: **20 працівників із Німеччини, Чехії та України**. HR owner: **Anna Kowalska, Head of People Poland**. Visa support remains required.

## 5. Pilot day result

Pilot day included **24 participants** and confirmed that core workplace, technology, security and support functions are usable subject to the conditions below.

## 6. Opening conditions and blockers

| Condition | Responsible owner | Deadline | Required evidence | Status |
|---|---|---|---|---|
| Fire-safety certification | Katarzyna Nowak, Workplace Operations Lead | Before 2027-03-15 | Final certification and archived evidence | Open |
| Backup internet connection | Marek Zieliński, Regional IT Manager | Before 2027-03-15 | Activation and failover test evidence | Open |
| Accessibility observations | Katarzyna Nowak, Workplace Operations Lead | Before full-readiness declaration | Remediation and accessibility recheck | Open |
| Relocation visas | Anna Kowalska, Head of People Poland | Before affected employees start work | Completed visa documentation | Open |

## 7. Decision

> **conditional open**

The decision reflects readiness testing, pilot findings, supplier dependencies, corrected space/location assumptions and open conditions.

## 8. Final package status

This report completes `OFFICE_OPENING_PACKAGE` together with D1 and D2.

## Readiness evidence notes

Facility evidence includes fit-out completion records, contractor handover documentation and supplier acceptance records.

Technology evidence includes primary and backup connectivity tests, wireless coverage results, server-room controls and access-log verification.

People evidence includes onboarding readiness, relocation case tracking, local employment documentation and named operational ownership.

The conditional-open decision remains bounded by the four explicit conditions in this report.
