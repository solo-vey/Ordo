# Office Opening Business & Location Brief

**Company:** Northstar Analytics GmbH  
**Brand:** Northstar  
**Industry:** B2B SaaS / аналітика ланцюгів постачання  
**Headquarters:** Німеччина  
**Target office:** Краків, Польща  
**Target opening date:** 2027-03-15

## 1. Business context and objective

Northstar Analytics GmbH operates under the **Northstar** brand in **B2B SaaS / аналітика ланцюгів постачання**. Headquarters: **Німеччина**; current workforce: **420 employees**.

Business objective: **Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі**. Initial budget envelope: **2 400 000 EUR**.

Year-one headcount is **85** and year-three headcount is **180**.

## 2. Workplace requirements

Work model: **hybrid**. Capacity: **96 workstations** and **10 meeting rooms**.

Special spaces: **Серверна кімната, чотири phone-booth зони, training room на 24 особи та більша зона спільної роботи**.

The corrected scenario assumption supersedes the earlier 110-workstation/8-room concept while preserving the restore audit trail.

## 3. Location search criteria

Priority: **Транспортна доступність, гнучке планування та нижча повна вартість оренди**. Commute target: **40 хвилин для 80% працівників**.

The search evaluates **4 candidate locations**. Preferred lease term: **48 months**. Maximum monthly rent: **54 000 EUR без комунальних витрат**.

## 4. Legal and operating model

A local legal entity is required. Tax model: **Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією**.

Employment model: **Пряме локальне працевлаштування через польську юридичну особу**.

Regulatory constraints: **Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці**.

Visa support is required for the relocation population.

## 5. Data residency and compliance

**Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі**.

This is a binding technology and compliance constraint.

## 6. Accessibility requirements

**Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця**.

Accessibility remains a mandatory location and fit-out criterion.

## 7. Selected location

Primary: **Mogilska 35, 31-545 Kraków, Poland**.

Backup: **Pawia 23, 31-154 Kraków, Poland**.

Usable area: **1 850 м²**. Technical readiness score: **82 зі 100**.

## 8. Business and location conclusion

The selected location supports **Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі** and the corrected space and lease assumptions. The programme may proceed subject to build, technology, security, people and readiness controls.
