# Collected Attributes

| ID | Attribute | Value | Status | Source |
|---|---|---|---|---|
| P01 | company_legal_name | Northstar Analytics GmbH | confirmed | runtime/run_state.json |
| P02 | company_brand_name | Northstar | confirmed | runtime/run_state.json |
| P03 | company_industry | B2B SaaS / аналітика ланцюгів постачання | confirmed | runtime/run_state.json |
| P04 | company_headquarters_country | Німеччина | confirmed | runtime/run_state.json |
| P05 | company_size_employees | 420 | confirmed | runtime/run_state.json |
| P06 | office_business_goal | Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі | confirmed | runtime/run_state.json |
| P07 | target_country | Польща | confirmed | runtime/run_state.json |
| P08 | target_city | Краків | confirmed | runtime/run_state.json |
| P09 | target_opening_date | 2027-03-15 | confirmed | runtime/run_state.json |
| P10 | initial_budget | 2 400 000 EUR | confirmed | runtime/run_state.json |
| P11 | planned_headcount_year1 | 85 | confirmed | runtime/run_state.json |
| P12 | planned_headcount_year3 | 180 | confirmed | runtime/run_state.json |
| P13 | work_model | hybrid | confirmed | runtime/run_state.json |
| P14 | required_workspace_count | 96 | confirmed | runtime/run_state.json |
| P15 | required_meeting_rooms | 10 | confirmed | runtime/run_state.json |
| P16 | special_space_requirements | Серверна кімната, чотири phone-booth зони, training room на 24 особи та більша зона спільної роботи | confirmed | runtime/run_state.json |
| P17 | location_priority | Транспортна доступність, гнучке планування та нижча повна вартість оренди | confirmed | runtime/run_state.json |
| P18 | maximum_commute_target | 40 хвилин для 80% працівників | confirmed | runtime/run_state.json |
| P19 | candidate_location_count | 4 | confirmed | runtime/run_state.json |
| P20 | preferred_lease_term_months | 48 | confirmed | runtime/run_state.json |
| P21 | maximum_monthly_rent | 54 000 EUR без комунальних витрат | confirmed | runtime/run_state.json |
| P22 | legal_entity_required | True | confirmed | runtime/run_state.json |
| P23 | regulatory_constraints | Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці | confirmed | runtime/run_state.json |
| P24 | tax_model | Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією | confirmed | runtime/run_state.json |
| P25 | employment_model | Пряме локальне працевлаштування через польську юридичну особу | confirmed | runtime/run_state.json |
| P26 | visa_support_required | True | confirmed | runtime/run_state.json |
| P27 | data_residency_requirement | Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі | confirmed | runtime/run_state.json |
| P28 | accessibility_standard | Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця | confirmed | runtime/run_state.json |
| P29 | selected_location_address | Mogilska 35, 31-545 Kraków, Poland | confirmed | runtime/run_state.json |
| P30 | backup_location_address | Pawia 23, 31-154 Kraków, Poland | confirmed | runtime/run_state.json |
| P31 | usable_area_sqm | 1 850 м² | confirmed | runtime/run_state.json |
| P32 | technical_readiness_score | 82 зі 100 | confirmed | runtime/run_state.json |
| P33 | renovation_scope | Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні | confirmed | runtime/run_state.json |
| P34 | renovation_budget | 740 000 EUR | confirmed | runtime/run_state.json |
| P35 | fitout_deadline | 2027-02-12 | confirmed | runtime/run_state.json |
| P36 | network_capacity_requirement | Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання | confirmed | runtime/run_state.json |
| P37 | server_room_required | True | confirmed | runtime/run_state.json |
| P38 | physical_security_level | Підвищений | confirmed | runtime/run_state.json |
| P39 | access_control_model | Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком | confirmed | runtime/run_state.json |
| P40 | furniture_standard | Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце | confirmed | runtime/run_state.json |
| P41 | primary_general_contractor | BuildCore Polska Sp. z o.o. | confirmed | runtime/run_state.json |
| P42 | critical_supplier_count | 6 | confirmed | runtime/run_state.json |
| P43 | local_hiring_target | 65 нових працівників у перший рік | confirmed | runtime/run_state.json |
| P44 | relocation_target | 20 працівників із Німеччини, Чехії та України | confirmed | runtime/run_state.json |
| P45 | local_hr_owner | Anna Kowalska, Head of People Poland | confirmed | runtime/run_state.json |
| P46 | local_it_owner | Marek Zieliński, Regional IT Manager | confirmed | runtime/run_state.json |
| P47 | local_facilities_owner | Katarzyna Nowak, Workplace Operations Lead | confirmed | runtime/run_state.json |
| P48 | readiness_test_date | 2027-02-22 | confirmed | runtime/run_state.json |
| P49 | pilot_day_participants | 24 | confirmed | runtime/run_state.json |
| P50 | final_opening_decision | conditional open | confirmed | runtime/run_state.json |
