# Result Summary

- `run_id`: `RUN_05`
- `run_status`: `ended`
- `terminal_identifier`: `END_RUN_AT_N02_BLOCKED`
- `current_step`: `N02_GEOGRAPHY_AND_TARGET_DATE`
- `received_event_count`: `2`
- `accepted_event_count`: `1`
- `blocked_event_count`: `1`
- Driver control: `CONTROL: END_RUN`

## Observed result

`E01` було прийнято, тому `N01_BUSINESS_INITIATION` завершено. `E02` було заблоковано, оскільки `target_city` мало значення «Не знаю», а `target_opening_date` було `null`. Канонічні бізнес-дані не змінено, процес не просунуто далі `N02_GEOGRAPHY_AND_TARGET_DATE`.

Жоден із трьох бізнес-документів не створено, бо необхідні вихідні кроки не були досягнуті. Відсутні значення не вигадувалися.
