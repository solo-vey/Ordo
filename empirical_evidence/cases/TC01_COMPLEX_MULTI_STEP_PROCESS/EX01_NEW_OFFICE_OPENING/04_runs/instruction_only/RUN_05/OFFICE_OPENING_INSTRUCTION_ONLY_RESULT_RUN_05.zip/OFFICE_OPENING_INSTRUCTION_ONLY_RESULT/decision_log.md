# Decision Log

- `E01`: `accepted`; `N01_BUSINESS_INITIATION` завершено, перехід до `N02_GEOGRAPHY_AND_TARGET_DATE`.
- `E02`: `blocked`; `target_city` невизначене, `target_opening_date` відсутня; активний крок залишається `N02_GEOGRAPHY_AND_TARGET_DATE`.
- `CONTROL: END_RUN`: виконання завершено у фактичному стані `END_RUN_AT_N02_BLOCKED`; подальше просування та генерацію бізнес-документів не виконано.
