# Office Readiness and Opening Decision Report

## 1. Executive readiness assessment

The final opening decision is **conditional open**.

The target office is located at Mogilska 35, 31-545 Kraków, Poland and is planned to open on 2027-03-15.

The final package is ready: true.

## 2. Facility and delivery readiness

The readiness test was performed on 2027-02-22.

The readiness status was passed.

Location search, screening, lease negotiation, legal-entity registration, fit-out planning, and facilities ownership were completed and documented.

Facility readiness remains subject to closure evidence for fire safety and accessibility observations.

## 3. Technology and security readiness

The technology design requires Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання.

Physical security is set at Підвищений with Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком.

Final technology readiness remains subject to commissioning evidence for the backup internet connection.

## 4. People and operating readiness

The first-year hiring plan is 65 нових працівників у перший рік.

The relocation plan is 20 працівників із Німеччини, Чехії та України.

HR ownership is assigned to Anna Kowalska, Head of People Poland.

IT ownership is assigned to Marek Zieliński, Regional IT Manager.

Facilities ownership is assigned to Katarzyna Nowak, Workplace Operations Lead.

Relocating employees may work onsite only after required visa and work-authorization evidence is complete.

## 5. Pilot day result

The pilot day included 24 participants.

Pilot completion status is true.

The pilot supports operational confidence but does not waive unresolved mandatory opening conditions.

## 6. Opening conditions and blockers

| Condition | Responsible owner | Deadline | Required evidence | Status |
|---|---|---|---|---|
| Fire-safety certification | Katarzyna Nowak, Workplace Operations Lead | Before 2027-03-15 | Final certificate and documented authority or landlord acceptance | Open |
| Backup internet connection | Marek Zieliński, Regional IT Manager | Before 2027-03-15 | Independent-line commissioning and successful failover test | Open |
| Accessibility observations | Katarzyna Nowak, Workplace Operations Lead | Before 2027-03-15 | Closed inspection observations, photographs, and signed acceptance | Open |
| Relocation visas | Anna Kowalska, Head of People Poland | Before each affected onsite start | Valid visa and work-authorization evidence | Open |

All four items are blocking conditions for unrestricted opening.

## 7. Decision

Proceed under a controlled **conditional open** decision.

Occupancy is authorized only when each condition is closed with documented evidence and no new critical legal, safety, technology, or people blocker is identified.

Any unresolved critical condition requires executive escalation and a renewed go/no-go decision.

## 8. Final package status

Document 1, Document 2, and Document 3 are generated and marked valid by the delivered events.

The execution evidence, state snapshots, collected attributes, dialogue log, model identity, and self-validation report are included in the result package.

The package records observed execution facts and self-checks without claiming evaluator pass or deterministic runtime validation.
