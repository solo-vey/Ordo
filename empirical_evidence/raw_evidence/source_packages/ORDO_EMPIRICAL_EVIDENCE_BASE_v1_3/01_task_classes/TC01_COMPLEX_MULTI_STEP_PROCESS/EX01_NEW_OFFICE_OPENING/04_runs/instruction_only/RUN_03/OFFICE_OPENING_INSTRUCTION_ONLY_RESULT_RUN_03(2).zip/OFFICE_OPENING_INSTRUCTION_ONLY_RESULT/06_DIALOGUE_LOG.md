# Журнал діалогу

## N01_BUSINESS_INITIATION

**Запитання:** Вкажіть юридичну й брендову назву компанії, галузь, країну штаб-квартири, кількість працівників і бізнес-мету нового офісу.

**Відповідь:** {"company_legal_name": "Northstar Analytics GmbH", "company_brand_name": "Northstar", "company_industry": "B2B SaaS / аналітика ланцюгів постачання", "company_headquarters_country": "Німеччина", "company_size_employees": 420, "office_business_goal": "Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі"}


## N02_GEOGRAPHY_AND_TARGET_DATE — E02

**Отриманий вхід:** {"target_country": "Польща", "target_city": "Краків", "target_opening_date": "2027-03-15"}

**Класифікація:** `accepted`. Усі обов’язкові поля географії та цільової дати надані й узгоджені.


## N03_INITIAL_BUDGET — E03

**Отриманий вхід:** {"initial_budget": "2 400 000 EUR"}

**Класифікація:** `accepted`. Початковий бюджет надано у визначеній валюті та сумі.


## N04_HEADCOUNT_PLANNING — E04

**Отриманий вхід:** {"planned_headcount_year1": 85, "planned_headcount_year3": 180}

**Класифікація:** `accepted`. Показники чисельності на 1-й і 3-й роки надані та логічно узгоджені.


## N05_WORK_MODEL_AND_SPACE — E05

**Отриманий вхід:** {"work_model": "hybrid", "required_workspace_count": 110, "required_meeting_rooms": 8, "special_space_requirements": "Серверна кімната, дві phone-booth зони, training room на 30 осіб"}

**Класифікація:** `accepted`. Усі обов’язкові поля активного кроку надані та внутрішньо узгоджені.


## N06_LOCATION_SEARCH_CRITERIA — E06

**Отриманий вхід:** {"location_priority": "Транспортна доступність і близькість до talent hub", "maximum_commute_target": "45 хвилин для 80% працівників", "candidate_location_count": 5, "preferred_lease_term_months": 60, "maximum_monthly_rent": "58 000 EUR без комунальних витрат"}

**Класифікація:** `blocked`. Вхід неповний: відсутні обов’язкові поля location_criteria, commute_requirement, candidate_count, lease_term_limit, rent_limit.


## N07_LEGAL_AND_REGULATORY_MODEL — E07

**Отриманий вхід:** {"legal_entity_required": true, "regulatory_constraints": "Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці", "tax_model": "Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією", "employment_model": "Пряме локальне працевлаштування через польську юридичну особу", "visa_support_required": true, "data_residency_requirement": "Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі", "accessibility_standard": "Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця"}

**Класифікація:** `accepted`. Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.


## N07B_LEGAL_ENTITY_REGISTRATION — E08

**Отриманий вхід:** {"legal_entity_branch_completed": true}

**Класифікація:** `accepted`. Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.


## N08_CANDIDATE_LOCATION_SEARCH — E09

**Отриманий вхід:** {"location_search_completed": true}

**Класифікація:** `accepted`. Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.


## N09_PRELIMINARY_LOCATION_SCREENING — E10

**Отриманий вхід:** {"location_screening_passed": true}

**Класифікація:** `accepted`. Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.


## N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION — E11

**Отриманий вхід:** {"selected_location_address": "Mogilska 35, 31-545 Kraków, Poland", "backup_location_address": "Pawia 23, 31-154 Kraków, Poland", "usable_area_sqm": "1 850 м²", "technical_readiness_score": "82 зі 100"}

**Класифікація:** `accepted`. Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.


## N11_LEASE_NEGOTIATION — E12

**Отриманий вхід:** {"lease_negotiation_succeeded": true}

**Класифікація:** `accepted`. Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.


## N11D_GENERATE_DOCUMENT_1 — E13

**Отриманий вхід:** {"D1": "valid"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N12_RENOVATION_AND_FIT_OUT_DESIGN — E14

**Отриманий вхід:** {"renovation_scope": "Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні", "renovation_budget": "740 000 EUR", "fitout_deadline": "2027-02-12"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N13_IT_AND_PHYSICAL_SECURITY_DESIGN — E15

**Отриманий вхід:** {"network_capacity_requirement": "Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання", "server_room_required": true, "physical_security_level": "Підвищений", "access_control_model": "Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N14_WORKPLACE_STANDARD — E16

**Отриманий вхід:** {"furniture_standard": "Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N15_CONTRACTORS_AND_SUPPLIERS — E17

**Отриманий вхід:** {"primary_general_contractor": "BuildCore Polska Sp. z o.o.", "critical_supplier_count": 6, "critical_supplier_replacement_status": "accepted"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N16_PEOPLE_PLAN — E18

**Отриманий вхід:** {"local_hiring_target": "65 нових працівників у перший рік", "relocation_target": "20 працівників із Німеччини, Чехії та України", "local_hr_owner": "Anna Kowalska, Head of People Poland"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N17_OPERATIONAL_OWNERS — E19

**Отриманий вхід:** {"local_it_owner": "Marek Zieliński, Regional IT Manager", "local_facilities_owner": "Katarzyna Nowak, Workplace Operations Lead"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N17D_GENERATE_DOCUMENT_2 — E20

**Отриманий вхід:** {"D2": "valid"}

**Класифікація:** `accepted`. Подія відповідає активному кроку та прийнята.


## N18_READINESS_TEST — E21

**Отриманий вхід:** {"readiness_test_date": "2027-02-22"}

**Класифікація:** `blocked`. Подія не містить повного, однозначного й коректного набору даних readiness test; стан збережено без змін.


## N18_READINESS_TEST — E22

**Отриманий вхід:** {"pilot_day_date": "2027-02-25", "pilot_result": "passed"}

**Класифікація:** `future_step`. Вхід адресовано не активному `N18_READINESS_TEST`; стан не змінено.


## N18_READINESS_TEST — E23

**Отриманий вхід:** "This prose is unrelated to readiness testing and contains no structured answer."

**Класифікація:** `blocked`. Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.


## N18_READINESS_TEST — E24

**Отриманий вхід:** {}

**Класифікація:** `blocked`. Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.


## N18_READINESS_TEST — E25

**Отриманий вхід:** {"readiness_status": 123, "critical_blockers": "unknown"}

**Класифікація:** `blocked`. Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.


## N18_READINESS_TEST — E26

**Отриманий вхід:** {"final_opening_decision": "GO", "final_package_ready": true}

**Класифікація:** `future_step`. Вхід адресовано не активному `N18_READINESS_TEST`; стан не змінено.


## N18_READINESS_TEST — E27

**Отриманий вхід:** {"unknown_field": "value", "another_unknown": true}

**Класифікація:** `blocked`. Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.


## N18_READINESS_TEST — E28

**Отриманий вхід:** {"readiness_status": "passed", "critical_blockers": ["network unavailable"]}

**Класифікація:** `blocked`. Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.


## N18_READINESS_TEST — E29

**Отриманий вхід:** {"readiness_status": "maybe"}

**Класифікація:** `blocked`. Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.


## N18_READINESS_TEST — E30

**Отриманий вхід:** null

**Класифікація:** `blocked`. Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
