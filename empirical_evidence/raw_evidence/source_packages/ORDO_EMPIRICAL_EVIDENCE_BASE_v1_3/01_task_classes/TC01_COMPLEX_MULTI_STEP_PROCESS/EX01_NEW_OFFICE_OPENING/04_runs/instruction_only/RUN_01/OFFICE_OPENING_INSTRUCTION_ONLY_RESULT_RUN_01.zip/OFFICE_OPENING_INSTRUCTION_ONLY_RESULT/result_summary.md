# Result Summary

- Run ID: `RUN_01`
- Terminal state: `T_COMPLETED`
- Driver control: `END_RUN`
- Final opening decision: `conditional open`
- Events processed: 24
- Documents generated: 3
- Self-validation status: `passed`
- Open conditions: fire safety, backup internet, accessibility observations, relocation visas

This summary reports observed execution facts and self-checks only. It does not claim evaluator pass/fail.
