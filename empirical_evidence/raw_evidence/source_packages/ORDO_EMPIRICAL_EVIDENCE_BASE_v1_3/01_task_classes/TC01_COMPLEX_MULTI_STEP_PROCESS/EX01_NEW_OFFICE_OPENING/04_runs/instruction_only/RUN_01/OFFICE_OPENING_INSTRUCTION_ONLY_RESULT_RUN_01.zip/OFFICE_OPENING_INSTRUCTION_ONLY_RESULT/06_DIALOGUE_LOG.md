# Dialogue Log

## E01 — N01_BUSINESS_INITIATION (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть юридичну та брендовану назву компанії, галузь, країну штаб-квартири, чисельність працівників і бізнес-мету нового офісу.

**USER_SIMULATOR:** `{"company_legal_name": "Northstar Analytics GmbH", "company_brand_name": "Northstar", "company_industry": "B2B SaaS / аналітика ланцюгів постачання", "company_headquarters_country": "Німеччина", "company_size_employees": 420, "office_business_goal": "Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі"}`

**Classification:** `accepted`
**Result step:** `N02_GEOGRAPHY_AND_TARGET_DATE`

## E02 — N02_GEOGRAPHY_AND_TARGET_DATE (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть країну, місто та цільову дату відкриття офісу.

**USER_SIMULATOR:** `{"target_country": "Польща", "target_city": "Краків", "target_opening_date": "2027-03-15"}`

**Classification:** `accepted`
**Result step:** `N03_INITIAL_BUDGET`

## E03 — N03_INITIAL_BUDGET (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть початковий бюджет відкриття офісу.

**USER_SIMULATOR:** `{"initial_budget": "2 400 000 EUR"}`

**Classification:** `accepted`
**Result step:** `N04_HEADCOUNT_PLANNING`

## E04 — N04_HEADCOUNT_PLANNING (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть заплановану чисельність персоналу на 1-й і 3-й роки.

**USER_SIMULATOR:** `{"planned_headcount_year1": 85, "planned_headcount_year3": 180}`

**Classification:** `accepted`
**Result step:** `N05_WORK_MODEL_AND_SPACE`

## E05 — N05_WORK_MODEL_AND_SPACE (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть модель роботи, кількість робочих місць і переговорних кімнат та спеціальні вимоги до простору.

**USER_SIMULATOR:** `{"work_model": "hybrid", "required_workspace_count": 110, "required_meeting_rooms": 8, "special_space_requirements": "Серверна кімната, дві phone-booth зони, training room на 30 осіб"}`

**Classification:** `accepted`
**Result step:** `N06_LOCATION_SEARCH_CRITERIA`

## E06 — N06_LOCATION_SEARCH_CRITERIA (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть пріоритети локації, ціль часу поїздки, кількість кандидатів, бажаний строк оренди та максимальну місячну орендну плату.

**USER_SIMULATOR:** `{"location_priority": "Транспортна доступність і близькість до talent hub", "maximum_commute_target": "45 хвилин для 80% працівників", "candidate_location_count": 5, "preferred_lease_term_months": 60, "maximum_monthly_rent": "58 000 EUR без комунальних витрат"}`

**Classification:** `accepted`
**Result step:** `N07_LEGAL_AND_REGULATORY_MODEL`

## E07 — N07_LEGAL_AND_REGULATORY_MODEL (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть потребу в юридичній особі, регуляторні обмеження, податкову й трудову модель, потребу у візовій підтримці, вимоги до резидентності даних і доступності.

**USER_SIMULATOR:** `{"legal_entity_required": true, "regulatory_constraints": "Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці", "tax_model": "Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією", "employment_model": "Пряме локальне працевлаштування через польську юридичну особу", "visa_support_required": true, "data_residency_requirement": "Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі", "accessibility_standard": "Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця"}`

**Classification:** `accepted`
**Result step:** `N07B_LEGAL_ENTITY_REGISTRATION`

## E08 — N07B_LEGAL_ENTITY_REGISTRATION (occurrence 1)

**PROCESS_EXECUTOR:** Підтвердьте завершення реєстрації локальної юридичної особи.

**USER_SIMULATOR:** `{"legal_entity_branch_completed": true}`

**Classification:** `accepted`
**Result step:** `N08_CANDIDATE_LOCATION_SEARCH`

## E09 — N08_CANDIDATE_LOCATION_SEARCH (occurrence 1)

**PROCESS_EXECUTOR:** Підтвердьте завершення пошуку кандидатних локацій.

**USER_SIMULATOR:** `{"location_search_completed": true}`

**Classification:** `accepted`
**Result step:** `N09_PRELIMINARY_LOCATION_SCREENING`

## E10 — N09_PRELIMINARY_LOCATION_SCREENING (occurrence 1)

**PROCESS_EXECUTOR:** Підтвердьте результат попереднього відбору локацій.

**USER_SIMULATOR:** `{"location_screening_passed": true}`

**Classification:** `accepted`
**Result step:** `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`

## E11 — N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть основну й резервну локації, корисну площу та оцінку технічної готовності.

**USER_SIMULATOR:** `{"selected_location_address": "Mogilska 35, 31-545 Kraków, Poland", "backup_location_address": "Pawia 23, 31-154 Kraków, Poland", "usable_area_sqm": "1 850 м²", "technical_readiness_score": "82 зі 100"}`

**Classification:** `accepted`
**Result step:** `N11_LEASE_NEGOTIATION`

## E12 — N11_LEASE_NEGOTIATION (occurrence 1)

**PROCESS_EXECUTOR:** Підтвердьте результат переговорів щодо оренди.

**USER_SIMULATOR:** `{"lease_negotiation_succeeded": true}`

**Classification:** `accepted`
**Result step:** `N12_RENOVATION_AND_FIT_OUT_DESIGN`

## E13 — N11D_GENERATE_DOCUMENT_1 (occurrence 1)

**PROCESS_EXECUTOR:** Підтвердьте валідність Document 1.

**USER_SIMULATOR:** `{"D1": "valid"}`

**Classification:** `accepted`
**Result step:** `N12_RENOVATION_AND_FIT_OUT_DESIGN`

## E14 — N12_RENOVATION_AND_FIT_OUT_DESIGN (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть обсяг ремонтних робіт, бюджет і крайній строк fit-out.

**USER_SIMULATOR:** `{"renovation_scope": "Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні", "renovation_budget": "740 000 EUR", "fitout_deadline": "2027-02-12"}`

**Classification:** `accepted`
**Result step:** `N13_IT_AND_PHYSICAL_SECURITY_DESIGN`

## E15 — N13_IT_AND_PHYSICAL_SECURITY_DESIGN (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть вимоги до мережі, потребу в серверній, рівень фізичної безпеки та модель контролю доступу.

**USER_SIMULATOR:** `{"network_capacity_requirement": "Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання", "server_room_required": true, "physical_security_level": "Підвищений", "access_control_model": "Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком"}`

**Classification:** `accepted`
**Result step:** `N14_WORKPLACE_STANDARD`

## E16 — N14_WORKPLACE_STANDARD (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть стандарт меблів і оснащення робочого місця.

**USER_SIMULATOR:** `{"furniture_standard": "Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце"}`

**Classification:** `accepted`
**Result step:** `N15_CONTRACTORS_AND_SUPPLIERS`

## E17 — N15_CONTRACTORS_AND_SUPPLIERS (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть генерального підрядника, кількість критичних постачальників і статус їх заміни.

**USER_SIMULATOR:** `{"primary_general_contractor": "BuildCore Polska Sp. z o.o.", "critical_supplier_count": 6, "critical_supplier_replacement_status": "accepted"}`

**Classification:** `accepted`
**Result step:** `N16_PEOPLE_PLAN`

## E18 — N16_PEOPLE_PLAN (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть ціль локального найму, план релокації та відповідального HR-власника.

**USER_SIMULATOR:** `{"local_hiring_target": "65 нових працівників у перший рік", "relocation_target": "20 працівників із Німеччини, Чехії та України", "local_hr_owner": "Anna Kowalska, Head of People Poland"}`

**Classification:** `accepted`
**Result step:** `N17_OPERATIONAL_OWNERS`

## E19 — N17_OPERATIONAL_OWNERS (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть локальних відповідальних за IT та facilities.

**USER_SIMULATOR:** `{"local_it_owner": "Marek Zieliński, Regional IT Manager", "local_facilities_owner": "Katarzyna Nowak, Workplace Operations Lead"}`

**Classification:** `accepted`
**Result step:** `N17D_GENERATE_DOCUMENT_2`

## E20 — N17D_GENERATE_DOCUMENT_2 (occurrence 1)

**PROCESS_EXECUTOR:** Підтвердьте валідність Document 2.

**USER_SIMULATOR:** `{"D2": "valid"}`

**Classification:** `accepted`
**Result step:** `N18_READINESS_TEST`

## E21 — N18_READINESS_TEST (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть дату та результат тесту готовності.

**USER_SIMULATOR:** `{"readiness_test_date": "2027-02-22", "readiness_status": "passed"}`

**Classification:** `accepted`
**Result step:** `N19_PILOT_DAY`

## E22 — N19_PILOT_DAY (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть кількість учасників пілотного дня та підтвердьте його завершення.

**USER_SIMULATOR:** `{"pilot_day_participants": 24, "pilot_completed": true}`

**Classification:** `accepted`
**Result step:** `N20_FINAL_DECISION_AND_PACKAGE`

## E23 — N20_FINAL_DECISION_AND_PACKAGE (occurrence 1)

**PROCESS_EXECUTOR:** Вкажіть фінальне рішення щодо відкриття, готовність пакета та обов’язкові умови відкриття.

**USER_SIMULATOR:** `{"final_opening_decision": "conditional open", "final_package_ready": true, "opening_condition_fire_safety": "Fire-safety certification", "opening_condition_backup_internet": "Backup internet connection", "opening_condition_accessibility": "Accessibility observations", "opening_condition_relocation_visas": "Relocation visas"}`

**Classification:** `accepted`
**Result step:** `N20D_GENERATE_DOCUMENT_3`

## E24 — N20D_GENERATE_DOCUMENT_3 (occurrence 1)

**PROCESS_EXECUTOR:** Підтвердьте валідність Document 3 і готовність фінального пакета.

**USER_SIMULATOR:** `{"D3": "valid", "final_package_ready": true}`

**Classification:** `accepted`
**Result step:** `T_COMPLETED`
