# Журнал рішень


## E07 — N07_LEGAL_AND_REGULATORY_MODEL

- `occurrence`: 1
- `submit_to`: `N07_LEGAL_AND_REGULATORY_MODEL`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.
- Результат: активний крок `N07B_LEGAL_ENTITY_REGISTRATION`.


## E08 — N07B_LEGAL_ENTITY_REGISTRATION

- `occurrence`: 1
- `submit_to`: `N07B_LEGAL_ENTITY_REGISTRATION`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.
- Результат: активний крок `N08_CANDIDATE_LOCATION_SEARCH`.


## E09 — N08_CANDIDATE_LOCATION_SEARCH

- `occurrence`: 1
- `submit_to`: `N08_CANDIDATE_LOCATION_SEARCH`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.
- Результат: активний крок `N09_PRELIMINARY_LOCATION_SCREENING`.


## E10 — N09_PRELIMINARY_LOCATION_SCREENING

- `occurrence`: 1
- `submit_to`: `N09_PRELIMINARY_LOCATION_SCREENING`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.
- Результат: активний крок `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`.


## E11 — N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION

- `occurrence`: 1
- `submit_to`: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.
- Результат: активний крок `N11_LEASE_NEGOTIATION`.


## E12 — N11_LEASE_NEGOTIATION

- `occurrence`: 1
- `submit_to`: `N11_LEASE_NEGOTIATION`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному delivery_step і містить повний структурований payload; дані прийнято.
- Результат: активний крок `N12_RENOVATION_AND_FIT_OUT_DESIGN`.


## E13 — N11D_GENERATE_DOCUMENT_1

- `occurrence`: 1
- `submit_to`: `N11D_GENERATE_DOCUMENT_1`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N12_RENOVATION_AND_FIT_OUT_DESIGN`.


## E14 — N12_RENOVATION_AND_FIT_OUT_DESIGN

- `occurrence`: 1
- `submit_to`: `N12_RENOVATION_AND_FIT_OUT_DESIGN`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N13_IT_AND_PHYSICAL_SECURITY_DESIGN`.


## E15 — N13_IT_AND_PHYSICAL_SECURITY_DESIGN

- `occurrence`: 1
- `submit_to`: `N13_IT_AND_PHYSICAL_SECURITY_DESIGN`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N14_WORKPLACE_STANDARD`.


## E16 — N14_WORKPLACE_STANDARD

- `occurrence`: 1
- `submit_to`: `N14_WORKPLACE_STANDARD`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N15_CONTRACTORS_AND_SUPPLIERS`.


## E17 — N15_CONTRACTORS_AND_SUPPLIERS

- `occurrence`: 1
- `submit_to`: `N15_CONTRACTORS_AND_SUPPLIERS`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N16_PEOPLE_PLAN`.


## E18 — N16_PEOPLE_PLAN

- `occurrence`: 1
- `submit_to`: `N16_PEOPLE_PLAN`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N17_OPERATIONAL_OWNERS`.


## E19 — N17_OPERATIONAL_OWNERS

- `occurrence`: 1
- `submit_to`: `N17_OPERATIONAL_OWNERS`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N17D_GENERATE_DOCUMENT_2`.


## E20 — N17D_GENERATE_DOCUMENT_2

- `occurrence`: 1
- `submit_to`: `N17D_GENERATE_DOCUMENT_2`
- Класифікація: `accepted`
- Рішення: Подія відповідає активному кроку та прийнята.
- Результат: активний крок `N18_READINESS_TEST`.


## E21 — N18_READINESS_TEST

- `occurrence`: 1
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Подія не містить повного, однозначного й коректного набору даних readiness test; стан збережено без змін.
- Результат: активний крок `N18_READINESS_TEST`.


## E22 — N18_READINESS_TEST

- `occurrence`: 2
- `submit_to`: `N19_PILOT_DAY`
- Класифікація: `future_step`
- Рішення: Вхід адресовано не активному `N18_READINESS_TEST`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E23 — N18_READINESS_TEST

- `occurrence`: 3
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E24 — N18_READINESS_TEST

- `occurrence`: 4
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E25 — N18_READINESS_TEST

- `occurrence`: 5
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E26 — N18_READINESS_TEST

- `occurrence`: 6
- `submit_to`: `N20_FINAL_DECISION_AND_PACKAGE`
- Класифікація: `future_step`
- Рішення: Вхід адресовано не активному `N18_READINESS_TEST`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E27 — N18_READINESS_TEST

- `occurrence`: 7
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E28 — N18_READINESS_TEST

- `occurrence`: 8
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E29 — N18_READINESS_TEST

- `occurrence`: 9
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.


## E30 — N18_READINESS_TEST

- `occurrence`: 10
- `submit_to`: `N18_READINESS_TEST`
- Класифікація: `blocked`
- Рішення: Вхід неповний або malformed: відсутній повний набір `readiness_test_date` і `readiness_test_result`; стан не змінено.
- Результат: активний крок `N18_READINESS_TEST`.
