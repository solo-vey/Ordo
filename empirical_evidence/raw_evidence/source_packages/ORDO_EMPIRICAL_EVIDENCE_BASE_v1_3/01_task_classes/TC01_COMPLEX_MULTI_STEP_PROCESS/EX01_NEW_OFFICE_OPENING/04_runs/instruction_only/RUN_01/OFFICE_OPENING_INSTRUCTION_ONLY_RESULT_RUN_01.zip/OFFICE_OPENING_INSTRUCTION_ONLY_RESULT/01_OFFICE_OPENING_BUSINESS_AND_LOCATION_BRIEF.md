# Office Opening Business and Location Brief

## 1. Business context and objective

Northstar Analytics GmbH, operating under the Northstar brand, is a B2B SaaS / аналітика ланцюгів постачання company headquartered in Німеччина with 420 employees.

The business objective is to Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі.

The new office will be established in Краків, Польща, with a target opening date of 2027-03-15.

The initial approved budget is 2 400 000 EUR.

Year-1 headcount is planned at 85 employees, scaling to 180 by year 3.

## 2. Workplace requirements

The operating model is hybrid.

The workplace requires 110 workspaces and 8 meeting rooms.

Special spaces include Серверна кімната, дві phone-booth зони, training room на 30 осіб.

The selected premises must support growth without compromising collaboration, focus work, training, or secure technology operations.

## 3. Location search criteria

The primary location priority is Транспортна доступність і близькість до talent hub.

The commute target is 45 хвилин для 80% працівників.

The search covered 5 candidate locations.

The preferred lease term is 60 months.

The maximum monthly rent is 58 000 EUR без комунальних витрат.

## 4. Legal and operating model

A local legal entity is required: true.

The selected model is Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією.

Employment will follow this model: Пряме локальне працевлаштування через польську юридичну особу.

Visa support is required: true.

The legal-entity registration branch was completed before location execution continued.

## 5. Data residency and compliance

The principal regulatory constraints are Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці.

The data-residency requirement is Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі.

Compliance controls must cover employment, GDPR, occupational safety, fire protection, and documented local approvals.

## 6. Accessibility requirements

The required accessibility standard is Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця.

Accessibility acceptance must be evidenced before unrestricted occupancy.

## 7. Selected location

The selected primary location is Mogilska 35, 31-545 Kraków, Poland.

The backup location is Pawia 23, 31-154 Kraków, Poland.

The selected office provides 1 850 м² of usable area.

Its technical-readiness score is 82 зі 100.

The candidate search was completed, preliminary screening passed, and lease negotiation succeeded.

## 8. Business and location conclusion

Proceed with the selected Kraków location as the basis for fit-out, technology, security, staffing, and operational-readiness planning.

The location is aligned with the business objective, workforce scale, commute target, rent ceiling, legal model, data-residency constraints, and accessibility requirements.
