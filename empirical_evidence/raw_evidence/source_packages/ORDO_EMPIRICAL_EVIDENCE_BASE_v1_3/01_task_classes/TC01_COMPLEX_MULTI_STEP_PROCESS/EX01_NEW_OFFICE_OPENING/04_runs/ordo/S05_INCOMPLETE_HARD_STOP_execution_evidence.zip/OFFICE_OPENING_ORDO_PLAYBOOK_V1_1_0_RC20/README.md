# Office Opening Ordo Playbook — RC20

Version: `1.1.0-rc.4`

RC20 is a targeted patch over RC17. The business tree, node IDs, gates, P01-P50 attributes, document contracts, branch scenarios and terminal pipeline are preserved.

## RC20 repair

- Checkpoint required fields now support nested dotted paths.
- `document_status.D1`, `document_status.D2`, and `document_status.D3` close correctly after validated document actions.
- S01 clean-control fixtures are synchronized with the canonical Northstar scenario state.
- Added nested checkpoint regressions for all three document nodes.

Start with `START_HERE_RUNTIME_MODE.md`. Preferred launcher: `python3 RUN_ORDO.py`.

## Runtime entry files

Use `START_PROMPT_RUNTIME_MODE.md`, then follow `START_HERE_RUNTIME_MODE.md`. The editable source is `source/program.ordo.yaml`; canonical runtime IR is `compiled/program.ir.json`.
