# Collected Attributes

| ID | Attribute | Value | Status | Source |
|---|---|---|---|---|
| P01 | `company_legal_name` | Northstar Analytics GmbH | accepted | N01 |
| P02 | `company_brand_name` | Northstar | accepted | N01 |
| P03 | `company_industry` | B2B SaaS / аналітика ланцюгів постачання | accepted | N01 |
| P04 | `company_headquarters_country` | Німеччина | accepted | N01 |
| P05 | `company_size_employees` | 420 | accepted | N01 |
| P06 | `office_business_goal` | Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі | accepted | N01 |
| P07 | `target_country` | Польща | accepted | N02 |
| P08 | `target_city` | Краків | accepted | N02 |
| P09 | `target_opening_date` | 2027-03-15 | accepted | N02 |
| P10 | `initial_budget` | 2 400 000 EUR | accepted | N03 |
| P11 | `planned_headcount_year1` | 85 | accepted | N04 |
| P12 | `planned_headcount_year3` | 180 | accepted | N04 |
| P13 | `work_model` | hybrid | accepted | N05 |
| P14 | `required_workspace_count` | 110 | accepted | N05 |
| P15 | `required_meeting_rooms` | 8 | accepted | N05 |
| P16 | `special_space_requirements` | Серверна кімната, дві phone-booth зони, training room на 30 осіб | accepted | N05 |
| P17 | `location_priority` | Транспортна доступність і близькість до talent hub | accepted | N06 |
| P18 | `maximum_commute_target` | 45 хвилин для 80% працівників | accepted | N06 |
| P19 | `candidate_location_count` | 5 | accepted | N06 |
| P20 | `preferred_lease_term_months` | 60 | accepted | N06 |
| P21 | `maximum_monthly_rent` | 58 000 EUR без комунальних витрат | accepted | N06 |
| P22 | `legal_entity_required` | false | accepted | N07 |
| P23 | `regulatory_constraints` | Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці | accepted | N07 |
| P24 | `tax_model` | Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією | accepted | N07 |
| P25 | `employment_model` | Пряме локальне працевлаштування через польську юридичну особу | accepted | N07 |
| P26 | `visa_support_required` | true | accepted | N07 |
| P27 | `data_residency_requirement` | Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі | accepted | N07 |
| P28 | `accessibility_standard` | Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця | accepted | N07 |
| P29 | `selected_location_address` | Mogilska 35, 31-545 Kraków, Poland | accepted | N10 |
| P30 | `backup_location_address` | Pawia 23, 31-154 Kraków, Poland | accepted | N10 |
| P31 | `usable_area_sqm` | 1 850 м² | accepted | N10 |
| P32 | `technical_readiness_score` | 82 зі 100 | accepted | N10 |
| P33 | `renovation_scope` | Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні | accepted | N12 |
| P34 | `renovation_budget` | 740 000 EUR | accepted | N12 |
| P35 | `fitout_deadline` | 2027-02-12 | accepted | N12 |
| P36 | `network_capacity_requirement` | Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання | accepted | N13 |
| P37 | `server_room_required` | true | accepted | N13 |
| P38 | `physical_security_level` | Підвищений | accepted | N13 |
| P39 | `access_control_model` | Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком | accepted | N13 |
| P40 | `furniture_standard` | Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце | accepted | N14 |
| P41 | `primary_general_contractor` | BuildCore Polska Sp. z o.o. | accepted | N15 |
| P42 | `critical_supplier_count` | 6 | accepted | N15 |
| P43 | `local_hiring_target` | 65 нових працівників у перший рік | accepted | N16 |
| P44 | `relocation_target` | 20 працівників із Німеччини, Чехії та України | accepted | N16 |
| P45 | `local_hr_owner` | Anna Kowalska, Head of People Poland | accepted | N16 |
| P46 | `local_it_owner` | Marek Zieliński, Regional IT Manager | accepted | N17 |
| P47 | `local_facilities_owner` | Katarzyna Nowak, Workplace Operations Lead | accepted | N17 |
| P48 | `readiness_test_date` | 2027-02-22 | accepted | N18 |
| P49 | `pilot_day_participants` | 24 | accepted | N19 |
| P50 | `final_opening_decision` | conditional open | accepted | N20 |
