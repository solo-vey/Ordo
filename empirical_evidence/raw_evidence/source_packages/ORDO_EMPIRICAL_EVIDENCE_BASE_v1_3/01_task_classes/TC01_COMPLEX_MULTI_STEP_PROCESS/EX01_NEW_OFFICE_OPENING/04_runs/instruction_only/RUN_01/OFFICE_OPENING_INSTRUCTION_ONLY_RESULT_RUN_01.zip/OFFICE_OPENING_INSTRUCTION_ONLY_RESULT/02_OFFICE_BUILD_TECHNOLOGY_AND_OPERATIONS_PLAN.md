# Office Build, Technology and Operations Plan

## 1. Facility and fit-out plan

The approved fit-out scope is Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні.

The renovation budget is 740 000 EUR.

The fit-out deadline is 2027-02-12.

The plan must deliver 110 workspaces, 8 meeting rooms, and all special-purpose spaces within the selected 1 850 м² premises.

Facility acceptance must include safety, accessibility, utilities, acoustic performance, and landlord handover evidence.

## 2. Technology infrastructure

The network requirement is Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання.

A server room is required: true.

Technology commissioning must include capacity, redundancy, Wi-Fi coverage, monitoring, failover, and secure equipment-room acceptance tests.

## 3. Physical security and access

The physical-security level is Підвищений.

The access-control model is Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком.

Commissioning evidence must show badge issuance, zoning, guest access, logging, emergency procedures, and ownership of access reviews.

## 4. Contractors and critical suppliers

The primary general contractor is BuildCore Polska Sp. z o.o..

There are 6 critical suppliers.

The critical-supplier replacement status is accepted.

Supplier controls must track contractual milestones, substitutions, lead times, dependencies, acceptance criteria, and recovery actions.

## 5. People and operating model

The local hiring target is 65 нових працівників у перший рік.

The relocation target is 20 працівників із Німеччини, Чехії та України.

The local HR owner is Anna Kowalska, Head of People Poland.

The local IT owner is Marek Zieliński, Regional IT Manager.

The local facilities owner is Katarzyna Nowak, Workplace Operations Lead.

The workplace furniture standard is Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце.

## 6. Delivery controls

A weekly delivery review will cover schedule, budget, safety, fit-out progress, technology readiness, physical security, furniture, hiring, relocation, visas, and critical suppliers.

Every material variance must have an owner, corrective action, deadline, and closure evidence.

Document control must preserve approvals, test records, certificates, handover materials, and accepted deviations.

## 7. Operational readiness summary

The plan provides accountable owners for facilities, IT, and people operations.

Readiness is contingent on completed fit-out, commissioned technology and security, installed workplace equipment, supplier acceptance, and staffing controls.

The office can move to formal readiness testing when all planned controls are evidenced and no critical blocker remains.
