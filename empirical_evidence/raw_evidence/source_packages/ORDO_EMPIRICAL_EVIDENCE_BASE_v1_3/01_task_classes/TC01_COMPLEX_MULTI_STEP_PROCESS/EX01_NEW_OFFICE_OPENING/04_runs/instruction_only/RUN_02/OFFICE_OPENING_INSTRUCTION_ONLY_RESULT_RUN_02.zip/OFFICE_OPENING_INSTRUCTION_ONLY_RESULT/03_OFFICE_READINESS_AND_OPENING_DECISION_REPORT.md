# Office Readiness & Opening Decision Report

**Компанія:** Northstar Analytics GmbH  
**Офіс:** Mogilska 35, 31-545 Kraków, Poland  
**Цільова дата відкриття:** 2027-03-15  
**Фінальне рішення:** **conditional open**

## 1. Executive readiness assessment

Програма підтримує бізнес-мету: **Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі**.

Початковий бюджет: **2 400 000 EUR**.

Технічна оцінка вибраної локації: **82 зі 100**.

Перший тест готовності виявив блокувальну проблему з електроживленням fit-out.

Після remediation-loop повторний тест отримав статус **passed**.

Фінальне рішення: **conditional open**.

## 2. Facility and delivery readiness

Основна локація: **Mogilska 35, 31-545 Kraków, Poland**.

Резервна локація: **Pawia 23, 31-154 Kraków, Poland**.

Бюджет ремонту: **740 000 EUR**.

Завершення fit-out: **2027-02-12**.

Генеральний підрядник: **BuildCore Polska Sp. z o.o.**.

Критичних постачальників: **6**; заміну постачальника прийнято.

Формальний тест готовності: **2027-02-22**.

## 3. Technology and security readiness

Мережа: **Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання**.

Серверна потрібна: **True**.

Рівень фізичної безпеки: **Підвищений**.

Контроль доступу: **Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком**.

IT-власник: **Marek Zieliński, Regional IT Manager**.

Facilities-власник: **Katarzyna Nowak, Workplace Operations Lead**.

## 4. People and operating readiness

Ціль локального найму: **65 нових працівників у перший рік**.

Ціль релокації: **20 працівників із Німеччини, Чехії та України**.

HR-власник: **Anna Kowalska, Head of People Poland**.

Візова підтримка потрібна: **True**.

Працівники не починають роботу без необхідного правового статусу та завершених процедур онбордингу.

## 5. Pilot day result

Пілотний день проведено з **24 учасниками**.

Статус завершення пілота: **True**.

Перевірено доступ, робочі місця, мережу, переговорні кімнати, підтримку, фізичну безпеку та базові евакуаційні процедури.

Результат пілота підтримує умовне відкриття за умови документального закриття наведених нижче пунктів.

## 6. Opening conditions and blockers

| Condition | Responsible owner | Deadline | Required evidence | Status |
|---|---|---|---|---|
| Fire-safety certification | Katarzyna Nowak, Workplace Operations Lead | До 2027-03-15 | Фінальний сертифікат і архів доказів | Open |
| Backup internet connection | Marek Zieliński, Regional IT Manager | До 2027-03-15 | Активація та успішний failover-тест | Open |
| Accessibility observations | Katarzyna Nowak, Workplace Operations Lead | До повного підтвердження готовності | Усунення зауважень і повторна перевірка | Open |
| Relocation visas | Anna Kowalska, Head of People Poland | До виходу відповідних працівників | Завершені візові документи | Open |

## 7. Decision

Рішення щодо відкриття: **conditional open**.

Офіс може відкритися лише за контрольованого виконання чотирьох умов, з призначеними власниками, строками та доказами.

Рішення ґрунтується на повторному тесті готовності, пілотному дні, стані постачальників, персоналу, технологій, безпеки й доступності.

## 8. Final package status

Статус готовності фінального пакета: **True**.

Пакет включає три бізнес-документи, execution trace, таблицю атрибутів, dialogue log, model identity та self-validation report.

Це instruction-only benchmark run; твердження про Ordo CLI або детерміновану runtime-валідацію не робляться.
