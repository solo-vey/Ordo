#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, json, shutil, subprocess, tempfile, yaml
from pathlib import Path

BASE_ORDER=['N01_BUSINESS_INITIATION','N02_GEOGRAPHY_AND_TARGET_DATE','N03_INITIAL_BUDGET','N04_HEADCOUNT_PLANNING','N05_WORK_MODEL_AND_SPACE','N06_LOCATION_SEARCH_CRITERIA','N07_LEGAL_AND_REGULATORY_MODEL','N07B_LEGAL_ENTITY_REGISTRATION','N08_CANDIDATE_LOCATION_SEARCH','N09_PRELIMINARY_LOCATION_SCREENING','N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION','N11_LEASE_NEGOTIATION','N11D_GENERATE_DOCUMENT_1','N12_RENOVATION_AND_FIT_OUT_DESIGN','N13_IT_AND_PHYSICAL_SECURITY_DESIGN','N14_WORKPLACE_STANDARD','N15_CONTRACTORS_AND_SUPPLIERS','N16_PEOPLE_PLAN','N17_OPERATIONAL_OWNERS','N17D_GENERATE_DOCUMENT_2','N18_READINESS_TEST','N18B_REMEDIATION_ROUTER','N19_PILOT_DAY','N20_FINAL_DECISION_AND_PACKAGE','N20D_GENERATE_DOCUMENT_3','N20V_VALIDATE_FINAL_PACKAGE']

class Harness:
    def __init__(self, src: Path, work: Path):
        self.src=src; self.work=work
        shutil.copytree(src,work,copy_function=shutil.copy2,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        self.answers=yaml.safe_load((work/'run_inputs/full_success_answers.yaml').read_text(encoding='utf-8'))['answers']
        self.events=[]
    def cmd(self,args, expected=(0,)):
        p=subprocess.run(['python3','RUN_ORDO.py']+args,cwd=self.work,text=True,capture_output=True)
        self.events.append({'command':' '.join(args),'exit_code':p.returncode,'stdout':p.stdout[-500:],'stderr':p.stderr[-500:]})
        if p.returncode not in expected: raise AssertionError(f"command failed {args}: {p.returncode} {p.stdout} {p.stderr}")
        return p
    def preflight(self):
        for a in [['verify-environment','.'],['verify-targets','.'],['verify-session','.'],['runtime-status','.'],['runtime-entry','.']]: self.cmd(a)
    def submit(self,node,answer,expect='passed'):
        af=self.work.parent/f'{self.work.name}_{node}.yaml'; af.write_text(yaml.safe_dump({'answer':answer},allow_unicode=True,sort_keys=False),encoding='utf-8')
        self.cmd(['intake','.','--submit',node,'--answer-file',str(af)], expected=(0,1))
        r=json.loads((self.work/'reports/intake_submit_report.json').read_text())
        if r.get('status')!=expect: raise AssertionError(f"{node}: expected {expect}, got {r.get('status')} next={r.get('next_node')}")
        return r
    def next(self):
        self.cmd(['next-step','.'],expected=(0,1))
        return json.loads((self.work/'reports/next_step_report.json').read_text())
    def fixture(self,name):
        shutil.copy2(self.work/'scenario_suite/fixtures/baseline_outputs'/name,self.work/'outputs'/name)

def valid(h,node,mods=None):
    a=copy.deepcopy(h.answers[node]);
    if mods:a.update(mods)
    return a

def run_s01(src,tmp):
    h=Harness(src,tmp/'S01');h.preflight()
    route=[]
    for node in BASE_ORDER:
        if node=='N18B_REMEDIATION_ROUTER': continue
        if node=='N11D_GENERATE_DOCUMENT_1': h.fixture('01_OFFICE_OPENING_BUSINESS_AND_LOCATION_BRIEF.md'); a={'generation_completed':True}
        elif node=='N17D_GENERATE_DOCUMENT_2': h.fixture('02_OFFICE_BUILD_TECHNOLOGY_AND_OPERATIONS_PLAN.md'); a={'generation_completed':True}
        elif node=='N20D_GENERATE_DOCUMENT_3':
            for n in ['03_OFFICE_READINESS_AND_OPENING_DECISION_REPORT.md','04_EXECUTION_TRACE.md','05_COLLECTED_ATTRIBUTES.md','06_DIALOGUE_LOG.md','07_MODEL_IDENTITY.json']: h.fixture(n)
            a={'generation_completed':True}
        elif node=='N20V_VALIDATE_FINAL_PACKAGE': break
        else:a=valid(h,node)
        r=h.submit(node,a);route.append(node)
    return {'status':'passed','route':route,'reached':r.get('next_node')}

def run_s02(src,tmp):
    h=Harness(src,tmp/'S02');h.preflight(); route=[]
    for node in BASE_ORDER[:7]:
        mods={'legal_entity_required':False} if node=='N07_LEGAL_AND_REGULATORY_MODEL' else None
        r=h.submit(node,valid(h,node,mods));route.append(node)
    assert r.get('next_node')=='N08_CANDIDATE_LOCATION_SEARCH',r
    for node in ['N08_CANDIDATE_LOCATION_SEARCH','N09_PRELIMINARY_LOCATION_SCREENING','N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION','N11_LEASE_NEGOTIATION']:
        r=h.submit(node,valid(h,node));route.append(node)
    h.fixture('01_OFFICE_OPENING_BUSINESS_AND_LOCATION_BRIEF.md'); h.submit('N11D_GENERATE_DOCUMENT_1',{'generation_completed':True});route.append('N11D_GENERATE_DOCUMENT_1')
    for node in ['N12_RENOVATION_AND_FIT_OUT_DESIGN','N13_IT_AND_PHYSICAL_SECURITY_DESIGN','N14_WORKPLACE_STANDARD']:
        h.submit(node,valid(h,node));route.append(node)
    r=h.submit('N15_CONTRACTORS_AND_SUPPLIERS',valid(h,'N15_CONTRACTORS_AND_SUPPLIERS',{'critical_supplier_replacement_status':'replace'}));route.append('N15_CONTRACTORS_AND_SUPPLIERS')
    assert r.get('next_node')=='N12_RENOVATION_AND_FIT_OUT_DESIGN',r
    for node in ['N12_RENOVATION_AND_FIT_OUT_DESIGN','N13_IT_AND_PHYSICAL_SECURITY_DESIGN','N14_WORKPLACE_STANDARD','N15_CONTRACTORS_AND_SUPPLIERS','N16_PEOPLE_PLAN','N17_OPERATIONAL_OWNERS']:
        h.submit(node,valid(h,node));route.append(node)
    h.fixture('02_OFFICE_BUILD_TECHNOLOGY_AND_OPERATIONS_PLAN.md');h.submit('N17D_GENERATE_DOCUMENT_2',{'generation_completed':True});route.append('N17D_GENERATE_DOCUMENT_2')
    r=h.submit('N18_READINESS_TEST',valid(h,'N18_READINESS_TEST',{'readiness_status':'blocked'}));route.append('N18_READINESS_TEST')
    assert r.get('next_node')=='N18B_REMEDIATION_ROUTER',r
    r=h.submit('N18B_REMEDIATION_ROUTER',{'blocking_defect':'fit-out power issue','responsible_workstream':'N12'});route.append('N18B_REMEDIATION_ROUTER')
    assert r.get('next_node')=='N12_RENOVATION_AND_FIT_OUT_DESIGN',r
    return {'status':'passed','route':route,'branch_history':r.get('state',{}).get('branch_history',[])}

def run_s03(src,tmp):
    h=Harness(src,tmp/'S03');h.preflight()
    r1=h.submit('N01_BUSINESS_INITIATION',{'company_legal_name':'Only name'},expect='blocked')
    r2=h.submit('N03_INITIAL_BUDGET',valid(h,'N03_INITIAL_BUDGET'),expect='blocked')
    r3=h.submit('N01_BUSINESS_INITIATION',valid(h,'N01_BUSINESS_INITIATION'))
    assert r3.get('state',{}).get('company_legal_name') and r3.get('next_node')=='N02_GEOGRAPHY_AND_TARGET_DATE'
    return {'status':'passed','blocked_attempts':2,'next':r3.get('next_node')}

def run_s04(src,tmp):
    h=Harness(src,tmp/'S04');h.preflight()
    for node in BASE_ORDER[:6]: h.submit(node,valid(h,node))
    before=json.loads((h.work/'runtime/run_state.json').read_text())
    h.cmd(['restore-session','.','--to-seq','4','--reason','User changed work model assumptions'])
    rr=json.loads((h.work/'reports/restore_session_report.json').read_text())
    if rr.get('status') not in ('passed','restored'): raise AssertionError(rr)
    ns=h.next()
    return {'status':'passed','restore_status':rr.get('status'),'suggested_next':ns.get('suggested_next_node') or ns.get('next_node'),'previous_work_model':before.get('work_model')}

def run_s05(src,tmp):
    h=Harness(src,tmp/'S05');h.preflight()
    h.submit('N01_BUSINESS_INITIATION',valid(h,'N01_BUSINESS_INITIATION'))
    before=json.loads((h.work/'runtime/run_state.json').read_text())
    r=h.submit('N02_GEOGRAPHY_AND_TARGET_DATE',{'target_country':'Польща','target_city':'Не знаю','target_opening_date':None},expect='blocked')
    after=json.loads((h.work/'runtime/run_state.json').read_text())
    assert before==after,'rejected answer mutated canonical state'
    return {'status':'passed','state_unchanged':True,'current_node':'N02_GEOGRAPHY_AND_TARGET_DATE'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('package',nargs='?',default='.');ap.add_argument('--scenario');args=ap.parse_args();src=Path(args.package).resolve()
    results={}
    with tempfile.TemporaryDirectory(prefix='ordo-disturbance-') as td:
        tmp=Path(td)
        for sid,fn in [('S01_CLEAN_CONTROL',run_s01),('S02_BRANCH_HEAVY',run_s02),('S03_INVALID_AND_IRRELEVANT',run_s03),('S04_BACKTRACK_AND_CORRECT',run_s04),('S05_INCOMPLETE_HARD_STOP',run_s05)]:
            if args.scenario and sid != args.scenario: continue
            try: results[sid]=fn(src,tmp)
            except Exception as e: results[sid]={'status':'failed','error':str(e)}
    passed=sum(v['status']=='passed' for v in results.values())
    report={'schema':'ordo.benchmark.disturbance_suite_report.v1','status':'passed' if passed==len(results) else 'failed','passed':passed,'total':len(results),'results':results}
    out=src/'reports/DISTURBANCE_SCENARIO_SUITE_REPORT.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(0 if report['status']=='passed' else 1)
if __name__=='__main__': main()
