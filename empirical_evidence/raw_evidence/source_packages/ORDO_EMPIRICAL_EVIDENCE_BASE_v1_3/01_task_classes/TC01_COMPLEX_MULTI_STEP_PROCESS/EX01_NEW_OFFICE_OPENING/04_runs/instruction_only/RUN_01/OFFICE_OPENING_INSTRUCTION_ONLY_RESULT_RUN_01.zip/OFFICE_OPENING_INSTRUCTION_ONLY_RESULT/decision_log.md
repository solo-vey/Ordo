# Decision Log

## E01 — N01_BUSINESS_INITIATION

- classification: `accepted`
- result_step: `N02_GEOGRAPHY_AND_TARGET_DATE`
- state_hash: `49dc49e7b9306495c8c176a49b37154407b6853dc9e0c45df34a00a49978b57f`

## E02 — N02_GEOGRAPHY_AND_TARGET_DATE

- classification: `accepted`
- result_step: `N03_INITIAL_BUDGET`
- state_hash: `7d97d6e03262445601b41bb448452d7be3125d1ac1ef0622d06b909bf43a57ed`
- state_changed: `true`

## E03 — N03_INITIAL_BUDGET

- classification: `accepted`
- result_step: `N04_HEADCOUNT_PLANNING`
- state_hash: `c5e4a6fa6c6e525d31c7a27f458e2c699ca74e3ad3478173cb357d8c9ad9ea5c`
- state_changed: `true`

## E04 — N04_HEADCOUNT_PLANNING

- classification: `accepted`
- result_step: `N05_WORK_MODEL_AND_SPACE`
- state_hash: `25b246da266b12a203a7fc0e885557264256ce7c2c7f5a2eda7079bf59353fba`
- state_changed: `true`

## E05 — N05_WORK_MODEL_AND_SPACE

- classification: `accepted`
- result_step: `N06_LOCATION_SEARCH_CRITERIA`
- state_hash: `81925956b64862d82c44b7989a64348f27352726a8b22ea59ed5e924ee505fee`
- state_changed: `true`

## E06 — N06_LOCATION_SEARCH_CRITERIA

- classification: `accepted`
- result_step: `N07_LEGAL_AND_REGULATORY_MODEL`
- state_hash: `56bf72bc35bad99c803698e4be49cc84f20819ab3f5a932887508b77d5f9d178`
- state_changed: `true`

## E07 — N07_LEGAL_AND_REGULATORY_MODEL

- classification: `accepted`
- result_step: `N07B_LEGAL_ENTITY_REGISTRATION`
- state_hash: `5c50e741a1421be62b6042220c5f1004c4b67ce65ad089c2938248c6cc0fe180`
- state_changed: `true`

## E08 — N07B_LEGAL_ENTITY_REGISTRATION

- classification: `accepted`
- result_step: `N08_CANDIDATE_LOCATION_SEARCH`
- state_hash: `89f0d65a3cfae51a6ca0b7133e33322afa6511db296f149102b64de1fba291a9`
- state_changed: `true`

## E09 — N08_CANDIDATE_LOCATION_SEARCH

- classification: `accepted`
- result_step: `N09_PRELIMINARY_LOCATION_SCREENING`
- state_hash: `3c8915b167df8963bb965bcc100aef12bfaed5b9b3c8f7f504497fd330103ffd`
- state_changed: `true`

## E10 — N09_PRELIMINARY_LOCATION_SCREENING

- classification: `accepted`
- result_step: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- state_hash: `5973c6c3b3a69977c7974f2d4a5f5267f74c5f4a94d3008274deada4ccca2707`
- state_changed: `true`

## E11 — N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION

- classification: `accepted`
- result_step: `N11_LEASE_NEGOTIATION`
- state_hash: `47e38b12641510f063c87fefe65280d75557be9bccf6f4aa2e4b4468338ebb18`
- state_changed: `true`

## E12 — N11_LEASE_NEGOTIATION

- classification: `accepted`
- result_step: `N12_RENOVATION_AND_FIT_OUT_DESIGN`
- state_hash: `2a0773927526f9ec4c9e952197774317b7b9e9a82c0480272b5de86ee365e574`
- state_changed: `true`

## E13 — N11D_GENERATE_DOCUMENT_1

- classification: `accepted`
- result_step: `N12_RENOVATION_AND_FIT_OUT_DESIGN`
- state_hash: `7692297222fa52c721e3a4d98eadf81775448276dcd43bc04632bd5622cf2c97`
- state_changed: `true`

## E14 — N12_RENOVATION_AND_FIT_OUT_DESIGN

- classification: `accepted`
- result_step: `N13_IT_AND_PHYSICAL_SECURITY_DESIGN`
- state_hash: `a1f0ddb3d10fc43d50d1c0905f3a2988a62263ed7e3db211a93cffeb3eab6b65`
- state_changed: `true`

## E15 — N13_IT_AND_PHYSICAL_SECURITY_DESIGN

- classification: `accepted`
- result_step: `N14_WORKPLACE_STANDARD`
- state_hash: `0f4ca26ab577253773d3161454c2ddaed999f7290773bf94e736597bc66dd0d2`
- state_changed: `true`

## E16 — N14_WORKPLACE_STANDARD

- classification: `accepted`
- result_step: `N15_CONTRACTORS_AND_SUPPLIERS`
- state_hash: `93bd8a295380d17dca6b4852f3362e9668e1ce15ccda675c391642437f7f450d`
- state_changed: `true`

## E17 — N15_CONTRACTORS_AND_SUPPLIERS

- classification: `accepted`
- result_step: `N16_PEOPLE_PLAN`
- state_hash: `0f30b913bbb1388bd480480b202ac48a414294a7b62ee0a870ddcc0a2d2953ca`
- state_changed: `true`

## E18 — N16_PEOPLE_PLAN

- classification: `accepted`
- result_step: `N17_OPERATIONAL_OWNERS`
- state_hash: `c68940a72c23519fe614601a8f6d5cdc8073c4fcd2b8fa9bd6c9aea02870ac24`
- state_changed: `true`

## E19 — N17_OPERATIONAL_OWNERS

- classification: `accepted`
- result_step: `N17D_GENERATE_DOCUMENT_2`
- state_hash: `caf7a80e35fe933e9abbba542c97f64ebbc9bcc2697afbf93f96bee8e0355efe`
- state_changed: `true`

## E20 — N17D_GENERATE_DOCUMENT_2

- classification: `accepted`
- result_step: `N18_READINESS_TEST`
- state_hash: `3bf613f823f892a99b48a6ee914e73d07fa676f71ba419b901242d2c62bacf23`
- state_changed: `true`

## E21 — N18_READINESS_TEST

- classification: `accepted`
- result_step: `N19_PILOT_DAY`
- state_hash: `cd0720143d85512bd3b7ee8549bb9defb6b0ede940b59161aad497026d4612ac`
- state_changed: `true`

## E22 — N19_PILOT_DAY

- classification: `accepted`
- result_step: `N20_FINAL_DECISION_AND_PACKAGE`
- state_hash: `0eef52605e434b536564c3ec04091e71ea78d5f10c5b08535095833061e6f9c1`
- state_changed: `true`

## E23 — N20_FINAL_DECISION_AND_PACKAGE

- classification: `accepted`
- result_step: `N20D_GENERATE_DOCUMENT_3`
- state_hash: `9bcffd54e20018dad3dc29f30363aeaa47145268a5977410f64c8e3759226e5d`
- state_changed: `true`

## E24 — N20D_GENERATE_DOCUMENT_3

- classification: `accepted`
- result_step: `T_COMPLETED`
- state_hash: `a18cc5f6fcd9d30b2bea878a69756f5bde8281ee92da2563b07bb8a393074b96`
- state_changed: `true`

