# Instruction-Only Office Opening Process

## Operating mode

Execute the process autonomously in one chat without Ordo CLI or any runtime engine.

Logically separate two roles:

- `PROCESS_EXECUTOR` asks the current question, records the response, updates the working state, and chooses the next step.
- `USER_SIMULATOR` reads only the current step entry from `inputs/full_success_answers.yaml` and answers that question.

Do not read future answers into the working state before their step. Do not skip required steps. Do not create final documents before the required source steps are complete.

## Language

All user-visible questions, progress updates, summaries, and the final response must be in Ukrainian. Keep file names, field names, step IDs, JSON keys, and technical identifiers unchanged.

## Model identity

Before Step 1, create `outputs/07_MODEL_IDENTITY.json` with:

- schema: `ordo.benchmark.model_identity.v1`
- provider
- model_name
- model_identifier
- reasoning_mode
- capture_method
- captured_at_utc
- backfilled: false

Self-report honestly. Use `unknown` when a value cannot be determined.

## Sequential process

Process these steps exactly in order unless a listed branch applies:

1. `N01_BUSINESS_INITIATION` — company profile and office business goal.
2. `N02_GEOGRAPHY_AND_TARGET_DATE` — target country, city, opening date.
3. `N03_INITIAL_BUDGET` — initial budget.
4. `N04_HEADCOUNT_PLANNING` — year-1 and year-3 headcount.
5. `N05_WORK_MODEL_AND_SPACE` — work model and workplace requirements.
6. `N06_LOCATION_SEARCH_CRITERIA` — location criteria, commute, candidate count, lease and rent limits.
7. `N07_LEGAL_AND_REGULATORY_MODEL` — legal entity, regulatory, tax, employment, visa, data residency and accessibility.
8. If `legal_entity_required=true`, execute `N07B_LEGAL_ENTITY_REGISTRATION` and record the branch decision.
9. `N08_CANDIDATE_LOCATION_SEARCH` — confirm search completion.
10. `N09_PRELIMINARY_LOCATION_SCREENING` — confirm screening result.
11. `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION` — primary and backup locations, usable area, technical score.
12. `N11_LEASE_NEGOTIATION` — confirm negotiation outcome.
13. Create Document 1 from the accepted data.
14. `N12_RENOVATION_AND_FIT_OUT_DESIGN` — scope, budget and deadline.
15. `N13_IT_AND_PHYSICAL_SECURITY_DESIGN` — network, server room, security and access control.
16. `N14_WORKPLACE_STANDARD` — furniture standard.
17. `N15_CONTRACTORS_AND_SUPPLIERS` — contractor and critical suppliers.
18. `N16_PEOPLE_PLAN` — hiring, relocation and HR owner.
19. `N17_OPERATIONAL_OWNERS` — IT and facilities owners.
20. Create Document 2 from the accepted data.
21. `N18_READINESS_TEST` — readiness test date and result.
22. If readiness failed, record remediation. For this supplied case, no remediation branch is required.
23. `N19_PILOT_DAY` — pilot participants and completion.
24. `N20_FINAL_DECISION_AND_PACKAGE` — final decision and opening conditions.
25. Create Document 3 and finalize the evidence package.

## Per-step behavior

For every user-input step:

1. Record the current step ID.
2. Formulate one concise Ukrainian question covering only the fields of the current step.
3. Read only the matching entry from `inputs/full_success_answers.yaml`.
4. Record the exact answer.
5. Normalize it into canonical fields.
6. Append the question, answer, normalized values, state changes, and next step to the dialogue and execution evidence.
7. Continue only when all fields for that step are present and internally coherent.

## Working state and evidence

Maintain these outputs throughout execution:

- `outputs/04_EXECUTION_TRACE.md`
- `outputs/05_COLLECTED_ATTRIBUTES.md`
- `outputs/06_DIALOGUE_LOG.md`

The execution trace must show every step and branch in chronological order, ending with `T_COMPLETED`.

The collected attributes file must contain explicit `P01`–`P50` rows using the mapping in `reference/ATTRIBUTE_STEP_MAPPING.md`.

The dialogue log must contain every question and every answer, not only summaries.

## Required business documents

Create:

1. `outputs/01_OFFICE_OPENING_BUSINESS_AND_LOCATION_BRIEF.md`
2. `outputs/02_OFFICE_BUILD_TECHNOLOGY_AND_OPERATIONS_PLAN.md`
3. `outputs/03_OFFICE_READINESS_AND_OPENING_DECISION_REPORT.md`

Use the templates in `templates/`. Render them into natural business language. Do not leave template instructions, placeholders, or mechanical phrases in the final documents.

For `conditional open`, Document 3 must contain a table with:

- Condition
- Responsible owner
- Deadline
- Required evidence
- Status

and four rows for fire safety, backup internet, accessibility, and relocation visas.

## Final self-validation

Before declaring completion, verify:

- all required sequential steps were processed;
- the legal-entity branch was recorded;
- all `P01`–`P50` attributes are present;
- all seven output artifacts exist and contain substantive content;
- all required document sections from `reference/ARTIFACT_REQUIRED_FACTS.yaml` are present;
- no placeholder or template instruction remains;
- values are consistent across all documents and evidence files;
- the execution trace ends with `T_COMPLETED`.

Create `outputs/08_SELF_VALIDATION_REPORT.md` with passed/failed checks and any limitations.

## Final package

Create a ZIP containing:

```text
OFFICE_OPENING_INSTRUCTION_ONLY_RESULT/
├── 01_OFFICE_OPENING_BUSINESS_AND_LOCATION_BRIEF.md
├── 02_OFFICE_BUILD_TECHNOLOGY_AND_OPERATIONS_PLAN.md
├── 03_OFFICE_READINESS_AND_OPENING_DECISION_REPORT.md
├── 04_EXECUTION_TRACE.md
├── 05_COLLECTED_ATTRIBUTES.md
├── 06_DIALOGUE_LOG.md
├── 07_MODEL_IDENTITY.json
└── 08_SELF_VALIDATION_REPORT.md
```

Do not claim deterministic runtime validation, Ordo gate validation, or CLI verification. This is an instruction-only benchmark run.
