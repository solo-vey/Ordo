# Office Opening — Instruction-Only Benchmark Package v1.0

This package executes the same office-opening business case as the accepted Ordo RC15 baseline, but without Ordo CLI, runtime engine, compiled IR, gates, or playbook execution.

The model must follow the written instructions directly and autonomously simulate both roles:

- `PROCESS_EXECUTOR`: asks and processes one step at a time.
- `USER_SIMULATOR`: supplies only the answer for the current step from `inputs/full_success_answers.yaml`.

The model must not copy a prebuilt final state. It must process the steps sequentially and produce the required evidence and business documents.

Start with `instructions/INSTRUCTION_ONLY_PROCESS.md` or use the separate start prompt supplied with the package.
