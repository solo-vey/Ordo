# Instruction-Only Result Contract

A successful result must contain eight substantive artifacts.

Minimum acceptance conditions:

- three completed business documents;
- chronological trace ending in `T_COMPLETED`;
- explicit P01–P50 table;
- complete question/answer dialogue;
- machine-readable model identity;
- self-validation report that clearly distinguishes instruction-only checks from Ordo runtime checks;
- no placeholder-only files;
- no claims that Ordo CLI or gates were executed.
