#!/usr/bin/env python3
from pathlib import Path
import sys,yaml,json,importlib.util
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); errors=[]
pb=yaml.safe_load((root/'playbook/PLAYBOOK.yaml').read_text())
if len(pb.get('steps',[]))!=126: errors.append('step_count_changed')
p=pb.get('run_02_completion_patch',{})
if p.get('version')!='1.17.1': errors.append('missing_patch_version')
if p.get('pre_passport_gate',{}).get('id')!='UNIT_INPUT_COMPLETENESS': errors.append('missing_unit_input_completeness_gate')
for c in ['UNIT_LITERAL_FIXTURE_MISSING','UNIT_BEHAVIOR_RELATION_MISSING','UNIT_INVOCATION_TARGET_MISSING']:
    if c not in p.get('validator_error_routes',{}): errors.append('missing_error_route:'+c)
if not p.get('positive_route_terminal_policy',{}).get('validator_failure_alone_is_not_terminal'): errors.append('validator_failure_can_end_positive_route')
spec=importlib.util.spec_from_file_location('drv',root/'driver/semantic_analyst_driver.py'); drv=importlib.util.module_from_spec(spec); spec.loader.exec_module(drv)
expect={
'What is the duplicate replay policy including second-cycle side effects?':'rule.deduplication',
'What is the payload-empty fallback?':'rule.normalization',
'Provide the exact missing-data fixture and absent change expectation.':'rule.missing_data',
'What is the rollback expectation and post-rollback verification?':'qa.rollback',
'What is the exact rule identifier?':'rule.identifier'}
classified={}
for q,w in expect.items():
    intents,conf=drv.requested_intents(q); classified[q]={'intents':intents,'confidence':conf}
    if w not in intents: errors.append('alias_not_classified:'+w)
print(json.dumps({'validator':'alpha_1_17_1_run_02_completion','step_count':len(pb.get('steps',[])),'classified':classified,'errors':errors,'result':'PASS' if not errors else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not errors else 1)
