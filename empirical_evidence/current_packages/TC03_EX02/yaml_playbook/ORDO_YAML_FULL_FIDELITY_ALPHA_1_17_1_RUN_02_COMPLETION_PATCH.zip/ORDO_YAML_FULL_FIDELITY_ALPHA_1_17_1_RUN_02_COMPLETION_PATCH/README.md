# Ordo YAML Full-Fidelity Alpha 1.17.1

Targeted RUN_02 completion patch over Alpha 1.17.0. Business semantics and the 126-step process are unchanged.
