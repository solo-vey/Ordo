# Ordo YAML Full-Fidelity Alpha 1.17.0

This release adds mandatory black-box pre-release self-validation for RUN_01–RUN_05.

- RUN_01, RUN_02, RUN_04: generated artifacts, document validators, cross-artifact gates, Driver receipts/approvals and T_COMPLETED/go.
- RUN_03: T_SCENARIO_EXHAUSTED with no business artifacts.
- RUN_05: T_INPUT_BLOCKED with no business artifacts.

Evidence is stored in `self_validation/`. The Playbook remains 126 steps.
