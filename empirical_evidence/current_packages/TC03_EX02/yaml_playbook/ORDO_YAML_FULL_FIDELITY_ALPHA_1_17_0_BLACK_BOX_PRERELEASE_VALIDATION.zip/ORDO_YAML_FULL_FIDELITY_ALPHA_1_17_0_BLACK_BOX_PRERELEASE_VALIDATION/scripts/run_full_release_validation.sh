#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python "$ROOT/validation/preflight_alpha_1_13_full_fidelity.py"
for s in \
 run_alpha_1_14_regression.py \
 run_alpha_1_16_regression.py \
 run_alpha_1_16_1_regression.py \
 run_alpha_1_16_2_regression.py \
 run_alpha_1_16_3_regression.py \
 run_alpha_1_16_4_regression.py \
 run_alpha_1_16_5_regression.py \
 run_alpha_1_16_7_regression.py \
 run_alpha_1_16_8_regression.py \
 run_alpha_1_16_9_regression.py; do
  python "$ROOT/validation/$s"
done
