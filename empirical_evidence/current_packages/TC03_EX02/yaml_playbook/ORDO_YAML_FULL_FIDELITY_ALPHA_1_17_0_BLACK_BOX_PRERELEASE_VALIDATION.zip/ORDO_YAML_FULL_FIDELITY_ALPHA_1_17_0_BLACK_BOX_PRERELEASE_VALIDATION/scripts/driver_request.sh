#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RUN_ID="${1:?RUN_ID required}"
REQUEST_FILE="${2:?request JSON file required}"
STATE_FILE="${3:-$ROOT/results/${RUN_ID}_SEMANTIC_DRIVER_STATE.json}"
python "$ROOT/driver/semantic_analyst_driver.py" --run-id "$RUN_ID" --state-file "$STATE_FILE" --request-file "$REQUEST_FILE"
