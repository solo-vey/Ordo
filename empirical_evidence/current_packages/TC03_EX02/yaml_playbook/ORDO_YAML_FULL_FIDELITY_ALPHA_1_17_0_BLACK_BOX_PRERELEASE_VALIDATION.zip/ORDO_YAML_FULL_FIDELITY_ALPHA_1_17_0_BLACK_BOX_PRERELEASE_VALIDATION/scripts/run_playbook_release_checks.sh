#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/run_full_release_validation.sh"
echo "Release checks PASS. Execute the selected RUN only after this command succeeds."
