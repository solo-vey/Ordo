# Isolated Manual QA semantic validation
Extract each MQA section. Verify local IDs only, required command/query per applicable step, deterministic branch, operation-schema compatibility, exact event/error/change assertions, and rollback symmetry. Repository-bound prose is BLOCKED, never PASS. Emit per-case evidence.
