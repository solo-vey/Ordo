# Runner-contract-bound automation generation v2
Generate each test as a full lifecycle bound to supported runner primitives. Positive event cases must assert exact event payload fields and exact persisted change fields. Duplicate behavior requires a second explicit publish/process stimulus and assertions for the second outcome. Omission-aware behavior is runnable only with authoritative omission binding; otherwise emit a structured blocked case. Never use matrix-only shorthand.


## Duplicate causal-cycle representation

For duplicate/idempotency behavior, do not group both publish actions before both process actions.
Represent exactly two ordered cycles using `cycles:`:

- cycle 1: publish → process → post-process assertions;
- cycle 2: equivalent publish → process → final cardinality/payload/negative assertions.

Two publish occurrences and two process occurrences without this causal order are invalid.


## Full authoritative Automation binding

Every runnable Automation case must carry an authoritative fixture reference and complete literal payloads.

For publish actions, include:
`changeId`, `documentId`, `recordKey`, `operationStatus`, `fieldPath`, `oldValue`, `newValue`.

For processing actions, include:
`changeId`, `ruleId`.

Duplicate/idempotency cycles must use the same authoritative business payload and dedup identity in both cycles.
Do not substitute sample IDs such as `CHG-1`, shorten request bodies, or omit Driver-confirmed fields.
The second cycle must finish with executable final cardinality and explicit no-second-record/event assertions.
