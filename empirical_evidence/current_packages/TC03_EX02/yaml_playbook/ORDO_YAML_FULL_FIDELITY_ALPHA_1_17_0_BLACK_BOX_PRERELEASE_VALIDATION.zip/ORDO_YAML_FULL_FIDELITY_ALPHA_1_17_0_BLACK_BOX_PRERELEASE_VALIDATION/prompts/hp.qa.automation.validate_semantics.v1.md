# Automation semantic validation
Validate final YAML, not intentions. Check manual mapping, non-empty lifecycle blocks, exact field assertions, zero-error assertions, duplicate second stimulus, cleanup assertions, and structured blockers. Structure-only presence is insufficient.

For duplicate cases, validate causal order, not only command counts: publish1 < process1 < assertions1 < publish2 < process2 < assertions2.


Validate all external-rubric Automation rules:
- authoritative fixture reference;
- complete publish and process payloads;
- action/process identity consistency;
- behavior-fixture relation;
- lifecycle and rollback semantics;
- duplicate causal order;
- equivalent business payload across duplicate cycles;
- identical authoritative dedup identity;
- final post-second-cycle cardinality;
- explicit no-second-side-effect assertion.
