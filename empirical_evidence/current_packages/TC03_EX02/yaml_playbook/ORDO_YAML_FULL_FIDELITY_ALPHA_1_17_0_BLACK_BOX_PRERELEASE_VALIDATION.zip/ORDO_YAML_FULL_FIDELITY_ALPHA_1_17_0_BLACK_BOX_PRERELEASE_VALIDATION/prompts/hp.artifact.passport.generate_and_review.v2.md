# Database-change Passport generation and semantic review v2

Before generation, reload in the current pass:
1. `templates/TEMPLATE_FULL_RECORD_CHANGE_PASSPORT.md`;
2. `test_inputs/RUN_01_CONFIRMED_INPUT.yaml`;
3. relevant operational/runtime contracts;
4. confirmed functional and unit/provider catalogs in state;
5. `contracts/UNIT_PROVIDER_ATOMIC_SPECIFICATION_CONTRACT.yaml`;
6. `contracts/FUNCTIONAL_UNIT_SEMANTIC_COVERAGE_CONTRACT.yaml`.

Extract a template contract containing every required section, canonical order, immutable headings, required table columns, adaptable fields, and final-ready gates. `PASSPORT_TEMPLATE_LOAD_GATE` blocks generation if this extraction is absent.

Generate only the Passport. Treat all supplied values as available for this focused simulation. Map confirmed values into the exact sections; never collapse detailed sections into prose summaries.

Mandatory semantic behavior:
- preserve evidence labels for every uncertain or reconstructed value;
- separate source-record, change-record and derived-output contracts;
- provide field-by-field mapping and exact missing behavior;
- separate comparison normalization from stored/display semantics;
- materialize every confirmed functional scenario as a full table row;
- materialize atomic unit/provider test specifications with stable IDs, concrete fixture fields/values, invocation target, exact field/value/cardinality assertions and rule-specific negative assertions;
- reject identical generic fixture/invocation/assertion cells reused across distinct unit topics;
- include semantic functional-to-unit traceability with covered rules and rationale; behavior-specific cases must reference their matching unit topics;
- do not claim runtime evidence not present in authoritative sources.

Post-render adversarial review:
1. Remove all prose except tables; verify the contract remains implementable/testable.
2. Remove any one functional row; validator must detect ID-set mismatch.
3. Remove any one unit/provider row; validator must detect uncovered critical rule.
4. Verify no generic sentence substitutes for atomic test specifications and no distinct unit rows share the same generic cells.
5. Verify every output field maps to an explicit source and missing behavior.
6. Verify open questions are visible and do not masquerade as confirmed values.
7. Verify semantic links: no-op→normalization+noop; fallback→fallback+mapping; missing→missing-block; duplicate→duplicate; unrelated→field-filter+independence.

Pass only when `passport_required_sections_complete`, `passport_sections_meaningful`, `passport_mapping_complete`, `passport_functional_catalog_complete`, `passport_unit_provider_contract_atomic`, `passport_test_traceability_complete`, and `passport_evidence_labels_valid` are all true.


## Cross-artifact traceability boundary

Passport must not duplicate full Manual QA procedures or Automation lifecycle bodies.

For every Functional ID include either an explicit row or an unambiguous authoritative registry reference containing:

- Functional ID;
- Manual QA ID;
- Automation ID;
- authoritative status;
- blocker and closure evidence when blocked.

Preferred table:

| Functional ID | Manual QA ID | Automation ID | Authoritative status | Blocker / closure evidence |
|---|---|---|---|---|

Use `runtime/CASE_STATUS_REGISTRY.yaml` as the authoritative status source.

## Mapping rationale and closure evidence
Every runnable TC→MQA→AUTO row must explain why the mapped artifacts cover the behavior, not only list IDs.
Every blocked row must name the exact missing authority and executable closure evidence that changes the status.


## Validation/correction loop requirement (Alpha 1.16.7)
After rendering, run every required validator on the exact saved artifact. If any validator fails, do not present or approve the artifact: invalidate that version, regenerate a new version, rerun all required validators, and present only the version whose immutable receipt records PASS, return code 0, and the same SHA-256.
