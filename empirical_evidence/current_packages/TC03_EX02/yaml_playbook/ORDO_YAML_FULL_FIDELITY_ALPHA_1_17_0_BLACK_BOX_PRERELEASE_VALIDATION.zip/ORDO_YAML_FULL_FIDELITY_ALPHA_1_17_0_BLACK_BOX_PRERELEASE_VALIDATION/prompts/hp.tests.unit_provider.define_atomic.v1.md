# Define atomic unit/provider tests v1

Reload in the current pass:
1. `test_inputs/RUN_01_CONFIRMED_INPUT.yaml`;
2. confirmed rule/decision/mapping/normalization state;
3. `contracts/UNIT_PROVIDER_ATOMIC_SPECIFICATION_CONTRACT.yaml`;
4. relevant operational/runtime contracts.

Create the unit/provider catalog before Passport rendering.

For every critical topic, materialize a concrete atomic row with:
- stable ID;
- one component/rule;
- concrete fixture fields and values;
- verified invocation target, or explicit repository-discovery-bound target when implementation symbols are unavailable;
- exact positive assertions naming decision, field values and cardinalities;
- exact negative assertions naming forbidden side effects;
- evidence status.

Do not copy one generic fixture/invocation/assertion sentence into multiple rows. Unknown class/method names do not permit generic behavior assertions: keep the callable dependency open while still specifying concrete behavioral input and expected output.

Block completion when distinct topics have identical generic cells or when any critical topic lacks a concrete boundary fixture and exact assertions.
