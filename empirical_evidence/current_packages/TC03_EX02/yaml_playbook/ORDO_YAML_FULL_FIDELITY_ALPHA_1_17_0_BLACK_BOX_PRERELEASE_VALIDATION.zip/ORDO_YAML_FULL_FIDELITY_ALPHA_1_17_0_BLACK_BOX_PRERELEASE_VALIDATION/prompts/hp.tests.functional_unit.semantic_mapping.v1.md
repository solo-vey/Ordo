# Build semantic functional-to-unit coverage v1

Reload in the current pass:
1. the confirmed functional test catalog;
2. the atomic unit/provider catalog;
3. `contracts/FUNCTIONAL_UNIT_SEMANTIC_COVERAGE_CONTRACT.yaml`;
4. confirmed rule/decision state.

For each functional case:
- identify its distinct behavior and exact expected decision;
- select all and only semantically relevant unit/provider IDs;
- include behavior-specific topics (no-op, fallback, missing mapping, duplicate, unrelated-field independence) when exercised;
- write a coverage rationale explaining the relationship.

Reject a repeated default mapping across all functional cases. Mapping completeness is semantic, not an ID-presence check.

Block completion when a behavior-specific unit topic exists but the corresponding functional case does not reference it.
