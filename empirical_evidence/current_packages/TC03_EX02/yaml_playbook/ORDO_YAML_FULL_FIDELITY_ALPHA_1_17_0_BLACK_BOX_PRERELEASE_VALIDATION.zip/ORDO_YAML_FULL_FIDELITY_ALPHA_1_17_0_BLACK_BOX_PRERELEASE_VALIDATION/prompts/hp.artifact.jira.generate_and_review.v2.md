# Database-change Jira artifact generation and independent review v2

Before generation, reload in the current pass:
1. `templates/TEMPLATE_JIRA_TASK.md`;
2. the final rendered Passport;
3. `test_inputs/RUN_01_CONFIRMED_INPUT.yaml`;
4. confirmed functional and unit/provider catalogs;
5. relevant operational/runtime contracts;
6. `contracts/UNIT_PROVIDER_ATOMIC_SPECIFICATION_CONTRACT.yaml`;
7. `contracts/FUNCTIONAL_UNIT_SEMANTIC_COVERAGE_CONTRACT.yaml`.

Extract the exact Jira template contract: all headings, section order, table columns, immutable rules, adaptable fields and blocking gates. `JIRA_TEMPLATE_LOAD_GATE` blocks generation when this extraction is absent.

Generate only the Jira task. Jira must be self-contained for developer, reviewer and QA while remaining a derived view of the Passport.

Mandatory materialization:
- business context and confirmed contract snapshot;
- atomic scope/out-of-scope;
- exact decision sequence, mapping, normalization/no-op, missing-data and duplicate behavior;
- atomic technical deliverables with evidence expectations;
- verifiable acceptance criteria grouped by concern;
- every confirmed functional test as a full row with exact expected result and Manual/Automation allocation;
- every Passport unit/provider ID as a self-contained implementation requirement row with concrete fixture summary, invocation dependency/target, exact assertion focus and negative assertion focus;
- preserve the semantic functional-to-unit coverage matrix or an equivalent case-specific coverage summary;
- stable QA reference data;
- dependencies/open questions with blocking impact;
- execution checklist and evidence-based Definition of Done;
- external references and local change log.

Forbidden transformations:
- summarizing the functional catalog;
- replacing technical deliverables with generic “implement and test” prose;
- omitting unit/provider IDs because details live in Passport;
- claiming implementation/test completion without evidence;
- inventing classes, files, URLs, environment bindings or runtime results.

Post-render adversarial review:
1. Remove the Passport from context; Jira must still be actionable and testable.
2. Remove one functional row; validator must detect exact ID-set mismatch.
3. Remove one unit/provider row; validator must detect delivery-coverage mismatch.
3a. Replace all unit rows with generic Passport references; validator must fail self-contained readiness.
3b. Reuse one default UNIT-ID set for all functional cases; validator must fail semantic coverage.
4. Inspect every acceptance criterion for input/behavior/expected-result verifiability.
5. Inspect every deliverable for a concrete output and completion evidence.
6. Verify no dependency/open question is hidden under ready status.

Pass only when `jira_self_contained`, `jira_contract_snapshot_complete`, `jira_deliverables_atomic`, `jira_acceptance_criteria_verifiable`, `jira_functional_catalog_complete`, `jira_unit_requirements_complete`, `jira_qa_allocation_complete`, `jira_dependencies_visible`, and `jira_dod_evidence_based` are all true.
