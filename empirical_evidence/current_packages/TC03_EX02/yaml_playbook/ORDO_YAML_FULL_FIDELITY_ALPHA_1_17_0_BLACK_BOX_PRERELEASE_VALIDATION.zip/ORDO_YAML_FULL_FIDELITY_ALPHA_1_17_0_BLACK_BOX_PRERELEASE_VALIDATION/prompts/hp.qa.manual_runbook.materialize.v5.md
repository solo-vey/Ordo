# Materialize fully expanded database-change Manual QA runbook

Before generation, reload in the current pass:
- `templates/TEMPLATE_QA_PACKAGE.md`;
- `templates/TEMPLATE_MANUAL_QA_EXECUTION_SPEC.yaml`;
- `contracts/DATABASE_CHANGE_OPERATIONAL_QA_CONTRACT.yaml`;
- `contracts/MANUAL_QA_OPERATIONAL_RECONSTRUCTION_CONTRACT.yaml`;
- `contracts/ISOLATED_TEST_CASE_EXECUTABILITY_CONTRACT.yaml`.

Do not generate until the template-load gate records paths and SHA-256 values.

## Normative isolated-test rule
Each test case is an independent execution source of truth. After removing all shared sections and all other cases, the remaining case must still be executable. Repeat every applicable operation directly inside every case:
- conditional baseline preparation;
- exact source lookup;
- full HTTP mutation request;
- exact source verification;
- ChangeRecord lookup and assertions;
- full processor request;
- event presence/absence assertions;
- error lookup and assertions;
- source rollback request;
- post-rollback source verification.

Never replace commands with “submit”, “invoke”, “query”, “restore”, “same as above”, or references to shared operations.

## Canonical sequence
0. Preflight baseline
1. Source lookup before action
2. REST action
3. Source state after action
4. ChangeRecord lookup
5. Processor invocation
6. Generated event assertion
7. Error assertion
8. Source rollback
9. Source state after rollback
Final expected result
Diagnostics

## Cleanup rule
Source fixture rollback is mandatory when the source was mutated. Deletion of generated ChangeRecord/event/error records is NOT part of Manual QA unless an authoritative cleanup operation is explicitly supplied. Its absence must not block the document and must not be listed as an open gap. Use unique case-local change IDs to isolate evidence.

## Placeholder rule
Only `${BASE_URL}`, `${AUTH_HEADERS}`, and `${DATABASE_NAME}` are runtime placeholders. Every placeholder must have a capture instruction. All confirmed paths, bodies, collection roles, filters and projections must be rendered directly.

## Partial executability
A missing runtime value blocks only the exact live step; it does not justify replacing known operations with generic prose.
