# Automation artifact

Перед генерацією обов’язково прочитай у поточному execution pass:

`templates/QA_AUTOMATION_RUNNER_SPEC_TEMPLATE.yaml`

Спочатку витягни та передай у generation context:

- canonical schema;
- fixed top-level structure;
- required field names and types;
- immutable sections;
- дозволені extensions і event-specific values.

Не починай generation, доки `AUTOMATION_SPEC_TEMPLATE_LOAD_GATE` не пройдено. Якщо template недоступний, schema не витягнута або adaptation scope не визначений, заблокуй generation і покажи точну відсутню precondition.

Generate only the executable automation runner spec and validate schema, coverage, inputs, assertions, polling defaults and source rollback.

Зберігай canonical template structure. Не замінюй її model-proposed YAML layout навіть якщо альтернативна структура здається логічно еквівалентною. Дозволено змінювати лише явно adaptable event-specific values і дозволені extensions.


## Mandatory v0.8.55 automation template lock

Apply `contracts/QA_AUTOMATION_TEMPLATE_LOCK_AND_RUNNABLE_CASE_CONTRACT.yaml` and `prompts/hp.qa.automation_template_lock_and_runner_readiness.v1.md`. Rendering is template-bound only. Preserve `suite`, `environment`, `defaults`, and `test_cases`; never substitute a model-designed schema. Coverage metadata is supplemental and cannot replace runnable `test_cases`.


## Runner-contract-bound generation (v0.8.56)

Before generation, reload `runner_contract/RUNNER_SPEC_CONTRACT.yaml`, `RUNNER_CAPABILITIES.yaml`, `RUNNER_VALIDATION_RULES.yaml`, `RUNNER_ENVIRONMENT_CONTRACT.md`, and `RUNNER_CONTRACT_SOURCE.json`; verify source hashes. The immutable root schema is `suite`, `environment`, `defaults`, `test_cases`. `environment` is not a runner root key and is forbidden. Generate only fields supported by the runner. Run structural conformance and, when runner code is available, parse/dry-run validation. A reference example is not required and is not authoritative.


## Lifecycle profile fidelity (v0.8.59)

Apply `contracts/QA_AUTOMATION_TEST_LIFECYCLE_PROFILE_CONTRACT.yaml` and `prompts/hp.qa.automation_test_lifecycle_profiles.v1.md`. Classify every case before rendering, materialize the full canonical skeleton for its profile, and do not shorten `event_absent_after_change` to `change_absent` without explicit authoritative evidence. Parameter matrices must either use runner-supported iteration with a full lifecycle or be expanded into complete cases. Blocked cases use the structured blocked schema rather than null-filled runnable blocks.


## Validation/correction loop requirement (Alpha 1.16.7)
After rendering, run every required validator on the exact saved artifact. If any validator fails, do not present or approve the artifact: invalidate that version, regenerate a new version, rerun all required validators, and present only the version whose immutable receipt records PASS, return code 0, and the same SHA-256.

## Mandatory correction-loop execution

A validator FAIL is a control-flow transition, not a report-only status.

On FAIL:
1. invalidate the current artifact version;
2. record the validator IDs, artifact version and SHA-256 in `runtime/CORRECTION_REGISTRY.json`;
3. return immediately to the owning generation step;
4. create a new artifact version;
5. rerun all required validators;
6. do not continue to presentation, another artifact, cross-artifact gates or packaging while this correction remains unresolved.

Case-local identifiers used for negative, unrelated-field or duplicate-cycle fixtures must be declared explicitly as `derived_case_literals` or `derived_case_literal:` entries. Undeclared conflicting literals are forbidden.
