# Manual QA materialization v6
Render each case independently. A case may contain only its own TC/MQA identifiers. Use one deterministic operational path. If a required operation, omission semantic, repository callable, response contract, or rollback representation is not authoritative, emit a structured blocked case rather than prose.
For executable cases, every Step 0-9 must contain the exact local command/query and exact assertions. Assert projections, cardinality, field values, negative effects, and exact rollback representation. Do not use cross-case conditions or phrases such as may/when available/except another case.


## Duplicate / idempotency cases

For a duplicate, deduplication, or idempotency behavior, materialize two complete executable cycles:

1. first publish;
2. first processing decision;
3. first post-process change/event cardinality assertions;
4. second equivalent publish;
5. second processing decision;
6. final change/event cardinality assertions after the second stimulus;
7. exact negative assertion that no second event/payload was created;
8. rollback and cleanup according to proven mutation provenance.

Words such as `repeat`, `again`, or `duplicate` are not evidence of a second cycle.
If the second executable cycle is absent, mark the artifact invalid and regenerate it.


## Executable exact assertions

Narrative statements such as `Assert exact fields`, `Verify payload`, or `Expected values match`
do not count as evidence.

When expected cardinality is 1, the same case-local fenced command block must:
- query/project the complete authoritative payload;
- compare every required field to literal expected values;
- fail nonzero on mismatch.

Cardinality-only queries are invalid for created change, event, or error records.

## Fail-closed zero and rollback assertions
Zero-count and rollback verification commands must exit nonzero on mismatch.
Printing a count/value is not an assertion. Rollback must prove the exact authoritative field/value was restored.


## Canonical fail-closed examples

Forbidden pseudo-assertion:
```bash
mongosh "$DB" --eval 'db.change_errors.countDocuments({changeId:"CHG-1"})'
# assert(count === 0); exit 1 on mismatch
```

Required executable form:
```bash
mongosh "$DB" --eval '
const n = db.change_errors.countDocuments({changeId:"CHG-2026-0005"});
if (n !== 0) quit(1);
'
```

Before rendering, inspect every Step 5, 7, 8 and 9 line by line. Ignore comments when deciding whether an assertion is executable. Every query result must be compared to exact literals and must have an executable failure path.


## Validation/correction loop requirement (Alpha 1.16.7)
After rendering, run every required validator on the exact saved artifact. If any validator fails, do not present or approve the artifact: invalidate that version, regenerate a new version, rerun all required validators, and present only the version whose immutable receipt records PASS, return code 0, and the same SHA-256.

## Mandatory correction-loop execution

A validator FAIL is a control-flow transition, not a report-only status.

On FAIL:
1. invalidate the current artifact version;
2. record the validator IDs, artifact version and SHA-256 in `runtime/CORRECTION_REGISTRY.json`;
3. return immediately to the owning generation step;
4. create a new artifact version;
5. rerun all required validators;
6. do not continue to presentation, another artifact, cross-artifact gates or packaging while this correction remains unresolved.

Case-local identifiers used for negative, unrelated-field or duplicate-cycle fixtures must be declared explicitly as `derived_case_literals` or `derived_case_literal:` entries. Undeclared conflicting literals are forbidden.
