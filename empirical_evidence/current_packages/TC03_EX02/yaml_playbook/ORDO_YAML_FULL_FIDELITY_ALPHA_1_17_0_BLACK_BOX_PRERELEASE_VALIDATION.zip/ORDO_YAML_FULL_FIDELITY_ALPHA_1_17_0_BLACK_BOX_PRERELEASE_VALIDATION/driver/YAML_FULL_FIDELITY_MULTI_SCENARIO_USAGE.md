# Alpha 1.13.0 multi-scenario usage

The YAML playbook remains the fixed 126-position Alpha 1.10 process.

The Driver supplies only scenario-specific facts, corrections, approvals, and terminal readiness.
The Alpha 1.10 operational and runner contracts remain authoritative and must always be loaded for
RUN_01, RUN_02, and RUN_04.

Initialize:

```bash
python driver/semantic_analyst_driver.py --run-id <RUN_ID> --request '{"action":"start"}'
```

Ask facts needed by the current YAML position:

```bash
python driver/semantic_analyst_driver.py --run-id <RUN_ID> --request '{"action":"ask","text":"<question>"}'
```

Maintain:

`runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml`

by combining Driver-disclosed business facts with:

`scenario_overlays/FULL_FIDELITY_COMMON_OPERATIONAL_OVERLAY.yaml`

Present versioned artifacts and finish through the Driver as required.
