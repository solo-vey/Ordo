# Full Record Change Passport — RUN_04 v1

## Scope and authoritative facts
Source `source_records`, document `DOC-11990`, record `REC-220`; field `item.processingState.`; confirmed stimulus `pending` → `reviewed`; operation status `modified`; change `CHG-2026-0004`; event `RECORD_PROCESSING_STATE_CHANGED`; occurred at `2026-07-15T11:00:00Z`. Exact production rule symbol is unavailable, therefore `RULE_PROCESSING_STATE_CHANGED` is a package-local specification identifier and not a claimed repository symbol.

## Atomic unit/provider specifications
| ID | Component/rule | Covered behavior | Fixture fields | Fixture values | Invocation target | Invocation input | Positive assertions | Negative assertions | Evidence status |
|---|---|---|---|---|---|---|---|---|---|
| UNIT-001 | normalizer | normalize null/missing/empty | raw value | null, missing, empty string | normalizeProcessingState | each literal | result value equals empty string | no trimming and no case mutation; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified from Driver fact |
| UNIT-002 | normalizer | preserve case and whitespace | raw value | " Approved " | normalizeProcessingState | literal string | result value equals input exactly | must not trim or lowercase; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified from Driver fact |
| UNIT-003 | change matcher | meaningful target-field change | fieldPath, oldValue, newValue | item.processingState., pending, reviewed | evaluateChange | canonical change input | decision equals mapped true | no unrelated-field match; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified |
| UNIT-004 | change matcher | equal values no-op | fieldPath, oldValue, newValue | item.processingState., reviewed, reviewed | evaluateChange | canonical change input | decision equals false | no event candidate created; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified |
| UNIT-005 | change matcher | unrelated field no-op | fieldPath, oldValue, newValue | item.otherField, pending, reviewed | evaluateChange | canonical change input | decision equals false | must not map event; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified |
| UNIT-006 | operation gate | unsupported status no-op | operationStatus | created | evaluateChange | canonical change input | decision equals false | no change processing candidate; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified |
| UNIT-007 | event mapper | positive event payload | record_key, field_path, old/new, rule_id | REC-220, item.processingState., pending/reviewed, RULE_PROCESSING_STATE_CHANGED | mapEvent | matched change record | event count equals 1 and fields equal fixture values | error count zero; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified |
| UNIT-008 | event mapper | event date mapping | occurred_at | 2026-07-15T11:00:00Z | mapEvent | matched change record | event_date equals occurred_at | must not use execution time; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified |
| UNIT-009 | deduplicator | same change/event duplicate | change_id,event_type | CHG-2026-0004, RECORD_PROCESSING_STATE_CHANGED | deduplicate | second identical candidate | candidate decision equals duplicate false | no second event emitted; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified; exact storage policy unconfirmed |
| UNIT-010 | error mapper | no error on valid mapping | change_id,rule_id | CHG-2026-0004,RULE_PROCESSING_STATE_CHANGED | processCandidate | valid candidate | error count equals zero | no error record created; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | specified |
| UNIT-011 | omission gate | missing required field blocked | fieldPath omission | fieldPath absent | requestSchemaBinding | omitted-field candidate | blocked equals true | must not claim runnable omission; fieldPath item.processingState.; operationStatus modified; oldValue pending; newValue reviewed; event type RECORD_PROCESSING_STATE_CHANGED; count=1 | blocked missing authoritative binding |

## Functional-to-unit semantic mapping
- TC-001 -> UNIT-003, UNIT-007, UNIT-008, UNIT-010 because these units verify target-field matching, exact event payload/date, and zero errors.
- TC-002 -> UNIT-001, UNIT-004 because normalization and equality ensure no event candidate.
- TC-003 -> UNIT-005 because it verifies unrelated fields do not map.
- TC-004 -> UNIT-006 because unsupported operation status prevents persistence and processing.
- TC-005 -> UNIT-007, UNIT-009 because initial mapping and duplicate suppression ensure one event.
- TC-006 -> UNIT-011 because the behavior remains blocked until legal omission is authoritatively bound.

## Operational behavior
The Alpha 1.10 overlay supplies exact local package operations and runtime-discovered placeholders. Source mutation uses `POST /api/test/database-change/publish`; processing uses `POST /api/database-change/process`; evidence queries use the confirmed MongoDB collections. No live result is claimed.
