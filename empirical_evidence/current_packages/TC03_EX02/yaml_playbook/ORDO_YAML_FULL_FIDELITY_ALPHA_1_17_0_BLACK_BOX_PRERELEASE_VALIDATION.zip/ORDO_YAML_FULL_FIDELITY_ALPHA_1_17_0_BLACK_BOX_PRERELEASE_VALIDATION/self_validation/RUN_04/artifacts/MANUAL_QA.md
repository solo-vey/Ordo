# Manual QA Execution Specification — RUN_04

derived_case_literal: field_path=item.otherField role=negative
derived_case_literal: change_id=CHG-2026-0005 role=case_local
derived_case_literal: change_id=CHG-2026-0006 role=case_local
derived_case_literal: change_id=CHG-2026-0007 role=case_local
derived_case_literal: change_id=CHG-2026-0008 role=case_local
derived_case_literal: change_id=CHG-2026-0004-RB role=case_local
derived_case_literal: change_id=CHG-2026-0005-RB role=case_local
derived_case_literal: change_id=CHG-2026-0006-RB role=case_local
derived_case_literal: change_id=CHG-2026-0007-RB role=case_local
derived_case_literal: change_id=CHG-2026-0008-RB role=case_local

## MQA-001 — Meaningful processing-state change
Functional TC: TC-001
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0004`.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.processingState!=="pending") quit(1)'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0004"}); if(n!==0) quit(1)'
```
### Step 3. Define expected cardinalities
Expected change/event/error: 1/1/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0004","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.processingState.","oldValue":"pending","newValue":"reviewed"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.change_records.findOne({change_id:"CHG-2026-0004"}); const n=db.change_records.countDocuments({change_id:"CHG-2026-0004"}); if(n!==1||!x||x.change_id!=="CHG-2026-0004"||x.document_id!=="DOC-11990"||x.record_key!=="REC-220"||x.field_path!=="item.processingState."||x.old_value!=="pending"||x.new_value!=="reviewed"||x.operation_status!=="modified") quit(1)'
```
Expected cardinality: 1
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0004","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.generated_events.findOne({change_id:"CHG-2026-0004"}); const n=db.generated_events.countDocuments({change_id:"CHG-2026-0004",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(n!==1||!x||x.event_type!=="RECORD_PROCESSING_STATE_CHANGED"||x.event_date!=="2026-07-15T11:00:00Z"||x.record_key!=="REC-220"||x.field_path!=="item.processingState."||x.old_value!=="pending"||x.new_value!=="reviewed"||x.rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1. 
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0004"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0004-RB","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.processingState.","oldValue":"reviewed","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.otherField!=="pending") quit(1)'
```
### Final expected result
Exact cardinalities 1/1/0.

## MQA-002 — Equal normalized values are no-op
Functional TC: TC-002
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0005`.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.processingState!=="pending") quit(1)'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0005"}); if(n!==0) quit(1)'
```
### Step 3. Define expected cardinalities
Expected change/event/error: 1/0/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0005","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.processingState.","oldValue":"reviewed","newValue":"reviewed"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.change_records.findOne({change_id:"CHG-2026-0005"}); const n=db.change_records.countDocuments({change_id:"CHG-2026-0005"}); if(n!==1||!x||x.change_id!=="CHG-2026-0005"||x.document_id!=="DOC-11990"||x.record_key!=="REC-220"||x.field_path!=="item.processingState."||x.old_value!=="reviewed"||x.new_value!=="reviewed"||x.operation_status!=="modified") quit(1)'
```
Expected cardinality: 1
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0005","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0005"}); if(n!==0) quit(1)'
```
Expected cardinality: 0. 
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0005"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0005-RB","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.processingState.","oldValue":"reviewed","newValue":"reviewed"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.otherField!=="reviewed") quit(1)'
```
### Final expected result
Exact cardinalities 1/0/0.

## MQA-003 — Unrelated field is no-op
Functional TC: TC-003
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0006`.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.processingState!=="pending") quit(1)'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0006"}); if(n!==0) quit(1)'
```
### Step 3. Define expected cardinalities
Expected change/event/error: 1/0/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0006","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.otherField","oldValue":"pending","newValue":"reviewed"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.change_records.findOne({change_id:"CHG-2026-0006"}); const n=db.change_records.countDocuments({change_id:"CHG-2026-0006"}); if(n!==1||!x||x.change_id!=="CHG-2026-0006"||x.document_id!=="DOC-11990"||x.record_key!=="REC-220"||x.field_path!=="item.otherField"||x.old_value!=="pending"||x.new_value!=="reviewed"||x.operation_status!=="modified") quit(1)'
```
Expected cardinality: 1
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0006","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0006"}); if(n!==0) quit(1)'
```
Expected cardinality: 0. 
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0006"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0006-RB","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.otherField","oldValue":"reviewed","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.otherField!=="pending") quit(1)'
```
### Final expected result
Exact cardinalities 1/0/0.

## MQA-004 — Unsupported operation status is no-op
Functional TC: TC-004
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0007`.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.processingState!=="pending") quit(1)'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0007"}); if(n!==0) quit(1)'
```
### Step 3. Define expected cardinalities
Expected change/event/error: 0/0/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0007","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"created","fieldPath":"item.processingState.","oldValue":"pending","newValue":"reviewed"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_records.countDocuments({change_id:"CHG-2026-0007"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 6. Invoke processing
Not applicable: no persisted change record exists under the authoritative unsupported-status contract.
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0007"}); if(n!==0) quit(1)'
```
Expected cardinality: 0. 
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0007"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 9. Rollback and verify
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.processingState!=="pending") quit(1)'
```
Rollback not required because no source mutation persisted.
### Final expected result
Exact cardinalities 0/0/0.

## MQA-005 — Duplicate stimulus is deduplicated
Functional TC: TC-005
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0008`.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.processingState!=="pending") quit(1)'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.generated_events.countDocuments({change_id:"CHG-2026-0008"}); if(n!==0) quit(1)'
```
### Step 3. Define expected cardinalities
Expected change/event/error: 1/1/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0008","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.processingState.","oldValue":"pending","newValue":"reviewed"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.change_records.findOne({change_id:"CHG-2026-0008"}); const n=db.change_records.countDocuments({change_id:"CHG-2026-0008"}); if(n!==1||!x||x.change_id!=="CHG-2026-0008"||x.document_id!=="DOC-11990"||x.record_key!=="REC-220"||x.field_path!=="item.processingState."||x.old_value!=="pending"||x.new_value!=="reviewed"||x.operation_status!=="modified") quit(1)'
```
Expected cardinality: 1
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0008","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0008","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.processingState.","oldValue":"pending","newValue":"reviewed"}'
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0008","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Second cycle repeats the identical business payload and dedup identity.
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.generated_events.findOne({change_id:"CHG-2026-0008"}); const n=db.generated_events.countDocuments({change_id:"CHG-2026-0008",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(n!==1||!x||x.event_type!=="RECORD_PROCESSING_STATE_CHANGED"||x.event_date!=="2026-07-15T11:00:00Z"||x.record_key!=="REC-220"||x.field_path!=="item.processingState."||x.old_value!=="pending"||x.new_value!=="reviewed"||x.rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1. Final cardinality remains 1; no second event is created.
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0008"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-11990","recordKey":"REC-220","changeId":"CHG-2026-0008-RB","occurredAt":"2026-07-15T11:00:00Z","operationStatus":"modified","fieldPath":"item.processingState.","oldValue":"reviewed","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-11990"}); if(!x||x.item.otherField!=="pending") quit(1)'
```
### Final expected result
Exact cardinalities 1/1/0.

## MQA-006 — Missing required field omission case
Functional TC: TC-006
status: blocked
evidence_status: blocked
blocked_reason: authoritative omission binding is not confirmed
missing_capability: exact request schema permitting omission of the required field
required_evidence: Driver-confirmed omission binding plus canonical omitted-field request body
