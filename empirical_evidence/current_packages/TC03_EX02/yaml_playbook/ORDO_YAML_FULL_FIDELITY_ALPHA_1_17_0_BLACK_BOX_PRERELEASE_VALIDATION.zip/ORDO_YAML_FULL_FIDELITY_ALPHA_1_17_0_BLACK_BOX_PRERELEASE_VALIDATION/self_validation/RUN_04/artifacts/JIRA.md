Authoritative run identity: DOC-11990 / REC-220 / CHG-2026-0004

# Jira Delivery Task — RUN_04 v1

## Summary and business context
Deliver a complete implementation-instruction and verification package for the confirmed processing-state change without claiming unavailable repository bindings or live results.

## Delivery requirements
| ID | Requirement | Evidence |
|---|---|---|
| DEL-001 | Implement the processing-state handler for item.processingState.: validate operationStatus modified, persist exactly one change record, emit exactly one event, and create zero error records. | Passport scope |
| DEL-002 | Implement normalization in the processingState normalizer: map null, missing, and empty to empty, preserve case and whitespace, and return a no-op with exactly zero events for equal normalized values. | UNIT-001..UNIT-006 |
| DEL-003 | Implement the event mapper for RECORD_PROCESSING_STATE_CHANGED: map record key, field path, old/new values and event date, emitting exactly one event and zero errors. | UNIT-007..UNIT-010 |
| DEL-004 | Create the Manual QA execution specification with executable fail-closed assertions for exactly six cases and measurable change/event/error counts. | MANUAL_QA.md |
| DEL-005 | Create the Automation runner specification with complete publish/process payloads, two duplicate cycles, exact cardinalities, and verified rollback of item.processingState.. | AUTOMATION.yaml |
| DEL-006 | Create and validate the cross-artifact consistency registry and validator rule; block the omission case until binding evidence exists, and return a resolved consistency report with zero unresolved drift. | CASE_STATUS_REGISTRY.yaml |

## Acceptance criteria
- AC-001: Positive pending-to-reviewed stimulus yields exactly one change, one event, zero errors.
- AC-002: Given oldValue reviewed and newValue reviewed when operationStatus is modified, the processor persists exactly one change record and creates zero events and zero errors.
- AC-003: Given fieldPath item.otherField with oldValue pending and newValue reviewed when operationStatus is modified, the processor persists exactly one change record and creates zero events and zero errors.
- AC-004: Unsupported operation status yields zero changes and is not processed.
- AC-005: Duplicate publish/process stimuli yield one event and zero errors.
- AC-006: Given a missing mandatory field when the authoritative omission binding is unavailable, the package remains blocked and creates exactly zero change records, zero events, and zero errors.

## Functional delivery coverage
| Functional ID | Requirement and exact expected result | Related delivery IDs | Manual QA | Automation | Status/blocker |
|---|---|---|---|---|---|
| TC-001 | Meaningful processing-state change pending to reviewed; exact change/event/error cardinality 1/1/0 | DEL-001, AC-001 | MQA-001 | AUTO-001 | runnable |
| TC-002 | Equal normalized values are no-op; exact change/event/error cardinality 1/0/0 | DEL-002, AC-002 | MQA-002 | AUTO-002 | runnable |
| TC-003 | Unrelated field is no-op; exact change/event/error cardinality 1/0/0 | DEL-003, AC-003 | MQA-003 | AUTO-003 | runnable |
| TC-004 | Unsupported operation status is no-op before persistence; exact change/event/error cardinality 0/0/0 | DEL-004, AC-004 | MQA-004 | AUTO-004 | runnable |
| TC-005 | Duplicate stimulus is deduplicated to one event; exact change/event/error cardinality 1/1/0 | DEL-005, AC-005 | MQA-005 | AUTO-005 | runnable |
| TC-006 | Missing required field omission case; exact change/event/error cardinality 0/0/0 | DEL-006, AC-006 | MQA-006 | AUTO-006 | blocked_missing_binding |

## Test and QA references
Passport atomic specifications UNIT-001 through UNIT-011; Manual QA v1; Automation v1; runtime CASE_STATUS_REGISTRY.yaml.

## Dependencies, open questions, and closure criteria
| ID | Missing evidence/capability or question | Affected DEL/AC | Impact | Owner/discovery action | Closure criterion | Work allowed while open | Blocks |
|---|---|---|---|---|---|---|---|
| DEP-001 | Exact production repository rule symbol unavailable | DEL-001/AC-001 | Implementation binding cannot be claimed | Repository owner performs discovery | Concrete module, symbol and invocation evidence | Documentation and local-package QA specification | Production implementation |
| DEP-002 | Authoritative omission binding unavailable | DEL-006/AC-006 | Missing-field case cannot run | Contract owner supplies exact legal omitted-field body | Driver-confirmed schema and request example | Other five cases | MQA-006 and AUTO-006 |

## Definition of Done
Evidence reports and validation logs prove all runnable rows pass; every blocker has explicit closure evidence and is resolved or remains explicitly blocked; Passport, Manual QA and Automation consistency checks pass; current version-bound Driver approvals are present; no live or repository result is invented.
