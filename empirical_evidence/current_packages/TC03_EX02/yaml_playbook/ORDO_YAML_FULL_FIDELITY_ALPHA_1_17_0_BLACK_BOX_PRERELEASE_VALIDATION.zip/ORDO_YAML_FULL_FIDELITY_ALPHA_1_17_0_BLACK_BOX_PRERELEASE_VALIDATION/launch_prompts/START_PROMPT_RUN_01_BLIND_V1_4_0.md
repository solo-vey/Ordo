You are executing a blind RUN_01 test of the Ordo Database Change Full-Fidelity YAML Playbook Alpha 1.4.0 Candidate.

1. Verify `SHA256SUMS.txt`.
2. Execute all 126 steps in order.
3. Use `test_inputs/RUN_01_CONFIRMED_INPUT.yaml` as confirmed benchmark input.
4. Before each relevant node, reload its bound prompt/template and these authoritative contracts:
   - `contracts/DATABASE_CHANGE_OPERATIONAL_QA_CONTRACT.yaml`
   - `contracts/DATABASE_CHANGE_AUTOMATION_RUNNER_CONTRACT.yaml`
   - `runtime/RUNTIME_EVIDENCE_BINDING_CONTRACT.md`
5. Materialize all confirmed endpoint paths, request schemas, collection roles, query shapes and runner actions. Do not replace them with generic verbs.
6. Keep placeholders only for runtime-discovered `BASE_URL`, `AUTH_HEADERS`, and `DATABASE_NAME`, and explain how to capture them.
7. Do not invent a live environment, credentials, runner CLI or execution results.
8. Generate and finalize separately: Passport, Jira, Implementation Prompt, Manual QA, Automation Spec and package metadata.
9. Treat artifact confirmation nodes as rendered-artifact completeness/consistency checks. Do not ask for interactive approval of already confirmed RUN_01 values.
10. On revision, invalidate and regenerate downstream artifacts.
11. Do not evaluate, score, grade or compare your own documents. Do not run EN v2 scoring. We will evaluate the returned files independently.
12. Return one ZIP containing the complete generated RUN_01 package, step execution log, exact unresolved blockers (if any), validation results limited to structural/consistency checks, and SHA-256.

This is execution only, not playbook review or redesign. Do not reuse previous RUN_01 outputs.
Respond in Ukrainian.
