You are executing one blind scenario of the Ordo Database Change YAML Full-Fidelity Rebuilt Multi-Scenario Package Alpha 1.13.0.

SELECTED RUN
RUN_ID = <RUN_01|RUN_02|RUN_03|RUN_04|RUN_05>

TASK
Execute only the selected RUN_ID and return the complete result package appropriate to its authoritative terminal route.

INPUT PACKAGE
ORDO_YAML_FULL_FIDELITY_ALPHA_1_13_0_REBUILT_MULTI_SCENARIO.zip

CANONICAL PROCESS SOURCE
playbook/PLAYBOOK.yaml

BASELINE GUARANTEE
This package is rebuilt from Alpha 1.10.0. Its operational QA, automation runner, templates,
prompts, and semantic validation contracts remain authoritative unless explicitly superseded by
the Jira v3 files named in the playbook.

MANDATORY RULES
1. Replace RUN_ID with exactly one supported value.
2. Verify SHA256SUMS.txt. On mismatch stop and report NO_CHANGE.
3. Run `python validation/preflight_alpha_1_13_full_fidelity.py .`; stop on FAIL.
4. Execute the fixed 126 YAML positions in order unless the selected scenario reaches an authoritative terminal hard stop.
5. Use the bundled Driver only for scenario business facts, corrections, approvals, and terminal readiness.
6. Never open, decrypt, inspect, or infer private/scenarios or private/expected files directly.
7. For RUN_01, RUN_02, and RUN_04, combine Driver-disclosed facts with `scenario_overlays/FULL_FIDELITY_COMMON_OPERATIONAL_OVERLAY.yaml`.
8. Materialize the combined current-pass state in `runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml`.
9. Do not replace the full-fidelity operational overlay with a short semantic snapshot.
10. Runtime values BASE_URL, AUTH_HEADERS, and DATABASE_NAME may remain placeholders and do not block exact Manual QA commands or declarative Automation cases.
11. Missing production repository symbols may remain repository-discovery-bound, but do not classify all Manual QA or Automation as blocked for that reason.
12. Before every relevant node, reload its exact prompt, template, operational contract, runner contract, selected-run input, and validator.
13. Generate separately and fully validate Passport, Jira, Implementation Prompt, Manual QA, Automation Spec, package metadata, and reports when the terminal route authorizes canonical documents.
14. Jira rules: do not duplicate unit-test specifications; specific Passport references are allowed; section order is irrelevant. Require atomic delivery requirements, behavior-specific acceptance criteria, functional coverage, blocker closure criteria, and evidence-based Definition of Done.
15. Preserve Alpha 1.10 quality requirements: atomic unit/provider tests, semantic functional-to-unit mapping, case-local executable Manual QA, schema compatibility, rollback symmetry, complete runner-oriented Automation cases, full payload assertions, and a real second stimulus for duplicate behavior.
16. Do not invent endpoints, collections, fields, repository symbols, live results, or unsupported cleanup capabilities.
17. On correction, invalidate and regenerate every dependent artifact, rerun consistency checks, and obtain new version-specific approval.
18. Do not force canonical document generation after T_INPUT_BLOCKED or T_SCENARIO_EXHAUSTED.
19. Do not score or grade your own documents. Do not run EN v2 scoring. Evidence Capture Quality must not be scored.
20. Return one ZIP with all route-authorized artifacts, execution log, Driver audit evidence, structural and semantic validation results, blockers/waivers, metadata, and internal SHA256SUMS.txt.

REPORT
- selected RUN_ID;
- input-package integrity result;
- preflight result;
- completed/blocked/no-go position counts;
- terminal state;
- generated artifact list;
- corrections and invalidations;
- unresolved blockers;
- SHA-256 of the returned ZIP.

This is blind execution only, not playbook review or redesign.
Respond in Ukrainian.
