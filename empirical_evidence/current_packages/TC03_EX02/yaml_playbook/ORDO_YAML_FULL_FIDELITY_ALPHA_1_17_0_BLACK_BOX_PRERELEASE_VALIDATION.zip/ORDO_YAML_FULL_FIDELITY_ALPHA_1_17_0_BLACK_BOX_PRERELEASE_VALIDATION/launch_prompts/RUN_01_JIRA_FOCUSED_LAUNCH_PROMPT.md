# Focused blind execution — Jira task, RUN_01, Alpha 1.8.0

Execute only the Jira formation path of the YAML playbook.

1. Verify `SHA256SUMS.txt`.
2. Load `test_inputs/RUN_01_CONFIRMED_INPUT.yaml`, the final Passport, `templates/TEMPLATE_JIRA_TASK.md`, `prompts/hp.artifact.jira.generate_and_review.v2.md`, and `contracts/JIRA_SELF_CONTAINED_DELIVERY_AND_TEST_COVERAGE_CONTRACT.yaml` in this pass.
3. Treat all RUN_01 and Passport values as available confirmed inputs.
4. Generate `02_JIRA_TASK_<ALIAS>.md` from scratch.
5. Preserve every functional and unit/provider ID exactly; include full functional rows and atomic unit/provider implementation requirements.
6. Make Jira self-contained: contract snapshot, exact behavior, mapping, acceptance criteria, deliverables, QA data, dependencies, checklist and evidence-based DoD.
7. Do not score the document and do not invent implementation completion, URLs, code paths, environment bindings or test results.
8. Run only structural/consistency gates and return the rendered Jira file plus validation evidence in one ZIP.

Respond in Ukrainian.
