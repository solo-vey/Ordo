# Blind focused execution — Automation Spec / RUN_01 / Alpha 1.6.0

Execute only the Automation Spec branch of the 126-step YAML playbook using `test_inputs/RUN_01_CONFIRMED_INPUT.yaml`.

Mandatory:
1. Reload the active automation node, all bound prompts, the three automation fidelity contracts, the database-change runner contract, runtime evidence contract, and `templates/TEMPLATE_QA_AUTOMATION_SPEC.yaml` in this pass.
2. Preserve immutable root keys: `suite`, `environment`, `defaults`, `test_cases`.
3. Classify every automated functional test into exactly one lifecycle profile before rendering.
4. Materialize the full canonical lifecycle for that profile; do not shorten event absence to change absence.
5. Use confirmed endpoints, collection roles, query shapes and declarative runner actions. Keep placeholders only for BASE_URL, AUTH_HEADERS and DATABASE_NAME, with exact capture instructions.
6. Do not invent a CLI, live environment, deletion operation or execution result. Generated-record deletion is not required; use unique case-local change IDs.
7. Every automated functional test must become a complete `test_cases[]` entry or a canonical structured blocked case.
8. Run structural fidelity and runnable-case validation using `validation/validate_automation_rendered.py`.
9. Return the rendered Automation Spec and validation output only. Do not score your own artifact.

Respond in Ukrainian.
