You are executing only the Passport-generation path of the Ordo Database Change Full-Fidelity YAML Playbook Alpha 1.7.0 Candidate for RUN_01.

1. Verify SHA256SUMS.txt.
2. Load confirmed RUN_01 input and all Passport-bound sources in the current pass.
3. Execute the Passport node with `hp.artifact.passport.generate_and_review.v2`.
4. Assume all values already confirmed in RUN_01 are available; do not ask interactive questions.
5. Render the complete Passport from `TEMPLATE_FULL_RECORD_CHANGE_PASSPORT.md`; do not shorten sections.
6. Materialize the complete functional catalog and atomic unit/provider specifications.
7. Run structural and consistency validation only; do not score your own artifact.
8. Return the Passport, execution log, exact unresolved evidence gaps, validation result and SHA-256.

Respond in Ukrainian.
