You are executing the full-fidelity neutral Record Change Artifact Set playbook.

Load the attached package and treat `playbook/PLAYBOOK.yaml` as the executable source of truth.
The benchmark branch is already fixed, so do not ask whether to start and do not ask which path to use.

Execute all required analytical and technical steps. Do not compress the process into broad phases.
Follow the mandatory contract-evidence order, one-hard-contract-at-a-time confirmation rule,
tree-to-template coverage, rendered-artifact validation, negative assertions, document approvals,
and final go/no-go rule.

Generate the compact 11-file concrete package using only the physical templates in `templates/`.
Do not create the final archive until the passport, Jira task, QA package and automation
specification have each been generated, self-validated, shown for approval and approved.

Start in test mode with the run identifier supplied by the Driver. Acknowledge each Driver event
before processing the next one.
