# Шаблон Jira task

Generated filename pattern: `02_JIRA_TASK_<ALIAS>.md`.

Цей шаблон створює Jira-ready задачу для реалізації або оновлення одного `HistoryEvent`.

## 0. Правила заповнення

- Документ має бути українською.
- Technical identifiers, aliases, enum values, field names і file names не перекладаються.
- Jira task має бути похідною від підтвердженого паспорта / intake contract.
- Не вигадувати поведінку, щоб задача виглядала завершеною.
- Якщо значення не підтверджене — позначити як open question або dependency.

## 1. Summary

`<ALIAS>` — `<короткий бізнес-сенс українською>`

## 2. Business context

Описати, навіщо потрібна подія, яку бізнес-зміну вона фіксує і де користувач побачить результат.

## 3. Scope

У scope входить:

- design-time source row evidence і runtime `ChangeRecord` mapping;
- `ChangeRecord.data.status` pre-filter;
- `delta.field` check;
- `delta.old` / `delta.new` normalization;
- формування `HistoryEvent`;
- UI/localization texts;
- functional QA tests у Jira task; unit/provider та integration tests залишаються в паспорті й QA package.

## 4. Out of scope

Окремо перелічити, що не входить у задачу: міграції, unrelated fields, зміни інших aliases, зовнішні інтеграції тощо.

## 5. Confirmed contract

| Поле | Значення |
|---|---|
| Alias | `<ALIAS>` |
| `type` | `<companyHistory/profileHistory/...>` |
| `sub_type` | `<EDR/...>` |
| `source` | `<LU_AUTO_HISTORY/...>` |
| Source row path | `<item....>` |
| `ChangeRecord.data.status` allowed values | `<modified/new/deleted selection>` |
| `delta.field` | `<...>` |
| Date source | `<ChangeRecord.date or fallback/open>` |
| `source_change_id` / dedup | `ChangeRecord._id` when available |

## 6. Порядок аналізу

1. Перевірити `ChangeRecord.data.status`.
2. Якщо status не дозволений — не аналізувати `ChangeRecord` для цієї події.
3. Якщо status дозволений — перевірити `delta.field`.
4. Перевірити `normalize(delta.old) != normalize(delta.new)`.
5. Перевірити date і `source_change_id`.
6. Створити `HistoryEvent`.

## 7. Data mapping

Описати mapping у форматі таблиці:

| Target | Source | Rule |
|---|---|---|
| `source_change_id` | `ChangeRecord._id` | primary dedup/source link |
| `item.date` | `<date source>` | must be confirmed/open |
| `item.values.old#...` | `delta.old` | normalized for comparison, raw/display as confirmed |
| `item.values.new#...` | `delta.new` | normalized for comparison, raw/display as confirmed |

## 8. UI / Monitoring Center texts

Вказати `display_name.uk`, `display_name.en`, `text_template.uk`, `text_template.en` і placeholder mapping.

## 9. Acceptance criteria

### 9.1 Event creation logic

- `HistoryEvent` створюється тільки якщо `ChangeRecord.data.status` входить у allowed values.
- `HistoryEvent` створюється тільки якщо `delta.field` відповідає підтвердженому полю.
- `HistoryEvent` не створюється, якщо normalized old/new values рівні.

### 9.2 Data mapping

- `source_change_id` бере значення з `ChangeRecord._id`, коли він доступний.
- Primary dedup key не базується на `root_id + date + old/new`.
- `item.values` використовує тільки підтверджені keys.

### 9.3 Normalization and no-op behavior

- Empty/null/whitespace-only values для comparison нормалізуються в empty string.
- Empty/null old/new записуються в `HistoryEvent.item.values` як `"-"`; `"-"` не використовується для comparison normalization і не є rendering-only fallback.

### 9.4 UI texts

- `uk` і `en` templates задані явно.
- Усі placeholders точно збігаються з keys у `item.values`; `uk/en` templates мають однаковий набір; невикористані keys дозволені лише з explicit `technical_only`.

### 9.5 Functional tests

Acceptance criteria не замінюють таблицю functional tests. У Jira task потрібно включити всі підтверджені `FUNC-TC-*` як компактну таблицю. Unit/provider tests у Jira не включати.

| TC | Назва | Що тестується | Вхідні умови | Очікуваний результат | Результат | Автоматизація |
|---|---|---|---|---|---|---|
| `FUNC-TC-01` | `<...>` | `<...>` | `<...>` | `<...>` | `<create/no-op/blocked/error/open gap>` | `<yes/no>` |

Обов’язково включити всі confirmed functional tests: positive, empty → value, value → empty, empty → empty/no-op, unchanged after normalization, wrong status, wrong field, missing `_id`, missing `date`, missing `ChangeRecord.data.root_id`, duplicate same `ChangeRecord._id + item.alias`; same `ChangeRecord._id` with different aliases must create separate events.

Заборонено:

- замінювати таблицю functional tests acceptance criteria;
- включати `UNIT-TC-*` у Jira;
- пропускати confirmed `FUNC-TC-*` rows.

## 10. External references

- Confluence passport: `<provided URL or Not provided>`.
- Jira issue: `<provided URL or Not provided>`.

Не вигадувати URL.


## Test execution allocation

Functional test tables мають показувати, чи кожен `FUNC-TC-*` входить до manual QA та automation. Passport і Jira не мають губити functional tests через те, що `Manual QA = Ні`.
