# Шаблон паспорта історичної події

Generated filename pattern: `01_HISTORY_EVENT_PASSPORT_<ALIAS>.md`.

Цей шаблон використовується для створення canonical contract / Confluence-ready паспорта для одного `HistoryEvent`.

## 0. Правила заповнення

### 0.1 Призначення

Паспорт є source of truth для:

- business meaning;
- source data;
- `ChangeRecord` contract;
- `HistoryEvent` output;
- normalization;
- UI text;
- trigger / no-op behavior;
- test model;
- traceability;
- open questions.

### 0.2 Evidence labels

| Label | Значення |
|---|---|
| `actual` | безпосередньо знайдено в source artifact / code / real example |
| `analyst-confirmed` | явно підтверджено аналітиком |
| `expected` | реконструйовано для нової події й підтверджено як очікувана поведінка |
| `candidate` | запропоновано моделлю, ще не підтверджено |
| `open question` | не вирішено, не можна трактувати як final |

Не підвищувати `candidate` до final без підтвердження аналітика.

### 0.3 Contract-first rules

- Не вигадувати source paths, `delta.field`, values keys, `type`, `sub_type`, `source`, status або normalization.
- Розділяти:
  - source row path: full path under `item`, наприклад `item.bankruptcy.stateText`;
  - `ChangeRecord.delta.field`: relative path без `item.`, наприклад `bankruptcy.stateText`;
  - `HistoryEvent.item.values` key, наприклад `old#stateText`.
- Якщо фактичного `ChangeRecord` або `HistoryEvent` немає, реконструювати expected contract і позначати статус поля.
- Невідомі значення записувати як open question.

### 0.4 Обов’язкові gates перед `final-ready`

| Gate | Вимога |
|---|---|
| Source/Input gate | source row path і branch підтверджені або явно open question |
| `ChangeRecord.data.status` pre-filter gate | allowed statuses обрані людиною з `modified`, `new`, `deleted` |
| ChangeRecord delta gate | `delta.field`, `delta.old`, `delta.new` підтверджені або reconstructed expected |
| Event date gate | source для `HistoryEvent.item.date` підтверджений або open gap |
| Values gate | кожен placeholder точно збігається з confirmed `HistoryEvent.item.values` key; uk/en використовують однаковий набір; невикористані keys мають explicit `technical_only` |
| UI text gate | `uk/en` event name і `uk/en` text template підтверджені |
| Normalization gate | кожен trigger `delta.field` має окреме normalization rule |
| Test model gate | повний QA package включає unit + functional + integration tests + automation explanation |
| Traceability gate | design-time source row evidence відділено від runtime `ChangeRecord` → normalization → `HistoryEvent` → UI text → tests |

### 0.5 Мовна політика

Документ генерується українською. Technical identifiers, enum values, aliases, field names, YAML/JSON keys і file names не перекладаються.

Product/UI localization всередині event definition має зберігати `uk` і `en`.

---

# 01_HISTORY_EVENT_PASSPORT_<ALIAS>.md

## 1. Статус документа

| Поле | Значення |
|---|---|
| Alias | `<ALIAS>` |
| Статус документа | `<draft / candidate / analyst-confirmed / final-ready / blocked>` |
| Статус події | `<new / existing / partial / unknown>` |
| Evidence status | `<actual / expected / mixed / structural examples only>` |
| Останнє підтвердження аналітика | `<date or not confirmed>` |

## 2. Ідентичність події

| Поле | Значення | Статус |
|---|---|---|
| Alias | `<...>` | `<...>` |
| Event name UA | `<...>` | `<...>` |
| Event name EN | `<...>` | `<...>` |
| Business meaning | `<...>` | `<...>` |

## 3. Група Monitoring Center

| Поле | Значення | Статус |
|---|---|---|
| Group key / code | `<...>` | `<...>` |
| Group name UA | `<...>` | `<...>` |
| Group name EN | `<...>` | `<...>` |
| `groupPriority` | `<...>` | `<...>` |

## 4. Шлях у процесі та intake-відповіді

| Крок | Відповідь |
|---|---|
| Source branch | `<...>` |
| Event status | `<...>` |
| Source row path | `<...>` |
| `ChangeRecord.data.status` allowed values | `<modified/new/deleted selection>` |

## 5. Source row contract

| Поле | Значення | Статус |
|---|---|---|
| Collection | `<...>` | `<...>` |
| Source row path | `<item....>` | `<...>` |
| Source identifiers | `<root_id / dms_id / source_row_id>` | `<...>` |

## 6. `ChangeRecord` contract

| Поле | Значення | Статус |
|---|---|---|
| `ChangeRecord.data.status` field | `ChangeRecord.data.status` | `confirmed` |
| Allowed statuses | `<...>` | `analyst-confirmed` |
| `delta.field` | `<...>` | `<...>` |
| `delta.old` source | `delta.old` | `<...>` |
| `delta.new` source | `delta.new` | `<...>` |
| Date source | `<ChangeRecord.date or fallback/open>` | `<...>` |
| `source_change_id` source | `ChangeRecord._id` | `<...>` |

## 7. Порядок аналізу

1. Перевірити `ChangeRecord.data.status`.
2. Якщо status не входить у allowed values — не аналізувати цей `ChangeRecord` для події.
3. Якщо status дозволений — перевірити `delta.field`.
4. Порівняти `normalize(delta.old)` і `normalize(delta.new)`.
5. Перевірити date і `source_change_id`.
6. Сформувати candidate `HistoryEvent`.

## 8. `HistoryEvent` output contract

| Поле | Значення | Статус / source |
|---|---|---|
| `type` | `<...>` | `<...>` |
| `sub_type` | `<...>` | `<...>` |
| `source` | `<...>` | `<...>` |
| `deleted` | `false` | `auto_default_confirmed` |
| `root_id` | `<ChangeRecord.data.root_id>` | `runtime ChangeRecord-only mapping` |
| `source_change_id` | `<ChangeRecord._id>` | `<...>` |
| `item.alias` | `<ALIAS>` | `<...>` |
| `item.group` | `<...>` | `<...>` |
| `item.groupPriority` | `<...>` | `<...>` |
| `item.isEdr` | `<true/false>` | `static selected tree path rule` |
| `item.date` | `<...>` | `<...>` |
| `item.year` | `<...>` | `<...>` |

## 9. Values mapping

| `HistoryEvent.item.values` key | Source | Status |
|---|---|---|
| `old#<last_attribute_name>` | `payload_value(delta.old)`; empty/null → `"-"` | `<...>` |
| `new#<last_attribute_name>` | `payload_value(delta.new)`; empty/null → `"-"` | `<...>` |

## 10. Normalization та no-op behavior

| Field | Rule |
|---|---|
| Comparison normalization | `<trim / collapse spaces / case-insensitive / empty handling>` |
| Event condition | `normalize(delta.old) != normalize(delta.new)` |
| No-op condition | `normalize(delta.old) == normalize(delta.new)` |
| Stored values fallback | empty/null/missing/whitespace-only old/new записується в `item.values` як `"-"`; не використовується для comparison |

## 11. UI / localization texts

| Поле | Значення |
|---|---|
| `display_name.uk` | `<...>` |
| `display_name.en` | `<...>` |
| `text_template.uk` | `<...>` |
| `text_template.en` | `<...>` |

## 12. Excluded fields

Перелік полів, які не входять у payload події, із поясненням причини.

## 13. Test model summary

Цей розділ не можна замінювати коротким summary. Потрібно перенести всі підтверджені `FUNC-TC-*` і `UNIT-TC-*` як компактні таблиці.

### 13.1 Functional tests

| TC | Назва | Що тестується | Вхідні умови | Очікуваний результат | Результат | Автоматизація |
|---|---|---|---|---|---|---|
| `FUNC-TC-01` | `<...>` | `<...>` | `<...>` | `<...>` | `<create/no-op/blocked/error/open gap>` | `<yes/no>` |

Обов’язково включити всі підтверджені functional tests. Типові сценарії: positive, empty → value, value → empty, empty → empty, unchanged after normalization, wrong status, wrong field, missing `_id`, missing `date`, missing `ChangeRecord.data.root_id`, dedup.

### 13.2 Unit/provider tests

| TC | Назва | Що тестується | Вхід | Очікуваний результат | Компонент / правило |
|---|---|---|---|---|---|
| `UNIT-TC-01` | `<...>` | `<...>` | `<...>` | `<...>` | `<...>` |

Обов’язково включити всі підтверджені unit/provider tests. Типові блоки: normalization, comparison, payload fallback `"-"`, status pre-filter, trigger field, create decision, mapping, date/year extraction, `item.isEdr`, localized templates, dedup key extraction, відсутність source-row dependency.

### 13.3 Test rendering consistency

| Check | Очікування |
|---|---|
| Passport functional rows | `passport_func_ids == confirmed_func_ids` |
| Passport unit rows | `passport_unit_ids == confirmed_unit_ids` |
| Summary replacement | Заборонено |

## 14. Open questions

| Питання | Impact | Owner |
|---|---|---|
| `<...>` | `<...>` | `<...>` |


## Test execution allocation

Functional test tables мають показувати, чи кожен `FUNC-TC-*` входить до manual QA та automation. Passport і Jira не мають губити functional tests через те, що `Manual QA = Ні`.
