# Шаблон human-first manual QA runbook

Generated filename pattern: `05_QA_PACKAGE_<ALIAS>.md`.

Документ є production-ready і самодостатнім для ручного виконання. Повний технічний контракт зберігається в `MANUAL_QA_EXECUTION_SPEC`; цей runbook матеріалізує його у стабільній, читабельній формі без втрати operational content.

## 0. Непорушні правила

- Кожен TC виконується незалежно без shared operational sections.
- Mongo/REST blocks, exact assertions і rollback повторюються в кожному TC.
- Загальні QA/dev data є лише index.
- `Not applicable` потрібен лише для відсутнього operational step і завжди має причину.
- Усі step headings починаються без indentation і знаходяться поза fenced code blocks.


## Operational reconstruction policy

Manual QA runbook MUST be an operational human-first execution document. When source evidence exists, reconstruct concrete Mongo/REST flow, ChangeRecord expectations, HistoryEvent assertions, change_errors checks and rollback. Known actions MUST be rendered directly.

## Placeholder policy

Placeholders are allowed only for runtime-generated or runtime-discovered values. Every placeholder MUST identify its capture step and exact reused name. Generic operation placeholders are forbidden.

## Known operation materialization

Known endpoint, collection, lookup pattern, projection, rollback pattern and history-processing action MUST be rendered directly. If only one sub-value is unknown, preserve the known operation and use a placeholder only for that value.

## Partial executability

One missing value MUST NOT downgrade the entire runbook. Block only the exact unavailable step; retain all known operational steps.

## 1. Статус
## 2. QA/dev data — довідковий index
## 3. Загальні правила — лише policy, без executable references
## 4. Compact TC index

## 5. Canonical структура кожного TC

```markdown
## TC-XX — <назва>

### Мета
<коротка мета>

### Крок 0. Preflight baseline
<conditional full lookup/restore або Not applicable з причиною>

### Крок 1. Source lookup до action
<full Mongo block>

Очікування: <exact cardinality і values>.

### Крок 2. REST action
```http
POST /relative/example-path
Content-Type: application/json
```
```json
{ "example": "value" }
```

Очікування: <exact action result>.

### Крок 3. Source row після action
<full Mongo block + exact expectation>

### Крок 4. ChangeRecord lookup
<full lookup або exact absence/conditional branch>

### Крок 5. Запуск history processing
<compact full request або Not applicable з причиною>

### Крок 6. HistoryEvent assertion
<full lookup + exact presence/absence assertions>

### Крок 7. change_errors assertion
<full lookup + exact result>

### Крок 8. Rollback
<compact full request або Not applicable з причиною>

### Крок 9. Source row після rollback
<full Mongo block + exact baseline assertion>

### Final expected result
<короткий exact result>

### Diagnostics при невідповідності
<лише додаткові, не дубльовані queries/actions>
```

## 6. Blocking quality gates

- canonical Step 0–9 sequence complete;
- Markdown headings render correctly;
- commands and expectations are adjacent;
- request blocks are compact;
- excessive `Not applicable` absent;
- diagnostics do not duplicate main flow;
- every TC passes isolated execution;
- execution spec and runbook are semantically equivalent.

## Local operational defaults

Use HTTP 200, timeout 20 seconds, and polling interval 2 seconds. Do not request or render base URL, endpoint authentication, or generated-record cleanup. Source rollback remains required where the fixture field is changed.
