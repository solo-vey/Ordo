# Package assembly

Assemble the package only from individually generated, artifact-quality-passed and confirmed artifacts. Do not regenerate or summarize them during assembly.
