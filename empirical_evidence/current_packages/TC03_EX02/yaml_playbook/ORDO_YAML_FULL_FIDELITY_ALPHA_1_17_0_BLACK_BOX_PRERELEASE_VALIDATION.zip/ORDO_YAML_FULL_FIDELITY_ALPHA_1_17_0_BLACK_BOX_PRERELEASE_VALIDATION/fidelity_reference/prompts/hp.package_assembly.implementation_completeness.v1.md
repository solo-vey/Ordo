# Implementation completeness before package assembly

Do not treat an implementation prompt, implementation plan, Jira task, or QA specification as materialized code.

Before assembling any implementation-complete or release-candidate package:
1. Classify every artifact by role: specification, instruction, implementation, validation evidence, or manifest.
2. Verify all mandatory implementation artifact classes exist.
3. Verify changed-file and diff/commit evidence.
4. Block direct transition from implementation-prompt confirmation to package assembly or completion.
5. If code is absent, either resume at CODE_IMPLEMENTATION or truthfully label the output as analysis_package with implementation incomplete.
6. Preserve confirmed analytical artifacts during targeted recovery.


## Local package rule for this playbook

Implementation completeness does not require embedding the code package archive into the aggregate draft ZIP. The code package is a separate related artifact. Verify its existence and validation status, reference it from the manifest if needed, and keep `embedded: false`.
