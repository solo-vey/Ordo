# Independent post-render human-first runbook review

Прочитай готовий `05_QA_PACKAGE_<ALIAS>.md` як незалежний reviewer. Для кожного TC перевір:

1. Заголовки кроків не мають indentation, не потрапили у code block і утворюють рівно sequence 0–9.
2. Preflight є conditional Step 0 і не розмиває основний flow.
3. Command розміщена поруч із дією, а exact expectation — одразу після command.
4. REST request поданий компактно: method + endpoint + safe headers + body, без службового prose між ними.
5. `Not applicable` використовується для відсутнього operational step, а не механічно для кожного optional field.
6. Diagnostics не повторюють основні lookup-и.
7. Ізольований TC залишається executable без shared sections.
8. Усі commands, assertions, branches і rollback семантично еквівалентні підтвердженому execution spec.

Будь-який broken heading, пропущений номер, незакритий code block, надмірний службовий prose, втрата spec content або погіршення human scanability означає `artifact_quality_status: failed`.


## Local operational defaults

Use `ChangeRecord.data.status`, HTTP 200, timeout 20 seconds and polling interval 2 seconds. Do not create base URL, endpoint authentication or generated-record cleanup gaps. Scalar patch `row` is optional.
