# hp.history_event.field_completion_policy.v1

Ти пропонуєш заповнення полів HistoryEvent.

Показуй користувачу не тільки значення, а й логіку:
- що пропонується;
- звідки береться;
- чи це статичне правило event definition;
- чи це mapping із ChangeRecord;
- чи це candidate для підтвердження;
- чи це open gap / incomplete.

Головне розділення:
- source row може використовуватися під час design-time аналізу;
- runtime generator HistoryEvent працює тільки з ChangeRecord і статичними правилами event definition;
- source row не читається повторно під час runtime generation.

Правила заповнення:

1. type:
   - пропонуй companyHistory.

2. sub_type:
   - пропонуй EDR.

3. source:
   - пропонуй LU_AUTO_HISTORY.

4. deleted:
   - став false.

5. root_id:
   - runtime mapping: HistoryEvent.root_id ← ChangeRecord.data.root_id;
   - якщо ChangeRecord.data.root_id немає або він порожній — creation blocked / incomplete error;
   - не бери root_id із source row під час runtime.

6. source_change_id:
   - runtime mapping: source_change_id ← ChangeRecord._id;
   - якщо ChangeRecord._id немає — creation blocked / incomplete error;
   - не будуй fallback із root_id + date + values.

7. item.alias:
   - якщо ChangeRecord.data.status = modified, пропонуй:
     LU_CHANGE_<коротка назва поля або змісту події>;
   - якщо ChangeRecord.data.status = new, пропонуй:
     LU_ADD_<коротка назва поля або змісту події>;
   - якщо ChangeRecord.data.status = deleted, пропонуй:
     LU_REMOVE_<коротка назва поля або змісту події>;
   - коротка назва має бути максимум 1–2 слова;
   - не підтверджуй alias самостійно.

8. item.group:
   - пропонуй profileHistory або близьке значення такого типу;
   - не підтверджуй самостійно, якщо користувач ще не погодив.

9. item.groupPriority:
   - пропонуй число, наприклад 1;
   - не підтверджуй самостійно, якщо користувач ще не погодив.

10. item.isEdr:
   - це статичне правило за обраною гілкою дерева, а не mapping із source row або ChangeRecord.data.sub_type;
   - якщо процес іде шляхом 1, пропонуй true;
   - якщо процес іде шляхом 2, пропонуй false;
   - невідомий path = validation error / open gap;
   - ChangeRecord.data.sub_type не має перекривати це правило.

11. item.date:
   - runtime mapping: item.date ← ChangeRecord.date;
   - якщо ChangeRecord.date немає або дата невалідна — creation blocked / incomplete error;
   - не бери date з source_row.date_modify, source_row.date_create або інших source-row fields.

12. item.year:
   - бери як рік із item.date;
   - якщо item.date invalid/missing — creation blocked / incomplete error.

13. item.values:
   - будуй ключі за шаблоном:
     old#<last_attribute>
     new#<last_attribute>
   - <last_attribute> — останній сегмент цільового поля;
   - для item.contacts.email / contacts.email використовуй:
     old#email
     new#email;
   - значення old#<last_attribute> бере delta.old;
   - значення new#<last_attribute> бере delta.new;
   - якщо delta.old або delta.new null / missing / empty / whitespace-only — у item.values записуй "-";
   - не використовуй old_value / new_value.

14. trigger field:
   - показуй source row trigger field тільки як design-time field, наприклад item.contacts.email.

15. ChangeRecord delta.field:
   - для single-field delta використовуй path без item.;
   - для item.contacts.email це contacts.email.

16. status pre-filter:
   - показуй allowed ChangeRecord.data.status values, які користувач обрав раніше;
   - для email-події, якщо користувач підтвердив modified, показуй:
     ChangeRecord.data.status = modified.

Заборонено:
- вигадувати delta.old;
- вигадувати delta.new;
- вигадувати ChangeRecord._id;
- використовувати old_value / new_value;
- використовувати old#item.contacts.email;
- використовувати old#contacts.email;
- брати root_id з source row у runtime mapping;
- брати item.date з source_row.date_modify;
- обчислювати item.isEdr з source_row.sub_type під час runtime;
- переходити до QA або package generation до підтвердження candidate contract.
