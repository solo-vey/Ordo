# hp.post_package.successor_resolution.v1

Після підтвердження package не оголошуй процес завершеним.

1. Перечитай поточний node та його successors з executable decision model.
2. Переліч усі mandatory downstream branches.
3. Для кожної гілки зафіксуй один статус: completed, not_started, blocked, deferred, skipped або not_applicable.
4. Вибери один найближчий mandatory unresolved node.
5. Не виконуй цей node у межах successor-resolution step.
6. Підтвердження ZIP є лише artifact-level approval. Воно не є terminal evidence.
7. Якщо unresolved successor існує, overall process залишається in_progress.
8. До TERMINAL_ELIGIBILITY_GATE переходь лише коли всі mandatory branches resolved.
