# Local package metadata and validation reports generation

Generate the following four files in one coordinated node from the same confirmed package state:

- `README.md`
- `SUMMARY.json`
- `VALIDATION_REPORT.json`
- `CONSISTENCY_CHECK_REPORT.json`

Rules:

1. Do not split this into four confirmation steps.
2. Use the confirmed package composition, artifact statuses, validation results, and consistency findings as the only source of truth.
3. Keep version, status, included artifacts, separate related artifacts, warnings, blockers, and execution limitations identical across all four outputs.
4. `README.md` is human-readable; the three JSON files are machine-readable.
5. If any output cannot be produced consistently, block the whole node rather than publishing a partial set.
6. When any source artifact or package status changes, regenerate and revalidate all four files together.
7. This is a local History Event Analysis Playbook package rule and must not be promoted to a global APF rule without explicit approval.
