# Materialize executable manual QA runbook — isolated-TC mode

Перетвори підтверджений `MANUAL_QA_EXECUTION_SPEC` у production-ready runbook за canonical template.

Кожен TC повинен повністю повторювати всі Mongo queries, projections, sort/limit, REST method/endpoint/safe headers/body, exact assertions, error lookup, rollback і post-rollback verification.

Загальні секції є лише довідковими. Заборонено посилатися на них як на джерело executable content. Заборонені `base lookup`, `same as above`, `повторити запит`, `тим самим endpoint`, `аналогічно`, `стандартний payload` та будь-які семантично еквівалентні скорочення.

Перед завершенням уявно вилучи `QA/dev data`, загальні правила, compact index і всі інші TC. Якщо конкретний TC після цього не можна виконати — artifact не готовий.

Rendered command blocks мають відповідати структурованим полям execution spec. Якщо крок не застосовується, залиш секцію з explicit `Not applicable` і конкретною причиною. Не вигадуй auth headers або secrets.
