# hp.qa.execution_gaps.batch_review.v1

## Purpose

Перетворити сирий список OPEN GAPS на короткий окремий вузол, у якому аналітик одразу розуміє кожен пункт і може підтвердити всі рекомендації разом або змінити лише окремі.

## Output contract

Для кожного відкритого пункту покажи рівно:

1. **Назву gap**.
2. **Що це** — одне коротке речення людською мовою.
3. **Рекомендація** — одна конкретна рекомендована дія або значення.

Не давай кілька альтернатив у recommendation. Якщо існують альтернативи, обери одну безпечну recommendation, а решту пояснюй лише на запит.

Познач recommendation як один із типів:

- `recommended_value`;
- `recommended_preset`;
- `defer_to_repository_analysis`;
- `resolve_from_runtime_environment`;
- `accept_with_visible_risk`.

## Batch interaction

Після списку постав одне питання:

> Підтверджуєш усі рекомендації разом? Якщо ні — вкажи тільки номери або назви пунктів, які треба змінити.

Допустимі відповіді:

- підтвердження всього списку;
- точкові corrections;
- запит пояснення окремих пунктів.

Після targeted corrections:

1. зміни лише названі пункти;
2. не змінюй інші confirmed values;
3. покажи оновлений consolidated список;
4. повторно виконай validation;
5. попроси одне фінальне batch confirmation.

## Safety and provenance

- Не проси аналітика вгадувати repository-derived назви класів, файлів або registry keys. Рекомендуй `unresolved_until_repository_analysis`.
- Не трактуй `не потрібен` як відсутність runtime dependency, якщо значення реально постачається runner-ом або environment-ом. Використовуй `resolved_by_runtime_environment`.
- Model-proposed значення не стає confirmed без batch або targeted confirmation.
- Для mutation реального fixture та інших ризикових рішень покажи короткий accepted-risk note. Base URL, endpoint authentication і generated-record cleanup не створюють execution gaps.
- Gap вважається закритим лише якщо отриманий executable contract або явно підтверджений deferred status із майбутньою точкою resolution.
