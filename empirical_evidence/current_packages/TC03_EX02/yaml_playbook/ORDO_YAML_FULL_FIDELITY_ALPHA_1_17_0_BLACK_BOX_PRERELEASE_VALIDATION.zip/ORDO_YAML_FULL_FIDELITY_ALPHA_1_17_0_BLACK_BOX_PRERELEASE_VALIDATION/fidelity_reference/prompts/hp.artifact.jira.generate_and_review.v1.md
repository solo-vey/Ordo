# Jira artifact generation and review

Before generation, load `templates/JIRA_TASK_TEMPLATE.md` in the current execution pass.

Extract and preserve:
- all required sections;
- canonical section order;
- fixed headings and structural rules;
- immutable sections;
- task-specific adaptable fields.

Do not generate from memory, a summary, or a generic Jira layout when the bound template is available.

`JIRA_TEMPLATE_LOAD_GATE` must pass before generation. If the template cannot be loaded or the extracted template contract is missing from the generation context, block generation.

Generate only the Jira task, preserving scope, out of scope, contract, acceptance criteria and Definition of Done, then review it independently.
