# Change impact assessment

After module analysis, materialize a separate visible impact assessment before implementation planning or executor selection.

Required output:
- level: low | medium | high;
- changed components;
- contract impact;
- test impact;
- backward-compatibility risk;
- migration need;
- concise rationale.

Do not modify code. Do not select an executor. Ask for explicit human confirmation or correction.
