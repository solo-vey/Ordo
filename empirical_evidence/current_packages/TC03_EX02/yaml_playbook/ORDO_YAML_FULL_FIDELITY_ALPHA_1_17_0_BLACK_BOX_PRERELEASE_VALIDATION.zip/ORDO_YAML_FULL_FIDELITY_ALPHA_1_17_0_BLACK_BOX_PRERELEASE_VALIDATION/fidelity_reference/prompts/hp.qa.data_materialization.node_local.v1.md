# Node-local QA data materialization

Apply this guidance only on Manual QA and QA automation generation/validation nodes that reference it. Do not place it in global start instructions.

Before setting `blocked_missing_operational_data`, classify every required value using this order:

1. confirmed user value;
2. provided source Mongo record;
3. confirmed process state;
4. reconstructed ChangeRecord contract;
5. reconstructed HistoryEvent contract;
6. repository evidence;
7. safely generated test input;
8. runtime-captured placeholder;
9. true open gap.

Render all known and reconstructable values directly. Generate deterministic synthetic values only for test inputs and negative/case/trim/add/remove scenarios. Never synthesize endpoint paths, collections, field paths, payload schemas, status paths, aliases, permissions, auth, cleanup or other contract values.

Use placeholders only for values that arise during execution. Every placeholder must include the exact capture step, source field and later name.

`blocked_missing_operational_data` is allowed only after proving that the value cannot be obtained, reconstructed, safely generated as test input or captured at runtime. Premature blocking is a validation failure.
