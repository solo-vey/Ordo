# Superseded

Use `hp.qa.manual_execution_spec.v3`.
