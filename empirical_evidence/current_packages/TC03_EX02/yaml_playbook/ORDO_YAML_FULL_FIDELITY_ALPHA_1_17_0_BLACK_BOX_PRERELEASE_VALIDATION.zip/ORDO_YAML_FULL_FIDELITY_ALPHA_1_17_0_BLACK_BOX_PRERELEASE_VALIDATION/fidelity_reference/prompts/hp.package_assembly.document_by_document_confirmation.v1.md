# Document-by-document analytical package confirmation rail

Confirm separately, in canonical order:

1. `01_HISTORY_EVENT_PASSPORT_<ALIAS>.md`
2. `02_JIRA_TASK_<ALIAS>.md`
3. `04_IMPLEMENTATION_PROMPT_<ALIAS>.md`
4. `05_QA_PACKAGE_<ALIAS>.md`
5. `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml`

`07_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md` and `09_QA_AUTOMATION_README_<ALIAS>.md` are generated-only. They have no standalone confirmation node and are reviewed only through aggregate package composition and inter-document consistency.

A generic `так` or `підтверджую` applies only to the active node. Operational QA contract confirmation does not confirm the Manual QA package. Implementation-plan confirmation does not confirm the implementation prompt. Aggregate package confirmation does not confirm individual documents. Repository mutation authorization confirms none of them.

On any revision, mark the changed document `revision_requested`, all dependent downstream documents `stale_requires_reconfirmation`, aggregate composition and consistency evidence stale, and the metadata bundle `stale_requires_regeneration`. A repository mutation after document confirmation applies the same invalidation to every affected artifact.

The only final route is:

`document confirmations → aggregate composition → inter-document consistency → metadata bundle regeneration → B1_G13A → B1_P14 → FINAL_COMPLETION_SCOPE_GATE`.

No legacy package route may bypass these prerequisites.
