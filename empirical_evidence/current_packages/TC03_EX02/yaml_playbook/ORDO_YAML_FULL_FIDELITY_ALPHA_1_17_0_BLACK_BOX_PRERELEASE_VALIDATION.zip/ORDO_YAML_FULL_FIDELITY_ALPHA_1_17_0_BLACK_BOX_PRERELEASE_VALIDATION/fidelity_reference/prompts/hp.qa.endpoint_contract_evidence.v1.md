# Manual QA endpoint-contract evidence enforcement

Before generating any executable REST request, load and record an `ENDPOINT_REQUEST_CONTRACT`.

## Hard rules

- Do not infer REST request schemas from endpoint names.
- Generate an executable request only when its exact contract is supported by `confirmed_user`, `canonical_example`, `repository_derived`, or `package_confirmed` evidence.
- Every emitted request-body key must have an evidence source.
- `model_proposed`, `unknown`, or `inferred_from_endpoint_name` blocks executable materialization.
- If the schema is unknown, preserve an explicit open gap and do not emit a hypothetical payload.
- Keep source-document, ChangeRecord-delta, and REST-operation paths as separate domains unless their equivalence is evidenced.
- Reconcile canonical examples selectively: use compatible payload invariants, but keep newer confirmed package contracts such as nested `ChangeRecord.data.status`.
- Rollback must use the same evidenced endpoint contract as the action request.

## Required validation

`ENDPOINT_REFERENCED → REQUEST_SCHEMA_AVAILABLE → EVERY_BODY_KEY_EVIDENCED → PATH_SEMANTICS_CONFIRMED → ROLLBACK_CONTRACT_CONFIRMED → EXECUTABLE_REQUEST_ALLOWED`

On a defect, invalidate only action/rollback REST blocks and dependent checks using `patch_request_contract_correction_required`; preserve confirmed test cases, Mongo lookups, and business expectations.


## Confirmed concrete contracts

- For `POST /api/history`, load `contracts/HISTORY_PROCESSING_ENDPOINT_CONTRACT.yaml`. The confirmed body is exactly `{"operation":"start"}`. Invoke it only after a real ChangeRecord has been found; skip it when no ChangeRecord exists for an expected no-op.
- For error verification, load `contracts/CHANGE_ERRORS_LOOKUP_CONTRACT.yaml` and correlate by `originalChangeId: <CHANGE_ID>`.
- The canonical source example contains incorrect root-level `status`; never copy it. The current package contract remains nested `ChangeRecord.data.status`.
- Response schema may remain unknown. Use local defaults HTTP 200, polling 2 seconds and timeout 20 seconds. Base URL, auth and generated-record cleanup are removed from this process, not open gaps.

## Confirmed patch endpoint path

- The authoritative endpoint is exactly `POST /api/test/product-queue/publish-mongo-patch`.
- `/internal/api/test/product-queue/publish-mongo-patch` is a known conflicting repository reference and is not valid for this playbook.
- Do not add, infer, normalize, or preserve an `/internal` prefix.
- On any endpoint-path conflict, the explicit confirmed-user path wins and the conflicting reference must be reported as stale evidence.
- Action and rollback must use the exact same confirmed path.
