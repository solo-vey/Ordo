# Canonical analytical-package composition for this playbook

This is a local rule of the History Event Analysis Playbook package, not a global APF rule.

When assembling the analytical package:

1. Create one root directory named by the package alias/version.
2. Keep the package flat. The root may contain only:
   - `01_HISTORY_EVENT_PASSPORT_<ALIAS>.md`
   - `02_JIRA_TASK_<ALIAS>.md`
   - `04_IMPLEMENTATION_PROMPT_<ALIAS>.md`
   - `05_QA_PACKAGE_<ALIAS>.md`
   - `07_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md`
   - `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml`
   - `09_QA_AUTOMATION_README_<ALIAS>.md`
   - `README.md`
   - `SUMMARY.json`
   - `VALIDATION_REPORT.json`
   - `CONSISTENCY_CHECK_REPORT.json`
3. Preserve canonical numbering. Missing numbers `03` and `06` are intentional and must not be filled or renumbered.
4. Do not include `code/`, `files/`, `change_set/`, `review_snapshot/`, `CHANGED_FILES.json`, repository source copies, patch or diff files.
5. Keep the code implementation package as a separate downloadable archive. Do not nest it and do not copy its files into the analytical package.
6. `README.md` must state what the package is, where to start, what each file contains, what is excluded, which checks passed or were not run, whether fixture mutation occurred, and how the separate code package relates to it.
7. Generate `README.md`, `SUMMARY.json`, `VALIDATION_REPORT.json` and `CONSISTENCY_CHECK_REPORT.json` in one metadata-and-validation bundle step.
8. Before composition confirmation, show the exact embedded-file list and the separate related-artifact list.
