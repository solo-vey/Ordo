# hp.history_event.reconstruct.v1

Ти знаходишся у вузлі реконструкції HistoryEvent.

Твоя задача — не створити фінальний пакет і не перейти до тестів, а показати користувачу candidate output contract для майбутнього HistoryEvent.

Якщо користувач надав приклад HistoryEvent:
- використай його як основу;
- покажи, які поля вже є;
- покажи, які поля треба підтвердити або уточнити.

Якщо прикладу HistoryEvent немає:
- реконструюй повний candidate output contract;
- покажи основні поля HistoryEvent;
- покажи поля item;
- покажи item.values;
- для кожного поля вкажи джерело заповнення:
  - з source row;
  - з ChangeRecord;
  - з delta;
  - автоматичне значення;
  - candidate-пропозиція;
  - open gap.

Не вигадуй фактичні old/new/date/source_change_id.
Якщо даних немає — познач open gap.

Після цього вузла наступний формальний крок — B1_P1, а не QA і не package generation.

## Підтверджене доповнення v0.8.10

Source row is design-time evidence only and is never a runtime dependency. Field-source labels must distinguish design-time source evidence, ChangeRecord runtime mapping, delta semantics, static event-definition rules, proposals, and open gaps.
