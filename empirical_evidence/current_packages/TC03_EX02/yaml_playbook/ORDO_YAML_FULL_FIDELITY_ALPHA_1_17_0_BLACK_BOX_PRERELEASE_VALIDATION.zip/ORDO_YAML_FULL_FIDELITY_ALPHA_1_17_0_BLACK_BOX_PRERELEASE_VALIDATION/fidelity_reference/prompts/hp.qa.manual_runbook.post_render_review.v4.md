# Independent isolated-test-case executability review

Прочитай готовий `05_QA_PACKAGE_<ALIAS>.md` як незалежний reviewer. Перевір кожен TC окремо, ніби його скопійовано в порожній документ без shared sections.

Для кожного TC перевір:

1. Усі застосовні REST requests наведені повністю: method, endpoint, headers і body.
2. Усі Mongo lookups наведені повністю з filters, projections, sort/limit та exact assertions.
3. History trigger наведений повністю, а не фразою «запустити processing».
4. HistoryEvent assertion або absence check наведені повністю.
5. `change_errors` lookup наведений повністю.
6. Rollback містить повний executable request.
7. Post-rollback verification містить повний lookup і точне очікування.
8. Polling/timeout описані без посилань на загальні секції.
9. TC не посилається на інший TC або shared executable section.
10. Немає скорочень: «виконати lookup», «повторити вище», «як у TC-XX», «rollback до baseline» без команди.
11. Повторення однакових команд між TC не позначається як дефект.
12. Commands, assertions, branches і rollback семантично еквівалентні підтвердженому execution spec.

Будь-яке обов’язкове посилання назовні, пропущений executable block або DRY-нормалізація означає:

`artifact_quality_status: failed`

і вимагає повної матеріалізації саме проблемного TC.


## Endpoint-contract evidence enforcement

Apply `hp.qa.endpoint_contract_evidence.v1` and `contracts/ENDPOINT_REQUEST_CONTRACT.yaml`. Do not emit an executable REST body unless every key and path semantic is evidenced. Endpoint-name inference is forbidden. Unknown schema means explicit open gap, not a hypothetical payload. Action and rollback must share the same evidenced contract.


## History processing contract
Load `contracts/HISTORY_PROCESSING_ENDPOINT_CONTRACT.yaml` and `contracts/CHANGE_ERRORS_LOOKUP_CONTRACT.yaml`. Use exact `/api/history` body `{"operation":"start"}` only when a real `<CHANGE_ID>` exists. Do not carry incorrect root-level `status` from examples; use `ChangeRecord.data.status = "modified"` and Mongo filter `"data.status": "modified"`. Use local operational defaults: HTTP 200, timeout 20 seconds and polling interval 2 seconds. Base URL, endpoint authentication and generated-record cleanup are removed from this process and must not appear as open gaps. Source-field rollback remains required for state-changing fixture mutations.


## Absolute prohibition of shared executable operations

`05_QA_PACKAGE_<ALIAS>.md` MUST NOT contain a shared executable section, reusable operation catalog, common lookup catalog, common REST action block, or operational pattern section that any TC must reference. Titles or semantic equivalents of `Reusable concrete operations`, `Common operational flow`, `Shared Mongo queries`, `Common REST actions`, and `Lookup patterns` are forbidden.

Every applicable operational block MUST be repeated in full inside every TC. This duplication is mandatory. A TC may not say `Виконай Source lookup`, `Виконай ChangeRecord lookup pattern`, `Виконай History processing`, `Виконай HistoryEvent lookup`, `повтори lookup`, `як у TC-...`, `використай блок вище`, `виконай positive flow`, or any semantic equivalent instead of the exact command block.

Before a TC can pass, remove all shared sections and all other test cases. The remaining TC must still contain every applicable command directly: full `db.cards.find(...)`, full patch HTTP request, full `db.changes.find(...)`, full `POST /api/history` body, full `db.events.find(...)`, full `db.change_errors.find(...)`, full rollback request, and full post-rollback `db.cards.find(...)`. An operation heading or prose instruction without its command block is a hard validation failure.
