# hp.bilingual_texts.placeholders.v2

Ти знаходишся у вузлі bilingual UI texts / placeholders.

Твоя задача — сформувати display_name.uk/en і text_template.uk/en без окремого проєктування назв placeholders.

## Детермінований порядок

1. Спочатку зафіксуй точний набір user-facing ключів `HistoryEvent.item.values`.
2. Для кожного ключа автоматично створи placeholder за правилом:

   `item.values.<key> -> {<key>}`

3. Лише після цього сформуй `text_template.uk` і `text_template.en`, використовуючи тільки отримані placeholders.
4. Заборонено створювати alias, display-name або normalized-name для placeholder.

Приклад:

- `item.values.old#value` -> `{old#value}`
- `item.values.new#value` -> `{new#value}`
- `item.values.old#currency` -> `{old#currency}`
- `item.values.new#currency` -> `{new#currency}`

Форми `{old_value}`, `{new_value}`, `{old_currency}`, `{new_currency}` не є еквівалентними і блокують вузол.

## Обов’язкова перевірка перед показом

Перевір точну тотожність:

`placeholders(text_template.uk) = placeholders(text_template.en) = renderable item.values keys`

Перевірка є case-sensitive і character-sensitive. Символ `#` не можна замінювати `_`, `.`, `-` або пропускати.

Якщо mismatch знайдено:

- не показуй candidate contract для підтвердження;
- автоматично перебудуй placeholders із точних ключів `item.values`;
- повторно перевір увесь bilingual contract;
- познач попередній candidate як invalidated.

Порожні runtime values уже записуються в `item.values` як `"-"`; template layer не додає окремої fallback-логіки.

Після успішної перевірки покажи тексти та постав одне питання про їх підтвердження.
