# Materialize fully expanded human-first executable manual QA runbook

Перед генерацією обов’язково прочитай у поточному execution pass:

`templates/MANUAL_FUNCTIONAL_TESTS_TEMPLATE.md`

Не покладайся на назву файла, попередній summary або пам’ять про структуру. Спочатку витягни та передай у generation context:

- обов’язкові секції та їх порядок;
- fixed headings і canonical step sequence;
- immutable formatting rules;
- event-specific adaptable fields;
- правила ізольованого виконання кожного TC.

Не починай generation, доки `MANUAL_QA_RUNBOOK_TEMPLATE_LOAD_GATE` не пройдено. Якщо template недоступний або fixed contract не витягнуто, заблокуй вузол і покажи точну відсутню precondition.

Перетвори підтверджений повний `MANUAL_QA_EXECUTION_SPEC` у production-ready human-first runbook без втрати executable content.

## Нормативне правило автономності TC

Кожен test case є самостійним execution source of truth. Його має бути можливо скопіювати в окремий файл і виконати без читання shared sections або інших TC.

Тому безпосередньо всередині кожного TC повтори повністю всі застосовні блоки:

- source lookup до action;
- повний HTTP method, endpoint, headers і request body;
- source verification після action;
- повний ChangeRecord lookup із projection та exact assertions;
- повний history-processing request;
- повний HistoryEvent lookup або absence assertion;
- повний `change_errors` lookup;
- повний rollback request;
- повний post-rollback source lookup і exact assertion;
- polling/timeout rule, якщо крок асинхронний;
- diagnostics, потрібні саме цьому TC.

Заборонено використовувати як executable step:

- «виконати source lookup»;
- «запустити history processing»;
- «повторити lookup»;
- «виконати послідовність TC-XX»;
- «як у попередньому тесті»;
- «rollback до baseline» без повного payload;
- будь-яке посилання на shared command/query section замість повторення команди в TC.

Shared sections дозволені лише як довідка. Вони не можуть бути необхідними для виконання будь-якого TC. Повторення однакових REST/Mongo blocks у різних TC є обов’язковим і не вважається дефектом або надмірністю.

Збережи стабільний ритм кожного TC:

- Крок 0. Preflight baseline — лише conditional setup/restore.
- Крок 1. Source lookup до action.
- Крок 2. REST action.
- Крок 3. Source row після action.
- Крок 4. ChangeRecord lookup.
- Крок 5. Запуск history processing.
- Крок 6. HistoryEvent assertion.
- Крок 7. change_errors assertion.
- Крок 8. Rollback.
- Крок 9. Source row після rollback.
- Final expected result.
- Diagnostics при невідповідності.

Кожен heading починається без indentation і знаходиться поза code block. Method, endpoint, safe headers і body подавай одним компактним executable HTTP block. `Not applicable` використовуй лише коли відсутній цілий operational step.

Runbook може бути коротшим за execution spec лише завдяки layout, але не за рахунок shared-step references, DRY-нормалізації або втрати команд.

Якщо fixed structure template конфліктує з model-default layout, використовуй template. Адаптуй лише event-specific content.


## Endpoint-contract evidence enforcement

Apply `hp.qa.endpoint_contract_evidence.v1` and `contracts/ENDPOINT_REQUEST_CONTRACT.yaml`. Do not emit an executable REST body unless every key and path semantic is evidenced. Endpoint-name inference is forbidden. Unknown schema means explicit open gap, not a hypothetical payload. Action and rollback must share the same evidenced contract.


## History processing contract
Load `contracts/HISTORY_PROCESSING_ENDPOINT_CONTRACT.yaml` and `contracts/CHANGE_ERRORS_LOOKUP_CONTRACT.yaml`. Use exact `/api/history` body `{"operation":"start"}` only when a real `<CHANGE_ID>` exists. Do not carry incorrect root-level `status` from examples; use `ChangeRecord.data.status = "modified"` and Mongo filter `"data.status": "modified"`. Use local operational defaults: HTTP 200, timeout 20 seconds and polling interval 2 seconds. Base URL, endpoint authentication and generated-record cleanup are removed from this process and must not appear as open gaps. Source-field rollback remains required for state-changing fixture mutations.

## Mandatory operational reconstruction

Apply `hp.qa.manual_runbook.operational_reconstruction.v1` and `contracts/MANUAL_QA_OPERATIONAL_RECONSTRUCTION_CONTRACT.yaml` before rendering. Build and validate the classification table first. Materialize all confirmed Mongo/REST operations. Use placeholders only for runtime-discovered values and provide a capture instruction for each. Preserve partial executability and explicit conditional no-op branches.


## Absolute prohibition of shared executable operations

`05_QA_PACKAGE_<ALIAS>.md` MUST NOT contain a shared executable section, reusable operation catalog, common lookup catalog, common REST action block, or operational pattern section that any TC must reference. Titles or semantic equivalents of `Reusable concrete operations`, `Common operational flow`, `Shared Mongo queries`, `Common REST actions`, and `Lookup patterns` are forbidden.

Every applicable operational block MUST be repeated in full inside every TC. This duplication is mandatory. A TC may not say `Виконай Source lookup`, `Виконай ChangeRecord lookup pattern`, `Виконай History processing`, `Виконай HistoryEvent lookup`, `повтори lookup`, `як у TC-...`, `використай блок вище`, `виконай positive flow`, or any semantic equivalent instead of the exact command block.

Before a TC can pass, remove all shared sections and all other test cases. The remaining TC must still contain every applicable command directly: full `db.cards.find(...)`, full patch HTTP request, full `db.changes.find(...)`, full `POST /api/history` body, full `db.events.find(...)`, full `db.change_errors.find(...)`, full rollback request, and full post-rollback `db.cards.find(...)`. An operation heading or prose instruction without its command block is a hard validation failure.
