# hp.package_generation.test_artifact_rendering.v1

Ти знаходишся у вузлі генерації draft package з підтвердженого стану.

Твоя задача — не просто створити файли, а коректно перенести підтверджену QA/test model у потрібні артефакти.

Не переходь до запиту Confluence URL або Jira URL, доки не виконано content verification і аналітик не підтвердив згенерований draft package.

Після успішної генерації та content verification обов’язково:
1. покажи короткий склад draft package;
2. переліч заповнені секції, placeholders/open gaps і місця для references;
3. отримай явне підтвердження draft;
4. лише після цього збирай відсутні Jira/Confluence URL.
Якщо URL уже надані раніше, використай їх без повторного запиту.


## Canonical template fidelity — mandatory

`01_HISTORY_EVENT_PASSPORT_<ALIAS>.md` must be rendered directly from `templates/HISTORY_EVENT_PASSPORT_TEMPLATE.md`, and `02_JIRA_TASK_<ALIAS>.md` directly from `templates/JIRA_TASK_TEMPLATE.md`.

Do not use a short summary renderer for these documents. Preserve every canonical required section and its order. A missing value does not permit section removal: write `Open gap: ...` or `Not applicable: ...` with a reason. A heading without meaningful content fails validation.

For the passport, preserve sections for document status, identity, Monitoring Center group, intake path, Source row, ChangeRecord, analysis order, HistoryEvent output, values mapping, normalization/no-op, UI/localization, exclusions, test model, open questions, and test execution allocation.

For Jira, preserve Summary, Business context, Scope, Out of scope, Confirmed contract, analysis order, Data mapping, UI/Monitoring Center texts, Acceptance criteria, External references, and test execution allocation.

Propagate all confirmed contract fields relevant to each document, including alias, branch/source type, source row path, allowed statuses, delta field and old/new semantics, date source, source_change_id, HistoryEvent identity/group, values mapping, normalization, no-op, localization, exclusions, dedup, references, and test allocation.

`implementation_status: greenfield` may affect execution readiness only. It must never shorten passport or Jira structure.

The generation manifest must record these booleans and overall `passed` is forbidden when any is false:
- `canonical_templates_used`;
- `passport_required_sections_complete`;
- `passport_sections_meaningful`;
- `passport_contract_propagation_complete`;
- `jira_required_sections_complete`;
- `jira_sections_meaningful`;
- `jira_contract_propagation_complete`.

## Обов’язковий розподіл тестів по артефактах

1. History Event Passport:
   - включити всі підтверджені functional tests;
   - включити всі підтверджені unit/provider tests;
   - формат: компактні таблиці;
   - functional tests мають мати ID `FUNC-TC-*`;
   - unit/provider tests мають мати ID `UNIT-TC-*`.

2. Jira task:
   - включити всі підтверджені functional tests;
   - не включати unit/provider tests;
   - формат: компактна таблиця `FUNC-TC-*`;
   - acceptance criteria не замінюють таблицю functional tests.

3. QA package:
   - включити functional tests;
   - включити unit/provider tests;
   - включити integration tests;
   - формат: деталізовані executable / manual-ready cases.

## Обов’язкові колонки

Functional tests у passport/Jira мають мати компактну таблицю з колонками:

- TC;
- Назва;
- Що тестується;
- Вхідні умови;
- Очікуваний результат;
- Результат;
- Автоматизація.

Unit/provider tests у passport мають мати компактну таблицю з колонками:

- TC;
- Назва;
- Що тестується;
- Вхід;
- Очікуваний результат;
- Компонент / правило.

## Заборони

- Не замінюй тестові таблиці коротким summary.
- Не вважай acceptance criteria заміною functional test table.
- Не переходь до Confluence URL, якщо passport або Jira не містять потрібних тестових таблиць.
- Не включай `UNIT-TC-*` у Jira task.
- Не губи підтверджені test IDs при рендерингу артефактів.

## Content verification перед переходом далі

Після генерації артефактів перевір:

- `passport_func_ids == confirmed_func_ids`;
- `jira_func_ids == confirmed_func_ids`;
- `qa_package_func_ids == confirmed_func_ids`;
- `passport_unit_ids == confirmed_unit_ids`;
- `jira_unit_ids == empty`;
- `qa_package_unit_ids == confirmed_unit_ids`;
- integration tests присутні в QA package або явно позначені як not applicable з причиною.

Якщо перевірка не пройдена, не проси Confluence URL. Спочатку перегенеруй відсутні або неповні секції.


## Manual QA та Automation allocation

Перед генерацією package files має бути підтверджена test execution allocation matrix.

- Passport містить усі confirmed `FUNC-TC-*` і показує для кожного `Manual QA` та `Automation`.
- Jira містить усі confirmed `FUNC-TC-*` і показує для кожного `Manual` та `Automated`.
- `05_QA_PACKAGE_<ALIAS>.md` містить тільки ті `FUNC-TC-*`, де `Manual QA = Так`, але всі такі IDs мають бути присутні.
- Automation spec містить усі `FUNC-TC-*`, де `Automated = Так`, з рівнем автоматизації.

Не скорочуй manual QA склад під час генерації. Не використовуй приклад формату як підтверджений список manual tests.

## Manual QA package completeness

`05_QA_PACKAGE_<ALIAS>.md` має застосовувати `MANUAL_FUNCTIONAL_TESTS_TEMPLATE` і бути самодостатнім executable runbook.

Заборонено:
- створювати placeholder-only required artifact;
- писати “буде допрацьовано на наступному кроці”;
- замінювати manual runbook коротким summary;
- пропускати rollback у state-changing TC;
- використовувати “same as above”;
- вигадувати fixture identifiers;
- включати unresolved placeholders, якщо вони не позначені явно як allowed.

Додатково перевір:
- `manual_qa_ids == FUNC-TC ids where Manual QA = Так`;
- `automation_ids == FUNC-TC ids where Automated = Так`;
- Passport/Jira містять усі confirmed `FUNC-TC-*`, навіть якщо `Manual QA = Ні`.


## 08_QA_AUTOMATION_SPEC

`08_QA_AUTOMATION_SPEC_<ALIAS>.yaml` має бути виконуваною специфікацією runner-а (`executable_automation_runner_spec`).

Обов’язково застосуй `QA_AUTOMATION_RUNNER_SPEC_TEMPLATE.yaml`. Кореневі секції: `suite`, `defaults`, `test_cases`. Allocation/coverage metadata можна додати, але вони не замінюють runnable `test_cases`.

Заборонено:
- підміняти executable spec coverage matrix;
- вважати target suites та assertions достатнім сценарієм;
- ставити `automation-ready`, якщо немає setup/input, expected outcome, потрібного source rollback або polling defaults;
- пропускати automated functional tests.

## Підтверджене доповнення v0.8.10

Generate a working directory first; final zip only after post-generation gates and explicit command. Use confirmed-state priority over examples. Produce a generation manifest with rendered IDs and validation status.
