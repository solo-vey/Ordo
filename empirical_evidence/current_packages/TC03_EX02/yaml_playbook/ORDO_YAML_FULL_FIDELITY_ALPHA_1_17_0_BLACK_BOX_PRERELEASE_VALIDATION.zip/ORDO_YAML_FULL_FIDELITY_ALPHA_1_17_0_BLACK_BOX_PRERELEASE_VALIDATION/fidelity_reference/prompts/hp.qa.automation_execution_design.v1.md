# Automation execution design

Ти знаходишся у вузлі проєктування виконуваних автоматичних тестів.

Твоя задача — перетворити підтверджений розподіл тестів на повний execution contract для кожного `FUNC-TC-*`, де `Automated = Так`.

Цей вузол не генерує загальну coverage matrix замість виконуваних сценаріїв. Coverage/allocation є вхідними metadata. Основний результат — automation runner design.

Для кожного автоматизованого functional test покажи й підтвердь:
- `functional_tc`;
- майбутній `AUTO-TC-*`;
- `automation_strategy`;
- `input_mode`;
- fixture/variables source;
- setup або source lookup;
- action або synthetic input;
- ChangeRecord lookup/assignment, якщо застосовно;
- processing step, якщо застосовно;
- expected events або expected absence;
- expected errors;
- polling/timeouts для asynchronous flow з defaults `2s` / `20s`;
- rollback source field; generated-record cleanup policy не запитується;
- зв’язок із manual TC, якщо він існує.

Дозволені `automation_strategy`:
- `source_patch_flow`;
- `synthetic_change_record`;
- `provider_unit_fixture`;
- `integration_fixture`;
- `concurrency_flow`.

Обов’язкові правила:
1. Кожен `Automated = Так` повинен мати завершений execution contract.
2. `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml` є `executable_automation_runner_spec`.
3. Не замінюй runnable `test_cases` списком target suites, assertions або coverage metadata.
4. Для state-changing source patch flow обов’язково визнач rollback і post-rollback verification.
5. Для asynchronous flow використовуй `polling_interval_seconds=2` і `timeout_seconds=20`, якщо немає підтвердженого override.
6. Для no-op сценарію явно визнач, чи допустима відсутність ChangeRecord; не вигадуй `CHANGE_ID`.
7. Для blocked/unit-only сценарію дозволено synthetic input без REST flow, але expected error/result має бути явним.
8. Не позначай artifact як `automation-ready`, якщо execution contract неповний.

9. Не обирай execution mode самостійно. Після підтвердження execution contract передай процес у `B1_N5E`, де користувач окремо обирає `draft`, `automation-ready` або `execute`.
10. Не вигадуй нові runner status values. Readiness і запуск — різні рішення.

Перед переходом далі покажи компактну матрицю automation design і попроси підтвердження.

## Підтверджене доповнення v0.8.10

Authoritative runner specification: specs/QA_AUTOMATION_RUNNER_SPECIFICATION.md. Strategy must match test nature. Confirmed design does not mean YAML generated, schema passed, automation-ready, or executed.

11. Expected HTTP success status за замовчуванням `200`. Base URL, auth policy і cleanup/retention generated records не є полями цього package. Для scalar patch `row` optional.
