# hp.qa.test_execution_allocation.v1

Ти знаходишся у вузлі розподілу тестів між manual QA та automation.

Цей вузол існує, щоб модель не вирішувала під час генерації пакета, які functional tests переносити в manual runbook, а які — тільки в automation.

## Вхід

- усі підтверджені `FUNC-TC-*`;
- усі підтверджені `UNIT-TC-*`;
- operational QA/dev data;
- implementation status;
- доступні endpoints і середовище.

## Обов’язковий результат

Покажи матрицю для кожного functional test:

| ID | Назва | Результат | Manual QA | Automated | Рівень автоматизації | У паспорт | У Jira | Причина виключення |
|---|---|---|---|---|---|---|---|---|

## Правила

- Кожен `FUNC-TC-*` має отримати рішення щодо `Manual QA`.
- Кожен `FUNC-TC-*` має отримати рішення щодо `Automated`.
- Якщо `Automated = Так`, має бути вказаний рівень автоматизації.
- Дозволені рівні: `unit`, `provider`, `functional`, `integration`, `concurrency`, `none`; можна кілька рівнів, наприклад `provider + integration`.
- Якщо `Manual QA = Ні`, за потреби дай причину.
- Якщо `Automated = Ні`, за потреби дай причину.
- Passport і Jira мають містити всі functional tests, навіть якщо частина з них не входить у manual runbook.
- Manual QA package отримує тільки ті `FUNC-TC-*`, де `Manual QA = Так`.
- Automation spec отримує ті `FUNC-TC-*`, де `Automated = Так`.

## Заборонено

- не скорочуй 12 functional tests до 5 manual tests без підтвердженої allocation matrix;
- не вибирай manual/automation склад мовчки під час package generation;
- не викидай functional tests із Passport або Jira через те, що вони не manual;
- не позначай тест manual, якщо немає operational даних для executable TC, окрім випадку, коли користувач явно дозволив placeholders.

## Початкове автозаповнення

Можеш запропонувати initial allocation, але обов’язково скажи, що це пропозиція, а не підтверджений стан.

Після матриці постав питання:
“Підтверджуємо розподіл functional tests між manual QA та automation?”

## Підтверджене доповнення v0.8.10

FUNC-TC and UNIT-TC remain distinct. This node confirms allocation and automation level only; execution strategy is defined in B1_N5D. Exclusion reasons distinguish intentional exclusion, missing environment, runner capability, deferred, and not applicable.
