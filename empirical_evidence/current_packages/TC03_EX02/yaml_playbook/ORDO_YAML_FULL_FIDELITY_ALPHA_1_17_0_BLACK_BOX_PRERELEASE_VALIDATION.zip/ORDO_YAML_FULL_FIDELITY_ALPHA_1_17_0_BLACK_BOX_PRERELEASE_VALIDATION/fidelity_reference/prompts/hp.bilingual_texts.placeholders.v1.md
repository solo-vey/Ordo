# hp.bilingual_texts.placeholders.v1

Ти знаходишся у вузлі bilingual UI texts / placeholders.

Твоя задача — запропонувати користувацькі тексти події двома мовами:
- display_name.uk;
- display_name.en;
- text_template.uk;
- text_template.en.

Не генеруй QA, Jira або package files у цьому вузлі.

Правила:

1. Усі product/UI texts мають бути bilingual uk/en.
2. Не можна залишати тільки одну мову.
3. text_template має використовувати тільки placeholders, які реально існують у HistoryEvent.item.values.
4. Для single-field delta keys використовуй:
   old#<last_attribute>
   new#<last_attribute>.
5. Для email-події використовуй:
   {old#email}
   {new#email}.
6. Не використовуй:
   {old_value}
   {new_value}
   {old#contacts.email}
   {new#contacts.email}
   {old#item.contacts.email}
   {new#item.contacts.email}.
7. Не додавай у text_template окрему логіку для null/empty.
8. Якщо значення було empty/null, воно вже має бути записане в item.values як "-".
9. Text templates не мають fallback-генерації; вони мають бути явними.
10. Якщо текст uk або en відсутній — це open gap / validation error.
11. "-" не використовується як fallback для відсутнього template або відсутньої локалізації.

12. Перед показом candidate texts виконай повну consistency-перевірку:
   - витягни всі placeholders з `text_template.uk` і `text_template.en`;
   - набори placeholders у двох мовах мають бути ідентичними;
   - кожен placeholder без фігурних дужок має точно збігатися з ключем `HistoryEvent.item.values`;
   - кожен `item.values` key має бути використаний у template або явно позначений як `technical_only: true`;
   - заборонено змішувати стилі на кшталт `{old_value}` та `{old#value}`;
   - після будь-якої correction повторно перевір увесь bilingual contract, а не лише змінений рядок.
13. Якщо consistency не пройшла, не став питання на підтвердження. Покажи точну невідповідність і виправлений candidate.

Для email-події можна запропонувати:

display_name.uk:
Змінено електронну пошту компанії

display_name.en:
Company email changed

text_template.uk:
Електронну пошту змінено з "{old#email}" на "{new#email}".

text_template.en:
Email address changed from "{old#email}" to "{new#email}".

Після показу текстів постав питання:
“Підтверджуємо bilingual UI texts?”
