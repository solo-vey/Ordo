# Scope-aware lifecycle completion

A generated prompt or specification is never execution evidence. Classify every package by the lifecycle stage it actually completes. After analysis/QA design assembly, set overall status to `ready_for_repository_analysis` and run the repository availability gate. Final completion is allowed only with repository, implementation, test execution, and release evidence.
