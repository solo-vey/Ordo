# hp.normalization.stored_values_fallback.v1

Ти знаходишся у вузлі normalization / stored values fallback.

Твоя задача — визначити:
1. як порівнювати delta.old і delta.new для рішення create/no-op;
2. як підготувати значення для запису в HistoryEvent.item.values.

Не генеруй QA і не переходь до тестів, доки normalization / values fallback правила не підтверджено.

Розділяй дві різні речі:

1. Normalization for comparison.
2. Normalization for stored item.values.

Normalization for comparison:
- застосовується тільки для визначення, чи old/new змінилися;
- trim spaces;
- collapse multiple spaces;
- null / missing / empty / whitespace-only → empty string;
- для email-полів пропонуй lower-case перед порівнянням;
- "-" не має спеціального значення для comparison normalization і не використовується як fallback при порівнянні.

Event condition:
- створити HistoryEvent, якщо normalize_for_compare(delta.old) != normalize_for_compare(delta.new);
- no-op, якщо normalize_for_compare(delta.old) == normalize_for_compare(delta.new).

Empty behavior:
- empty → value = створити HistoryEvent;
- value → empty = створити HistoryEvent;
- empty → empty = no-op.

Stored item.values:
- item.values мають бути готовими для підстановки в text_template;
- якщо значення має зміст — записуй display-safe значення;
- якщо значення null / missing / empty / whitespace-only — записуй "-";
- "-" записується саме в HistoryEvent.item.values;
- template/render layer не має додатково перевіряти null/empty;
- rendering-only interpretation заборонена;
- item.values не мають зберігати порожнє семантичне значення для user-facing placeholder, якщо воно має показуватися як "-".

Для email:
- delta.old = empty → item.values.old#email = "-";
- delta.new = empty → item.values.new#email = "-";
- delta.old = "OLD@MAIL.COM" і delta.new = "old@mail.com" → no-op після comparison normalization;
- якщо event створюється, item.values мають містити готові display-safe values.

Заборонені формулювання:
- fallback "-" only at rendering;
- placeholder display fallback only;
- item.values keeps empty semantic value;
- "-" must not affect stored values.

Після пояснення постав питання:
“Підтверджуємо normalization / stored values fallback правила?”
