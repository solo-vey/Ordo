# hp.qa.manual_runbook.v1

Ти знаходишся у вузлі підтвердження manual QA runbook перед генерацією package files.

Твоя задача — показати manual QA склад і структуру до генерації `05_QA_PACKAGE_<ALIAS>.md`, щоб модель не створила заглушку і не перенесла лише частину тестів без погодження.

## Вхід

- confirmed functional tests;
- confirmed test execution allocation;
- operational QA/dev data;
- implementation status;
- manual test template rules.

## Обов’язковий результат

1. QA/dev data table.
2. Загальні правила виконання.
3. Compact manual TC index: тільки `FUNC-TC-*`, де `Manual QA = Так`.
4. Для кожного manual TC — executable structure або короткий попередній план секцій:
   - source lookup до action;
   - REST/test action;
   - source lookup після action;
   - ChangeRecord lookup або expected absence;
   - `/api/history` тільки якщо є `<CHANGE_ID>` і сценарій це дозволяє;
   - HistoryEvent lookup або expected absence;
   - `change_errors` lookup;
   - rollback;
   - source lookup після rollback.

## Правила

- `05_QA_PACKAGE_<ALIAS>.md` не може бути placeholder-only artifact.
- Не можна писати “буде допрацьовано на наступному кроці”.
- Не можна використовувати `same as above`.
- Кожен state-changing TC має rollback.
- Кожен rollback має post-rollback verification.
- Усі Mongo queries мають projection.
- Для normalization no-op scenario допустимо, що `ChangeRecord` не створиться; тоді `/api/history` не запускати і не вигадувати `<CHANGE_ID>`.
- Source row у manual QA може використовуватись для створення тестової зміни та перевірки fixture, але не є runtime mapping source для HistoryEvent generator.

## Consistency checks

Перед підтвердженням покажи:

- `manual_qa_ids == FUNC-TC ids where Manual QA = Так`;
- усі manual TC мають executable steps;
- no unresolved placeholders, якщо вони не позначені явно;
- placeholder character / old-new source / normalization узгоджені з Passport, Jira і Implementation prompt.

Після цього постав питання:
“Підтверджуємо manual QA runbook plan?”

## Підтверджене доповнення v0.8.10

Authoritative template: templates/MANUAL_FUNCTIONAL_TESTS_TEMPLATE.md. MANUAL-TC must trace to FUNC-TC. Placeholder-only artifacts are invalid. executable means data complete, not tests already run.
