# QA automation test lifecycle profiles

Before rendering or validating `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml`, classify every `AUTO-TC-*` into exactly one authoritative lifecycle profile:

- `event_created`;
- `event_absent_after_change`;
- `change_absent`;
- `blocked`;
- `parameterized`.

Do not shorten a test lifecycle on your own. A test whose expected result is “no HistoryEvent” uses `event_absent_after_change` unless the confirmed test contract explicitly requires that no ChangeRecord is created.

## Canonical lifecycle skeletons

`event_created`:

`variables → source → setup → action → change_record → processing → expected_errors → expected_events → rollback → cleanup`

`event_absent_after_change`:

`variables → source → setup → action → change_record → processing → expected_errors → expected_events_absent → rollback → cleanup`

`change_absent`:

`variables → source → setup → action → expected_change_absent → rollback → cleanup`

Use `change_absent` only when absence of ChangeRecord is an explicit authoritative expectation.

`blocked` cases must use the canonical blocked schema with structured `blocked_reason`, `missing_capability`, and `required_evidence`. Do not create a runnable skeleton filled with `null` values.

`parameterized` cases must contain a complete reusable lifecycle supported by the runner. A matrix without action, capture, processing, assertions, and rollback is not a runnable test. If the runner has no supported iteration construct, expand the matrix into complete cases.

Before confirmation, validate every case against exactly one profile. Fail on lifecycle shortening, missing required blocks, matrix-only cases, or substitution of `expected_change_absent` for a required HistoryEvent-absence assertion.
