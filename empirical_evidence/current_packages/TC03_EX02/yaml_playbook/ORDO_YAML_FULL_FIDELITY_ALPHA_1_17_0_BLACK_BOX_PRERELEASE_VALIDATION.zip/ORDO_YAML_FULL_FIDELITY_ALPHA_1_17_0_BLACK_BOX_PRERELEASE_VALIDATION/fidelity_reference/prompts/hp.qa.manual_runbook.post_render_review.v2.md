# Independent post-render isolated-TC review

Прочитай готовий `05_QA_PACKAGE_<ALIAS>.md` як незалежний reviewer. Для кожного TC окремо:

1. Ізолюй лише текст цього TC.
2. Вилучи `QA/dev data`, загальні правила, compact index та всі інші TC.
3. Перевір наявність повних Mongo commands з projection/sort/limit, REST method/endpoint/safe headers/body, exact assertions, ChangeRecord/HistoryEvent/error lookup, rollback і post-rollback verification або explicit `Not applicable` з причиною.
4. Перевір відповідність rendered blocks структурованому execution spec.
5. Виявляй не тільки заборонені фрази, а будь-яку залежність від shared/base operational content.

Хоча б один reference-only, inconsistent або silently omitted step означає `artifact_quality_status: failed`.
