# Passport artifact generation and review

Before generation, load `templates/HISTORY_EVENT_PASSPORT_TEMPLATE.md` in the current execution pass.

Extract and preserve:
- all required sections;
- canonical section order;
- fixed headings and structural rules;
- immutable sections;
- event-specific adaptable fields.

Do not generate from memory, a summary, or a generic passport layout when the bound template is available.

`PASSPORT_TEMPLATE_LOAD_GATE` must pass before generation. If the template cannot be loaded or the extracted template contract is missing from the generation context, block generation.

Generate only the passport, map confirmed values into the allowed adaptable fields, preserve every required section, then run artifact-specific semantic review.
