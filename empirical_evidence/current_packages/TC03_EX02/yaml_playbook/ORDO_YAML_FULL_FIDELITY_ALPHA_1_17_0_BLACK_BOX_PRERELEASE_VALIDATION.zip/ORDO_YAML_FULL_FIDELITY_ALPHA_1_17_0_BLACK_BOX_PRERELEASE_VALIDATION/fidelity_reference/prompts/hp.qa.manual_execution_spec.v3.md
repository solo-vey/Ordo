# Manual QA execution spec — template-bound generation

Створи повний `MANUAL_QA_EXECUTION_SPEC` для кожного `MANUAL-TC`, але перед будь-якою генерацією обов'язково завантаж прив'язаний реальний manual QA template/reference artifact.

## Обов'язковий pre-generation flow

```text
LOAD_ATTACHED_MANUAL_QA_TEMPLATE
→ EXTRACT_FIXED_CONTRACT
→ DEFINE_ADAPTATION_SCOPE
→ MANUAL_QA_TEMPLATE_LOAD_GATE
→ GENERATE_MANUAL_QA_EXECUTION_SPEC
```

## Blocking rule

Якщо reference template доступний, заборонено реконструювати fixed REST, Mongo, trigger, identifier, storage, fallback або error-lookup contract із пам'яті, загальних знань чи типових практик.

Якщо template не завантажено або fixed contract не витягнуто, generation блокується. Не створюй candidate payload для заміни пропущеного template-read pass.

## Що витягнути з template до generation

Зафіксуй у generation context:

- exact REST method, endpoint, safe headers і request-body shape;
- exact Mongo database/collection, filter, projection, sort і identifier representation;
- processing trigger contract;
- error lookup contract;
- rollback shape;
- exact fallback/formatting conventions;
- immutable sections template;
- adaptable event-specific fields.

## Adaptation scope

Дозволено змінювати лише явно event-specific частини, наприклад:

- target path/field;
- alias;
- fixture identifiers;
- test values;
- expected event-specific assertions.

Fixed transport/storage/query structure з template має залишатися без семантичних змін.

## Поведінка після виявлення пропущеного template

Якщо раніше сформований candidate contract суперечить template:

1. інвалідуй увесь залежний непідтверджений execution contract;
2. повторно завантаж template;
3. заново витягни fixed contract;
4. повторно виконай adaptation;
5. повторно запусти всі залежні validation gates.

Локального виправлення одного рядка недостатньо, якщо помилка могла вплинути на інші REST/Mongo/trigger/error блоки.

## Самодостатність кожного TC

Кожен TC повинен містити повністю матеріалізовані concrete Mongo/REST steps, exact assertions, conditional branches, error checks, rollback і post-rollback verification. Заборонено посилатися на shared/base/common executable sections.

## Quality condition

Execution spec не готовий, якщо:

- template не прочитаний у поточному generation pass;
- fixed contract не передано в generation context;
- immutable/adaptable sections не визначені;
- output містить model-generated structure замість template structure;
- хоча б один TC не можна виконати ізольовано.


## Endpoint-contract evidence enforcement

Apply `hp.qa.endpoint_contract_evidence.v1` and `contracts/ENDPOINT_REQUEST_CONTRACT.yaml`. Do not emit an executable REST body unless every key and path semantic is evidenced. Endpoint-name inference is forbidden. Unknown schema means explicit open gap, not a hypothetical payload. Action and rollback must share the same evidenced contract.


## History processing contract
Load `contracts/HISTORY_PROCESSING_ENDPOINT_CONTRACT.yaml` and `contracts/CHANGE_ERRORS_LOOKUP_CONTRACT.yaml`. Use exact `/api/history` body `{"operation":"start"}` only when a real `<CHANGE_ID>` exists. Do not carry incorrect root-level `status` from examples; use `ChangeRecord.data.status = "modified"` and Mongo filter `"data.status": "modified"`. Use HTTP 200, timeout 20 seconds and polling interval 2 seconds as local defaults. Do not ask for base URL, auth policy or generated-record cleanup. For scalar patch operations[].row is optional.
