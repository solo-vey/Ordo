# QA automation runner-contract-bound generation

1. Reload and verify the versioned Runner Contract Bundle.
2. Lock root schema to `suite/environment/defaults/test_cases`.
3. Build each case from confirmed automation scope using only runner-supported sections and step types.
4. Render known operations directly; runtime variables use runner `$NAME` semantics and must be defined, assigned, or runner-generated.
5. Do not place secrets or headers in YAML.
6. Use `expected_change_absent` for supported no-op flows without inventing `$CHANGE_ID`.
7. Validate structural fidelity, runnable-case completeness, contract drift and runner conformance before confirmation.


## Node-local data materialization requirement

Reload `contracts/QA_DATA_MATERIALIZATION_POLICY.yaml` in the current node pass. Use provided source records, confirmed state and reconstructed ChangeRecord/HistoryEvent contracts before declaring data missing. Generate safe deterministic test inputs where allowed. Use capture placeholders for runtime values. `blocked_missing_operational_data` is valid only for a proven true open gap.


## Lifecycle profile fidelity (v0.8.59)

Apply `contracts/QA_AUTOMATION_TEST_LIFECYCLE_PROFILE_CONTRACT.yaml` and `prompts/hp.qa.automation_test_lifecycle_profiles.v1.md`. Classify every case before rendering, materialize the full canonical skeleton for its profile, and do not shorten `event_absent_after_change` to `change_absent` without explicit authoritative evidence. Parameter matrices must either use runner-supported iteration with a full lifecycle or be expanded into complete cases. Blocked cases use the structured blocked schema rather than null-filled runnable blocks.
