# Implementation prompt generation and dry check

## Purpose

Створити один універсальний implementation / verification prompt, придатний і для AI coding model, і для розробника, до вибору виконавця змін.

## Input

- результат аналізу архіву модуля;
- підтверджений контракт HistoryEvent;
- Jira URL, якщо надано;
- Confluence URL, якщо надано;
- відомі обмеження проєкту та доступні способи перевірки.

## Required prompt structure

1. Контекст: greenfield, verification або alignment існуючої реалізації.
2. Jira / Confluence references без вигаданих URL.
3. Підтверджений контракт події.
4. Що перевірити або змінити в коді.
5. Які файли, класи, provider registration і docs входять у scope.
6. Unit/provider test scenarios з ID, коли вони відомі.
7. Документація, яку треба створити або оновити.
8. Вимога зафіксувати Jira/Confluence references у rule class documentation, test documentation і event passport, якщо ці артефакти змінюються або створюються.
9. Заборонені зміни та компоненти поза scope.
10. Acceptance criteria.
11. Доступні команди або способи перевірки.
12. Очікуваний формат результату.

## Scope discipline

- Не читати весь проєкт без потреби.
- Працювати тільки з релевантними rule/provider/tests/docs файлами.
- Не розширювати scope непомітно.
- Якщо під час реалізації потрібні суттєво ширші зміни, зупинитися й повернути їх на окреме погодження.

## Dry check

Перед вибором виконавця перевірити, що prompt:

- конкретний і однозначний;
- містить достатній контекст для іншої моделі або розробника;
- визначає дозволену область змін і заборони;
- містить тести, documentation updates та acceptance criteria;
- зберігає Jira/Confluence traceability, якщо посилання були надані;
- не вимагає вигаданих URL, даних або результатів тестів;
- має перевірюваний очікуваний результат.

Якщо dry check не пройдено, prompt потрібно виправити до показу вибору executor-а.
