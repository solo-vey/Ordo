# Implementation prompt artifact generation and review

Before generation, load `templates/IMPLEMENTATION_PROMPT_TEMPLATE.md` in the current execution pass.

Extract and preserve:
- required sections and their canonical order;
- required references;
- required constraints and prohibitions;
- immutable structure;
- implementation-specific adaptable fields.

Do not generate from memory, a summary, or a generic implementation-prompt format when the bound template is available.

`IMPLEMENTATION_PROMPT_TEMPLATE_LOAD_GATE` must pass before generation. If the template cannot be loaded or the extracted template contract is missing from the generation context, block generation.

Generate only the implementation prompt, map confirmed implementation context into the allowed fields, preserve required references and constraints, then run an independent dry check and artifact-specific quality review.
