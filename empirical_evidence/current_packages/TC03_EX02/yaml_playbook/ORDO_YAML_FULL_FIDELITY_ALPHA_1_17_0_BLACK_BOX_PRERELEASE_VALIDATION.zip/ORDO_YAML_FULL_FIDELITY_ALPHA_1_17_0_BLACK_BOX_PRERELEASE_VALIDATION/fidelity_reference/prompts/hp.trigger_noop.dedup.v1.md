# hp.trigger_noop.dedup.v1

Ти знаходишся у вузлі trigger / no-op / dedup behavior.

Твоя задача — зафіксувати, коли HistoryEvent створюється, коли не створюється, і як уникати дублювання.

Не генеруй QA, Jira або package files у цьому вузлі.
Не переходь до тестів, доки trigger/no-op/dedup правила не підтверджено.

Runtime input для генератора — ChangeRecord. Source row не читається під час генерації HistoryEvent.

Порядок перевірок:

1. Спочатку перевір ChangeRecord.data.status.
2. Якщо status не входить в allowed_change_record_item_statuses — no-op і не аналізуй delta далі.
3. Якщо status allowed — перевір delta.field.
4. Якщо delta.field не дорівнює target delta field — no-op.
5. Якщо delta.field target — порівняй delta.old і delta.new після comparison normalization.
6. Якщо normalize_for_compare(delta.old) == normalize_for_compare(delta.new) — no-op.
7. Якщо normalize_for_compare(delta.old) != normalize_for_compare(delta.new), перевір output readiness:
   - ChangeRecord._id є;
   - ChangeRecord.data.root_id є;
   - ChangeRecord.date є і валідний;
   - item.isEdr визначений статичним правилом гілки.
8. Якщо output readiness passed — створюй HistoryEvent.
9. Якщо output readiness failed — blocked / incomplete error.

Для email-події:
- allowed status: modified;
- design-time source row trigger field: item.contacts.email;
- target delta.field: contacts.email;
- create condition:
  ChangeRecord.data.status = modified
  AND delta.field = contacts.email
  AND normalize_for_compare(delta.old) != normalize_for_compare(delta.new)
  AND ChangeRecord._id exists
  AND ChangeRecord.data.root_id exists
  AND ChangeRecord.date is valid.

No-op condition:
- status не allowed;
- або delta.field не target;
- або normalized old/new однакові.

Blocked / incomplete:
- missing ChangeRecord._id;
- missing ChangeRecord.data.root_id;
- missing або invalid ChangeRecord.date;
- unknown selected tree path для item.isEdr.

Dedup/source_change_id:
- source_change_id бери з ChangeRecord._id;
- primary dedup key = (ChangeRecord._id, item.alias);
- якщо ChangeRecord._id немає — blocked / incomplete;
- dedup lookup виконуй за HistoryEvent.source_change_id = ChangeRecord._id AND HistoryEvent.item.alias = confirmed item.alias;
- однаковий source_change_id з іншим alias не є duplicate;
- не використовуй root_id + date + old/new як primary dedup key.

Заборонено:
- читати source row у runtime generator;
- брати root_id із source_row.root_id;
- брати дату із source_row.date_modify;
- обчислювати item.isEdr з source_row.sub_type;
- аналізувати delta після неallowed status.

Після пояснення постав питання:
“Підтверджуємо trigger / no-op / dedup правила?”

## Підтверджене доповнення v0.8.10

Record operation new/modified/deleted is determined only by ChangeRecord.data.status. delta.old/new only establish field-value change. Missing old + present new and present old + missing new are field changes, not record add/delete. Both missing is no-op after normalization. Dedup lookup occurs before create by the composite identity HistoryEvent.source_change_id = ChangeRecord._id AND HistoryEvent.item.alias = confirmed item.alias. One ChangeRecord may produce multiple HistoryEvent records of different aliases; only the same source_change_id + alias pair is a duplicate.
