# Materialize human-first executable manual QA runbook

Перед генерацією обов’язково прочитай у поточному execution pass:

`templates/MANUAL_FUNCTIONAL_TESTS_TEMPLATE.md`

Не покладайся на назву файла, попередній summary або пам’ять про структуру. Спочатку витягни та передай у generation context:

- обов’язкові секції та їх порядок;
- fixed headings і canonical step sequence;
- immutable formatting rules;
- event-specific adaptable fields;
- правила ізольованого виконання кожного TC.

Не починай generation, доки `MANUAL_QA_RUNBOOK_TEMPLATE_LOAD_GATE` не пройдено. Якщо template недоступний або fixed contract не витягнуто, заблокуй вузол і покажи точну відсутню precondition.

Перетвори підтверджений повний `MANUAL_QA_EXECUTION_SPEC` у компактний production-ready human-first runbook. Не копіюй структуру внутрішнього contract дослівно. Збережи всі Mongo/REST commands, branches, exact assertions, rollback і diagnostics, але подай їх у стабільному ритмі кожного TC:

- Крок 0. Preflight baseline — лише conditional setup/restore.
- Крок 1. Source lookup до action.
- Крок 2. REST action.
- Крок 3. Source row після action.
- Крок 4. ChangeRecord lookup.
- Крок 5. Запуск history processing.
- Крок 6. HistoryEvent assertion.
- Крок 7. change_errors assertion.
- Крок 8. Rollback.
- Крок 9. Source row після rollback.
- Final expected result.
- Diagnostics при невідповідності.

Кожен heading починається без indentation і знаходиться поза code block. Method, endpoint, safe headers і body подавай одним компактним executable HTTP block. `Not applicable` використовуй лише коли відсутній цілий operational step; не повторюй його для необов’язкових header fields. Base URL і endpoint authentication не є частиною цього package та не описуються.

Кожен TC залишається повністю ізольованим: усі queries, projections, payloads, assertions і rollback повторюються. Diagnostics не дублюють основні lookup-и, а додають лише поглиблені перевірки. Runbook може бути коротшим за execution spec лише завдяки layout, а не втраті змісту.

Якщо fixed structure template конфліктує з model-default layout, використовуй template. Адаптуй лише event-specific content.


## Local operational defaults

Use `ChangeRecord.data.status`, HTTP 200, timeout 20 seconds and polling interval 2 seconds. Do not create base URL, endpoint authentication or generated-record cleanup gaps. Scalar patch `row` is optional.
