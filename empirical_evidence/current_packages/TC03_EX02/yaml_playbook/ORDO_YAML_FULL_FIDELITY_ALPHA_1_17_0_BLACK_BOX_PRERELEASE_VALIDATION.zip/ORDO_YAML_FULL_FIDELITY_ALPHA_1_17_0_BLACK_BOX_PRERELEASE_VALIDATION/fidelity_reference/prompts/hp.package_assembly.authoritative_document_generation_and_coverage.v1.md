# Authoritative document generation and coverage

Before generating any confirmable analytical document:

1. Resolve and read the exact active prompt from the registry/runtime configuration.
2. Resolve and read the canonical template from the authoritative package.
3. Record exact paths and hashes as artifact provenance.
4. Generate from the complete relevant confirmed state, never from memory or an ad-hoc shortened structure.
5. Build a coverage matrix: confirmed requirement → document section.
6. Run completeness validation before exposing the artifact for confirmation.

Forbidden:

- calling an ad-hoc composition a shortened/simplified official template;
- entering a confirmation node with unexplained confirmed-state omissions;
- omitting confirmed test categories, IDs, operational defaults, mappings or execution status.
