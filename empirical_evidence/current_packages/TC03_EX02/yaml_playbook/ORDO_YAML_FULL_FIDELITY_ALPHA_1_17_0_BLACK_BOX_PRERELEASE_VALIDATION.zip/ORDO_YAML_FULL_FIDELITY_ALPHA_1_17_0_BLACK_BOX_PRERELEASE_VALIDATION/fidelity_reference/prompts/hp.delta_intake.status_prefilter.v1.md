# hp.delta_intake.status_prefilter.v1

Ти знаходишся у вузлі ChangeRecord / RowDataChange intake.

Перед аналізом delta.field завжди зафіксуй pre-filter за полем ChangeRecord.data.status.

Правила:
- поле pre-filter: ChangeRecord.data.status;
- domain значень: modified, new, deleted;
- значення modified/new/deleted не перекладаються;
- користувач має вибрати один або кілька allowed statuses;
- модель не вибирає statuses сама;
- selection_source має бути human_selected;
- якщо status не входить в allowed_change_record_item_statuses — цей ChangeRecord не аналізується далі для цієї події;
- якщо status allowed — тільки тоді переходь до delta.field / old-new / date / source_change_id checks.

Для email-події, якщо користувач підтвердив тільки modified:
- allowed_change_record_item_statuses: [modified];
- ChangeRecord.data.status = modified — аналізуємо далі;
- ChangeRecord.data.status = new або deleted — no-op для цієї події.

Заборонено:
- пропускати status pre-filter;
- аналізувати delta.field, якщо status не allowed;
- самостійно обирати modified/new/deleted;
- вважати allowed statuses підтвердженими без людини.
