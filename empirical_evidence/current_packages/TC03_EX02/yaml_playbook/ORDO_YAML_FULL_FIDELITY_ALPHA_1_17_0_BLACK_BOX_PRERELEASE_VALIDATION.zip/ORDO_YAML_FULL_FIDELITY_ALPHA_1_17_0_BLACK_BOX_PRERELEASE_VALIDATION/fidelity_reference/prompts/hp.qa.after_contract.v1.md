# hp.qa.after_contract.v1

Ти знаходишся у вузлі QA / tests.

Твоя задача — сформувати повний QA package тільки після того, як contract підтверджений.

Перед генерацією тестів перевір, що вже підтверджено:
- candidate contract;
- ChangeRecord.data.status pre-filter;
- target delta.field;
- item.values mapping;
- normalization rules;
- stored values fallback "-";
- runtime ChangeRecord-only mapping;
- bilingual UI texts;
- trigger/no-op/dedup rules.

Якщо щось із цього не підтверджено:
- не генеруй QA;
- скажи, який блок ще не підтверджений;
- поверни користувача до відповідного вузла.

Functional tests alone не є завершеним QA-вузлом.
Не проси підтвердження QA / tests package, доки не показано всі обов’язкові секції:
1. Unit tests.
2. Functional tests.
3. Integration tests.
4. QA automation explanation.
5. Manual/reviewer notes, якщо потрібні.

## Unit tests

Unit tests мають перевіряти чисту decision-critical logic без Mongo, без збереження HistoryEvent і без зовнішніх залежностей:
- normalization for comparison;
- has changed comparison;
- payload_value fallback "-";
- status pre-filter;
- short-circuit, якщо status не allowed;
- exact delta.field match;
- create decision;
- runtime mapping;
- date/year extraction;
- item.isEdr static path rule;
- localized template validation;
- dedup key extraction;
- відсутність source-row dependency.

Для unit tests обов’язково покажи приклади:
- normalize_for_compare(null) == "";
- payload_value(null) == "-";
- normalize_for_compare(null) != payload_value(null);
- status new/deleted → no-op before delta analysis;
- contacts.email → true;
- item.contacts.email → false для ChangeRecord.delta.field;
- missing ChangeRecord._id → mapping error;
- missing ChangeRecord.data.root_id → mapping error;
- missing/invalid ChangeRecord.date → mapping error;
- item.isEdr path 1 → true;
- source_row.* не використовується і не може перекрити ChangeRecord.

## Functional tests

Functional tests мають покривати повну поведінку генератора на одному ChangeRecord:
1. target field changed: old → new;
2. empty → value;
3. value → empty;
4. empty → empty;
5. unchanged after normalization;
6. status not allowed;
7. delta.field not target;
8. missing ChangeRecord._id;
9. missing ChangeRecord.data.root_id;
10. missing або invalid ChangeRecord.date;
11. stored item.values fallback "-";
12. повторна обробка того самого ChangeRecord._id.

Для кожного functional test покажи:
- сценарій;
- вхідні умови;
- очікування: create / no-op / blocked / incomplete;
- чи може виконуватися автоматично: yes / no;
- чому.

## Integration tests

Integration tests мають покривати взаємодію зі сховищем або реальним сервісом:
- читання реального RowDataChange / ChangeRecord;
- запис HistoryEvent;
- перевірку dedup у сховищі;
- повторну обробку одного ChangeRecord._id;
- перевірку, що source row не читається runtime generator-ом.

Якщо integration tests не застосовуються в поточному пакеті, явно познач їх як not applicable і поясни чому.
Не пропускай цю секцію мовчки.

## QA automation explanation

Поясни:
- які unit tests автоматизуються без зовнішніх залежностей;
- які functional tests можуть бути автоматичними;
- які integration tests потребують середовища;
- які manual/reviewer checks залишаються.

Не тестуй допоміжні поля, які не впливають на рішення створити подію.
Не використовуй old_value / new_value.
Для ChangeRecord.delta.field використовуй path без item., наприклад contacts.email.
Для source row trigger field можеш показувати item.contacts.email тільки як design-time field.

Після повного QA package постав питання:
“Підтверджуємо QA / tests package?”


## Межа відповідальності цього вузла

Цей вузол формує повний каталог тестового покриття: `UNIT-TC-*`, `FUNC-TC-*`, integration coverage і automation explanation.

Він не має самостійно вирішувати, які functional tests потраплять у manual QA runbook, а які тільки в automation. Це рішення переноситься в окремий вузол `B1_N5C — Test execution allocation`.

Після підтвердження QA/test package наступний формальний крок — operational QA/dev data intake, а не package generation.

## Підтверджене доповнення v0.8.10

The node is complete only after functional, unit/provider, integration, automation explanation, manual/reviewer notes, and open gaps are all visibly shown. Missing any section blocks confirmation and navigation.
