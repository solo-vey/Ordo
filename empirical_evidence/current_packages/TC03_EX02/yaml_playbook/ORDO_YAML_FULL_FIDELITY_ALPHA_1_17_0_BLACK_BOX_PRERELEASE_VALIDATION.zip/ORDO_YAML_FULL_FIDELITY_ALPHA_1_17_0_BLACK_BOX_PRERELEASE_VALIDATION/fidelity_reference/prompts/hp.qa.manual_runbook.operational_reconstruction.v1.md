# Operational reconstruction for human-first Manual QA runbook

Before rendering `05_QA_PACKAGE_<ALIAS>.md`, reread the active Manual QA template, execution spec, endpoint contracts, source fixture evidence and validation profiles in the current node pass.

Build a classification table for every value and operation:

1. confirmed static value;
2. confirmed operational action;
3. runtime-discovered value;
4. open gap;
5. forbidden or not required.

Rules:

- Render confirmed static values directly.
- Render confirmed operational actions directly.
- Use placeholders only for runtime-discovered values.
- Every placeholder must state where and when it is captured and its exact later name.
- Generic action placeholders such as `<PROCESSING_ACTION>`, `<LOOKUP_ACTION>`, `<ERROR_LOOKUP_ACTION>`, `<ROLLBACK_ACTION>`, `<SOURCE_QUERY>` and `<HISTORY_QUERY>` are forbidden.
- Materialize known Mongo queries, relative REST endpoints, payloads, assertions, polling, rollback and post-rollback verification.
- Preserve known operation structure when only one sub-value is unknown.
- One missing runtime value blocks only the affected step, not the whole runbook.
- Negative/no-op tests must explicitly branch when ChangeRecord may legitimately be absent.
- A source Mongo record must drive concrete lookup, baseline, mutation, expected ChangeRecord, expected HistoryEvent and rollback values when non-contradictory.
- Do not infer endpoint prefixes, auth, cleanup, row values, database names, collection names or payload keys.
- For scalar fields, omit `operations[].row` unless exact evidence requires it.
- Use the exact confirmed fallback symbol consistently across all artifacts.

Each TC must independently materialize Step 0 through Step 9, final expected result, diagnostics and evidence. `Not applicable` is allowed only for a specific inapplicable step and must include the exact reason.


## Absolute prohibition of shared executable operations

`05_QA_PACKAGE_<ALIAS>.md` MUST NOT contain a shared executable section, reusable operation catalog, common lookup catalog, common REST action block, or operational pattern section that any TC must reference. Titles or semantic equivalents of `Reusable concrete operations`, `Common operational flow`, `Shared Mongo queries`, `Common REST actions`, and `Lookup patterns` are forbidden.

Every applicable operational block MUST be repeated in full inside every TC. This duplication is mandatory. A TC may not say `Виконай Source lookup`, `Виконай ChangeRecord lookup pattern`, `Виконай History processing`, `Виконай HistoryEvent lookup`, `повтори lookup`, `як у TC-...`, `використай блок вище`, `виконай positive flow`, or any semantic equivalent instead of the exact command block.

Before a TC can pass, remove all shared sections and all other test cases. The remaining TC must still contain every applicable command directly: full `db.cards.find(...)`, full patch HTTP request, full `db.changes.find(...)`, full `POST /api/history` body, full `db.events.find(...)`, full `db.change_errors.find(...)`, full rollback request, and full post-rollback `db.cards.find(...)`. An operation heading or prose instruction without its command block is a hard validation failure.


## Node-local data materialization requirement

Reload `contracts/QA_DATA_MATERIALIZATION_POLICY.yaml` in the current node pass. Use provided source records, confirmed state and reconstructed ChangeRecord/HistoryEvent contracts before declaring data missing. Generate safe deterministic test inputs where allowed. Use capture placeholders for runtime values. `blocked_missing_operational_data` is valid only for a proven true open gap.
