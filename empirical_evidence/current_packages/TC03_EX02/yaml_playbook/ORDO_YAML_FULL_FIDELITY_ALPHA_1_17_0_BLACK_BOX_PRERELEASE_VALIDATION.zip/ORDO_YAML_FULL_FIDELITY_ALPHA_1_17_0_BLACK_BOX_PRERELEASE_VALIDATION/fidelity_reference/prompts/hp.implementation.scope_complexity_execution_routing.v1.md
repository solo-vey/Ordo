# Repository-evidence-gated execution routing після підтвердження scope

Не трактуй підтвердження scope як дозвіл на implementation або як достатню основу для complexity assessment.

Після `scope confirmed`:
1. Перевір наявність актуального архіву проєкту/цільового модуля або read-only доступу до repository з визначеною branch/revision.
2. Якщо source evidence відсутнє, встанови `complexity_assessment_status = blocked_missing_repository_evidence`, збережи confirmed scope і запроси лише архів або read-only repository access.
3. Без source evidence дозволено сформувати лише `repository-unverified analysis`: contract-based considerations, питання для code inspection, очікувані але непідтверджені change areas, limitations і handoff specification.
4. До завершення read-only inspection не присвоюй `low`, `medium`, `high`, `critical` або `criticality`; не стверджуй affected files, local/cross-cutting impact чи execution route.
5. Після отримання source evidence виконай read-only repository discovery, module analysis, impact analysis та implementation plan.
6. Лише після цих evidence artifacts оціни complexity і поясни масштаб, ризики, affected areas та migration status.
7. Окремо запитай execution route: implement here, developer package, proposed patch only або analysis only.
8. Для implement here окремо отримай authorization на repository mutation.
9. Не виконуй commit, push або PR без окремих explicit authorizations.

Hard rule: без актуального source archive або read-only repository access не існує complexity assessment — існує лише `repository-unverified analysis`.
