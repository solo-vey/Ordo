# `hp.qa.automation_runner_spec_generation.v1`

Ти формуєш `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml`.

Перед генерацією прочитай і застосуй:

`specs/QA_AUTOMATION_RUNNER_SPECIFICATION.md`

Цей файл має бути executable automation runner spec.

Не замінюй його:
- coverage matrix;
- test allocation plan;
- переліком target suites;
- implementation notes;
- списком assertions без runnable steps.

Використовуй підтверджені:
- automated `FUNC-TC-*`;
- automation strategy;
- fixture/environment data;
- execution mode;
- runner-compatible status;
- polling defaults and source-field rollback policy.

Для кожного automated functional test створи окремий `AUTO-TC-*` із посиланням на `functional_tc`.

Обов’язково сформуй `suite`, `defaults`, `environment`, `test_cases`.

Якщо execution contract для будь-якого automated test неповний, не позначай файл `automation-ready`; покажи open gaps.

## Підтверджене доповнення v0.8.10

Use specs/QA_AUTOMATION_RUNNER_SPECIFICATION.md as authoritative runner contract. The artifact is executable_automation_runner_spec, not a coverage matrix.

## Local operational defaults

Generate `expected_http_status: 200`, `timeout_seconds: 20`, and `poll_interval_seconds: 2`. Do not generate base URL, endpoint authentication, or generated-record cleanup fields/gaps. For state-changing source-patch flows, require source rollback and post-rollback verification.


## Mandatory v0.8.55 structural fidelity and runnable-case rules

- Clone `templates/QA_AUTOMATION_RUNNER_SPEC_TEMPLATE.yaml` as the immutable skeleton.
- Root keys `suite`, `environment`, `defaults`, and `test_cases` are mandatory and may not be renamed or replaced.
- Sections such as `tests`, `scope`, `coverage`, or `gates` may not substitute for `test_cases`.
- Confirmed state supplies values, not schema.
- Each automated functional test must be materialized as a runner-oriented case with full operational blocks.
- `strategy/input/expected` alone is a coverage description and must fail runner-readiness validation.
- Run independent structural fidelity and runnable-case validation before confirmation.


## Runner-contract-bound generation (v0.8.56)

Before generation, reload `runner_contract/RUNNER_SPEC_CONTRACT.yaml`, `RUNNER_CAPABILITIES.yaml`, `RUNNER_VALIDATION_RULES.yaml`, `RUNNER_ENVIRONMENT_CONTRACT.md`, and `RUNNER_CONTRACT_SOURCE.json`; verify source hashes. The immutable root schema is `suite`, `environment`, `defaults`, `test_cases`. `environment` is not a runner root key and is forbidden. Generate only fields supported by the runner. Run structural conformance and, when runner code is available, parse/dry-run validation. A reference example is not required and is not authoritative.


## Lifecycle profile fidelity (v0.8.59)

Apply `contracts/QA_AUTOMATION_TEST_LIFECYCLE_PROFILE_CONTRACT.yaml` and `prompts/hp.qa.automation_test_lifecycle_profiles.v1.md`. Classify every case before rendering, materialize the full canonical skeleton for its profile, and do not shorten `event_absent_after_change` to `change_absent` without explicit authoritative evidence. Parameter matrices must either use runner-supported iteration with a full lifecycle or be expanded into complete cases. Blocked cases use the structured blocked schema rather than null-filled runnable blocks.
