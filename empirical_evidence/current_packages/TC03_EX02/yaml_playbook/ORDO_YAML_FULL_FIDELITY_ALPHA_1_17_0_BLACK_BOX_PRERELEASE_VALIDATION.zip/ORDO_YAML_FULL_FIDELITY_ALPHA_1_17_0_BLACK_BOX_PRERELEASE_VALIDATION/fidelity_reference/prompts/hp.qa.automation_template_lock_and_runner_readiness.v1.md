# QA automation template lock and runner readiness

Before generating or confirming `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml`, reread in the current node execution:

- `templates/QA_AUTOMATION_RUNNER_SPEC_TEMPLATE.yaml`;
- `contracts/QA_AUTOMATION_TEMPLATE_LOCK_AND_RUNNABLE_CASE_CONTRACT.yaml`;
- `specs/QA_AUTOMATION_RUNNER_SPECIFICATION.md`;
- the active node contract and confirmation rail contract.

Record exact paths, SHA-256 values, package version and authoritative tree revision. Prior reading, summaries and memory are non-authoritative.

## Immutable template structure

The artifact MUST preserve canonical root keys:

- `suite`;
- `environment`;
- `defaults`;
- `test_cases`.

Do not replace them with `tests`, `scenarios`, `cases`, `coverage`, `scope` or `gates`. Supplemental allocation/coverage metadata may be added only in allowlisted optional fields and may never replace `test_cases`.

Do not design a new YAML schema. Clone the canonical structural skeleton and fill only adaptable event-specific values. Confirmed state supplies values, never schema.

## Runnable cases

Every confirmed automated `FUNC-TC-*` MUST be represented by one or an explicitly linked set of `AUTO-TC-*` entries under `test_cases`. Each case must contain a complete runner-oriented flow, not only IDs, strategy, input and expected result.

Required operational blocks include variables, source/fixture setup, action, ChangeRecord lookup and capture, history processing, expected event or exact absence, expected errors, assertions, and rollback where applicable. Known actions are rendered directly. Runtime placeholders require exact capture instructions.

Coverage/allocation information is supplemental only. A coverage matrix is not an executable runner spec.

## Independent validation

Before confirmation, independently compare the rendered YAML with the canonical template and validate every `test_cases[]` entry. Do not trust validation status written inside the artifact.

Block confirmation on schema substitution, missing canonical keys, non-runnable cases, uncaptured placeholders, or coverage metadata replacing operational scenarios.


## Runner-contract-bound generation (v0.8.56)

Before generation, reload `runner_contract/RUNNER_SPEC_CONTRACT.yaml`, `RUNNER_CAPABILITIES.yaml`, `RUNNER_VALIDATION_RULES.yaml`, `RUNNER_ENVIRONMENT_CONTRACT.md`, and `RUNNER_CONTRACT_SOURCE.json`; verify source hashes. The immutable root schema is `suite`, `environment`, `defaults`, `test_cases`. `environment` is not a runner root key and is forbidden. Generate only fields supported by the runner. Run structural conformance and, when runner code is available, parse/dry-run validation. A reference example is not required and is not authoritative.


## Lifecycle profile fidelity (v0.8.59)

Apply `contracts/QA_AUTOMATION_TEST_LIFECYCLE_PROFILE_CONTRACT.yaml` and `prompts/hp.qa.automation_test_lifecycle_profiles.v1.md`. Classify every case before rendering, materialize the full canonical skeleton for its profile, and do not shorten `event_absent_after_change` to `change_absent` without explicit authoritative evidence. Parameter matrices must either use runner-supported iteration with a full lifecycle or be expanded into complete cases. Blocked cases use the structured blocked schema rather than null-filled runnable blocks.
