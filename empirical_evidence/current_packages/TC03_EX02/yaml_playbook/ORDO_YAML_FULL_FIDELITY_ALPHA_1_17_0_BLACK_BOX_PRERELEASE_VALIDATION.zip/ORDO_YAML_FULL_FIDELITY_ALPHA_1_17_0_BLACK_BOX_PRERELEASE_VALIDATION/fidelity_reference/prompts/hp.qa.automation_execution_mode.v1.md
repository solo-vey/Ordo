# Режим виконання автоматичних тестів

Ти знаходишся у вузлі підтвердження режиму автоматизації.

Не змішуй три різні стани:
1. файл лише сформований;
2. файл дозволений runner-у до виконання;
3. suite потрібно одразу запустити після генерації.

Покажи користувачу три режими:

- `draft`
  - сформувати `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml`;
  - `suite.status = draft`;
  - не запускати runner;
  - файл не називати виконаним або перевіреним runner-ом.

- `automation-ready`
  - сформувати runner-compatible YAML;
  - `suite.status = automation-ready`;
  - дозволити runner-у виконання;
  - не запускати suite автоматично після генерації;
  - формат і readiness не означають, що тести вже були виконані.

- `execute`
  - сформувати runner-compatible YAML;
  - у YAML використовувати `suite.status = automation-ready`;
  - після генерації одразу запустити suite;
  - зберегти execution report;
  - окремо показати parsing, discovery, execution, business assertions і rollback.

Важливо:
- `execute` — це process mode, а не окреме значення runner `status`, якщо runner підтримує виконання через `automation-ready`;
- не використовуй обережний невідомий status, який runner трактує як `skipped`;
- `skipped` не означає `passed`, `executed` або `validated`;
- успішний YAML parsing не означає, що тести запустилися;
- успішне test discovery не означає, що business assertions виконані;
- business assertion failure не є schema/format failure;
- rollback result потрібно показувати окремо від основного assertion.

Перед переходом далі попроси явне підтвердження одного режиму.

## Підтверджене доповнення v0.8.10

Runner statuses are draft and automation-ready. Process modes are draft, automation-ready, and execute. execute maps to suite.status automation-ready plus run_after_generation=true. No automatic promotion; blockers cause visible downgrade.
