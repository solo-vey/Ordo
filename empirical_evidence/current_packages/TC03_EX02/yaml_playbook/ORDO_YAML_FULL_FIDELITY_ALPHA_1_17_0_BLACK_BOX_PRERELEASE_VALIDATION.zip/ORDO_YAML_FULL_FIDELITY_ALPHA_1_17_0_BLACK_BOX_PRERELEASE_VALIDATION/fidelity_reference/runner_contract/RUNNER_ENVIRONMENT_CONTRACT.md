# Environment contract для History QA Runner

Цей документ фіксує налаштування, яких достатньо для запуску будь-якого `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml` через shared runner.

## 1. Джерело налаштувань

Runner використовує environment variables як основний contract. На macOS/Linux використовуй `python3`; на Windows зазвичай використовуй `py -3`. Для локального запуску можна передати файл із `KEY=VALUE` рядками через CLI-параметр:

```bash
python3 qa_history_runner.py \
  --env-file ./config.qa-dev.env \
  --spec ./08_QA_AUTOMATION_SPEC_<ALIAS>.yaml \
  --report-dir ./qa-reports/<ALIAS>
```

`--env-file` завантажується до ініціалізації runner-а. За замовчуванням він не перетирає вже експортовані змінні; для перетирання використовуй `--env-override`.

## Інтерактивне створення локального env-файла

Для macOS/Linux можна створити або оновити `config.qa-dev.env` без редактора:

```bash
python3 configure_runner.py
```

Для Windows:

```powershell
py -3 configure_runner.py
```

Скрипт запитує `ClientSecret`, Mongo URI, base URL, назви Mongo database і timeout-и, після чого записує локальний `config.qa-dev.env`. Якщо файл уже існує, створюється `.bak` backup. Реальні секрети залишаються тільки в локальному env-файлі й не мають переноситися в YAML-spec або analysis package.

Файл із реальними секретами не комітити, не вкладати в `analysis package` і не додавати в shared runner artifact.

## 2. Обов’язкові environment variables

| Змінна | Приклад | Призначення |
|---|---|---|
| `HISTORY_QA_BASE_URL` | `https://api-in-dev.ligazakon.net/compliance/data-import/v1.0` | Backward-compatible fallback base URL. Використовується, якщо окремі `HISTORY_QA_DATA_IMPORT_BASE_URL` / `HISTORY_QA_HISTORY_BASE_URL` не задані. |
| `HISTORY_QA_DATA_IMPORT_BASE_URL` | `https://api-in-dev.ligazakon.net/compliance/data-import/v1.0` | Base URL для data-import/product-queue/test endpoint-ів, зокрема `/api/test/product-queue/publish-mongo-patch`. |
| `HISTORY_QA_HISTORY_BASE_URL` | `https://api-in-dev.ligazakon.net/compliance/create-history/v1.0` | Base URL для create-history processing endpoint-а, зокрема `/api/history`. |
| `HISTORY_QA_AUTH_TYPE` | `none` / `bearer` | Тип авторизації REST-запитів. Для поточного dev curl авторизації немає, тому використовуй `none`. |
| `HISTORY_QA_TOKEN` | `<TOKEN>` або порожньо | Bearer token потрібен тільки якщо `HISTORY_QA_AUTH_TYPE=bearer`. |
| `HISTORY_QA_CLIENT_SECRET` | `<CLIENT_SECRET>` | Обов’язкове значення для HTTP header `ClientSecret`. |
| `HISTORY_QA_MONGO_URI` | `mongodb://...` | Mongo connection string. Для qa/dev може містити router hosts, `authMechanism` і `authSource`. |
| `HISTORY_QA_MONGO_DATA_DATABASE` | `dossier` | Mongo database для `cards`, `changes`, `change_errors` і більшості `mongo_find` кроків. |
| `HISTORY_QA_MONGO_HISTORY_DATABASE` | `history` | Mongo database для `events`. |

## 3. Опційні environment variables

| Змінна | Default | Призначення |
|---|---:|---|
| `HISTORY_QA_MONGO_DATABASE` | порожньо | Backward-compatible single-DB режим. Якщо задано тільки його, runner читає всі collection-и з цієї бази. |
| `HISTORY_QA_REQUEST_TIMEOUT_SECONDS` | `30` | Timeout REST request. |
| `HISTORY_QA_POLL_TIMEOUT_SECONDS` | `60` | Timeout очікування `changes/events/change_errors`. |
| `HISTORY_QA_POLL_INTERVAL_SECONDS` | `2` | Інтервал polling. |
| `HISTORY_QA_FAIL_FAST` | `false` | Зупинити suite після першого runtime failed/blocked/rollback_failed TC. YAML-declared `automation-blocked` TC не запускаються і не тригерять fail-fast. |

## 4. HTTP headers

Runner сам формує headers. YAML-spec не має дублювати headers і не має зберігати secrets.

Для всіх REST-запитів runner додає:

```http
ClientSecret: <HISTORY_QA_CLIENT_SECRET>
```

Якщо `HISTORY_QA_AUTH_TYPE=bearer`, runner також додає:

```http
Authorization: Bearer <HISTORY_QA_TOKEN>
```

Важливо: header називається саме `ClientSecret`, одним словом, без пробілу, з великою `C` і великою `S`.

## 5. URL contract

У YAML-spec endpoint-и зазвичай мають бути відносними:

```yaml
endpoint: /api/test/product-queue/publish-mongo-patch
```

Runner сам додає `HISTORY_QA_BASE_URL`. Для поточного dev data-import прикладу це дає URL:

```text
https://api-in-dev.ligazakon.net/compliance/data-import/v1.0/api/test/product-queue/publish-mongo-patch
```

Якщо окремий endpoint живе на іншому base URL, у spec можна передати повний `https://...` endpoint. Не записувати secrets у spec.

## 6. Mongo collections contract

За замовчуванням runner очікує такі collection-и:

```text
cards
changes
events
change_errors
```

За поточним dev layout runner читає:

```text
dossier.cards
dossier.changes
dossier.change_errors
history.events
```

Їх можна перевизначити в `defaults` YAML-spec:

```yaml
defaults:
  source_collection: cards
  changes_collection: changes
  events_collection: events
  errors_collection: change_errors
  source_database: dossier
  changes_database: dossier
  errors_database: dossier
  events_database: history
```

Якщо `database` або `db` заданий прямо в `source`, `change_record`, `expected_events`, `expected_errors` або `mongo_find` step, це значення має пріоритет над default/env routing.

Для `mongo_find` step collection задається прямо в step:

```yaml
setup:
  - type: mongo_find
    collection: cards
```

Mongo-доступ runner-а залишається read-only: `mongo_find`, `find_one` і polling. Записи змінюються тільки через REST QA endpoint-и.

## 7. Processing contract

Стандартний режим:

```yaml
processing:
  type: rest
  method: POST
  endpoint: /api/history
```

Дозволені типи:

| Тип | Значення |
|---|---|
| `rest` | Runner сам викликає endpoint processing. |
| `none` | Processing не запускається runner-ом. |
| `external` | Processing виконується зовнішнім job-ом або вручну; runner тільки очікує результат. |

## 8. Runtime variables

| Назва | Що означає |
|---|---|
| `mongo_id` | `_id` source row у Mongo. |
| `root_id` | root/company/entity id для пошуку пов’язаних записів. |
| `$CHANGE_ID` | `_id` створеного запису в `changes`, який runner зберігає після `change_record.find`. |
| `$MEMBER_MONGO_ID` | Типова змінна, яку `mongo_find` може присвоїти після створення тимчасового `companyMember`. |

Event бажано шукати через:

```yaml
source_change_id: "$CHANGE_ID"
```

## 9. Placeholders

Якщо TC містить placeholders на кшталт:

```text
<MONGO_ID>
<ROOT_ID>
<OLD_VALUE>
<NEW_VALUE>
```

такий TC не може мати статус `automation-ready`.

## 10. Rollback і cleanup contract

`rollback` повертає бізнес-стан існуючого запису. `cleanup` прибирає тимчасові rows, створені в `setup`.

Якщо є і `rollback`, і `cleanup`, порядок виконання:

```text
rollback
cleanup
```

`cleanup` виконується у `finally`:

- якщо тест успішний;
- якщо action failed;
- якщо `change_record` не знайдений;
- якщо processing failed;
- якщо expected event не знайдений;
- якщо rollback failed.

Optional cleanup failure не перекриває основний результат тесту, але потрапляє в report.


## Split backend URL routing

Для середовища, де data-import і create-history розгорнуті як різні backend-и, задавай обидва окремі URL-и:

```env
HISTORY_QA_BASE_URL=https://api-in-dev.ligazakon.net/compliance/data-import/v1.0
HISTORY_QA_DATA_IMPORT_BASE_URL=https://api-in-dev.ligazakon.net/compliance/data-import/v1.0
HISTORY_QA_HISTORY_BASE_URL=https://api-in-dev.ligazakon.net/compliance/create-history/v1.0
```

Routing за замовчуванням:

| Runner phase | Base URL |
|---|---|
| `setup`, `action`, `post_action`, `rollback`, `cleanup` REST | `HISTORY_QA_DATA_IMPORT_BASE_URL` |
| `processing` REST | `HISTORY_QA_HISTORY_BASE_URL` |

Якщо окремі змінні не задані, runner використовує `HISTORY_QA_BASE_URL` як fallback для всіх REST phase.


## 9. `expected_change_absent` environment impact

`expected_change_absent` не потребує нових environment variables. Він використовує вже наявні Mongo-змінні runner-а:

- `HISTORY_QA_MONGO_URI`;
- `HISTORY_QA_MONGO_DATA_DATABASE` або fallback `HISTORY_QA_MONGO_DATABASE`;
- `defaults.changes_database` / `database`, якщо вони задані у spec.

No-op TC з `expected_change_absent` може пройти без `$CHANGE_ID`, без `processing` і без `expected_events`.
