#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
validator=Path(__file__).with_name('validate_jira_implementation_output.py')
p=subprocess.run([sys.executable,str(validator),sys.argv[1]],text=True)
sys.exit(p.returncode)
