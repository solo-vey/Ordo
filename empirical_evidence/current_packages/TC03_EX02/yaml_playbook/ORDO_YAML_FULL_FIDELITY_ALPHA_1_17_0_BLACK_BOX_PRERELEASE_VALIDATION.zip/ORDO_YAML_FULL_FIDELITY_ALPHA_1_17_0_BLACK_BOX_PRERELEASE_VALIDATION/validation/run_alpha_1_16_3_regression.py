#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, json
root=Path(__file__).resolve().parents[1]
v=root/"validation/validate_automation_rendered.py"
tests=[
 ("full_good", "AUTO_DUPLICATE_FULL_GOOD.yaml", False, []),
 ("short_payload", "AUTO_DUPLICATE_SHORT_PAYLOAD_BAD.yaml", True, ["AUTO_CYCLE_1_PUBLISH_PAYLOAD_INCOMPLETE"]),
 ("identity_mismatch", "AUTO_DUPLICATE_IDENTITY_BAD.yaml", True, ["AUTO_DUPLICATE_DEDUP_IDENTITY_MISMATCH"]),
 ("business_payload_mismatch", "AUTO_DUPLICATE_BUSINESS_PAYLOAD_BAD.yaml", True, ["AUTO_DUPLICATE_BUSINESS_PAYLOAD_MISMATCH"]),
 ("authoritative_ref_missing", "AUTO_AUTHORITATIVE_REF_MISSING_BAD.yaml", True, ["AUTO_AUTHORITATIVE_FIXTURE_REFERENCE_MISSING"]),
 ("final_assertion_missing", "AUTO_DUPLICATE_FINAL_ASSERTION_BAD.yaml", True, ["AUTO_DUPLICATE_FINAL_ASSERTION_MISSING"]),
]
results=[]; failed=[]
for name,file,expect_reject,codes in tests:
 p=subprocess.run([sys.executable,str(v),str(root/"validation/regression_1163"/file)],capture_output=True,text=True)
 rejected=p.returncode!=0
 ok=(rejected==expect_reject) and all(code in p.stdout for code in codes)
 results.append({"name":name,"expected_rejected":expect_reject,"actual_rejected":rejected,
                 "returncode":p.returncode,"required_codes":codes,"stdout":p.stdout,"stderr":p.stderr,
                 "result":"PASS" if ok else "FAIL"})
 if not ok: failed.append(name)
print(json.dumps({"suite":"alpha_1_16_3_automation_full_rule_alignment","results":results,
                  "failed":failed,"result":"PASS" if not failed else "FAIL"},ensure_ascii=False,indent=2))
sys.exit(0 if not failed else 1)
