#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,zipfile,subprocess,sys,tempfile,shutil,yaml

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def verify_tree(root):
 errors=[]
 sums=root/'SHA256SUMS.txt'
 if not sums.exists(): return ['SHA256SUMS_MISSING']
 for line in sums.read_text().splitlines():
  if not line.strip(): continue
  exp,rel=line.split('  ',1); p=root/rel
  if not p.exists(): errors.append(f'MISSING:{rel}')
  elif sha(p)!=exp: errors.append(f'HASH_MISMATCH:{rel}')
 pb=yaml.safe_load((root/'playbook/PLAYBOOK.yaml').read_text())
 if len(pb.get('steps',[]))!=126: errors.append(f'STEP_COUNT:{len(pb.get("steps",[]))}')
 required=['driver/semantic_analyst_driver.py','validation/validate_artifact_approval_receipt.py','validation/validate_selected_run_literal_consistency.py','validation/run_alpha_1_16_8_regression.py','validation/run_alpha_1_16_9_regression.py','contracts/CORRECTION_LOOP_RUNTIME_ENFORCEMENT_CONTRACT.yaml','contracts/CROSS_ARTIFACT_FAILURE_OWNER_ROUTING_CONTRACT.yaml','scripts/run_full_release_validation.sh']
 for rel in required:
  if not (root/rel).exists(): errors.append(f'REQUIRED_MISSING:{rel}')
 return errors

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('package'); args=ap.parse_args(); z=Path(args.package)
 errors=[]
 if not zipfile.is_zipfile(z): errors.append('ZIP_INVALID')
 else:
  with tempfile.TemporaryDirectory() as td:
   with zipfile.ZipFile(z) as f: f.extractall(td)
   roots=[p for p in Path(td).iterdir() if p.is_dir()]
   if len(roots)!=1: errors.append('ZIP_ROOT_COUNT')
   else: errors += verify_tree(roots[0])
 print(json.dumps({'validator':'release_package_self_validation_v1','package':str(z),'sha256':sha(z) if z.exists() else None,'errors':errors,'result':'PASS' if not errors else 'FAIL'},indent=2))
 return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main())
