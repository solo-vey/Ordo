document_id: DOC-74291
record_key: REC-184
field_path: item.processingState
change_id: CHG-2026-0001
occurred_at: 2026-07-15T09:30:00Z
event_type: RECORD_PROCESSING_STATE_CHANGED
