document_id: DOC-88310
record_key: REC-902
field_path: item.processingState
change_id: CHG-2026-0002
occurred_at: 2026-07-15T10:15:00Z
event_type: RECORD_PROCESSING_STATE_CHANGED
