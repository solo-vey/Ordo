#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
R=Path(__file__).resolve().parents[1]
V=R/'validation/validate_selected_run_literal_consistency.py'
F=R/'validation/regression_1168'
def run(name):
 p=subprocess.run([sys.executable,str(V),str(F/'SELECTED.yaml'),str(F/name)],capture_output=True,text=True)
 return p
ok=run('GOOD.md'); stale=run('STALE.md')
assert ok.returncode==0, ok.stdout+ok.stderr
assert stale.returncode!=0, stale.stdout+stale.stderr
assert 'expected=DOC-88310:actual=DOC-74291' in stale.stdout
print(json.dumps({'suite':'alpha_1_16_8_release_self_validation','good_fixture':'PASS','stale_context_rejected':'PASS','result':'PASS'}))
