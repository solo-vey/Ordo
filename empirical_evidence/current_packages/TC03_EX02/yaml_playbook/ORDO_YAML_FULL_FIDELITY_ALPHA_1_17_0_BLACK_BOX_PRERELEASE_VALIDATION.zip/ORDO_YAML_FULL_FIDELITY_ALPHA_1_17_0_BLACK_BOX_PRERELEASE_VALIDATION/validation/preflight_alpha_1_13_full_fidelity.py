#!/usr/bin/env python3
from pathlib import Path
import sys, yaml, json

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
errors = []

playbook = yaml.safe_load((root / "playbook/PLAYBOOK.yaml").read_text(encoding="utf-8"))
if len(playbook.get("steps", [])) != 126:
    errors.append("playbook_step_count_not_126")

playbook_text = (root / "playbook/PLAYBOOK.yaml").read_text(encoding="utf-8")
if "test_inputs/RUN_01_CONFIRMED_INPUT.yaml" in playbook_text:
    errors.append("static_run01_input_still_active")
if "runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml" not in playbook_text:
    errors.append("selected_run_full_fidelity_input_not_bound")

required = [
    "contracts/DATABASE_CHANGE_OPERATIONAL_QA_CONTRACT.yaml",
    "contracts/DATABASE_CHANGE_AUTOMATION_RUNNER_CONTRACT.yaml",
    "fidelity_reference/runner_contract/RUNNER_CAPABILITIES.yaml",
    "scenario_overlays/FULL_FIDELITY_COMMON_OPERATIONAL_OVERLAY.yaml",
    "test_inputs/SELECTED_RUN_FULL_FIDELITY_INPUT_TEMPLATE.yaml",
    "prompts/hp.artifact.jira.generate_and_review.v3.md",
    "templates/TEMPLATE_JIRA_TASK_V3.md",
    "contracts/JIRA_DELIVERY_FOCUSED_CONTRACT_V2.yaml",
    "validation/validate_jira_delivery_content.py",
]
for rel in required:
    if not (root / rel).exists():
        errors.append(f"missing:{rel}")

scenario_files = sorted((root / "private/scenarios").glob("RUN_*.enc"))
if len(scenario_files) != 5:
    errors.append(f"expected_5_scenarios_found_{len(scenario_files)}")

print(json.dumps({
    "validator": "alpha_1_13_full_fidelity_preflight",
    "step_count": len(playbook.get("steps", [])),
    "scenario_count": len(scenario_files),
    "errors": errors,
    "result": "PASS" if not errors else "FAIL",
}, ensure_ascii=False, indent=2))
sys.exit(0 if not errors else 1)
