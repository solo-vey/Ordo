#!/usr/bin/env python3
from pathlib import Path
import re,sys,json
text=Path(sys.argv[1]).read_text(encoding='utf-8')
errs=[]

def strip_comments(code):
    lines=[]
    for line in code.splitlines():
        s=line.lstrip()
        if s.startswith('#') or s.startswith('//'): continue
        # remove trailing shell comments outside quotes conservatively
        if ' #' in line: line=line.split(' #',1)[0]
        lines.append(line)
    return '\n'.join(lines)

def blocks(sec):
    return [strip_comments(x) for x in re.findall(r'```(?:bash|sh|js|javascript)?\s*(.*?)```',sec,re.S|re.I)]

def executable_assertion(code, expected=None):
    low=code.lower()
    has_query=bool(re.search(r'countdocuments|\.count\s*\(|findone\s*\(|find\s*\(',low))
    has_compare=bool(re.search(r'(===|!==|==|!=|<=|>=)|\bassert\s*\(|\bif\s*\(',low))
    has_fail=bool(re.search(r'quit\s*\(\s*1\s*\)|process\.exit\s*\(\s*1\s*\)|exit\s+1|throw\s+new\s+error',low)) or bool(re.search(r'\bassert\s*\(',low))
    expected_ok=True if expected is None else bool(re.search(r'(?<!\d)'+re.escape(str(expected))+r'(?!\d)',low))
    return has_query and has_compare and has_fail and expected_ok

def section(sec,step):
    m=re.search(rf'### Step {step}\..*?(?=^###|\Z)',sec,re.S|re.M|re.I)
    return m.group(0) if m else ''

for sec in re.split(r'(?=^## MQA-\d+)',text,flags=re.M):
    m=re.search(r'^## (MQA-\d+)',sec,re.M)
    if not m: continue
    cid=m.group(1)
    if re.search(r'evidence_status:\s*blocked|status:\s*blocked',sec,re.I): continue
    for step_no in (5,7,8):
        st=section(sec,step_no)
        cm=re.search(r'Expected cardinality:\s*(\d+)',st,re.I)
        if cm:
            expected=int(cm.group(1))
            candidates=[b for b in blocks(st) if re.search(r'countdocuments|\.count\s*\(|findone\s*\(|find\s*\(',b,re.I)]
            if not candidates or not any(executable_assertion(b,expected) for b in candidates):
                code='MQA_ZERO_ASSERTION_NOT_FAIL_CLOSED' if expected==0 else 'MQA_CARDINALITY_ASSERTION_NOT_FAIL_CLOSED'
                errs.append(f'{cid}:STEP_{step_no}:{code}')
    rb=section(sec,9)
    if rb:
        rb_blocks=blocks(rb)
        if not rb_blocks or not any(executable_assertion(b,None) for b in rb_blocks):
            errs.append(cid+':MQA_ROLLBACK_ASSERTION_NOT_FAIL_CLOSED')
        executable='\n'.join(rb_blocks).lower()
        # exact restoration requires a field read and literal comparison in executable code.
        has_field=bool(re.search(r'processingstate|item\.[a-z0-9_.]+|fieldpath',executable,re.I))
        has_literal_compare=bool(re.search(r'(===|==|!==|!=)\s*["\'][^"\']+["\']',executable))
        if not (has_field and has_literal_compare): errs.append(cid+':MQA_ROLLBACK_EXACT_RESTORATION_MISSING')

print(json.dumps({'validator':'manual_qa_syntax_aware_fail_closed_v2','errors':sorted(set(errs)),'result':'PASS' if not errs else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not errs else 1)
