#!/usr/bin/env python3
from pathlib import Path
import re, sys, json, yaml

passport = Path(sys.argv[1]).read_text(encoding="utf-8")
registry = yaml.safe_load(Path(sys.argv[2]).read_text(encoding="utf-8"))
errors = []
rows = []

for b in registry.get("behaviors", []):
    tc = b.get("functional_id")
    mqa = b.get("manual_qa_id")
    auto = b.get("automation_id")
    status = b.get("authoritative_status")
    blocker = b.get("blocking_capability")
    closure = b.get("required_closure_evidence")
    matching = [ln for ln in passport.splitlines() if tc and tc in ln]
    explicit = next((ln for ln in matching if mqa in ln and auto in ln and status in ln), "")
    registry_ref_ok = (
        "runtime/CASE_STATUS_REGISTRY.yaml" in passport
        and tc in passport
        and mqa in passport
        and auto in passport
    )
    row_errors = []
    if not explicit and not registry_ref_ok:
        row_errors.append("missing_TC_MQA_AUTO_status_traceability")
    if str(status).startswith("blocked"):
        evidence_text = " ".join(matching)
        if blocker and blocker not in evidence_text and not registry_ref_ok:
            row_errors.append("blocked_behavior_missing_capability")
        if closure and closure not in evidence_text and not registry_ref_ok:
            row_errors.append("blocked_behavior_missing_closure_evidence")
    for e in row_errors:
        errors.append(f"{tc}:{e}")
    rows.append({"functional_id": tc, "errors": row_errors})

print(json.dumps({
    "validator": "passport_cross_artifact_traceability_validator_v1",
    "rows": rows,
    "errors": errors,
    "result": "PASS" if not errors else "FAIL",
}, ensure_ascii=False, indent=2))
sys.exit(0 if not errors else 1)
