#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parents[1]
tests=[
 ('jira_bad','validate_jira_implementation_output.py','JIRA_TABLE_REFERENCE_ONLY_BAD.md',True),
 ('jira_good','validate_jira_implementation_output.py','JIRA_TABLE_GOOD.md',False),
 ('manual_bad','validate_manual_qa_fail_closed.py','MANUAL_COMMENT_ASSERT_BAD.md',True),
 ('manual_good','validate_manual_qa_fail_closed.py','MANUAL_EXECUTABLE_GOOD.md',False),
 ('receipt_bad','validate_artifact_approval_receipt.py','RECEIPT_BAD.json',True),
 ('receipt_good','validate_artifact_approval_receipt.py','RECEIPT_GOOD.json',False),
]
results=[];failed=[]
for name,val,file,reject in tests:
 p=subprocess.run([sys.executable,str(root/'validation'/val),str(root/'validation/regression_1165'/file)],capture_output=True,text=True,timeout=10)
 ok=((p.returncode!=0)==reject)
 results.append({'name':name,'expected_reject':reject,'actual_reject':p.returncode!=0,'stdout':p.stdout,'stderr':p.stderr,'result':'PASS' if ok else 'FAIL'})
 if not ok: failed.append(name)
print(json.dumps({'suite':'alpha_1_16_5_targeted_validator_and_approval_binding','results':results,'failed':failed,'result':'PASS' if not failed else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not failed else 1)
