# Manual QA Package — PROCESSING_STATE_CHANGED

Runtime placeholders: `BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME`. Capture them from the target environment configuration/secret store and active database connection before execution. Collection and endpoint bindings below are authoritative.

## MQA-001 — Meaningful state change
Functional TC: TC-001

### Step 0. Preconditions
`BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` are captured; collections are reachable; use isolated change id `CHG-2026-0001`.
### Step 1. Source lookup
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{document_id:1,record_key:1,"item.processingState":1})'
```
Expected cardinality: 1; projection contains document and baseline field.
### Step 2. Capture baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.findOne({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected baseline is captured verbatim for rollback.
### Step 3. Test data
```json
{"documentId": "DOC-74291", "recordKey": "REC-184", "changeId": "CHG-2026-0001", "occurredAt": "2026-07-15T09:30:00Z", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "approved"}
```
### Step 4. Publish change
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0001","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
Expected HTTP status: 200.
### Step 5. Change-record assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0001"},{change_id:1,record_key:1,field_path:1,old_value:1,new_value:1,operation_status:1,occurred_at:1})'
```
Expected cardinality: 1; projection and persisted fields must equal the case payload where a change record is expected.
### Step 6. Process
```bash
curl -sS -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0001","ruleId":"RULE_RECORD_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200 or contract-defined blocked response for missing mandatory data.
### Step 7. Event assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0001",event_type:"RECORD_PROCESSING_STATE_CHANGED"},{event_type:1,rule_id:1,change_id:1,document_id:1,record_key:1,field_path:1,old_value:1,new_value:1,event_date:1,values:1})'
```
Expected cardinality: 1; when cardinality is 1, assert full payload: event_type `RECORD_PROCESSING_STATE_CHANGED`, rule_id `RULE_RECORD_PROCESSING_STATE_CHANGED`, change_id `CHG-2026-0001`, document_id `DOC-74291`, record_key `REC-184`, field_path `item.processingState`, old_value `pending`, new_value `approved`, event_date `2026-07-15T09:30:00Z`, values.oldValue `pending`, values.newValue `approved`.
### Step 8. Error assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0001",rule_id:"RULE_RECORD_PROCESSING_STATE_CHANGED"},{change_id:1,rule_id:1,reason:1})'
```
Expected cardinality: 0; projection must contain the exact identities and, when blocked, a mandatory-data reason.
### Step 9. Rollback and verification
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0001-RB","occurredAt":"2026-07-15T09:31:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected cardinality: 1; projection shows restored baseline `pending`. Generated records are isolated by unique change_id; no delete capability is assumed.
### Final expected result
Case outcome matches TC-001; all exact cardinality and projection assertions hold.

## MQA-002 — Equal normalized values
Functional TC: TC-002

### Step 0. Preconditions
`BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` are captured; collections are reachable; use isolated change id `CHG-2026-0002`.
### Step 1. Source lookup
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{document_id:1,record_key:1,"item.processingState":1})'
```
Expected cardinality: 1; projection contains document and baseline field.
### Step 2. Capture baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.findOne({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected baseline is captured verbatim for rollback.
### Step 3. Test data
```json
{"documentId": "DOC-74291", "recordKey": "REC-184", "changeId": "CHG-2026-0002", "occurredAt": "2026-07-15T09:30:00Z", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "pending"}
```
### Step 4. Publish change
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0002","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"pending"}'
```
Expected HTTP status: 200.
### Step 5. Change-record assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0002"},{change_id:1,record_key:1,field_path:1,old_value:1,new_value:1,operation_status:1,occurred_at:1})'
```
Expected cardinality: 1; projection and persisted fields must equal the case payload where a change record is expected.
### Step 6. Process
```bash
curl -sS -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0002","ruleId":"RULE_RECORD_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200 or contract-defined blocked response for missing mandatory data.
### Step 7. Event assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0002",event_type:"RECORD_PROCESSING_STATE_CHANGED"},{event_type:1,rule_id:1,change_id:1,document_id:1,record_key:1,field_path:1,old_value:1,new_value:1,event_date:1,values:1})'
```
Expected cardinality: 0; when cardinality is 1, assert full payload: event_type `RECORD_PROCESSING_STATE_CHANGED`, rule_id `RULE_RECORD_PROCESSING_STATE_CHANGED`, change_id `CHG-2026-0002`, document_id `DOC-74291`, record_key `REC-184`, field_path `item.processingState`, old_value `pending`, new_value `pending`, event_date `2026-07-15T09:30:00Z`, values.oldValue `pending`, values.newValue `pending`.
### Step 8. Error assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0002",rule_id:"RULE_RECORD_PROCESSING_STATE_CHANGED"},{change_id:1,rule_id:1,reason:1})'
```
Expected cardinality: 0; projection must contain the exact identities and, when blocked, a mandatory-data reason.
### Step 9. Rollback and verification
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0002-RB","occurredAt":"2026-07-15T09:31:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected cardinality: 1; projection shows restored baseline `pending`. Generated records are isolated by unique change_id; no delete capability is assumed.
### Final expected result
Case outcome matches TC-002; all exact cardinality and projection assertions hold.

## MQA-003 — Unrelated field
Functional TC: TC-003

### Step 0. Preconditions
`BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` are captured; collections are reachable; use isolated change id `CHG-2026-0003`.
### Step 1. Source lookup
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{document_id:1,record_key:1,"item.processingState":1})'
```
Expected cardinality: 1; projection contains document and baseline field.
### Step 2. Capture baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.findOne({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected baseline is captured verbatim for rollback.
### Step 3. Test data
```json
{"documentId": "DOC-74291", "recordKey": "REC-184", "changeId": "CHG-2026-0003", "occurredAt": "2026-07-15T09:30:00Z", "operationStatus": "modified", "fieldPath": "item.otherField", "oldValue": "pending", "newValue": "approved"}
```
### Step 4. Publish change
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0003","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.otherField","oldValue":"pending","newValue":"approved"}'
```
Expected HTTP status: 200.
### Step 5. Change-record assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0003"},{change_id:1,record_key:1,field_path:1,old_value:1,new_value:1,operation_status:1,occurred_at:1})'
```
Expected cardinality: 1; projection and persisted fields must equal the case payload where a change record is expected.
### Step 6. Process
```bash
curl -sS -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0003","ruleId":"RULE_RECORD_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200 or contract-defined blocked response for missing mandatory data.
### Step 7. Event assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0003",event_type:"RECORD_PROCESSING_STATE_CHANGED"},{event_type:1,rule_id:1,change_id:1,document_id:1,record_key:1,field_path:1,old_value:1,new_value:1,event_date:1,values:1})'
```
Expected cardinality: 0; when cardinality is 1, assert full payload: event_type `RECORD_PROCESSING_STATE_CHANGED`, rule_id `RULE_RECORD_PROCESSING_STATE_CHANGED`, change_id `CHG-2026-0003`, document_id `DOC-74291`, record_key `REC-184`, field_path `item.otherField`, old_value `pending`, new_value `approved`, event_date `2026-07-15T09:30:00Z`, values.oldValue `pending`, values.newValue `approved`.
### Step 8. Error assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0003",rule_id:"RULE_RECORD_PROCESSING_STATE_CHANGED"},{change_id:1,rule_id:1,reason:1})'
```
Expected cardinality: 0; projection must contain the exact identities and, when blocked, a mandatory-data reason.
### Step 9. Rollback and verification
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0003-RB","occurredAt":"2026-07-15T09:31:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected cardinality: 1; projection shows restored baseline `pending`. Generated records are isolated by unique change_id; no delete capability is assumed.
### Final expected result
Case outcome matches TC-003; all exact cardinality and projection assertions hold.

## MQA-004 — Unsupported operation status
Functional TC: TC-004

### Step 0. Preconditions
`BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` are captured; collections are reachable; use isolated change id `CHG-2026-0004`.
### Step 1. Source lookup
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{document_id:1,record_key:1,"item.processingState":1})'
```
Expected cardinality: 1; projection contains document and baseline field.
### Step 2. Capture baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.findOne({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected baseline is captured verbatim for rollback.
### Step 3. Test data
```json
{"documentId": "DOC-74291", "recordKey": "REC-184", "changeId": "CHG-2026-0004", "occurredAt": "2026-07-15T09:30:00Z", "operationStatus": "created", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "approved"}
```
### Step 4. Publish change
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0004","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"created","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
Expected HTTP status: 200.
### Step 5. Change-record assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0004"},{change_id:1,record_key:1,field_path:1,old_value:1,new_value:1,operation_status:1,occurred_at:1})'
```
Expected cardinality: 0; projection and persisted fields must equal the case payload where a change record is expected.
### Step 6. Process
```bash
curl -sS -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0004","ruleId":"RULE_RECORD_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200 or contract-defined blocked response for missing mandatory data.
### Step 7. Event assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0004",event_type:"RECORD_PROCESSING_STATE_CHANGED"},{event_type:1,rule_id:1,change_id:1,document_id:1,record_key:1,field_path:1,old_value:1,new_value:1,event_date:1,values:1})'
```
Expected cardinality: 0; when cardinality is 1, assert full payload: event_type `RECORD_PROCESSING_STATE_CHANGED`, rule_id `RULE_RECORD_PROCESSING_STATE_CHANGED`, change_id `CHG-2026-0004`, document_id `DOC-74291`, record_key `REC-184`, field_path `item.processingState`, old_value `pending`, new_value `approved`, event_date `2026-07-15T09:30:00Z`, values.oldValue `pending`, values.newValue `approved`.
### Step 8. Error assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0004",rule_id:"RULE_RECORD_PROCESSING_STATE_CHANGED"},{change_id:1,rule_id:1,reason:1})'
```
Expected cardinality: 0; projection must contain the exact identities and, when blocked, a mandatory-data reason.
### Step 9. Rollback and verification
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0004-RB","occurredAt":"2026-07-15T09:31:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected cardinality: 1; projection shows restored baseline `pending`. Generated records are isolated by unique change_id; no delete capability is assumed.
### Final expected result
Case outcome matches TC-004; all exact cardinality and projection assertions hold.

## MQA-005 — Duplicate composite identity
Functional TC: TC-005

### Step 0. Preconditions
`BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` are captured; collections are reachable; use isolated change id `CHG-2026-0005`.
### Step 1. Source lookup
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{document_id:1,record_key:1,"item.processingState":1})'
```
Expected cardinality: 1; projection contains document and baseline field.
### Step 2. Capture baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.findOne({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected baseline is captured verbatim for rollback.
### Step 3. Test data
```json
{"documentId": "DOC-74291", "recordKey": "REC-184", "changeId": "CHG-2026-0005", "occurredAt": "2026-07-15T09:30:00Z", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "approved"}
```
### Step 4. Publish change
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0005","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
Expected HTTP status: 200.
### Step 5. Change-record assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0005"},{change_id:1,record_key:1,field_path:1,old_value:1,new_value:1,operation_status:1,occurred_at:1})'
```
Expected cardinality: 1; projection and persisted fields must equal the case payload where a change record is expected.
### Step 6. Process
```bash
curl -sS -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0005","ruleId":"RULE_RECORD_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200 or contract-defined blocked response for missing mandatory data.
Repeat the exact Step 4 publish command and exact Step 6 process command as a real second stimulus.
### Step 7. Event assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0005",event_type:"RECORD_PROCESSING_STATE_CHANGED"},{event_type:1,rule_id:1,change_id:1,document_id:1,record_key:1,field_path:1,old_value:1,new_value:1,event_date:1,values:1})'
```
Expected cardinality: 1; when cardinality is 1, assert full payload: event_type `RECORD_PROCESSING_STATE_CHANGED`, rule_id `RULE_RECORD_PROCESSING_STATE_CHANGED`, change_id `CHG-2026-0005`, document_id `DOC-74291`, record_key `REC-184`, field_path `item.processingState`, old_value `pending`, new_value `approved`, event_date `2026-07-15T09:30:00Z`, values.oldValue `pending`, values.newValue `approved`.
### Step 8. Error assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0005",rule_id:"RULE_RECORD_PROCESSING_STATE_CHANGED"},{change_id:1,rule_id:1,reason:1})'
```
Expected cardinality: 0; projection must contain the exact identities and, when blocked, a mandatory-data reason.
### Step 9. Rollback and verification
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0005-RB","occurredAt":"2026-07-15T09:31:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected cardinality: 1; projection shows restored baseline `pending`. Generated records are isolated by unique change_id; no delete capability is assumed.
### Final expected result
Case outcome matches TC-005; all exact cardinality and projection assertions hold.

## MQA-006 — Missing mandatory record key
Functional TC: TC-006

### Step 0. Preconditions
`BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` are captured; collections are reachable; use isolated change id `CHG-2026-0006`.
### Step 1. Source lookup
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{document_id:1,record_key:1,"item.processingState":1})'
```
Expected cardinality: 1; projection contains document and baseline field.
### Step 2. Capture baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.findOne({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected baseline is captured verbatim for rollback.
### Step 3. Test data
```json
{"documentId": "DOC-74291", "changeId": "CHG-2026-0006", "occurredAt": "2026-07-15T09:30:00Z", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "approved"}
```
### Step 4. Publish change
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","changeId":"CHG-2026-0006","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
Expected HTTP status: 200.
### Step 5. Change-record assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0006"},{change_id:1,record_key:1,field_path:1,old_value:1,new_value:1,operation_status:1,occurred_at:1})'
```
Expected cardinality: 1; projection and persisted fields must equal the case payload where a change record is expected.
### Step 6. Process
```bash
curl -sS -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0006","ruleId":"RULE_RECORD_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200 or contract-defined blocked response for missing mandatory data.
### Step 7. Event assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0006",event_type:"RECORD_PROCESSING_STATE_CHANGED"},{event_type:1,rule_id:1,change_id:1,document_id:1,record_key:1,field_path:1,old_value:1,new_value:1,event_date:1,values:1})'
```
Expected cardinality: 0; when cardinality is 1, assert full payload: event_type `RECORD_PROCESSING_STATE_CHANGED`, rule_id `RULE_RECORD_PROCESSING_STATE_CHANGED`, change_id `CHG-2026-0006`, document_id `DOC-74291`, record_key `REC-184`, field_path `item.processingState`, old_value `pending`, new_value `approved`, event_date `2026-07-15T09:30:00Z`, values.oldValue `pending`, values.newValue `approved`.
### Step 8. Error assertion
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0006",rule_id:"RULE_RECORD_PROCESSING_STATE_CHANGED"},{change_id:1,rule_id:1,reason:1})'
```
Expected cardinality: 1; projection must contain the exact identities and, when blocked, a mandatory-data reason.
### Step 9. Rollback and verification
```bash
curl -sS -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0006-RB","occurredAt":"2026-07-15T09:31:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Expected cardinality: 1; projection shows restored baseline `pending`. Generated records are isolated by unique change_id; no delete capability is assumed.
### Final expected result
Case outcome matches TC-006; all exact cardinality and projection assertions hold.

