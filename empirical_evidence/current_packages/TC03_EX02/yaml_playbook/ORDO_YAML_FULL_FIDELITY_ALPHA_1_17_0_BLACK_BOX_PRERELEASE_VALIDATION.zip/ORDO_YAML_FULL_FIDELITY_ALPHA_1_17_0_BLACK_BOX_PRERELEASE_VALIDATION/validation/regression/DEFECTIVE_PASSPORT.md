# Record Change Passport — PROCESSING_STATE_CHANGED

## 1. Статус документа
Version: v1.0.0  
Document status: final-ready  
Confirmation source: RUN_01 Driver + authoritative operational overlay.

## 2. Ідентичність і бізнес-мета
- Contract ID: `RULE_RECORD_PROCESSING_STATE_CHANGED`
- Event type: `RECORD_PROCESSING_STATE_CHANGED`
- Display name: `Processing state changed`
- Мета: документувати й перевірити, як meaningful зміна processing state створює повний implementation/verification package.

## 3. Source record contract
- MongoDB collection: `source_records`.
- Stable document identifier: `DOC-74291`.
- Stable record key: `REC-184`.
- Target path: `item.processingState`.
- Baseline: `pending`; changed value: `approved`.

## 4. Change record contract
- Collection role: `change_records`.
- `change_id`: `CHG-2026-0001`.
- operation/status: `modified`.
- field path: `item.processingState`.
- old/new: `pending` → `approved`.
- occurred_at: `2026-07-15T09:30:00Z`.

## 5. Decision contract
1. Require source identifiers, change identifier, mapping, operation/status, field path, old/new and occurred_at.
2. Accept only `modified` for this rule.
3. Match only `item.processingState`.
4. Normalize null, missing and empty string to empty string for comparison; do not trim or alter case.
5. Equal normalized values, unrelated fields and unsupported statuses are no-op.
6. Meaningful change creates exactly one event.
7. Deduplicate by composite identity `(change_id, event_type)`; a duplicate creates no additional event.
8. Missing mandatory data blocks processing and writes diagnostic evidence to `change_errors` keyed by `change_id` and `rule_id`.

## 6. Derived event exact mapping
| Target field | Exact source/value | Missing behavior |
|---|---|---|
| event_type | `RECORD_PROCESSING_STATE_CHANGED` | block |
| rule_id | `RULE_RECORD_PROCESSING_STATE_CHANGED` | block |
| change_id | `change_records.change_id` | block |
| document_id | `DOC-74291` | block |
| record_key | `REC-184` | block |
| field_path | `item.processingState` | block |
| old_value | `pending` | normalize only for comparison |
| new_value | `approved` | normalize only for comparison |
| event_date | `2026-07-15T09:30:00Z` | block |
| values.oldValue | original old value; display fallback `-` only when empty | preserve stored value |
| values.newValue | original new value; display fallback `-` only when empty | preserve stored value |

Expected cardinality: exactly `1` for a meaningful first stimulus; `0` for no-op; remains `1` after duplicate stimulus.

## 7. Observability
- Created: `generated_events` query by `change_id` + `event_type` returns one full payload; `change_errors` count is zero.
- No-op: event count zero and no processing error.
- Blocked: event count zero and one diagnostic in `change_errors` with rule/change identity and missing-data reason.
- Duplicate: event count remains one after a real second publish and process request.

## 8. Functional test catalog
| ID | Behavior | Expected | Allocation |
|---|---|---|---|
| TC-001 | meaningful modified state change | one exact event, zero errors | MQA-001 / AUTO-001 |
| TC-002 | equal normalized values | no event, zero errors | MQA-002 / AUTO-002 |
| TC-003 | unrelated field | no event, zero errors | MQA-003 / AUTO-003 |
| TC-004 | unsupported operation status | no event, zero errors | MQA-004 / AUTO-004 |
| TC-005 | duplicate composite identity | second real stimulus adds no event | MQA-005 / AUTO-005 |
| TC-006 | mandatory identifier missing | blocked, diagnostic error, no event | MQA-006 / AUTO-006 |

## 9. Atomic unit/provider specifications
| ID | Atomic behavior | Exact assertions |
|---|---|---|
| UNIT-001 | target-path matcher accepts `item.processingState` | true only for exact path |
| UNIT-002 | operation matcher accepts `modified` | true only for supported status |
| UNIT-003 | meaningful comparator detects `pending`→`approved` | create decision |
| UNIT-004 | equal normalized values are noop | no event candidate |
| UNIT-005 | empty display fallback | rendered placeholder is `-`, stored semantics unchanged |
| UNIT-006 | missing mandatory identity | blocked decision with diagnostic reason |
| UNIT-007 | event mapper | all exact fields and values mapped |
| UNIT-008 | event cardinality | one candidate for one meaningful change |
| UNIT-009 | composite duplicate check | same change_id+event_type rejected |
| UNIT-010 | normalization preserves case/whitespace | no trim, no case conversion |
| UNIT-011 | unrelated field is noop | no candidate and no error |

## 10. Functional-to-unit semantic mapping
- TC-001 → UNIT-001, UNIT-002, UNIT-003, UNIT-007, UNIT-008.
- TC-002 → UNIT-004, UNIT-010.
- TC-003 → UNIT-011.
- TC-004 → UNIT-002.
- TC-005 → UNIT-009.
- TC-006 → UNIT-006.

## 11. Repository binding and exclusions
Concrete implementation module and repository symbols are unavailable. Production code edits and exact symbol names remain repository-discovery-bound. This does not block the exact declarative Manual QA and Automation specifications. No live execution result is claimed.
