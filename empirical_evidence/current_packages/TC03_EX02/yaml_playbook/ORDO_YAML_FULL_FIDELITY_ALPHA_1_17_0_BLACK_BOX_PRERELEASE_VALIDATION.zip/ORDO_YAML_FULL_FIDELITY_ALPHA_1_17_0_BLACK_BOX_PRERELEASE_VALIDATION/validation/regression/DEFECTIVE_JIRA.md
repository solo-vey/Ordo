# Jira Task — PROCESSING_STATE_CHANGED

## Summary and business context
Deliver support for `RECORD_PROCESSING_STATE_CHANGED` when `source_records` document `DOC-74291`, record `REC-184`, changes `item.processingState` from `pending` to `approved` under `RULE_RECORD_PROCESSING_STATE_CHANGED`. Canonical Passport reference: `01_RECORD_CHANGE_PASSPORT_PROCESSING_STATE_CHANGED.md`, sections 3–10, version v1.0.0.

## Delivery Requirements
| Delivery ID | Atomic requirement | Evidence |
|---|---|---|
| DEL-001 | Discover and record the production module/provider responsible for database-change rule dispatch. | repository path and symbol reference |
| DEL-002 | Bind `RULE_RECORD_PROCESSING_STATE_CHANGED` to exact field-path and operation matching. | code diff + UNIT-001/002 |
| DEL-003 | Implement comparison normalization without trimming or case conversion. | UNIT-003/004/010 |
| DEL-004 | Map exactly one `RECORD_PROCESSING_STATE_CHANGED` payload with all Passport section 6 fields. | UNIT-007/008 |
| DEL-005 | Enforce composite deduplication by `change_id` and `event_type`. | UNIT-009 + TC-005 |
| DEL-006 | Implement no-op for equal values, unrelated fields and unsupported statuses. | TC-002/003/004 |
| DEL-007 | Block missing mandatory data and emit diagnostic evidence. | UNIT-006 + TC-006 |
| DEL-008 | Preserve rollback symmetry and observability bindings. | Manual QA evidence |
| DEL-009 | Add runner-ready automation cases with full payload assertions. | validated automation spec |

## Acceptance Criteria
- AC-001: Given `modified`, exact target path, and `pending`→`approved`, processing persists exactly one event with every mapped field equal to Passport section 6.
- AC-002: Equal normalized values persist zero events and zero errors.
- AC-003: An unrelated field persists zero events and zero errors.
- AC-004: An unsupported status persists zero events and zero errors.
- AC-005: A second explicit publish/process stimulus with the same composite identity leaves event cardinality at one.
- AC-006: Missing mandatory identity persists zero events and a diagnostic error keyed by change and rule.
- AC-007: Rollback restores the captured baseline value.
- AC-008: Manual QA cases are case-local and executable with only runtime placeholders.
- AC-009: Automation schema and semantic validators pass.

## Functional delivery coverage
TC-001 through TC-006 are defined in Passport section 8 and mapped one-to-one to MQA-001..006 and AUTO-001..006.

## Dependencies and blockers
| DEP ID | Dependency/blocker | Closure criterion |
|---|---|---|
| DEP-001 | Production repository module/provider symbols unavailable. | Repository discovery records exact file, symbol, dispatch point and test locations before coding. |
| DEP-002 | BASE_URL, AUTH_HEADERS and DATABASE_NAME are runtime-discovered. | Operator captures values from the target environment before execution; document generation remains unblocked. |
| DEP-003 | No compatible runner/live environment was supplied. | Execute validated spec in a compatible runner before claiming live pass/fail. |

## Definition of Done
All DEL rows are complete with evidence; AC-001..009 have evidence or visible unresolved blocker; Passport version is current; repository discovery evidence is recorded; Manual QA and Automation handoffs validate; observability is verified; no live result is invented; final cross-document consistency passes.
