#!/usr/bin/env python3
from pathlib import Path
import json,sys,datetime
p=Path(sys.argv[1]); d=json.loads(p.read_text(encoding='utf-8')); e=[]
req=['artifact','artifact_version','artifact_sha256','required_validator_ids','validator_results','validated_at']
for k in req:
    if not d.get(k): e.append('RECEIPT_FIELD_MISSING:'+k)
sha=d.get('artifact_sha256'); results=d.get('validator_results') or []
byid={x.get('validator_id'):x for x in results if isinstance(x,dict)}
for vid in d.get('required_validator_ids') or []:
    r=byid.get(vid)
    if not r: e.append('REQUIRED_VALIDATOR_RESULT_MISSING:'+str(vid)); continue
    if r.get('result')!='PASS' or r.get('return_code') not in (0,'0'): e.append('VALIDATOR_NOT_PASS:'+str(vid))
    if r.get('artifact_sha256')!=sha: e.append('VALIDATOR_HASH_MISMATCH:'+str(vid))
if d.get('latest_regeneration_at') and d.get('validated_at') <= d.get('latest_regeneration_at'):
    e.append('VALIDATION_PRECEDES_LATEST_REGENERATION')
print(json.dumps({'validator':'artifact_approval_receipt_v1','errors':e,'result':'PASS' if not e else 'FAIL'},indent=2));sys.exit(0 if not e else 1)
