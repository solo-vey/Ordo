#!/usr/bin/env python3
from pathlib import Path
import argparse, json, re, yaml
from datetime import date, datetime

FIELDS = {
  "document_id": ["document_id", "documentId"],
  "record_key": ["record_key", "recordKey"],
  "field_path": ["field_path", "fieldPath"],
  "change_id": ["change_id", "changeId"],
  "occurred_at": ["occurred_at", "occurredAt"],
  "event_type": ["event_type", "eventType"],
}

def norm(v):
    if isinstance(v, (datetime, date)):
        s=v.isoformat()
    else:
        s=str(v).strip().strip('"').strip("'").strip("`")
    return s.replace("+00:00","Z").rstrip(".,;:").rstrip(".,;:").rstrip(".,;:").rstrip(".,;:")

def deep_find(obj, names):
    if isinstance(obj, dict):
        for k,v in obj.items():
            if k in names and v not in (None, ""): return norm(v)
            found=deep_find(v,names)
            if found is not None: return found
    elif isinstance(obj,list):
        for x in obj:
            found=deep_find(x,names)
            if found is not None: return found
    return None

def collect_declared(obj):
    allowed={k:set() for k in FIELDS}
    if not isinstance(obj,dict): return allowed
    blocks=[]
    for key in ("allowed_derived_literals","derived_case_literals","negative_fixture_literals"):
        v=obj.get(key)
        if isinstance(v,dict): blocks.append(v)
    for block in blocks:
        for field,values in block.items():
            if field in allowed:
                if not isinstance(values,list): values=[values]
                allowed[field].update(norm(x) for x in values)
    return allowed

def parse_artifact(path):
    text=path.read_text(encoding="utf-8",errors="replace")
    data=None
    if path.suffix.lower() in {".yaml",".yml",".json"}:
        try:
            data=yaml.safe_load(text)
        except Exception:
            data=None
    allowed=collect_declared(data)
    # Markdown declaration form:
    # derived_case_literal: change_id=CHG-... role=dedup
    for m in re.finditer(r'(?im)^\s*(?:derived_case_literal|negative_fixture_literal)\s*:\s*(\w+)\s*=\s*([^\s|,]+)',text):
        field,val=m.group(1),norm(m.group(2))
        if field in allowed: allowed[field].add(val)
    return text,data,allowed

def all_values(obj,names):
    out=[]
    if isinstance(obj,dict):
        for k,v in obj.items():
            if k in {"allowed_derived_literals","derived_case_literals","negative_fixture_literals"}:
                continue
            if k in names and v not in (None,""): out.append(norm(v))
            out.extend(all_values(v,names))
    elif isinstance(obj,list):
        for x in obj: out.extend(all_values(x,names))
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("selected_input")
    ap.add_argument("artifacts",nargs="+")
    args=ap.parse_args()
    selected=yaml.safe_load(Path(args.selected_input).read_text(encoding="utf-8"))
    expected={k:deep_find(selected,names) for k,names in FIELDS.items()}
    expected={k:v for k,v in expected.items() if v is not None}
    selected_allowed=collect_declared(selected)
    errors=[]; checked=[]; declarations={}
    for pstr in args.artifacts:
        p=Path(pstr); text,data,local_allowed=parse_artifact(p)
        checked.append(str(p))
        allowed={k:set(selected_allowed[k])|set(local_allowed[k]) for k in FIELDS}
        declarations[p.name]={k:sorted(v) for k,v in allowed.items() if v}
        for key,names in FIELDS.items():
            exp=expected.get(key)
            if exp is None: continue
            vals=all_values(data,names) if data is not None else []
            if data is None:
                pats=[]
                for n in names:
                    pats += [
                      rf'(?im)^\s*[-|]*\s*{re.escape(n)}\s*[:=|]\s*["`]?([^\s|,"`]+)',
                      rf'(?i)["\']{re.escape(n)}["\']\s*:\s*["\']([^"\']+)',
                    ]
                for pat in pats: vals += [norm(m.group(1)) for m in re.finditer(pat,text)]
            for val in vals:
                if val in {exp} or val in allowed[key] or val.startswith(("${","{{","<")):
                    continue
                errors.append(f"{p.name}:{key}:expected={exp}:actual={val}:undeclared_derived_literal")
        identities=[expected.get("document_id"),expected.get("record_key"),expected.get("change_id")]
        identities=[x for x in identities if x]
        if identities and not any(x in text for x in identities):
            errors.append(f"{p.name}:NO_AUTHORITATIVE_RUN_IDENTITY_LITERAL")
    result={
      "validator":"selected_run_literal_consistency_v2",
      "expected":expected,"declared_derived_literals":declarations,
      "checked":checked,"errors":errors,"result":"PASS" if not errors else "FAIL"
    }
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if not errors else 1
if __name__=="__main__": raise SystemExit(main())
