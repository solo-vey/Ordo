#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("drv", ROOT/"driver/semantic_analyst_driver.py")
drv=importlib.util.module_from_spec(spec); spec.loader.exec_module(drv)
scenario={"name":"test","terminal_policy":"complete_go","approval_policy":"allowed"}
state=drv.default_state("RUN_02",scenario)

def receipt(key,version,sha,result="PASS",rc=0):
 return {"artifact":key,"artifact_version":version,"artifact_sha256":sha,"validated_at":"2026-07-16T12:00:00Z","validator_results":[{"validator_id":"v","validator_version":"1","result":result,"return_code":rc,"artifact_sha256":sha}]}

# approval without receipt rejected
r=drv.handle_present(scenario,state,{"artifact":"passport","version":"v1"}); assert r["status"]=="not_approved"
# validate+approve all current hashes
items=[("passport","approval.passport"),("jira","approval.jira"),("qa package","approval.qa"),("automation specification","approval.automation")]
for i,(name,key) in enumerate(items,1):
 rec=receipt(key,"v1",f"sha{i}")
 assert drv.handle_validation(state,{"artifact":name,"validation_receipt":rec})["status"]=="validated"
 assert drv.handle_present(scenario,state,{"artifact":name,"version":"v1","validation_receipt":rec})["status"]=="approved"
# terminal still blocked until final gates
r=drv.determine_terminal(scenario,state); assert r["status"]=="not_ready" and r["reason"]=="final_gates_not_passed"
assert drv.handle_gate(state,{"gate":"cross_artifact","result":"PASS"})["status"]=="gate_passed"
assert drv.handle_gate(state,{"gate":"package","result":"PASS"})["status"]=="gate_passed"
r=drv.determine_terminal(scenario,state); assert r["terminal"]=="T_COMPLETED" and r["go_no_go"]=="go"
# invalidation reopens terminal and removes approval
r=drv.handle_invalidate(state,{"artifact":"jira"}); assert r["status"]=="invalidated" and state["terminal"] is None and not state["complete"]
r=drv.determine_terminal(scenario,state); assert r["status"]=="not_ready"
# failed validation requires regeneration and no approval
bad=receipt("approval.jira","v2","sha-new","FAIL",1)
r=drv.handle_validation(state,{"artifact":"jira","validation_receipt":bad}); assert r["status"]=="validation_failed" and "approval.jira" in state["regeneration_required"]
print(json.dumps({"result":"PASS","tests":6,"version":"1.16.7"}))
