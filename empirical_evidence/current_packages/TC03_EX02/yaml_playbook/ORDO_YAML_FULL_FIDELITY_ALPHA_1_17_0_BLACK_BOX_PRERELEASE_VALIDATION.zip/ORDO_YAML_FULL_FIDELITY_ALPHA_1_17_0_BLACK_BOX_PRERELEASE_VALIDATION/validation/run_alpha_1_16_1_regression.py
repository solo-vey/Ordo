#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, json

root = Path(__file__).resolve().parents[1]
validator = root / "validation/validate_automation_rendered.py"

tests = [
    {
        "name": "alpha_1_14_defective_automation_rejected",
        "fixture": root / "validation/regression/DEFECTIVE_AUTOMATION.yaml",
        "expect_reject": True,
        "required_codes": [
            "AUTO-003:post_rollback_verification_observes_different_field",
            "AUTO-004:change_absent_rollback_without_source_mutation_provenance",
        ],
    },
    {
        "name": "positive_automation_accepted",
        "fixture": root / "validation/regression_1161/AUTOMATION_POSITIVE.yaml",
        "expect_reject": False,
        "required_codes": [],
    },
]

results = []
failed = []

for t in tests:
    p = subprocess.run(
        [sys.executable, str(validator), str(t["fixture"])],
        capture_output=True, text=True
    )
    rejected = p.returncode != 0
    codes_ok = all(code in p.stdout for code in t["required_codes"])
    ok = (rejected == t["expect_reject"]) and codes_ok
    results.append({
        "name": t["name"],
        "fixture": str(t["fixture"].relative_to(root)),
        "expected_rejected": t["expect_reject"],
        "actual_rejected": rejected,
        "validator_returncode": p.returncode,
        "required_codes_present": codes_ok,
        "stdout": p.stdout,
        "stderr": p.stderr,
        "result": "PASS" if ok else "FAIL",
    })
    if not ok:
        failed.append(t["name"])

print(json.dumps({
    "suite": "alpha_1_16_1_automation_lifecycle_restore",
    "results": results,
    "failed": failed,
    "result": "PASS" if not failed else "FAIL",
}, ensure_ascii=False, indent=2))
sys.exit(0 if not failed else 1)
