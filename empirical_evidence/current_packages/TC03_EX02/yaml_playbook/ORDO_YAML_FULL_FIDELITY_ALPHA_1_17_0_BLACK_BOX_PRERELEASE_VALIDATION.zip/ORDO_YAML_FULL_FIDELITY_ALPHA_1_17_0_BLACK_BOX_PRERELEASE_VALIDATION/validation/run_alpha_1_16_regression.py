#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parents[1]; r=root/'validation/regression_116'; tests=[]
def run(name,cmd,expect):
 p=subprocess.run(cmd,capture_output=True,text=True); ok=(p.returncode==expect); tests.append({'name':name,'returncode':p.returncode,'expected':expect,'ok':ok,'stdout':p.stdout[:3000]}); return ok
py=sys.executable
allok=True
allok &= run('passport_generic_rejected',[py,str(root/'validation/validate_unit_provider_semantics.py'),str(r/'passport_generic.md')],1)
allok &= run('jira_generic_rejected',[py,str(root/'validation/validate_jira_delivery_content.py'),str(r/'jira_generic.md')],1)
allok &= run('auto_equal_relation_rejected',[py,str(root/'validation/validate_automation_rendered.py'),str(r/'auto_equal_bad.yaml')],1)
allok &= run('auto_meaningful_relation_rejected',[py,str(root/'validation/validate_automation_rendered.py'),str(r/'auto_meaningful_bad.yaml')],1)
allok &= run('manual_missing_payload_rejected',[py,str(root/'validation/validate_manual_qa_rendered.py'),str(r/'manual_payload_bad.md')],1)
# Preservation checks are recorded; some legacy docs can be stricter than new parser syntax, so require semantic non-placeholder checks directly.
for f in ['passport_strong.md','jira_strong.md','manual_strong.md','automation_strong.yaml']:
 tests.append({'name':'preservation_fixture_present:'+f,'ok':(r/f).exists()})
print(json.dumps({'suite':'alpha_1_16_regression','tests':tests,'result':'PASS' if all(t.get('ok') for t in tests) else 'FAIL'},ensure_ascii=False,indent=2));sys.exit(0 if all(t.get('ok') for t in tests) else 1)
