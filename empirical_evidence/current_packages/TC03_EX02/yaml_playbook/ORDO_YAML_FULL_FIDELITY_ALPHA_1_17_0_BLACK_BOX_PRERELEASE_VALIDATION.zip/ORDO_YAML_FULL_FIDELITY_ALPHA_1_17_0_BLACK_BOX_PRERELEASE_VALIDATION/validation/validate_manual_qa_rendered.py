#!/usr/bin/env python3
import re, sys, pathlib, json

p = pathlib.Path(sys.argv[1])
t = p.read_text(encoding="utf-8")
errs = []
case_results = []

def section(case, n):
    m = re.search(rf"### Step {n}\..*?(?=### Step {n+1}\.|### Final expected result|\Z)", case, re.S)
    return m.group(0) if m else ""

def json_bodies(s):
    bodies = []
    for raw in re.findall(r"--data\s+'(\{.*?\})'", s, re.S):
        try:
            import json as _json
            bodies.append(_json.loads(raw))
        except Exception:
            pass
    return bodies

cases = re.split(r"(?=^## MQA-\d+)", t, flags=re.M)[1:]
if not cases:
    errs.append("no_cases")

for c in cases:
    m = re.search(r"^## (MQA-\d+)", c, re.M)
    cid = m.group(1) if m else "UNKNOWN"
    tc = re.search(r"Functional TC:\s*(TC-\d+)", c)
    local_errors = []
    blocked = bool(re.search(r"evidence_status:\s*blocked|status:\s*blocked|blocked_(?:missing_evidence|repository_binding|contract_conflict|missing_binding)", c, re.I))

    ids = set(re.findall(r"\b(?:MQA|TC)-\d+\b", c))
    allowed = {cid}
    if tc:
        allowed.add(tc.group(1))
    foreign = sorted(ids - allowed)
    if foreign:
        local_errors.append(f"cross_case_identifiers:{foreign}")

    if blocked:
        for token in ["blocked_reason", "missing_capability", "required_evidence"]:
            if token not in c:
                local_errors.append(f"blocked_case_missing:{token}")
    else:
        for n in range(10):
            if f"Step {n}." not in c:
                local_errors.append(f"missing_step:{n}")
        for n in [1,2,4,5,6,7,8,9]:
            sec = section(c, n)
            if sec and not re.search(r"```|\b(GET|POST|PUT|PATCH|DELETE)\b|mongosh|mongo_find|Not applicable|not required", sec, re.I):
                local_errors.append(f"step_{n}_lacks_concrete_command_or_explicit_na")

        s3, s4, s5, s6, s7, s8, s9 = [section(c, n) for n in [3,4,5,6,7,8,9]]
        stimuli = json_bodies(s4)
        rollbacks = json_bodies(s9)
        stimulus = stimuli[0] if stimuli else {}
        # In duplicate/idempotency cases Step 9 may contain the second publish/process cycle
        # before the actual rollback. Treat the last publish body as rollback.
        duplicate_hint = bool(re.search(r"duplicate|deduplic|idempot", c, re.I))
        rollback = (rollbacks[-1] if duplicate_hint and rollbacks else (rollbacks[0] if rollbacks else {}))

        # Extract expected cardinalities by step.
        def card(s):
            mm = re.search(r"Expected cardinality:\s*(\d+)", s, re.I)
            return int(mm.group(1)) if mm else None
        change_count, event_count, error_count = card(s5), card(s7), card(s8)

        # Conditional positive assertions are forbidden when expected count is zero.
        if event_count == 0 and re.search(r"when cardinality is 1|if cardinality.*1", s7, re.I):
            local_errors.append("event_zero_with_conditional_positive_payload_assertions")
        if change_count == 0 and re.search(r"where a change record is expected|when.*change record", s5, re.I):
            local_errors.append("change_zero_with_conditional_positive_projection_assertions")

        # Processor cannot consume a changeId when the case asserts no change record, absent an explicit alternate contract.
        if change_count == 0 and re.search(r"/api/database-change/process|process", s6, re.I) and not re.search(r"Not applicable|alternate authoritative", s6, re.I):
            local_errors.append("processor_invoked_while_change_cardinality_zero")

        stimulus_field = stimulus.get("fieldPath")
        stimulus_old = stimulus.get("oldValue")
        stimulus_new = stimulus.get("newValue")
        rollback_field = rollback.get("fieldPath")
        rollback_old = rollback.get("oldValue")
        rollback_new = rollback.get("newValue")

        # Rollback symmetry and mutation provenance.
        rollback_is_na = bool(re.search(r"Not applicable|rollback.*not required|no source rollback", s9, re.I))
        if rollback and stimulus:
            if rollback_field != stimulus_field:
                local_errors.append(f"rollback_field_mismatch:{stimulus_field}->{rollback_field}")
            if rollback_old != stimulus_new or rollback_new != stimulus_old:
                local_errors.append("rollback_values_not_inverse_of_stimulus")
            # Post-rollback verification must observe the same field.
            if rollback_field and rollback_field not in s9:
                local_errors.append("post_rollback_verification_missing_mutated_field")
        elif not rollback and not rollback_is_na:
            local_errors.append("rollback_neither_concrete_nor_explicit_na")

        # No-record negative path: a rejected/nonpersisted stimulus cannot synthesize a reverse publish.
        if change_count == 0 and rollback:
            local_errors.append("reverse_publish_for_nonpersisted_change_forbidden")

        # Missing required field executable case requires explicit authoritative omission binding.
        title_match = re.search(r"^## MQA-\d+[^\n]*", c, re.M)
        title_low = title_match.group(0).lower() if title_match else ""
        if ("missing mandatory" in title_low or "missing required" in title_low or "omit" in title_low):
            if not re.search(r"authoritative omission binding:\s*(confirmed|available)|omission_binding_status:\s*confirmed", c, re.I):
                local_errors.append("missing_field_case_executable_without_authoritative_omission_binding")

        # Exact negative assertions are mandatory for each persisted output family.
        for label, secx in [("change", s5), ("event", s7), ("error", s8)]:
            if "Expected cardinality" not in secx:
                local_errors.append(f"{label}_cardinality_missing")


    # Duplicate/idempotency behavior requires two real publish/process cycles and final assertions after cycle 2.
    is_duplicate = bool(re.search(r"duplicate|deduplic|idempot", c, re.I))
    if is_duplicate and not blocked:
        publish_matches = list(re.finditer(r"curl\s+-X\s+POST\s+\"\$BASE_URL/api/test/database-change/publish\"", c, re.I))
        process_matches = list(re.finditer(r"curl\s+-X\s+POST\s+\"\$BASE_URL/api/database-change/process\"", c, re.I))
        if len(publish_matches) < 2 or len(process_matches) < 2:
            local_errors.append(
                f"MQA_DUPLICATE_SECOND_CYCLE_MISSING:publish={len(publish_matches)},process={len(process_matches)}"
            )
        else:
            second_publish_pos = publish_matches[1].start()
            second_process_pos = process_matches[1].start()
            if second_process_pos < second_publish_pos:
                local_errors.append("duplicate_second_process_precedes_second_publish")
            after_second = c[max(second_publish_pos, second_process_pos):]
            final_cards = re.findall(r"Expected cardinality:\s*(\d+)", after_second, re.I)
            if len(final_cards) < 2:
                local_errors.append("duplicate_final_change_event_cardinality_after_second_cycle_missing")
            if not re.search(r"no second|without a second|second.*not.*created|final.*cardinality.*1", after_second, re.I):
                local_errors.append("duplicate_exact_negative_second_event_assertion_missing")
            # Compare stable business payload fields in the first two publish commands only.
            publish_bodies = []
            publish_pattern = re.compile(
                r'curl\s+-X\s+POST\s+"\$BASE_URL/api/test/database-change/publish".*?--data\s+\'(\{.*?\})\'',
                re.I | re.S,
            )
            for raw in publish_pattern.findall(c):
                try:
                    import json as _json
                    publish_bodies.append(_json.loads(raw))
                except Exception:
                    pass
            if len(publish_bodies) >= 2:
                stable_fields = ["recordKey", "fieldPath", "oldValue", "newValue", "operationStatus", "ruleId"]
                mismatches = [f for f in stable_fields if publish_bodies[0].get(f) != publish_bodies[1].get(f)]
                if mismatches:
                    local_errors.append("duplicate_business_payload_not_equivalent:" + ",".join(mismatches))

    for e in local_errors:
        errs.append(f"{cid}:{e}")
    case_results.append({"id": cid, "blocked": blocked, "errors": local_errors})

# Executable exact-payload checks.
def strip_code_comments(code):
    lines=[]
    for line in code.splitlines():
        s=line.lstrip()
        if s.startswith("#") or s.startswith("//"):
            continue
        if " #" in line:
            line=line.split(" #",1)[0]
        lines.append(line)
    return "\n".join(lines)

def fenced_blocks(sec):
    return [strip_code_comments(x) for x in re.findall(r"```(?:bash|sh|javascript|js)?\s*(.*?)```", sec, re.S | re.I)]

def normalized(s):
    return re.sub(r"[^a-z0-9]+", "", s.lower())

def executable_contains_all(sec, required_groups):
    blocks = fenced_blocks(sec)
    for block in blocks:
        low=block.lower()
        has_query=bool(re.search(r"countdocuments|\.count\s*\(|findone\s*\(|find\s*\(",low))
        has_compare=bool(re.search(r"(===|!==|==|!=)|\bassert\s*\(|\bif\s*\(",low))
        has_fail=bool(re.search(r"quit\s*\(\s*1\s*\)|process\.exit\s*\(\s*1\s*\)|exit\s+1|throw\s+new\s+error",low)) or bool(re.search(r"\bassert\s*\(",low))
        blob=normalized(block)
        fields_ok=all(any(normalized(token) in blob for token in group) for group in required_groups)
        if has_query and has_compare and has_fail and fields_ok:
            return True
    return False

for c in cases:
    mm = re.search(r"^## (MQA-\d+)", c, re.M)
    cid = mm.group(1) if mm else "UNKNOWN"
    blocked = bool(re.search(r"evidence_status:\s*blocked|status:\s*blocked", c, re.I))
    if blocked:
        continue

    s5, s7, s8 = section(c, 5), section(c, 7), section(c, 8)

    def card(sec):
        m = re.search(r"Expected cardinality:\s*(\d+)", sec, re.I)
        return int(m.group(1)) if m else None

    change_count, event_count, error_count = card(s5), card(s7), card(s8)

    if change_count == 1:
        groups = [["change_id", "changeid"], ["document_id", "documentid"], ["record_key", "recordkey"], ["field_path", "fieldpath"], ["old_value", "oldvalue"], ["new_value", "newvalue"], ["operation_status", "operationstatus"]]
        if not executable_contains_all(s5, groups): errs.append(cid + ":MQA_CHANGE_EXECUTABLE_EXACT_ASSERTION_MISSING")
    if event_count == 1:
        groups = [["event_type", "eventtype"], ["event_date", "eventdate", "occurredat"], ["record_key", "recordkey"], ["field_path", "fieldpath"], ["old_value", "oldvalue"], ["new_value", "newvalue"], ["rule_id", "ruleid"]]
        if not executable_contains_all(s7, groups): errs.append(cid + ":MQA_EVENT_EXECUTABLE_EXACT_ASSERTION_MISSING")
    if error_count == 1:
        groups = [["error_type", "errorcode", "code"], ["change_id", "changeid", "record_key", "recordkey"], ["field", "reason"], ["rule_id", "ruleid"], ["status"]]
        if not executable_contains_all(s8, groups): errs.append(cid + ":MQA_ERROR_EXECUTABLE_EXACT_ASSERTION_MISSING")

print(json.dumps({
    "validator": "manual_qa_syntax_aware_exact_assertion_v5",
    "cases": case_results,
    "errors": errs,
    "result": "PASS" if not errs else "FAIL",
}, ensure_ascii=False, indent=2))
sys.exit(0 if not errs else 1)
