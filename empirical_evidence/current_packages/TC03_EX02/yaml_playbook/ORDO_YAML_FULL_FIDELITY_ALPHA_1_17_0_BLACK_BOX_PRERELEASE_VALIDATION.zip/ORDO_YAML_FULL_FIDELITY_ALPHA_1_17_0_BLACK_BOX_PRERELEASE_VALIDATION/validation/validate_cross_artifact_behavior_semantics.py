#!/usr/bin/env python3
from pathlib import Path
import re,yaml,sys,json
passport=Path(sys.argv[1]).read_text(encoding='utf-8'); manual=Path(sys.argv[2]).read_text(encoding='utf-8'); auto=yaml.safe_load(Path(sys.argv[3]).read_text(encoding='utf-8')); errs=[]
for c in auto.get('test_cases',[]):
 cid=c.get('id',''); n=re.search(r'(\d+)$',cid); tc=f'TC-{int(n.group(1)):03d}' if n else None; title=str(c.get('title','')).lower(); blob=yaml.safe_dump(c)
 if tc and tc not in passport: errs.append(tc+':CROSS_ARTIFACT_BEHAVIOR_SEMANTIC_MISMATCH:missing_passport')
 if cid and cid.replace('AUTO','MQA') not in manual: errs.append(cid+':CROSS_ARTIFACT_BEHAVIOR_SEMANTIC_MISMATCH:missing_manual')
 if ('equal-value' in title or 'equal value' in title) and not re.search(r'(approved\s*(?:→|->|to)\s*approved|pending\s*(?:→|->|to)\s*pending)',passport+manual,re.I): errs.append(cid+':CROSS_ARTIFACT_BEHAVIOR_SEMANTIC_MISMATCH')
print(json.dumps({'validator':'cross_artifact_behavior_semantics_v1','errors':errs,'result':'PASS' if not errs else 'FAIL'},ensure_ascii=False,indent=2));sys.exit(0 if not errs else 1)
