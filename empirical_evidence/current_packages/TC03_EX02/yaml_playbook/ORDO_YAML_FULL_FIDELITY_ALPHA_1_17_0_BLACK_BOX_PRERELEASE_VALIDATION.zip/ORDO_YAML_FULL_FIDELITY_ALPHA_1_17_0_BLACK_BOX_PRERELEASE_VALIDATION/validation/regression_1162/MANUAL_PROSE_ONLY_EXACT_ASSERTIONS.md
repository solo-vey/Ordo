## MQA-001 — Meaningful change
Functional TC: TC-001
### Step 0. Case identity
x
### Step 1. Setup
```bash
echo setup
```
### Step 2. Preconditions
```bash
echo pre
```
### Step 3. Expectations
Expected 1/1/0.
### Step 4. Publish
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" --data '{"changeId":"CHG-1","documentId":"DOC-1","recordKey":"REC-1","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
### Step 5. Assert change
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.countDocuments({change_id:"CHG-1"})'
```
Expected cardinality: 1. Assert exact change payload fields.
### Step 6. Process
```bash
curl -X POST "$BASE_URL/api/database-change/process" --data '{"changeId":"CHG-1","ruleId":"RULE-1"}'
```
### Step 7. Assert event
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.countDocuments({change_id:"CHG-1"})'
```
Expected cardinality: 1. Assert exact event payload fields.
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.countDocuments({change_id:"CHG-1"})'
```
Expected cardinality: 0.
### Step 9. Rollback
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" --data '{"changeId":"CHG-1","documentId":"DOC-1","recordKey":"REC-1","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
```
