## MQA-001
### Step 5. Assert change
```bash
mongosh "$DB" --eval 'db.change_records.countDocuments({changeId:"CHG-1"})'
# assert(count === 0); exit 1 on mismatch
```
Expected cardinality: 0
### Step 7. Assert event
```bash
mongosh "$DB" --eval 'db.events.countDocuments({changeId:"CHG-1"})'
# assert(count === 0); exit 1
```
Expected cardinality: 0
### Step 8. Assert errors
```bash
mongosh "$DB" --eval 'db.errors.countDocuments({changeId:"CHG-1"})'
# assert(count === 0); exit 1
```
Expected cardinality: 0
### Step 9. Rollback
```bash
mongosh "$DB" --eval 'db.source.findOne({documentId:"DOC-1"})'
# assert(item.processingState === "pending"); exit 1
```
