## MQA-001
### Step 5. Assert change
```bash
mongosh "$DB" --eval 'const n=db.change_records.countDocuments({changeId:"CHG-1"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 7. Assert event
```bash
mongosh "$DB" --eval 'const n=db.events.countDocuments({changeId:"CHG-1"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 8. Assert errors
```bash
mongosh "$DB" --eval 'const n=db.errors.countDocuments({changeId:"CHG-1"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 9. Rollback
```bash
mongosh "$DB" --eval 'const x=db.source.findOne({documentId:"DOC-1"}); if(!x || x.item.processingState!=="pending") quit(1)'
```
