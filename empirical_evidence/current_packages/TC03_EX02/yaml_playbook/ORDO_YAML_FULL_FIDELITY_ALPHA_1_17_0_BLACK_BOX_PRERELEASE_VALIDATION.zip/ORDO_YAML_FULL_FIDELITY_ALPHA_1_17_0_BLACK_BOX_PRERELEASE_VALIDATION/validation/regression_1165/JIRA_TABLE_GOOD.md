# Jira
| ID | Delivery | Ref |
|---|---|---|
| DEL-001 | Implement processing-state handling for item.processingState; persist exactly one change record, emit exactly one event, and create zero error records. | Passport TC-001 |
| AC-001 | Given oldValue pending and newValue approved when operationStatus is modified, the processor creates exactly one change record, emits exactly one event, and creates zero errors. | TC-001 |
## Definition of Done
Evidence report and logs are linked; blockers have closure evidence; Passport, Manual QA and Automation consistency checks pass.
