#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, json

root = Path(__file__).resolve().parents[1]
reg = root / "validation/regression"
tests = [
    ("passport_defect_rejected", [sys.executable, str(root/"validation/validate_unit_provider_semantics.py"), str(reg/"DEFECTIVE_PASSPORT.md")]),
    ("manual_defects_rejected", [sys.executable, str(root/"validation/validate_manual_qa_rendered.py"), str(reg/"DEFECTIVE_MANUAL_QA.md")]),
    ("automation_defects_rejected", [sys.executable, str(root/"validation/validate_automation_rendered.py"), str(reg/"DEFECTIVE_AUTOMATION.yaml")]),
    ("cross_status_drift_rejected", [
        sys.executable, str(root/"validation/validate_cross_artifact_semantics.py"),
        str(reg/"DEFECTIVE_PASSPORT.md"), str(reg/"DEFECTIVE_JIRA.md"), str(reg/"DEFECTIVE_MANUAL_QA.md"),
        str(reg/"DEFECTIVE_AUTOMATION.yaml"), str(reg/"NEGATIVE_CASE_STATUS_REGISTRY.yaml")
    ]),
]
results = []
failed = []
for name, cmd in tests:
    p = subprocess.run(cmd, capture_output=True, text=True)
    # Negative fixtures pass regression only when validator rejects them.
    ok = p.returncode != 0
    results.append({"name":name,"negative_fixture_rejected":ok,"validator_returncode":p.returncode,"stdout":p.stdout[:4000],"stderr":p.stderr[:1000]})
    if not ok:
        failed.append(name)
print(json.dumps({"suite":"alpha_1_14_negative_regression","results":results,"failed":failed,"result":"PASS" if not failed else "FAIL"}, ensure_ascii=False, indent=2))
sys.exit(0 if not failed else 1)
