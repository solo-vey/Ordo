#!/usr/bin/env python3
from pathlib import Path
import re, sys, yaml
root=Path(sys.argv[1])
qa=next(root.glob('05_QA_PACKAGE_*.md')).read_text()
auto=yaml.safe_load(next(root.glob('08_QA_AUTOMATION_SPEC_*.yaml')).read_text())
errors=[]
cases=re.split(r'(?=^### MQA-\d+)',qa,flags=re.M)[1:]
if not cases: errors.append('no manual cases')
required=['Setup commands','Setup verification commands','Action/mutation commands','Trigger/invocation command','Verification commands','Rollback commands','Post-rollback verification commands']
for c in cases:
    cid=re.search(r'MQA-\d+',c).group(0)
    for key in required:
        if key not in c: errors.append(f'{cid}: missing {key}')
    if c.count('```') < 12: errors.append(f'{cid}: fewer than six fenced command blocks')
    for phrase in ['invoke processor','submit update','upsert source','query events','restore baseline','delete prior artifacts']:
        if phrase in c.lower(): errors.append(f'{cid}: unbound abstract phrase {phrase}')
for t in auto.get('tests',[]):
    for key in ['id','title','requirement_refs','manual_test_refs','preconditions','test_data','setup','action','assertions','cleanup','post_cleanup_assertions','limitations']:
        if key not in t: errors.append(f"{t.get('id','?')}: missing {key}")
    action=str(t.get('action',''))
    if 'record-change-cli process' not in action: errors.append(f"{t.get('id')}: missing concrete runner command")
if errors:
    print('\n'.join(errors)); sys.exit(1)
print('rendered EN v2 structural hard gates: PASS')
