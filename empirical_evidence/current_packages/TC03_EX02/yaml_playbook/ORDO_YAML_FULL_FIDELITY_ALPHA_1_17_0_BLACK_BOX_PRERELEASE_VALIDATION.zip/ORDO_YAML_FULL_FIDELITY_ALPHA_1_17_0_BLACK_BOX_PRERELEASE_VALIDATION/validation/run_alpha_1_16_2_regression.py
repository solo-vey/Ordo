#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, json

root = Path(__file__).resolve().parents[1]
tests = [
    ("manual_prose_only_rejected", root/"validation/validate_manual_qa_rendered.py", root/"validation/regression_1162/MANUAL_PROSE_ONLY_EXACT_ASSERTIONS.md", True,
     ["MQA_CHANGE_EXECUTABLE_EXACT_ASSERTION_MISSING","MQA_EVENT_EXECUTABLE_EXACT_ASSERTION_MISSING"]),
    ("manual_executable_exact_accepted", root/"validation/validate_manual_qa_rendered.py", root/"validation/regression_1162/MANUAL_EXECUTABLE_EXACT_ASSERTIONS.md", False, []),
    ("automation_grouped_duplicate_rejected", root/"validation/validate_automation_rendered.py", root/"validation/regression_1162/AUTOMATION_GROUPED_DUPLICATE_BAD.yaml", True,
     ["AUTO_DUPLICATE_CAUSAL_ORDER_INVALID"]),
    ("automation_causal_duplicate_accepted", root/"validation/validate_automation_rendered.py", root/"validation/regression_1162/AUTOMATION_CAUSAL_DUPLICATE_GOOD.yaml", False, []),
]
results=[]; failed=[]
for name,validator,fixture,expect_reject,codes in tests:
    p=subprocess.run([sys.executable,str(validator),str(fixture)],capture_output=True,text=True)
    rejected=p.returncode!=0
    ok=(rejected==expect_reject) and all(code in p.stdout for code in codes)
    results.append({"name":name,"expected_rejected":expect_reject,"actual_rejected":rejected,
                    "returncode":p.returncode,"required_codes":codes,"stdout":p.stdout,"stderr":p.stderr,
                    "result":"PASS" if ok else "FAIL"})
    if not ok: failed.append(name)
print(json.dumps({"suite":"alpha_1_16_2_external_rubric_alignment","results":results,
                  "failed":failed,"result":"PASS" if not failed else "FAIL"},ensure_ascii=False,indent=2))
sys.exit(0 if not failed else 1)
