#!/usr/bin/env python3
import sys, json
from pathlib import Path

p = Path(sys.argv[1])
d = json.loads(p.read_text(encoding="utf-8"))
errs = []
for node in d.get("nodes", []):
    nid = node.get("node_id", "UNKNOWN")
    for src in node.get("loaded_sources", []):
        for k in ["path","sha256","loaded_at_utc"]:
            if not src.get(k):
                errs.append(f"{nid}:source_missing_{k}")
    for run in node.get("validator_runs", []):
        for k in ["command","validator_sha256","exit_code","stdout_path","run_at_utc"]:
            if run.get(k) in [None, ""]:
                errs.append(f"{nid}:validator_run_missing_{k}")
required_nodes = {"T035","T039","T045","T052","T059"}
present = {n.get("node_id") for n in d.get("nodes", [])}
for n in required_nodes - present:
    errs.append(f"missing_node_provenance:{n}")
print(json.dumps({"validator":"provenance_manifest_validator_v1","errors":errs,"result":"PASS" if not errs else "FAIL"}, indent=2))
sys.exit(0 if not errs else 1)
