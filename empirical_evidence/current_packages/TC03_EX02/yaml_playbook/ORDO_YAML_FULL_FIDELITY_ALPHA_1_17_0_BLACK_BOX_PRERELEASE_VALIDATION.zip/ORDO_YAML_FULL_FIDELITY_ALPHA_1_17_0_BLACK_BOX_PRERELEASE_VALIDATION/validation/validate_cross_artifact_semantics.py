#!/usr/bin/env python3
import sys, re, yaml, json
from pathlib import Path

if len(sys.argv) != 6:
    print("usage: validate_cross_artifact_semantics.py PASSPORT JIRA MANUAL_QA AUTOMATION CASE_STATUS_REGISTRY")
    sys.exit(2)

passport = Path(sys.argv[1]).read_text(encoding="utf-8")
jira = Path(sys.argv[2]).read_text(encoding="utf-8")
manual = Path(sys.argv[3]).read_text(encoding="utf-8")
auto = yaml.safe_load(Path(sys.argv[4]).read_text(encoding="utf-8"))
registry = yaml.safe_load(Path(sys.argv[5]).read_text(encoding="utf-8"))

errs = []
matrix = []

behaviors = registry.get("behaviors", [])
if not behaviors:
    errs.append("case_status_registry_empty")

manual_sections = {m.group(1): m.group(0) for m in re.finditer(r"(?ms)^## (MQA-\d+).*?(?=^## MQA-\d+|\Z)", manual)}
auto_cases = {c.get("id"): c for c in auto.get("test_cases", [])}

for b in behaviors:
    tc = b.get("functional_id")
    mqa = b.get("manual_qa_id")
    aid = b.get("automation_id")
    status = b.get("authoritative_status")
    row_errors = []

    if tc not in passport:
        row_errors.append("functional_id_missing_from_passport")
    if tc not in jira:
        row_errors.append("functional_id_missing_from_jira")
    if mqa not in manual_sections:
        row_errors.append("manual_case_missing")
    if aid not in auto_cases:
        row_errors.append("automation_case_missing")

    msec = manual_sections.get(mqa, "")
    acase = auto_cases.get(aid, {})
    mblocked = bool(re.search(r"status:\s*blocked|evidence_status:\s*blocked|blocked_reason", msec, re.I))
    ablocked = acase.get("status") == "blocked" or acase.get("lifecycle_profile") == "blocked"

    expected_blocked = str(status).startswith("blocked")
    if msec and mblocked != expected_blocked:
        row_errors.append(f"manual_status_mismatch:expected_{status}")
    if acase and ablocked != expected_blocked:
        row_errors.append(f"automation_status_mismatch:expected_{status}")
    if msec and acase and mblocked != ablocked:
        row_errors.append("manual_automation_status_drift")

    # Jira must contain an explicit matrix row carrying all linked IDs and status.
    jira_row = next((ln for ln in jira.splitlines() if tc in ln), "")
    for token in [tc, mqa, aid]:
        if token and token not in jira_row:
            row_errors.append(f"jira_matrix_row_missing:{token}")
    if status and status not in jira_row:
        row_errors.append("jira_matrix_row_missing_status")
    if not re.search(r"DEL-\d+", jira_row):
        row_errors.append("jira_matrix_row_missing_DEL")
    if not re.search(r"AC-\d+", jira_row):
        row_errors.append("jira_matrix_row_missing_AC")

    # Passport must link the behavior to unit/provider IDs.
    p_line = next((ln for ln in passport.splitlines() if tc in ln and "UNIT-" in ln), "")
    if not p_line:
        row_errors.append("passport_functional_unit_link_missing")

    for e in row_errors:
        errs.append(f"{tc}:{e}")
    matrix.append({"functional_id": tc, "errors": row_errors})

print(json.dumps({
    "validator": "cross_artifact_semantic_matrix_validator_v1",
    "matrix": matrix,
    "errors": errs,
    "result": "PASS" if not errs else "FAIL",
}, ensure_ascii=False, indent=2))
sys.exit(0 if not errs else 1)
