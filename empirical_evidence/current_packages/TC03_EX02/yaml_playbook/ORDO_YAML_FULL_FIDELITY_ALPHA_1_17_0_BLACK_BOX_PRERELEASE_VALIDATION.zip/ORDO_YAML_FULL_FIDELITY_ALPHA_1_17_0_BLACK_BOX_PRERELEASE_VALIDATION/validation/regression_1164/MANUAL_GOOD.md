## MQA-001
### Step 5. Assert change
```bash
mongosh "$DB" --eval 'const n=db.changes.countDocuments({change_id:"CHG-1"}); if(n!==0) quit(1)'
```
Expected cardinality: 0
### Step 9. Rollback
```bash
mongosh "$DB" --eval 'const x=db.source.findOne({document_id:"DOC-1"}); if(!x||x.item.processingState!="pending") quit(1)'
```
fieldPath=item.processingState oldValue=approved newValue=pending
