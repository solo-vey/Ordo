DEL-001: See Passport TC-001 and Automation.
AC-001: Coverage is consistent.
