## MQA-001
### Step 5. Assert change
```bash
mongosh "$DB" --eval 'db.changes.countDocuments({change_id:"CHG-1"})'
```
Expected cardinality: 0
### Step 9. Rollback
```bash
mongosh "$DB" --eval 'db.source.findOne({document_id:"DOC-1"})'
```
