# Passport
| TC | MQA | AUTO | Status | Blocker |
| TC-001 | MQA-001 | AUTO-001 | runnable | - |
| TC-006 | MQA-006 | AUTO-006 | blocked_missing_binding | missing info |
