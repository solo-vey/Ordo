# Alpha 1.16.6 fixture compatibility fix

`JIRA_GOOD.md` was a stale positive fixture. Alpha 1.16.5 correctly strengthened
the Jira validator to require an evidence-based Definition of Done, but the inherited
Alpha 1.16.4 positive fixture did not contain that required block.

The fixture was updated to satisfy the already-authoritative contract.
The validator was not weakened.
