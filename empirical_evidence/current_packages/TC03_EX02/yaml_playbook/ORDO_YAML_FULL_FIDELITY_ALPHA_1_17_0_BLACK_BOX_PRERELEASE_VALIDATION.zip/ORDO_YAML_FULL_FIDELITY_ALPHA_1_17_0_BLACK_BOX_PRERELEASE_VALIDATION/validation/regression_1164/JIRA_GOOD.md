DEL-001: Implement processing-state change handling for item.processingState, persisting exactly one change record and emitting exactly one RECORD_PROCESSING_STATE_CHANGED event while creating zero error records.
AC-001: Given pending→approved under operationStatus=modified, the processor creates exactly one change record, exactly one event, zero errors, and performs no unrelated mutation.

## Definition of Done

- Evidence: attach the semantic validation report, execution log, and artifact SHA-256 proving DEL-001 and AC-001 passed.
- Blocker closure: any blocker must be recorded with closure evidence and marked resolved or explicitly unblocked before approval.
- Cross-artifact consistency: verify consistency with Passport, Manual QA, and Automation for the same TC/MQA/AUTO mapping.
