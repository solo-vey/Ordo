# Passport
| TC | MQA | AUTO | Status | Rationale / closure |
| TC-001 | MQA-001 | AUTO-001 | runnable | MQA-001 validates the same meaningful-change lifecycle because it uses the authoritative TC-001 fixture; AUTO-001 covers the same behavior and status. |
| TC-006 | MQA-006 | AUTO-006 | blocked_missing_binding | Required omitted-field request schema and binding are absent; closure evidence is Driver-provided request body/schema that unblocks generation. |
