#!/usr/bin/env python3
from pathlib import Path
import re,sys,json
text=Path(sys.argv[1]).read_text(encoding='utf-8'); errs=[]
generic=[r'\bvariant\s+\d+\b',r'\bfixture\s+\d+\b',r'\bbehavior\s+\d+\b',r'\bexpected values?\b',r'\bconcrete values?\b',r'\bexplicit fixture\b',r'\bsame expected result\b',r'\bgeneric assertion\b']
for pat in generic:
 if re.search(pat,text,re.I): errs.append('UNIT_GENERIC_FIXTURE_PLACEHOLDER:'+pat)
rows=[]
for ln in text.splitlines():
 if re.match(r'^\|\s*UNIT-\d+',ln): rows.append([c.strip() for c in ln.strip('|').split('|')])
if not rows: errs.append('UNIT_TABLE_MISSING')
assertions=[]
for r in rows:
 uid=r[0]; blob=' | '.join(r[1:]);
 literals=bool(re.search(r'(item\.[A-Za-z0-9_.]+|pending|approved|modified|created|RECORD_[A-Z_]+|RULE_[A-Z0-9_]+|REC-\d+|DOC-\d+|count\s*[=:]\s*[01]|\b[01]\b)',blob))
 if not literals: errs.append(uid+':UNIT_LITERAL_FIXTURE_MISSING')
 if not re.search(r'(oldValue|newValue|old value|new value|fieldPath|field path|operationStatus|event type|cardinality|count)',blob,re.I): errs.append(uid+':UNIT_BEHAVIOR_RELATION_MISSING')
 norm=re.sub(r'UNIT-\d+|\d+','',blob.lower()); norm=re.sub(r'\s+',' ',norm).strip(); assertions.append((uid,norm))
from collections import Counter
c=Counter(n for _,n in assertions)
for uid,n in assertions:
 if c[n]>1 and len(n)<260: errs.append(uid+':UNIT_GENERIC_ASSERTION_REUSE')
print(json.dumps({'validator':'unit_provider_semantics_v3','errors':errs,'result':'PASS' if not errs else 'FAIL'},ensure_ascii=False,indent=2)); sys.exit(0 if not errs else 1)
