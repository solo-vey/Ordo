# Manual QA Execution Specification — RUN_01 v1

## MQA-001 — Meaningful processing-state change pending to approved
Functional TC: TC-001
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0001`; do not reuse it outside this case.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0001"}).count()'
```
Expected zero pre-existing records.
### Step 3. Define expected cardinalities
Expected source mutation: true. Expected change/event/error: 1/1/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0001","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.change_records.findOne({change_id:"CHG-2026-0001"}); if(!x||x.document_id!="DOC-74291"||x.record_key!="REC-184"||x.field_path!="item.processingState"||x.old_value!="pending"||x.new_value!="approved"||x.operation_status!="modified") quit(1)'
```
Expected cardinality: 1. Assert exact field_path, old_value, new_value and operation_status equal the stimulus.
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0001","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.generated_events.findOne({change_id:"CHG-2026-0001"}); if(!x||x.event_type!="RECORD_PROCESSING_STATE_CHANGED"||x.event_date!="2026-07-15T09:30:00Z"||x.record_key!="REC-184"||x.field_path!="item.processingState"||x.old_value!="pending"||x.new_value!="approved"||x.rule_id!="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1. Assert event_type, event_date, old_value, new_value, record_key, field_path and rule_id exactly equal the case values.
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0001",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no error record exists.
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0001","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Verify `item.processingState` equals `pending`. Generated records remain isolated by unique change id; no delete capability is claimed.
### Final expected result
MQA-001 satisfies authoritative status `runnable` and exact cardinalities 1/1/0.

## MQA-002 — Equal normalized values are no-op
Functional TC: TC-002
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0002`; do not reuse it outside this case.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0002"}).count()'
```
Expected zero pre-existing records.
### Step 3. Define expected cardinalities
Expected source mutation: true. Expected change/event/error: 1/0/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0002","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"approved"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0002"}).count()'
```
Expected cardinality: 1. Assert exact field_path, old_value, new_value and operation_status equal the stimulus.
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0002","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0002",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no event exists; no conditional positive payload assertion applies.
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0002",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no error record exists.
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0002","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"approved"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Verify `item.processingState` equals `approved`. Generated records remain isolated by unique change id; no delete capability is claimed.
### Final expected result
MQA-002 satisfies authoritative status `runnable` and exact cardinalities 1/0/0.

## MQA-003 — Unrelated field is no-op
Functional TC: TC-003
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0003`; do not reuse it outside this case.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0003"}).count()'
```
Expected zero pre-existing records.
### Step 3. Define expected cardinalities
Expected source mutation: true. Expected change/event/error: 1/0/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0003","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.otherField","oldValue":"pending","newValue":"approved"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0003"}).count()'
```
Expected cardinality: 1. Assert exact field_path, old_value, new_value and operation_status equal the stimulus.
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0003","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0003",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no event exists; no conditional positive payload assertion applies.
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0003",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no error record exists.
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0003","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.otherField","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.otherField":1})'
```
Verify `item.otherField` equals `pending`. Generated records remain isolated by unique change id; no delete capability is claimed.
### Final expected result
MQA-003 satisfies authoritative status `runnable` and exact cardinalities 1/0/0.

## MQA-004 — Unsupported operation status is no-op before persistence
Functional TC: TC-004
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0004`; do not reuse it outside this case.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0004"}).count()'
```
Expected zero pre-existing records.
### Step 3. Define expected cardinalities
Expected source mutation: false. Expected change/event/error: 0/0/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0004","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"created","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0004"}).count()'
```
Expected cardinality: 0. Assert the record is absent; no positive projection assertion applies.
### Step 6. Invoke processing
Not applicable: expected change cardinality is zero, so no nonexistent change is processed.
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0004",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no event exists; no conditional positive payload assertion applies.
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0004",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no error record exists.
### Step 9. Rollback and verify
Not applicable: no source mutation is proven; rollback is not required. Confirm no source rollback or generated-record deletion is attempted.
### Final expected result
MQA-004 satisfies authoritative status `runnable` and exact cardinalities 0/0/0.

## MQA-005 — Duplicate stimulus is deduplicated to one event
Functional TC: TC-005
### Step 0. Case identity and isolation
Use unique change id `CHG-2026-0005`; do not reuse it outside this case.
### Step 1. Capture source baseline
```bash
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
### Step 2. Verify preconditions
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0005"}).count()'
```
Expected zero pre-existing records.
### Step 3. Define expected cardinalities
Expected source mutation: true. Expected change/event/error: 1/1/0.
### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0005","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved"}'
```
### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_records.find({change_id:"CHG-2026-0005"}).count()'
```
Expected cardinality: 1. Assert exact field_path, old_value, new_value and operation_status equal the stimulus.
### Step 6. Invoke processing
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0005","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'db.generated_events.find({change_id:"CHG-2026-0005",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 1. Assert event_type, event_date, old_value, new_value, record_key, field_path and rule_id exactly equal the case values.
### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'db.change_errors.find({change_id:"CHG-2026-0005",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).count()'
```
Expected cardinality: 0. Assert no error record exists.
### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","changeId":"CHG-2026-0005","occurredAt":"2026-07-15T09:30:00Z","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending"}'
mongosh "$DATABASE_NAME" --eval 'db.source_records.find({document_id:"DOC-74291"},{"item.processingState":1})'
```
Verify `item.processingState` equals `pending`. Generated records remain isolated by unique change id; no delete capability is claimed.
### Final expected result
MQA-005 satisfies authoritative status `runnable` and exact cardinalities 1/1/0.

## MQA-006 — Missing required field omission case
Functional TC: TC-006
status: blocked
evidence_status: blocked
blocked_reason: authoritative omission binding is not confirmed
missing_capability: exact request schema permitting omission of the required field
required_evidence: Driver-confirmed omission binding plus canonical omitted-field request body
