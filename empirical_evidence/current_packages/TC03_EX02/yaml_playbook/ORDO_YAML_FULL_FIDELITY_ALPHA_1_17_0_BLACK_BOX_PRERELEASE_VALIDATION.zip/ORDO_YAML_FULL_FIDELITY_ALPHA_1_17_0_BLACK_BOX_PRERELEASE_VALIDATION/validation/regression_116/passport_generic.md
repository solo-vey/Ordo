| ID | fixture fields | fixture values | invocation target | invocation input | exact assertions | negative assertions | status |
|---|---|---|---|---|---|---|---|
| UNIT-001 | field | concrete RUN_01 values variant 3 | fn | explicit fixture 3 | decision and event/cardinality fields equal expected values | no unintended event | runnable |
