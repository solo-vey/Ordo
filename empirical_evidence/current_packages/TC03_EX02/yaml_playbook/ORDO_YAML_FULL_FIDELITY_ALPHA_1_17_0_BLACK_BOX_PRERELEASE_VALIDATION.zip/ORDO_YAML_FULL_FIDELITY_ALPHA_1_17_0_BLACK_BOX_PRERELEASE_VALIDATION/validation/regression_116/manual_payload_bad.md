## MQA-001 — meaningful
Functional TC: TC-001
Expected cardinality: 1
```bash
curl -X POST "$BASE_URL/api/database-change/process"
mongosh "$DATABASE_NAME" --eval 'db.generated_events.countDocuments({changeId:"CHG-1"})'
```
