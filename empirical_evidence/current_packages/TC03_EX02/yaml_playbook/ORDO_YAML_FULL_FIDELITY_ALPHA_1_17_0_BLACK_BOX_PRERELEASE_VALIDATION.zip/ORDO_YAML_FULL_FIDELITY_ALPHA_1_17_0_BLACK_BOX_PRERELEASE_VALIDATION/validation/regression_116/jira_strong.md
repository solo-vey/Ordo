# Jira Delivery Task — RUN_01 v1

## Summary and business context
Deliver a complete implementation-instruction and verification package for the confirmed processing-state change without claiming unavailable repository bindings or live results.

## Delivery requirements
| ID | Requirement | Evidence |
|---|---|---|
| DEL-001 | Bind confirmed source identifiers and field semantics | Passport scope |
| DEL-002 | Specify normalization and no-op rules | UNIT-001..UNIT-006 |
| DEL-003 | Specify exact event mapping | UNIT-007..UNIT-010 |
| DEL-004 | Provide causal Manual QA lifecycle cases | MANUAL_QA.md |
| DEL-005 | Provide declarative runner lifecycle profiles | AUTOMATION.yaml |
| DEL-006 | Maintain authoritative cross-artifact status registry | CASE_STATUS_REGISTRY.yaml |

## Acceptance criteria
- AC-001: Positive pending-to-approved stimulus yields exactly one change, one event, zero errors.
- AC-002: Equal normalized values yield one captured change and zero events/errors.
- AC-003: Unrelated field yields one captured change and zero events/errors.
- AC-004: Unsupported operation status yields zero changes and is not processed.
- AC-005: Duplicate publish/process stimuli yield one event and zero errors.
- AC-006: Missing-field omission remains blocked in both MQA and AUTO until authoritative binding exists.

## Functional delivery coverage
| Functional ID | Requirement and exact expected result | Related delivery IDs | Manual QA | Automation | Status/blocker |
|---|---|---|---|---|---|
| TC-001 | Meaningful processing-state change pending to approved; exact change/event/error cardinality 1/1/0 | DEL-001, AC-001 | MQA-001 | AUTO-001 | runnable |
| TC-002 | Equal normalized values are no-op; exact change/event/error cardinality 1/0/0 | DEL-002, AC-002 | MQA-002 | AUTO-002 | runnable |
| TC-003 | Unrelated field is no-op; exact change/event/error cardinality 1/0/0 | DEL-003, AC-003 | MQA-003 | AUTO-003 | runnable |
| TC-004 | Unsupported operation status is no-op before persistence; exact change/event/error cardinality 0/0/0 | DEL-004, AC-004 | MQA-004 | AUTO-004 | runnable |
| TC-005 | Duplicate stimulus is deduplicated to one event; exact change/event/error cardinality 1/1/0 | DEL-005, AC-005 | MQA-005 | AUTO-005 | runnable |
| TC-006 | Missing required field omission case; exact change/event/error cardinality 0/0/0 | DEL-006, AC-006 | MQA-006 | AUTO-006 | blocked_missing_binding |

## Test and QA references
Passport atomic specifications UNIT-001 through UNIT-011; Manual QA v1; Automation v1; runtime CASE_STATUS_REGISTRY.yaml.

## Dependencies, open questions, and closure criteria
| ID | Missing evidence/capability or question | Affected DEL/AC | Impact | Owner/discovery action | Closure criterion | Work allowed while open | Blocks |
|---|---|---|---|---|---|---|---|
| DEP-001 | Exact production repository rule symbol unavailable | DEL-001/AC-001 | Implementation binding cannot be claimed | Repository owner performs discovery | Concrete module, symbol and invocation evidence | Documentation and local-package QA specification | Production implementation |
| DEP-002 | Authoritative omission binding unavailable | DEL-006/AC-006 | Missing-field case cannot run | Contract owner supplies exact legal omitted-field body | Driver-confirmed schema and request example | Other five cases | MQA-006 and AUTO-006 |

## Definition of Done
All runnable rows pass semantic validators; blockers retain explicit closure criteria; version-specific Driver approvals are current; cross-artifact semantics and provenance validators pass; no live or repository result is invented.
