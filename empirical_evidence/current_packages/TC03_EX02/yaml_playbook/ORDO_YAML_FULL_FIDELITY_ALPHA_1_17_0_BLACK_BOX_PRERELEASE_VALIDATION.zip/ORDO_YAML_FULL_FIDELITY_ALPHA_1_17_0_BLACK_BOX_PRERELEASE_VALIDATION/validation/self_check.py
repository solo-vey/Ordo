#!/usr/bin/env python3
from pathlib import Path
import yaml, json, sys
root=Path(__file__).resolve().parents[1]
pb=yaml.safe_load((root/"playbook/PLAYBOOK.yaml").read_text())
errors=[]
steps=pb["steps"]
if len(steps)!=126: errors.append(f"step_count={len(steps)}")
if sum(s["class"]=="analytical" for s in steps)!=62: errors.append("analytical_count")
if sum(s["class"]=="technical" for s in steps)!=64: errors.append("technical_count")
if len({s["id"] for s in steps})!=126: errors.append("duplicate_step_ids")
for f in ["TEMPLATE_README.md","TEMPLATE_SUMMARY.json","TEMPLATE_VALIDATION_REPORT.json",
"TEMPLATE_CONSISTENCY_CHECK_REPORT.json","TEMPLATE_FULL_RECORD_CHANGE_PASSPORT.md",
"TEMPLATE_JIRA_TASK.md","TEMPLATE_IMPLEMENTATION_PROMPT.md","TEMPLATE_QA_PACKAGE.md",
"TEMPLATE_PROCESS_IMPROVEMENT_FEEDBACK.md","TEMPLATE_QA_AUTOMATION_SPEC.yaml",
"TEMPLATE_QA_AUTOMATION_README.md"]:
    if not (root/"templates"/f).exists(): errors.append("missing:"+f)
print(json.dumps({"status":"passed" if not errors else "failed","errors":errors,
"counts":{"total":len(steps),"analytical":sum(s["class"]=="analytical" for s in steps),
"technical":sum(s["class"]=="technical" for s in steps)}},indent=2))
sys.exit(1 if errors else 0)
