#!/usr/bin/env python3
from pathlib import Path
import re,sys,json

text=Path(sys.argv[1]).read_text(encoding='utf-8')
errs=[]

def clean_cell(s):
    return re.sub(r'\s+',' ',s.strip().strip('|').strip())

def parse_markdown_table_rows(text, prefix):
    rows=[]
    for line_no,line in enumerate(text.splitlines(),1):
        stripped=line.strip()
        if not stripped.startswith('|') or prefix not in stripped:
            continue
        cells=[clean_cell(c) for c in stripped.strip('|').split('|')]
        for i,c in enumerate(cells):
            if re.fullmatch(prefix+r'-\d+',c,re.I):
                body=' | '.join(cells[i+1:])
                rows.append((c.upper(),body,line_no,cells))
                break
    return rows

def parse_list_rows(text,prefix):
    rows=[]
    pat=re.compile(r'^\s*[-*]?\s*('+prefix+r'-\d+)\s*[:|-]\s*(.+)$',re.I)
    for line_no,line in enumerate(text.splitlines(),1):
        m=pat.match(line)
        if m: rows.append((m.group(1).upper(),m.group(2).strip(),line_no,[m.group(1),m.group(2)]))
    return rows

def dedupe(rows):
    seen=set(); out=[]
    for r in rows:
        key=(r[0],r[2])
        if key not in seen: seen.add(key); out.append(r)
    return out

del_rows=dedupe(parse_markdown_table_rows(text,'DEL')+parse_list_rows(text,'DEL'))
ac_rows=dedupe(parse_markdown_table_rows(text,'AC')+parse_list_rows(text,'AC'))
rendered_del_ids=sorted(set(re.findall(r'\bDEL-\d+\b',text,re.I)))
rendered_ac_ids=sorted(set(re.findall(r'\bAC-\d+\b',text,re.I)))
parsed_del_ids=sorted(set(r[0] for r in del_rows))
parsed_ac_ids=sorted(set(r[0] for r in ac_rows))
if rendered_del_ids and not del_rows: errs.append('JIRA_DEL_PARSER_ZERO_ROWS')
if set(x.upper() for x in rendered_del_ids)-set(parsed_del_ids): errs.append('JIRA_DEL_PARSER_COVERAGE_INCOMPLETE')
if rendered_ac_ids and not ac_rows: errs.append('JIRA_AC_PARSER_ZERO_ROWS')
if set(x.upper() for x in rendered_ac_ids)-set(parsed_ac_ids): errs.append('JIRA_AC_PARSER_COVERAGE_INCOMPLETE')

action_words=('implement','create','update','persist','emit','reject','prevent','validate','handle','map','store','return','block','skip','deduplicate')
target_patterns=(r'item\.[A-Za-z0-9_.]+',r'processingstate',r'processor',r'handler',r'mapper',r'endpoint',r'database change',r'change record',r'event',r'error record',r'rule')
output_patterns=(r'exactly\s+\d+',r'zero\s+',r'one\s+',r'no\s+(?:second\s+)?(?:record|event|error|mutation)',r'persist',r'emit',r'reject',r'prevent',r'create',r'return',r'blocked',r'no-op')
refs=('passport','manual qa','automation','unit-','tc-','mqa-','auto-','see ','refer to')
for did,body,line_no,cells in del_rows:
    low=body.lower()
    no_refs=re.sub(r'\b(?:passport|manual qa|automation|unit-\d+|tc-\d+|mqa-\d+|auto-\d+)\b','',low)
    if not any(w in no_refs for w in action_words): errs.append(f'{did}:JIRA_DEL_ACTION_MISSING')
    if not any(re.search(p,no_refs,re.I) for p in target_patterns): errs.append(f'{did}:JIRA_DEL_TARGET_MISSING')
    if not any(re.search(p,no_refs,re.I) for p in output_patterns): errs.append(f'{did}:JIRA_DEL_MEASURABLE_OUTPUT_MISSING')
    if any(w in low for w in refs) and len(re.sub(r'[^a-z0-9]+','',no_refs)) < 35:
        errs.append(f'{did}:JIRA_DEL_EXTERNAL_REFERENCE_ONLY')

for aid,body,line_no,cells in ac_rows:
    low=body.lower()
    stimulus=any(x in low for x in ('given','when','oldvalue','newvalue','operationstatus','pending','approved','modified','duplicate','unsupported'))
    outcome=bool(re.search(r'\b(exactly\s+\d+|zero|one|does not|must not|no event|no error|blocked|returns|creates|emits|persists)\b',low))
    if not stimulus or not outcome: errs.append(f'{aid}:JIRA_AC_NOT_INDEPENDENTLY_VERIFIABLE')

# DoD must include evidence semantics, not heading only.
dod_match=re.search(r'(?is)(?:Definition of Done|\bDoD\b)(.*?)(?:\n#{1,3}\s|\Z)',text)
if not dod_match:
    errs.append('JIRA_DOD_MISSING')
else:
    dod=dod_match.group(1).lower()
    for label,tokens in {
      'JIRA_DOD_EVIDENCE_MISSING':('evidence','proof','report','link','log'),
      'JIRA_DOD_BLOCKER_CLOSURE_MISSING':('blocker','closure','resolved','unblocked'),
      'JIRA_DOD_CROSS_ARTIFACT_CHECK_MISSING':('consistency','passport','manual qa','automation')
    }.items():
        if not any(t in dod for t in tokens): errs.append(label)

print(json.dumps({'validator':'jira_structured_delivery_semantics_v2','parsed_del_count':len(del_rows),'parsed_ac_count':len(ac_rows),'errors':sorted(set(errs)),'result':'PASS' if not errs else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not errs else 1)
