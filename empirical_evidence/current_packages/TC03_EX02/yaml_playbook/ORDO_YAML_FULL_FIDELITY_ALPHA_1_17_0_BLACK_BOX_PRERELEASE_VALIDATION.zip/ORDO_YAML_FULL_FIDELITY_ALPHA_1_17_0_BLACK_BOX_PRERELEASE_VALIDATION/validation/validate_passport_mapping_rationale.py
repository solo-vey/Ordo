#!/usr/bin/env python3
from pathlib import Path
import re,sys,json
text=Path(sys.argv[1]).read_text(encoding='utf-8')
errs=[]
for ln in text.splitlines():
    if not re.search(r'\bTC-\d+\b',ln) or ('MQA-' not in ln and 'AUTO-' not in ln):
        continue
    low=ln.lower()
    if 'blocked' in low:
        if not any(x in low for x in ['required','provide','binding','schema']):
            errs.append('PASSPORT_BLOCKER_MISSING_EXACT_AUTHORITY')
        if not any(x in low for x in ['closure','unblock','evidence']):
            errs.append('PASSPORT_BLOCKER_CLOSURE_EVIDENCE_INSUFFICIENT')
    else:
        if not any(x in low for x in ['because','covers','validates','behavior','same lifecycle']):
            errs.append('PASSPORT_MAPPING_RATIONALE_MISSING')
print(json.dumps({'validator':'passport_mapping_rationale_v1','errors':sorted(set(errs)),'result':'PASS' if not errs else 'FAIL'},indent=2))
sys.exit(0 if not errs else 1)
