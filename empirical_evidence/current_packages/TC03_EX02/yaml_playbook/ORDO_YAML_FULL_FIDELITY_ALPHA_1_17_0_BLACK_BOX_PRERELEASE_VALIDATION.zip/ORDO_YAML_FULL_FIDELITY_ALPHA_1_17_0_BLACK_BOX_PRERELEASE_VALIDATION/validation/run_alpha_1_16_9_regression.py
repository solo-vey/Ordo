#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("drv",ROOT/"driver/semantic_analyst_driver.py")
drv=importlib.util.module_from_spec(spec); spec.loader.exec_module(drv)
scenario={"name":"test","terminal_policy":"complete_go","approval_policy":"allowed"}
state=drv.default_state("RUN_02",scenario)
bad={"artifact":"approval.jira","artifact_version":"v1","artifact_sha256":"badsha","validated_at":"2026-07-16T12:00:00Z","validator_results":[{"validator_id":"jira_structured_delivery_semantics_v2","validator_version":"2","result":"FAIL","return_code":1,"artifact_sha256":"badsha"}]}
r=drv.handle_validation(state,{"artifact":"jira","validation_receipt":bad})
assert r["status"]=="validation_failed"
assert r["next_step"]=="T038"
assert "T040" in r["prohibited_successors"]
assert drv.handle_gate(state,{"gate":"cross_artifact","result":"PASS"})["status"]=="gate_blocked"
assert drv.determine_terminal(scenario,state)["reason"]=="pending_regeneration"
good={"artifact":"approval.jira","artifact_version":"v2","artifact_sha256":"goodsha","validated_at":"2026-07-16T12:05:00Z","validator_results":[{"validator_id":"jira_structured_delivery_semantics_v2","validator_version":"2","result":"PASS","return_code":0,"artifact_sha256":"goodsha"}]}
assert drv.handle_validation(state,{"artifact":"jira","validation_receipt":good})["status"]=="validated"
assert not [x for x in state["correction_registry"] if x["status"]=="regeneration_required"]

V=ROOT/"validation/validate_selected_run_literal_consistency.py"
F=ROOT/"validation/regression_1169"
ok=subprocess.run([sys.executable,str(V),str(F/"SELECTED.yaml"),str(F/"DERIVED_ALLOWED.yaml")],capture_output=True,text=True)
badp=subprocess.run([sys.executable,str(V),str(F/"SELECTED.yaml"),str(F/"DERIVED_UNDECLARED.yaml")],capture_output=True,text=True)
assert ok.returncode==0,ok.stdout+ok.stderr
assert badp.returncode!=0,badp.stdout+badp.stderr
assert "undeclared_derived_literal" in badp.stdout
print(json.dumps({"suite":"alpha_1_16_9_enforced_correction_routing","correction_transition":"PASS","forward_execution_blocked":"PASS","declared_case_literals":"PASS","undeclared_conflict_rejected":"PASS","result":"PASS"}))
