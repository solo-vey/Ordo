# Process Improvement Feedback — <ALIAS>

## Observed issue
## Scope classification
## Root cause
## Affected process steps
## Affected templates and gates
## Rule propagation matrix
## Recommended correction
## Regression prevention
## Status
