# Шаблон Jira task для database-change rule

Generated filename pattern: `02_JIRA_TASK_<ALIAS>.md`.

## 0. Правила заповнення
- Документ українською; technical identifiers не перекладаються.
- Jira є self-contained delivery view, похідною від підтвердженого Passport і RUN input.
- Не вигадувати code paths, runtime bindings, URLs або результати тестів.
- Невідоме фіксувати як dependency/open question, а не приховувати.
- Acceptance criteria не замінюють functional-test catalog.
- Jira містить усі confirmed functional tests і достатню конкретику unit/provider requirements для self-contained delivery; не використовує лише посилання “див. Passport”.

# Jira Task — <ALIAS>

## 1. Summary
`<ALIAS>` — `<короткий бізнес-сенс>`

## 2. Business context
Описати бізнесову зміну, очікуваний сигнал, користувача/споживача результату та операційну цінність.

## 3. Confirmed contract snapshot
| Поле | Значення | Source/evidence |
|---|---|---|
| Alias / rule ID | `<...>` | `<...>` |
| Source record role/path | `<...>` | `<...>` |
| Change operation/status | `<...>` | `<...>` |
| Change field path | `<...>` | `<...>` |
| Old/new sources | `<...>` | `<...>` |
| Output type | `<...>` | `<...>` |
| Identity/dedup | `<...>` | `<...>` |
| Date source | `<...>` | `<...>` |

## 4. Scope
Перелічити атомарно:
- source/change evidence intake;
- operation/status and field-path filters;
- normalization and no-op behavior;
- exact output mapping;
- duplicate prevention;
- observability/diagnostics;
- production implementation;
- unit/provider tests;
- manual QA and automation handoff;
- code-adjacent documentation/source links.

## 5. Out of scope
Явно перелічити unrelated fields, migrations, UI/config changes, external integrations, deployment work та інші aliases, якщо не підтверджено інакше.

## 6. Required implementation behavior
### 6.1 Decision sequence
1. Validate operation/status.
2. Validate target field path.
3. Resolve required IDs/date.
4. Normalize old/new for comparison.
5. Apply no-op rule.
6. Build exact output payload.
7. Apply duplicate identity rule.
8. Emit create/no-op/blocked/error diagnostics.

### 6.2 Mapping
| Target | Source | Transformation | Missing behavior |
|---|---|---|---|
| `<...>` | `<...>` | `<...>` | `<block/no-op/default>` |

### 6.3 Normalization/no-op/duplicate
| Concern | Required behavior | Observable result |
|---|---|---|
| Normalization | `<...>` | `<...>` |
| No-op | `<...>` | `<...>` |
| Missing mapping | `<...>` | `<...>` |
| Duplicate | `<...>` | `<...>` |

## 7. Technical deliverables
| ID | Deliverable | Required content | Completion evidence |
|---|---|---|---|
| `DEL-01` | Production implementation | exact existing extension point or discovery requirement; no unrelated refactor | code/review reference |
| `DEL-02` | Mapping and decision logic | operation, field, normalization, mapping, duplicate behavior | tests + review |
| `DEL-03` | Observability | structured create/no-op/blocked/duplicate/error diagnostics | observable assertions |
| `DEL-04` | Unit/provider tests | implement all Passport `UNIT-*` requirements | test report |
| `DEL-05` | Manual QA | execute all allocated `MQA-*` cases | evidence reference |
| `DEL-06` | Automation | implement/execute all allocated `AUTO-*` cases when runner available | report/reference |
| `DEL-07` | Documentation | source links and current contract notes | file/link |

## 8. Implementation constraints
- Preserve existing architecture and extension points.
- No unrelated refactoring.
- No invented file paths/classes if codebase evidence is absent; require code discovery.
- Do not derive runtime behavior from template examples.
- Do not weaken blocked/no-op/duplicate semantics.
- Runtime placeholders remain placeholders until captured from environment.

## 9. Acceptance criteria
### 9.1 Creation logic
- `<atomic verifiable criteria>`
### 9.2 Mapping
- `<atomic verifiable criteria>`
### 9.3 Normalization/no-op
- `<atomic verifiable criteria>`
### 9.4 Missing data and diagnostics
- `<atomic verifiable criteria>`
### 9.5 Duplicate behavior
- `<atomic verifiable criteria>`
### 9.6 Documentation and traceability
- `<atomic verifiable criteria>`

## 10. Functional test catalog
Включити всі confirmed functional IDs. Один row на один case; acceptance criteria не є заміною таблиці.

| Functional ID | Name | Requirement/rule | Preconditions/input | Action | Exact expected result | Manual QA allocation | Automation allocation |
|---|---|---|---|---|---|---|---|
| `TC-01` | `<...>` | `<...>` | `<...>` | `<...>` | `<create/no-op/blocked/error + exact assertions>` | `<MQA-.../No>` | `<AUTO-.../No>` |

Заборонено пропускати confirmed rows або замінювати їх summary.

## 11. Unit/provider implementation requirements
Jira не копіює весь Passport дослівно, але повинна бути self-contained: для кожного UNIT-ID матеріалізувати конкретну fixture summary, invocation dependency/target, exact assertion focus і negative assertion focus.

| Unit/provider ID | Component/rule | Concrete fixture summary | Invocation target/dependency | Exact assertion focus | Negative assertion focus | Covered functional IDs | Delivery status |
|---|---|---|---|---|---|---|---|
| `UNIT-01` | `<...>` | `<fields + concrete values>` | `<verified target or repository-discovery dependency>` | `<decision/field/value/cardinality>` | `<forbidden side effects>` | `<TC-...>` | `<planned/implemented/passed>` |

## 12. QA reference data
| Datum ID | Value | Used by cases | Runtime-discovered? |
|---|---|---|---|
| `<...>` | `<...>` | `<...>` | `<yes/no>` |

## 13. Dependencies and open questions
| ID | Dependency/question | Impact | Owner | Blocks implementation/verification |
|---|---|---|---|---|
| `<...>` | `<...>` | `<...>` | `<...>` | `<yes/no>` |

## 14. Execution / delivery checklist
- [ ] Passport confirmed/current.
- [ ] Code discovery completed and extension point recorded.
- [ ] Production implementation completed.
- [ ] All `UNIT-*` implemented and passed with evidence.
- [ ] All allocated Manual QA cases completed with evidence.
- [ ] All allocated Automation cases completed or explicitly deferred with reason.
- [ ] Observability assertions verified.
- [ ] Documentation/source links updated.
- [ ] Final consistency review passed.

## 15. Definition of Done
- All blocking deliverables complete.
- Every confirmed functional ID appears in Jira and maps to Passport/Manual/Automation.
- Every Passport unit/provider ID appears in Jira implementation requirements.
- No unresolved blocker is hidden by `ready` status.
- Evidence links/statuses are recorded in the primary tracker.

## 16. External references
- Passport/Confluence: `<provided URL or Not provided>`
- Jira issue: `<provided URL or Not provided>`
- Analytical package: `<reference or Not provided>`

Не вигадувати URL.

## 17. Change log
| Date | Source | Change summary | Reason/reference |
|---|---|---|---|
| `<...>` | `<...>` | `<...>` | `<...>` |

## 18. Artifact validation
| Check | Expected |
|---|---|
| Self-contained delivery view | pass |
| Confirmed contract snapshot complete | pass |
| Atomic technical deliverables | pass |
| Acceptance criteria verifiable | pass |
| Functional ID set exact | `jira_functional_ids == passport_functional_ids` |
| Unit/provider ID set exact | `jira_unit_ids == passport_unit_ids` |
| Unit requirements self-contained | no generic “assertions from Passport” rows |
| Semantic functional-unit coverage | case-specific links preserved; no repeated default mapping |
| QA allocation preserved | pass |
| Dependencies visible | pass |
| DoD evidence-based | pass |
