# Manual QA package — <ALIAS>

## 0. Immutable rules
- Every test case is executable in isolation.
- Commands, request bodies, assertions and source rollback are repeated in every applicable case.
- Shared sections are reference-only and never required for execution.
- Generated-record deletion is not required unless an authoritative cleanup operation exists. Unique change IDs isolate case evidence.
- Only `${BASE_URL}`, `${AUTH_HEADERS}`, `${DATABASE_NAME}` may remain runtime placeholders, each with capture instructions.

## 1. Status and runtime-value capture
Describe how to capture the three permitted runtime values. Do not claim live execution.

## 2. QA/dev data index
Reference-only table of case IDs, unique change IDs, source baseline and expected outcome.

## 3. Compact test index
Map every canonical requirement ID to one Manual QA case.

## 4. Test cases

Repeat this complete structure for every case:

## MQA-XX — <title>
### Goal
### Preconditions and exact case-local data
### Step 0. Preflight baseline
Full conditional lookup/restore, or explicit Not applicable with reason.
### Step 1. Source lookup before action
Full query, projection, cardinality and exact expected values.
### Step 2. REST action
Full method, relative path, safe headers and complete JSON body.
### Step 3. Source state after action
Full query and exact assertion.
### Step 4. ChangeRecord lookup
Full query/projection and exact presence, cardinality, mapping and absence assertions.
### Step 5. Processor invocation
Full method, relative path, headers and JSON body.
### Step 6. Generated event assertion
Full query/projection and exact presence/absence, payload and dedup assertions.
### Step 7. Error assertion
Full query/projection and exact expected count/reason.
### Step 8. Source rollback
Full rollback request when source was mutated; otherwise Not applicable with exact reason. Do not require generated-record deletion without an authoritative operation.
### Step 9. Source state after rollback
Full query and exact baseline assertion.
### Final expected result
### Diagnostics
Only additional diagnostics; never substitute main-flow commands.

## 5. Blocking gates
- Every relevant confirmed requirement is represented.
- Every case survives isolated-case validation.
- No generic verbs or shared executable references.
- Exact commands are adjacent to exact assertions.
- Source rollback is complete where applicable.
- Missing generated-record deletion is not treated as a blocker.


## Mandatory per-case metadata
Each case must declare:
- Functional TC: <LOCAL_TC_ONLY>
- execution_level: operational|repository_provider
- evidence_status: confirmed|blocked_missing_evidence
- authoritative_binding: <EXACT_CONTRACT_OR_SOURCE>
- blocker_source: <NONE_OR_EXACT_SOURCE_GAP>

A case containing another TC/MQA identifier is invalid. Ambiguous branches are invalid. Repository/provider prose without a callable is blocked, not executable.
