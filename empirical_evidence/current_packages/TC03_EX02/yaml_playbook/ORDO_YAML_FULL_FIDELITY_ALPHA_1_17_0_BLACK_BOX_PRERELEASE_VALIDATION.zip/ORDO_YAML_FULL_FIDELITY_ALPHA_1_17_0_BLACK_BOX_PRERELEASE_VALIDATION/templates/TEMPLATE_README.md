# <PACKAGE TITLE>

## Purpose
## Scope
## Selected process branch
## Package status
## Canonical source of truth
## Generated files
## Reading order
## Open blockers
## Handoff status
