# QA Automation README — <ALIAS>

## Purpose
## Runner prerequisites
## Runner contract evidence
## How test discovery works
## How to run one test
## How to run the full specification
## Structure-validation status
## Runner-discovery status
## Live-run status
## No-op handling
## Troubleshooting
## Generated reports
## Limitations
