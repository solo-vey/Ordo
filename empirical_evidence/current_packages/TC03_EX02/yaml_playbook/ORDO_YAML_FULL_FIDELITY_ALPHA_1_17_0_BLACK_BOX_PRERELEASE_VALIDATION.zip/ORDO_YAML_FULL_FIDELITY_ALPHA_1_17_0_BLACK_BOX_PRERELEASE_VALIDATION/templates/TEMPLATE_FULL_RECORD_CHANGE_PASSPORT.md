# Шаблон паспорта зміни запису

Generated filename pattern: `01_RECORD_CHANGE_PASSPORT_<ALIAS>.md`.

## 0. Правила заповнення

### 0.1 Призначення
Паспорт є canonical source of truth для business meaning, source record, change record, derived event, mapping, normalization/no-op, observability, localization, exclusions, functional tests, unit/provider tests, traceability та open questions.

### 0.2 Evidence labels
| Label | Значення |
|---|---|
| `actual` | знайдено в підтвердженому source/runtime contract |
| `analyst-confirmed` | явно підтверджено у RUN input |
| `expected` | реконструйовано з confirmed rules |
| `candidate` | запропоновано, не final |
| `open question` | невідомо; не можна трактувати як final |

### 0.3 Contract-first rules
- Не вигадувати endpoint, collection, runner, source path або mapping.
- Розділяти source-record path, change-record field path і output values key.
- Unknown data лишається `open question`.
- Greenfield status не скорочує документ.

### 0.4 Mandatory final-ready gates
| Gate | Вимога |
|---|---|
| Input gate | усі confirmed RUN values перенесені без втрат |
| Source contract gate | collection role, identifiers і target path визначені |
| Change contract gate | operation, field path, old/new/date/id sources визначені |
| Output gate | усі output fields мають source/status |
| Normalization gate | comparison і stored-display semantics розділені |
| Values gate | exact keys і placeholder use узгоджені |
| Functional test gate | усі confirmed functional IDs присутні |
| Unit/provider gate | атомарні unit/provider specs з IDs присутні |
| Allocation gate | для кожного functional test вказано Manual QA та Automation |
| Traceability gate | source → change → decision → output → tests простежується |

---

# Record Change Passport — <ALIAS>

## 1. Статус документа
| Поле | Значення |
|---|---|
| Alias | `<ALIAS>` |
| Contract ID | `RULE_<ALIAS>` |
| Version | `<VERSION>` |
| Document status | `<draft/candidate/final-ready/blocked>` |
| Evidence status | `<actual/expected/mixed>` |
| Confirmation source | `<RUN input / analyst confirmation>` |

## 2. Ідентичність правила
| Поле | Значення | Evidence |
|---|---|---|
| Alias | `<...>` | `<...>` |
| Business name | `<...>` | `<...>` |
| Business meaning | `<...>` | `<...>` |
| Event/output type | `<...>` | `<...>` |

## 3. Обрана process branch та intake
| Крок | Підтверджене значення |
|---|---|
| Scenario | `<RUN_01>` |
| Source branch | `<...>` |
| Change kind/operation | `<...>` |
| Target source path | `<...>` |
| Allowed operation/status values | `<...>` |

## 4. Source record contract
| Поле | Значення | Evidence |
|---|---|---|
| Collection role | `<...>` | `<...>` |
| Stable identifiers | `<...>` | `<...>` |
| Target source path | `<...>` | `<...>` |
| Baseline value | `<...>` | `<...>` |
| Changed value | `<...>` | `<...>` |

## 5. Change record contract
| Поле | Значення | Evidence/source |
|---|---|---|
| Change ID | `<...>` | `<...>` |
| Operation/status | `<...>` | `<...>` |
| Field path | `<...>` | `<...>` |
| Old value source | `<...>` | `<...>` |
| New value source | `<...>` | `<...>` |
| Occurred-at/date source | `<...>` | `<...>` |
| Root/source identifiers | `<...>` | `<...>` |

## 6. Порядок аналізу та decision contract
1. Validate operation/status.
2. Validate target field path.
3. Resolve required identifiers and date.
4. Normalize old/new for comparison only.
5. Apply no-op rule.
6. Build output candidate with exact mapping.
7. Apply duplicate identity rule.
8. Return create/no-op/blocked/error with reason.

## 7. Derived event/output contract
| Output field | Value/source | Evidence/status |
|---|---|---|
| Type | `<...>` | `<...>` |
| Identity/dedup key | `<...>` | `<...>` |
| Source identifiers | `<...>` | `<...>` |
| Field path | `<...>` | `<...>` |
| Old value | `<...>` | `<...>` |
| New value | `<...>` | `<...>` |
| Event date | `<...>` | `<...>` |
| Values object | `<exact keys>` | `<...>` |

## 8. Exact mapping matrix
| Target | Source | Transformation | Missing behavior |
|---|---|---|---|
| `<...>` | `<...>` | `<none/defined>` | `<block/no-op/default>` |

## 9. Values shape та exact keys
| Key | Source | Stored semantics | Display semantics | Used by UI |
|---|---|---|---|---|
| `<...>` | `<...>` | `<...>` | `<...>` | `<yes/no>` |

## 10. Normalization, trigger, no-op, missing-data та duplicate behavior
| Concern | Rule | Observable result |
|---|---|---|
| Comparison normalization | `<...>` | `<...>` |
| Trigger | `<...>` | `<create>` |
| No-op | `<...>` | `<no event + reason>` |
| Missing required mapping | `<...>` | `<blocked + diagnostic>` |
| Duplicate | `<...>` | `<reject/no additional side effect>` |

## 11. UI / localization
| Поле | Значення | Placeholder set |
|---|---|---|
| Display name locale 1 | `<...>` | `<...>` |
| Display name locale 2 | `<...>` | `<...>` |
| Text template locale 1 | `<...>` | `<...>` |
| Text template locale 2 | `<...>` | `<...>` |

## 12. Observability contract
| Decision | Required observable evidence |
|---|---|
| Created | `<...>` |
| No-op | `<...>` |
| Blocked | `<...>` |
| Duplicate | `<...>` |
| Error | `<...>` |

## 13. Exclusions / out of scope
| Item | Reason |
|---|---|
| `<...>` | `<...>` |

## 14. Functional test contract
Не замінювати summary. Один row на кожен confirmed functional test.

| ID | Назва | Requirement/rule | Preconditions/input | Action | Expected decision/output | Manual QA | Automation |
|---|---|---|---|---|---|---|---|
| `TC-01` | `<...>` | `<...>` | `<...>` | `<...>` | `<...>` | `<MQA-ID/No>` | `<AUTO-ID/No>` |

## 15. Unit/provider test contract
Не використовувати загальну фразу “tests must verify”. Один атомарний row на кожне правило/компонент.

| ID | Компонент/правило | Covered behavior | Fixture fields | Fixture values | Invocation target/input | Exact assertions | Negative assertions | Evidence |
|---|---|---|---|---|---|---|---|---|
| `UNIT-01` | `<normalization>` | `<one atomic behavior>` | `<field list>` | `<concrete values>` | `<verified callable or repository-discovery dependency + input>` | `<decision/field/value/cardinality assertions>` | `<specific forbidden effects>` | `<actual/confirmed/expected/open>` |

Мінімально покрити: operation/status filter, field-path filter, normalization, no-op decision, empty-display fallback, required mapping blocking, exact payload mapping, date mapping, duplicate identity, localized placeholder consistency, independence from unrelated source fields.

Заборонено повторювати однакові generic fixture/invocation/assertion cells у різних rows. Unknown code symbol може бути dependency, але fixture і behavior assertions мають залишатися конкретними.

## 16. Functional ↔ unit/provider traceability
| Functional ID | Behavior under test | Covered rules | Unit/provider IDs | Coverage rationale |
|---|---|---|---|---|
| `TC-01` | `<exact behavior/decision>` | `<semantic rule set>` | `<UNIT-...>` | `<why these units cover this case>` |

## 17. QA reference data
| Datum | Value | Evidence |
|---|---|---|
| `<...>` | `<...>` | `<...>` |

## 18. Acceptance criteria
- Усі confirmed functional cases присутні та мають exact expected decision.
- Усі critical rules мають атомарні unit/provider specs.
- Mapping, normalization, missing-data і duplicate semantics не суперечать один одному.
- Manual/Automation allocation повне і простежуване.

## 19. Open questions
| Питання | Impact | Owner | Blocks final-ready |
|---|---|---|---|
| `<...>` | `<...>` | `<...>` | `<yes/no>` |

## 20. Artifact-specific validation
| Check | Expected |
|---|---|
| Required sections | complete and meaningful |
| Functional IDs | `passport_functional_ids == confirmed_functional_ids` |
| Unit IDs | `passport_unit_ids == confirmed_unit_ids` |
| Unit row specificity | distinct topics have concrete non-duplicated fixtures/invocations/assertions |
| Semantic coverage | behavior-specific functional cases reference matching unit topics |
| Summary replacement | forbidden |
| Candidate promoted without evidence | forbidden |
| Derived behavior not in confirmed contract | forbidden |
