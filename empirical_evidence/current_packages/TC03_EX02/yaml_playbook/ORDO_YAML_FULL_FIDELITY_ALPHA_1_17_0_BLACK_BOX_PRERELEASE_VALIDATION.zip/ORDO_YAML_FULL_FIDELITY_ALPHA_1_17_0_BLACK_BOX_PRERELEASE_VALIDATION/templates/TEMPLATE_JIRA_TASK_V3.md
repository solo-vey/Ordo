# Jira task template — database-change delivery view v3

Generated filename: `02_JIRA_TASK_<ALIAS>.md`.

## Filling rules

- Ukrainian prose; preserve technical identifiers.
- Jira is a delivery view derived from the confirmed Passport.
- Jira may reference Passport sections and stable IDs instead of repeating detailed unit tests,
  mapping tables, or full traceability.
- Unit/provider test specifications are not required in Jira.
- Section order is flexible. All required content must be present somewhere in the document.
- Never invent repository paths, classes, URLs, runtime bindings, or execution results.

# Jira Task — <ALIAS>

## Summary and business context

- Summary: `<...>`
- Business outcome / consumer: `<...>`
- Operational value: `<...>`
- Passport reference/version: `<...>`

## Confirmed contract summary

| Concern | Confirmed value/behavior | Authoritative source or Passport reference |
|---|---|---|
| Rule/alias | `<...>` | `<...>` |
| Source/change identity | `<...>` | `<...>` |
| Target field/operation | `<...>` | `<...>` |
| Normalization/no-op | `<...>` | `<...>` |
| Output and mapping | `<...>` | `<...>` |
| Date and duplicate identity | `<...>` | `<...>` |
| Missing-data behavior | `<...>` | `<...>` |

## Scope and exclusions

### In scope
`<atomic scope items>`

### Out of scope
`<explicit exclusions>`

## Delivery requirements

One row per concrete delivery output.

| Delivery ID | Concern/component | Concrete expected output | Authoritative source / Passport reference | Dependency or blocker | Completion evidence | Status |
|---|---|---|---|---|---|---|
| `DEL-01` | `<operation/status filter>` | `<specific implementation result>` | `<Passport section/ID or contract>` | `<none/DEP-...>` | `<code review/test/evidence>` | `<planned/blocked/done>` |

Required concerns when applicable:

- operation/status filter;
- target field filter;
- normalization/comparison;
- no-op decision;
- required-data validation;
- payload mapper;
- event date mapping;
- duplicate guard;
- diagnostics/observability;
- repository/code binding;
- Manual QA handoff;
- Automation handoff;
- documentation/source references.

## Acceptance criteria

One criterion per independently verifiable behavior. Split unrelated behavior into separate rows.

| AC ID | Concern/behavior | Given / input | When / action | Then / exact observable result | Verification/evidence | Blocker applicability |
|---|---|---|---|---|---|---|
| `AC-01` | `<successful creation>` | `<exact precondition/input>` | `<exact decision/action>` | `<exact output/cardinality/diagnostic>` | `<MQA/AUTO/Passport ref>` | `<none/DEP-...>` |

Cover every applicable behavior: creation, operation/status rejection, unrelated field, normalized
same-value no-op, missing data, mapping, date, duplicate identity, boundary values, diagnostics,
documentation and traceability.

## Functional delivery coverage

| Functional ID | Requirement and exact expected result | Related delivery IDs | Manual QA | Automation | Status/blocker |
|---|---|---|---|---|---|
| `TC-01` | `<...>` | `<DEL-...>` | `<MQA-...>` | `<AUTO-...>` | `<...>` |

The detailed functional definition may be referenced from the Passport using a stable section or ID.

## Test and QA references

- Unit/provider test specifications: `<Passport section / UNIT-ID range>`.
- Detailed semantic traceability: `<Passport section/table>`.
- Manual QA package: `<artifact/reference>`.
- Automation specification: `<artifact/reference>`.
- Stable QA data: `<inline values or specific Passport/runtime reference>`.

Do not copy detailed unit-test specifications unless needed to clarify a delivery dependency.

## Dependencies, open questions, and closure criteria

| ID | Missing evidence/capability or question | Affected DEL/AC | Impact | Owner/discovery action | Closure criterion | Work allowed while open | Blocks |
|---|---|---|---|---|---|---|---|
| `DEP-01` | `<...>` | `<DEL-... / AC-...>` | `<...>` | `<...>` | `<specific evidence that closes it>` | `<...>` | `<implementation/verification/live execution>` |

## Delivery checklist

- [ ] Current Passport reference recorded.
- [ ] Concrete code/repository binding recorded or explicitly blocked.
- [ ] Every delivery row has completion evidence or a blocker.
- [ ] Every applicable acceptance criterion is verified or correctly blocked/deferred.
- [ ] Manual QA handoff complete.
- [ ] Automation handoff complete or explicitly deferred.
- [ ] Observability/diagnostics verified.
- [ ] Documentation and source references updated.
- [ ] Cross-document consistency review passed.
- [ ] No unresolved blocker is hidden by a ready/done status.

## Definition of Done

- All blocking delivery requirements are complete.
- Every applicable acceptance criterion has evidence or a valid unresolved blocker.
- Passport reference and dependent artifact versions are current.
- Repository/code discovery evidence is recorded when production binding is required.
- Manual QA and Automation handoffs are complete or explicitly deferred with reasons.
- Observability requirements are verified.
- Evidence links and statuses are recorded.
- Unresolved blockers and their closure criteria remain visible.
- Final consistency validation passes.

## External references

- Passport/Confluence: `<provided reference or Not provided>`
- Jira issue: `<provided URL or Not provided>`
- Analytical package: `<reference or Not provided>`

Never invent URLs.

## Change log

| Date | Source | Change | Reason/reference |
|---|---|---|---|
| `<...>` | `<...>` | `<...>` | `<...>` |

## Artifact validation

| Check | Expected |
|---|---|
| Required content present regardless of section order | pass |
| Delivery rows atomic and concrete | pass |
| Acceptance criteria atomic and verifiable | pass |
| Functional delivery coverage complete | pass |
| Passport references specific | pass |
| Dependencies visible | pass |
| Every blocker has a closure criterion | pass |
| DoD evidence-based | pass |
| No invented bindings/results | pass |
| Unit-test duplication required | no |
