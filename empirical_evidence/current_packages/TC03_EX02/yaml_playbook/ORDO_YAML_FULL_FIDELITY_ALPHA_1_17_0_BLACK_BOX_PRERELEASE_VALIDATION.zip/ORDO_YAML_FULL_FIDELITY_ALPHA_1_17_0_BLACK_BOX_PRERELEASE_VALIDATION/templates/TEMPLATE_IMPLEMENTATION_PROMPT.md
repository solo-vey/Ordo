# Implementation Prompt — <ALIAS>

## Objective
## Canonical contract
## Required code discovery
## Source and change contracts
## Derived event contract
## Exact mapping
## Trigger, no-op and error rules
## Duplicate and versioning behavior
## Required tests
## Documentation updates
## Architecture preservation constraints
## Forbidden unrelated changes
## Self-validation before handoff
## Expected change-impact classification
