# Previous Results Invalidated

All earlier playbook and instruction-only runs for this database-change benchmark are invalid.

Reason: the prior adapted playbook did not preserve the full analytical and technical process
of the canonical donor branch. None of the earlier scores or conclusions may be used in the
evidence base or comparative analysis.
