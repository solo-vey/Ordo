# Runtime Evidence Binding Contract — Alpha 1.4.0

The package distinguishes three evidence classes:

1. **Confirmed business input** — `test_inputs/RUN_01_CONFIRMED_INPUT.yaml`.
2. **Confirmed local operational contract** — exact endpoint paths, request schemas, collection roles and query shapes in `contracts/DATABASE_CHANGE_OPERATIONAL_QA_CONTRACT.yaml`.
3. **Runtime-discovered environment values** — base URL, authentication headers and database name. These may remain explicit placeholders with capture instructions.

A model must materialize all operation structures supplied by classes 1 and 2. It must not block the whole document merely because a class-3 value is unknown. It must not invent a live environment value.

Generated Manual QA commands are executable specifications against the confirmed local contract, not evidence that a live endpoint exists. Generated Automation is a declarative spec conforming to the supplied runner contract; do not invent a CLI or claim execution.
