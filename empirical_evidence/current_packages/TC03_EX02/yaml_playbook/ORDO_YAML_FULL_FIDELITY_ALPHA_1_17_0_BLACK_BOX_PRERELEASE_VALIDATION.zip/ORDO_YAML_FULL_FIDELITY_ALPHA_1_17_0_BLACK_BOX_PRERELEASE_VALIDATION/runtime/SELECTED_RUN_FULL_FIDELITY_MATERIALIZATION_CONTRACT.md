# Selected-run full-fidelity materialization contract

This package is rebuilt from Alpha 1.10.0.

For RUN_01, RUN_02, or RUN_04, the current-pass input is the combination of:

1. Business/scenario facts disclosed by `driver/semantic_analyst_driver.py`;
2. `scenario_overlays/FULL_FIDELITY_COMMON_OPERATIONAL_OVERLAY.yaml`;
3. The unchanged Alpha 1.10 operational, runner, runtime, prompt, template, and validation contracts.

Materialize this combined state into:

`runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml`

Rules:

- Never inspect encrypted hidden scenarios directly.
- Never replace the operational overlay with a short semantic snapshot.
- Runtime values BASE_URL, AUTH_HEADERS, and DATABASE_NAME may remain placeholders.
- Runtime placeholders do not block generation of exact Manual QA commands or declarative Automation cases.
- Missing production repository symbols may remain repository-discovery-bound.
- Do not classify all QA/Automation as blocked solely because repository symbols or live environment values are unavailable.
- RUN_03 and RUN_05 must follow their authoritative terminal routes without forcing canonical document generation.
- Every materialized business fact must cite a Driver interaction.
