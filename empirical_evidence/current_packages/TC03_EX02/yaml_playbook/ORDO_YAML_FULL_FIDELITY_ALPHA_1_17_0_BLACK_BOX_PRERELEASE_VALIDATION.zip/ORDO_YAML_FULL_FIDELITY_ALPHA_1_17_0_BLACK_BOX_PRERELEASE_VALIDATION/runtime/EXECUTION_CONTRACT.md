# Runtime Execution Contract — Alpha 1.4.0

Execute all 126 steps in order for RUN_01 using the confirmed benchmark input and local operational contracts supplied in this package.

## Blind benchmark mode

- Do not ask the analyst to reconfirm values marked `confirmed` in the RUN_01 input.
- Confirmation nodes validate completeness and consistency of the active rendered artifact; they are not interactive approval requests.
- Generate separately: Passport, Jira, Implementation Prompt, Manual QA, Automation Spec, metadata and consistency artifacts.
- On revision, invalidate and regenerate dependent artifacts.
- Materialize known operation shapes. Preserve placeholders only for `BASE_URL`, `AUTH_HEADERS`, and `DATABASE_NAME`, with capture instructions.
- Do not execute live systems and do not claim that tests ran.
- Do not score or grade the generated documents. Evaluation is performed outside this execution.
- Finish the process and return the complete output ZIP plus process log, blockers and SHA-256.

A missing live environment value does not block document generation. A missing business-contract value or missing operation schema does block the affected artifact.
