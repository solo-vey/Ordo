#!/usr/bin/env python3
from pathlib import Path
import sys, re, json, yaml
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
jira=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else None
errors=[]
pb=yaml.safe_load((root/'playbook/PLAYBOOK.yaml').read_text(encoding='utf-8'))
if len(pb.get('steps',[]))!=126: errors.append('STEP_COUNT_CHANGED')
patch=pb.get('release_patch',{})
if patch.get('version') not in ['1.17.4','1.17.4.1']: errors.append('PATCH_VERSION_MISSING')
for f in ['contracts/JIRA_RUN_01_DELIVERY_QUALITY_CONTRACT_V5.yaml','prompts/hp.artifact.jira.generate_and_review.v6.md']:
    if not (root/f).exists(): errors.append('MISSING:'+f)
if jira:
    text=jira.read_text(encoding='utf-8')
    sections=['Product implementation requirements','Verification deliverables','Evidence and package requirements','Acceptance criteria','Definition of Done']
    for s in sections:
        if s.lower() not in text.lower(): errors.append('MISSING_SECTION:'+s)
    dels=set(re.findall(r'\bDEL-\d{3}\b',text))
    ac_blocks=re.findall(r'(?ms)^.*?\bAC-\d{3}\b.*?(?=^.*?\bAC-\d{3}\b|\Z)',text)
    refs=set(re.findall(r'\bDEL-\d{3}\b','\n'.join(ac_blocks)))
    if dels and not dels.issubset(refs): errors.append('DEL_WITHOUT_AC:'+','.join(sorted(dels-refs)))
    if 'binding_status' not in text and 'binding status' not in text.lower(): errors.append('BINDING_STATUS_MISSING')
    if re.search(r'(?i)exact (repository|module|class|function).*(unknown|unavailable)',text):
        for term in ['discovery owner','discovery action','closure evidence']:
            if term not in text.lower(): errors.append('UNRESOLVED_BINDING_FIELD_MISSING:'+term)
print(json.dumps({'validator':'jira_run_01_delivery_quality_v5','errors':errors,'result':'PASS' if not errors else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not errors else 1)
