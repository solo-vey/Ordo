#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parents[1]
val=root/'validation/validate_jira_delivery_quality_v3.py'
cases=[('bad',root/'validation/regression_1172/JIRA_BAD_MIXED_AND_MISALIGNED.md',True),('good',root/'validation/regression_1172/JIRA_GOOD.md',False)]
results=[]; failed=[]
for name,path,expect_reject in cases:
 p=subprocess.run([sys.executable,str(val),str(path)],capture_output=True,text=True)
 rejected=p.returncode!=0
 ok=rejected==expect_reject
 results.append({'name':name,'expected_rejected':expect_reject,'actual_rejected':rejected,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'result':'PASS' if ok else 'FAIL'})
 if not ok: failed.append(name)
print(json.dumps({'suite':'alpha_1_17_2_jira_quality','results':results,'failed':failed,'result':'PASS' if not failed else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not failed else 1)
