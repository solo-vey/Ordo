#!/usr/bin/env python3
from pathlib import Path
import sys,yaml,json
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errs=[]
pb=yaml.safe_load((root/'playbook/PLAYBOOK.yaml').read_text(encoding='utf-8'))
if len(pb.get('steps',[]))!=126: errs.append('step_count_changed')
if pb.get('release_patch',{}).get('version')!='1.17.2': errs.append('release_patch_missing')
for f in ['contracts/JIRA_DELIVERY_QUALITY_CONTRACT_V3.yaml','templates/TEMPLATE_JIRA_TASK_V4.md','prompts/hp.artifact.jira.generate_and_review.v4.md','validation/validate_jira_delivery_quality_v3.py']:
    if not (root/f).exists(): errs.append('missing:'+f)
text=(root/'playbook/PLAYBOOK.yaml').read_text(encoding='utf-8')
for token in ['TEMPLATE_JIRA_TASK_V4.md','hp.artifact.jira.generate_and_review.v4.md','JIRA_DELIVERY_QUALITY_CONTRACT_V3.yaml','validate_jira_delivery_quality_v3.py']:
    if token not in text: errs.append('playbook_not_bound:'+token)
print(json.dumps({'validator':'alpha_1_17_2_run_04_jira_patch','step_count':len(pb.get('steps',[])),'errors':errs,'result':'PASS' if not errs else 'FAIL'},indent=2))
sys.exit(0 if not errs else 1)
