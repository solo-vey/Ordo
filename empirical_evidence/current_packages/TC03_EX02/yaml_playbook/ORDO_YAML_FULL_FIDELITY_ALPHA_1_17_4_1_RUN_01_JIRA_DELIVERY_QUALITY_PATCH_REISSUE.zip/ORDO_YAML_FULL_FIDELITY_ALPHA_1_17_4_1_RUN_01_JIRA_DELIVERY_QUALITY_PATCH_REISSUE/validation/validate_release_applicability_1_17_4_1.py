#!/usr/bin/env python3
from pathlib import Path
import json,sys,yaml
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); errors=[]
app=json.loads((root/'validation/REGRESSION_APPLICABILITY.json').read_text())
pb=yaml.safe_load((root/'playbook/PLAYBOOK.yaml').read_text())
if app.get('package_version')!='1.17.4.1': errors.append('APPLICABILITY_VERSION_MISMATCH')
if pb.get('release_patch',{}).get('version')!='1.17.4.1': errors.append('PLAYBOOK_RELEASE_VERSION_MISMATCH')
blocking=set(app.get('release_blocking',[]))
for needed in ['validate_jira_run_01_delivery_quality_v5.py','validate_release_applicability_1_17_4_1.py']:
    if needed not in blocking: errors.append('MISSING_RELEASE_BLOCKING:'+needed)
na={x.get('validator') for x in app.get('not_applicable_release_identity_validators',[])}
for forbidden in ['validate_alpha_1_17_2_run_04_jira_patch.py','validate_alpha_1_17_3_run_04_fact_lock_patch.py']:
    if forbidden not in na: errors.append('RUN04_IDENTITY_NOT_MARKED_NA:'+forbidden)
script=(root/'scripts/run_full_release_validation.sh').read_text()+'\n'+(root/'scripts/run_release_validation.py').read_text()
for forbidden in ['validate_alpha_1_17_2_run_04_jira_patch.py','validate_alpha_1_17_3_run_04_fact_lock_patch.py']:
    if forbidden in script: errors.append('RUN04_IDENTITY_STILL_RELEASE_BLOCKING:'+forbidden)
for required in ['validate_alpha_1_17_1_run_02_completion.py','validate_jira_run_01_delivery_quality_v5.py','validate_release_applicability_1_17_4_1.py']:
    if required not in script: errors.append('RELEASE_SCRIPT_MISSING:'+required)
print(json.dumps({'validator':'release_applicability_1_17_4_1','errors':errors,'result':'PASS' if not errors else 'FAIL'},indent=2))
sys.exit(0 if not errors else 1)
