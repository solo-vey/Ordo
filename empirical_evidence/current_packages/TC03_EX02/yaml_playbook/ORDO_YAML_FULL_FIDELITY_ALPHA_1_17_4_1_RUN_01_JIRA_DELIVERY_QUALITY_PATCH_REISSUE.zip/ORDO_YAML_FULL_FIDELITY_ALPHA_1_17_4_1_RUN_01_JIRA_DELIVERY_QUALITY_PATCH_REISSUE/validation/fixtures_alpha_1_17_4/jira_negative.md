# Jira
## Delivery requirements
DEL-001 Implement handler.
## Acceptance criteria
AC-001 Unrelated no-op.
