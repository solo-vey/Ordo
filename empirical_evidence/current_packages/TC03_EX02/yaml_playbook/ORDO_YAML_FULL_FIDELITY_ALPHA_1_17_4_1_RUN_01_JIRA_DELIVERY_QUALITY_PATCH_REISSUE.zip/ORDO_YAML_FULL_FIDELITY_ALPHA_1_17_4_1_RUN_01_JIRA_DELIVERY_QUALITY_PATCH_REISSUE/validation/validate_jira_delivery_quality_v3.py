#!/usr/bin/env python3
from pathlib import Path
import re,sys,json
text=Path(sys.argv[1]).read_text(encoding='utf-8')
errs=[]
low=text.lower()
for heading in ('product implementation requirements','verification deliverables','evidence and package requirements','del ↔ ac traceability'):
    if heading not in low: errs.append('JIRA_GROUP_MISSING:'+heading)

def section(name,next_names):
    pat=r'(?is)^##\s+'+re.escape(name)+r'\s*$\n(.*?)(?=^##\s+(?:'+ '|'.join(re.escape(x) for x in next_names) +r')\s*$|\Z)'
    m=re.search(pat,text,re.M)
    return m.group(1) if m else ''

def table_rows(block,prefix):
    out=[]
    for ln,line in enumerate(block.splitlines(),1):
        if not line.strip().startswith('|'): continue
        cells=[c.strip() for c in line.strip().strip('|').split('|')]
        if cells and re.fullmatch(prefix+r'-\d+',cells[0],re.I): out.append((cells[0].upper(),cells,ln))
    return out

product_block=section('Product implementation requirements',['Verification deliverables'])
ac_block=section('Acceptance criteria',['DEL ↔ AC traceability'])
trace_block=section('DEL ↔ AC traceability',['Functional delivery coverage','Dependencies, open questions, and closure criteria','Delivery checklist','Definition of Done','External references'])
product=table_rows(product_block,'DEL')
acs=table_rows(ac_block,'AC')
if not product: errs.append('JIRA_PRODUCT_DEL_MISSING')
if not acs: errs.append('JIRA_AC_MISSING')

for did,cells,ln in product:
    if len(cells)<10: errs.append(f'{did}:JIRA_PRODUCT_DEL_FIELDS_MISSING')
    joined=' '.join(cells).lower()
    if not any(x in joined for x in ('handler','normalizer','mapper','guard','validator','domain','component','processor','rule')):
        errs.append(f'{did}:JIRA_COMPONENT_BOUNDARY_MISSING')
    if not any(x in joined for x in ('implement','update','create','reject','prevent','map','validate','persist','emit','block','skip','deduplicate')):
        errs.append(f'{did}:JIRA_IMPLEMENTATION_ACTION_MISSING')
    if not any(x in joined for x in ('exactly','zero','one','no ','must not','cardinality','payload','blocked','no-op')):
        errs.append(f'{did}:JIRA_MEASURABLE_BEHAVIOR_MISSING')
    if not any(x in joined for x in ('bound','unavailable','to-discover','to_be_discovered','not provided')):
        errs.append(f'{did}:JIRA_BINDING_STATUS_MISSING')
    if any(x in joined for x in ('unavailable','to-discover','to_be_discovered','not provided')):
        if not any(x in joined for x in ('owner','tech lead','developer','analyst','discover','repository')):
            errs.append(f'{did}:JIRA_DISCOVERY_OWNER_ACTION_MISSING')
        if not any(x in joined for x in ('closure','path confirmed','symbol confirmed','binding recorded','repository evidence')):
            errs.append(f'{did}:JIRA_BINDING_CLOSURE_MISSING')

all_del_ids={d[0] for d in product}; all_ac_ids={a[0] for a in acs}
linked_del=set(); linked_ac=set()
for aid,cells,ln in acs:
    joined=' '.join(cells).upper(); ds=set(re.findall(r'\bDEL-\d+\b',joined))
    if not ds: errs.append(f'{aid}:JIRA_AC_LINKED_DEL_MISSING')
    linked_del |= ds; linked_ac.add(aid)
for line in trace_block.splitlines():
    up=line.upper()
    if 'DEL-' in up and 'AC-' in up:
        linked_del |= set(re.findall(r'\bDEL-\d+\b',up)); linked_ac |= set(re.findall(r'\bAC-\d+\b',up))
for did in sorted(all_del_ids-linked_del): errs.append(f'{did}:JIRA_DEL_LINKED_AC_MISSING')
for aid in sorted(all_ac_ids-linked_ac): errs.append(f'{aid}:JIRA_AC_TRACEABILITY_MISSING')

print(json.dumps({'validator':'jira_delivery_quality_v3','product_del_count':len(product),'ac_count':len(acs),'errors':sorted(set(errs)),'result':'PASS' if not errs else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not errs else 1)
