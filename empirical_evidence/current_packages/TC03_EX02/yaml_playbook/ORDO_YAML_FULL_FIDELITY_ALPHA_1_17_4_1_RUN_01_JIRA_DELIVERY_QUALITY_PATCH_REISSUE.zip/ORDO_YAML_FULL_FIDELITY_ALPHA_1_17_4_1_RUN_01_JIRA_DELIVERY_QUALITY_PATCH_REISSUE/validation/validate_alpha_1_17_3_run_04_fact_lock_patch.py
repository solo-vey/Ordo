#!/usr/bin/env python3
from pathlib import Path
import sys,yaml,json,tempfile,subprocess
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve();e=[]
pb=yaml.safe_load((root/'playbook/PLAYBOOK.yaml').read_text(encoding='utf-8'))
if len(pb.get('steps',[]))!=126:e.append('step_count_changed')
if pb.get('release_patch',{}).get('version')!='1.17.3':e.append('release_patch_missing')
req=['contracts/JIRA_AUTHORITATIVE_FACT_LOCK_CONTRACT_V4.yaml','templates/TEMPLATE_JIRA_TASK_V5.md','prompts/hp.artifact.jira.generate_and_review.v5.md','validation/validate_jira_authoritative_fact_lock_v4.py']
for f in req:
 if not (root/f).exists():e.append('missing:'+f)
t=(root/'playbook/PLAYBOOK.yaml').read_text(encoding='utf-8')
for x in ['TEMPLATE_JIRA_TASK_V5.md','generate_and_review.v5.md','JIRA_AUTHORITATIVE_FACT_LOCK_CONTRACT_V4.yaml','validate_jira_authoritative_fact_lock_v4.py']:
 if x not in t:e.append('playbook_not_bound:'+x)
# Positive/negative executable fixture
with tempfile.TemporaryDirectory() as td:
 td=Path(td); sel=td/'sel.yaml'; good=td/'good.md'; bad=td/'bad.md'
 sel.write_text('document_id: DOC-4\nrecord_key: REC-4\nfield_path: item.processingState\nold_value: pending\nnew_value: reviewed\noperation_status: UPDATE\nevent_type: PROCESSING_STATE_CHANGED\nchange_id: CHG-4\noccurred_at: 2026-07-17T00:00:00Z\n')
 good.write_text('document_id: DOC-4\nrecord_key: REC-4\nfield_path: item.processingState\nold_value: pending\nnew_value: reviewed\noperation_status: UPDATE\nevent_type: PROCESSING_STATE_CHANGED\nchange_id: CHG-4\noccurred_at: 2026-07-17T00:00:00Z\npending -> reviewed\n')
 bad.write_text(good.read_text().replace('reviewed','approved'))
 cmd=[sys.executable,str(root/'validation/validate_jira_authoritative_fact_lock_v4.py'),str(sel),str(good)]
 if subprocess.run(cmd,capture_output=True).returncode!=0:e.append('positive_fixture_failed')
 cmd[-1]=str(bad)
 if subprocess.run(cmd,capture_output=True).returncode==0:e.append('negative_fixture_not_rejected')
print(json.dumps({'validator':'alpha_1_17_3_run_04_fact_lock_patch','step_count':len(pb.get('steps',[])),'errors':e,'result':'PASS' if not e else 'FAIL'},indent=2));sys.exit(0 if not e else 1)
