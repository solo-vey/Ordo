#!/usr/bin/env python3
from pathlib import Path
import argparse,json,re,yaml
from datetime import date,datetime
ALIASES={
'document_id':['document_id','documentId'],'record_key':['record_key','recordKey'],
'field_path':['field_path','fieldPath'],'old_value':['old_value','oldValue'],
'new_value':['new_value','newValue'],'operation_status':['operation_status','operationStatus','operation','status'],
'event_type':['event_type','eventType'],'change_id':['change_id','changeId'],'occurred_at':['occurred_at','occurredAt']}
def norm(v):
 if isinstance(v,(date,datetime)): return v.isoformat().replace('+00:00','Z')
 return str(v).strip().strip('`"\'').rstrip('.,;:')
def deep_find(o,names):
 if isinstance(o,dict):
  for k,v in o.items():
   if k in names and v not in (None,''): return norm(v)
   x=deep_find(v,names)
   if x is not None:return x
 if isinstance(o,list):
  for v in o:
   x=deep_find(v,names)
   if x is not None:return x
 return None
def main():
 ap=argparse.ArgumentParser();ap.add_argument('selected_input');ap.add_argument('jira');a=ap.parse_args()
 selected=yaml.safe_load(Path(a.selected_input).read_text(encoding='utf-8'))
 expected={k:deep_find(selected,v) for k,v in ALIASES.items()};expected={k:v for k,v in expected.items() if v is not None}
 text=Path(a.jira).read_text(encoding='utf-8',errors='replace')
 errors=[];presence={}
 for k,v in expected.items():
  presence[k]=v in text
  if k in {'field_path','old_value','new_value','event_type','operation_status'} and v not in text:
   errors.append(f'JIRA_AUTHORITATIVE_FACT_MISSING:{k}:expected={v}')
 # Detect common explicit transitions and key-value/table declarations.
 for k,exp in expected.items():
  names='|'.join(re.escape(x) for x in ALIASES[k])
  pats=[rf'(?im)^\s*[-|]*\s*(?:{names})\s*[:=|]\s*[`"\']?([^\s|,"\']+)',rf'(?i)["\'](?:{names})["\']\s*:\s*["\']([^"\']+)']
  for pat in pats:
   for m in re.finditer(pat,text):
    got=norm(m.group(1))
    if got.startswith(('<','${','{{')): continue
    if got!=exp: errors.append(f'JIRA_AUTHORITATIVE_FACT_DRIFT:{k}:expected={exp}:actual={got}')
 # For old -> new transitions, reject a transition from expected old to any other literal.
 old,new=expected.get('old_value'),expected.get('new_value')
 if old and new:
  for m in re.finditer(re.escape(old)+r'\s*(?:→|->|to)\s*[`"\']?([A-Za-z0-9_.:-]+)',text,re.I):
   got=norm(m.group(1))
   if got!=new: errors.append(f'JIRA_AUTHORITATIVE_FACT_DRIFT:new_value:expected={new}:actual={got}')
 out={'validator':'jira_authoritative_fact_lock_v4','expected':expected,'presence':presence,'errors':sorted(set(errors)),'result':'PASS' if not errors else 'FAIL'}
 print(json.dumps(out,ensure_ascii=False,indent=2));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
