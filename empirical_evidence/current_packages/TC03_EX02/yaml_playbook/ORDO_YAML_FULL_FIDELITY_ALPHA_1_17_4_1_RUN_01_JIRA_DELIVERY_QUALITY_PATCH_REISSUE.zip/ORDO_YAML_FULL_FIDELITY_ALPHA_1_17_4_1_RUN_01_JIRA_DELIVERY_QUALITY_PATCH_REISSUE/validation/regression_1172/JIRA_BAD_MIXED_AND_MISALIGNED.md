# Jira Task — bad
## Product implementation requirements
| Delivery ID | Target component/domain object | Implementation action | Concrete output or prohibited side effect | Measurable behavior | Binding status | Owner/discovery action | Closure condition | Completion evidence | Status |
|---|---|---|---|---|---|---|---|---|---|
| DEL-001 | event mapper | Implement mapping | emit one event | exactly one event | unavailable | unknown | unknown | Passport | planned |
| DEL-002 | Manual QA | Create test document | document exists | one document | bound | QA | document | link | planned |
## Verification deliverables
| Delivery ID | Verification target | Required test/check | Exact expected result | Linked product DEL IDs | Completion evidence | Status |
|---|---|---|---|---|---|---|
| DEL-V01 | no-op | Manual QA | zero event | DEL-001 | MQA-01 | planned |
## Evidence and package requirements
| Delivery ID | Evidence object | Required content | Linked DEL/AC IDs | Completion evidence | Status |
|---|---|---|---|---|---|
| DEL-E01 | receipt | PASS | DEL-001 | receipt | planned |
## Acceptance criteria
| AC ID | Linked DEL IDs | Given / input | When / action | Then / exact observable result | Verification/evidence | Blocker applicability |
|---|---|---|---|---|---|---|
| AC-001 | DEL-002 | unrelated field | process | zero events | MQA-01 | none |
## DEL ↔ AC traceability
| Delivery ID | Acceptance criteria | Semantic alignment statement |
|---|---|---|
| DEL-002 | AC-001 | unrelated field no-op |
