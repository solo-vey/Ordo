# Jira task template — database-change delivery view v4

Generated filename: `02_JIRA_TASK_<ALIAS>.md`.

## Filling rules

- Ukrainian prose; preserve technical identifiers.
- Keep product implementation, verification, and evidence/package work in separate delivery groups.
- Never invent repository paths, classes, URLs, runtime bindings, owners, or execution results.
- When an exact code binding is unavailable, identify the component/domain boundary, discovery owner, discovery action, closure evidence, and work allowed before closure.
- Every product DEL must map to at least one AC; every AC must map to at least one DEL.
- DEL and AC must describe the same behavior/output.

# Jira Task — <ALIAS>

## Summary and business context

- Summary: `<...>`
- Business outcome / consumer: `<...>`
- Operational value: `<...>`
- Passport reference/version: `<...>`

## Confirmed contract summary

| Concern | Confirmed value/behavior | Authoritative source or Passport reference |
|---|---|---|
| Rule/alias | `<...>` | `<...>` |
| Source/change identity | `<...>` | `<...>` |
| Target field/operation | `<...>` | `<...>` |
| Normalization/no-op | `<...>` | `<...>` |
| Output and mapping | `<...>` | `<...>` |
| Date and duplicate identity | `<...>` | `<...>` |
| Missing-data behavior | `<...>` | `<...>` |

## Scope and exclusions

### In scope
`<atomic scope items>`

### Out of scope
`<explicit exclusions>`

## Product implementation requirements

One row per concrete product/code behavior. Do not include QA-document creation or package assembly here.

| Delivery ID | Target component/domain object | Implementation action | Concrete output or prohibited side effect | Measurable behavior | Binding status | Owner/discovery action | Closure condition | Completion evidence | Status |
|---|---|---|---|---|---|---|---|---|---|
| `DEL-001` | `<handler/normalizer/mapper/domain boundary>` | `<implement/update/reject/prevent/map>` | `<exact result>` | `<cardinality/payload/no-side-effect>` | `<bound/unavailable/to-discover>` | `<owner and action>` | `<specific evidence>` | `<code/test/review evidence>` | `<planned/blocked/done>` |

Required concerns when applicable: operation/status filter, field-path filter, normalization/comparison, no-op, required-data validation, payload mapping, date mapping, duplicate guard, diagnostics, production binding discovery.

## Verification deliverables

| Delivery ID | Verification target | Required test/check | Exact expected result | Linked product DEL IDs | Completion evidence | Status |
|---|---|---|---|---|---|---|
| `DEL-V01` | `<behavior>` | `<Manual QA/Automation/validator>` | `<exact result>` | `<DEL-...>` | `<evidence>` | `<...>` |

## Evidence and package requirements

| Delivery ID | Evidence object | Required content | Linked DEL/AC IDs | Completion evidence | Status |
|---|---|---|---|---|---|
| `DEL-E01` | `<traceability/receipt/package object>` | `<exact required content>` | `<DEL-... / AC-...>` | `<evidence>` | `<...>` |

## Acceptance criteria

One criterion per independently verifiable behavior. Each AC must link to the DEL that implements the same behavior.

| AC ID | Linked DEL IDs | Given / input | When / action | Then / exact observable result | Verification/evidence | Blocker applicability |
|---|---|---|---|---|---|---|
| `AC-001` | `DEL-001` | `<exact precondition/input>` | `<exact decision/action>` | `<exact output/cardinality/diagnostic>` | `<MQA/AUTO/validator ref>` | `<none/DEP-...>` |

Cover every applicable behavior separately: successful creation, unsupported operation/status, unrelated field, normalized same-value no-op, missing data, mapping, date, duplicate identity, boundaries, diagnostics.

## DEL ↔ AC traceability

| Delivery ID | Acceptance criteria | Semantic alignment statement |
|---|---|---|
| `DEL-001` | `AC-001` | `<same target, action and observable result>` |

## Functional delivery coverage

| Functional ID | Requirement and exact expected result | Product DEL IDs | AC IDs | Manual QA | Automation | Status/blocker |
|---|---|---|---|---|---|---|
| `TC-01` | `<...>` | `<DEL-...>` | `<AC-...>` | `<MQA-...>` | `<AUTO-...>` | `<...>` |

## Dependencies, open questions, and closure criteria

| ID | Missing evidence/capability or question | Affected DEL/AC | Impact | Owner/discovery action | Closure criterion | Work allowed while open | Blocks |
|---|---|---|---|---|---|---|---|
| `DEP-01` | `<...>` | `<DEL-... / AC-...>` | `<...>` | `<...>` | `<specific evidence that closes it>` | `<...>` | `<implementation/verification/live execution>` |

## Delivery checklist

- [ ] Product, verification, and evidence deliverables are separated.
- [ ] Every product DEL names a component/domain boundary, action, output, measurable behavior, and binding status.
- [ ] Missing binding has owner, discovery action, closure evidence, and allowed pre-closure work.
- [ ] Every product DEL maps to at least one AC.
- [ ] Every AC maps to at least one DEL and is semantically aligned.
- [ ] Manual QA and Automation handoffs are complete or explicitly deferred.
- [ ] Cross-document consistency review passed.

## Definition of Done

- All blocking product delivery requirements are complete.
- Every applicable AC has evidence or a valid blocker with closure criterion.
- DEL ↔ AC traceability is complete and semantically aligned.
- Exact code binding is recorded, or the discovery dependency is closed with evidence.
- Verification and evidence/package deliverables are complete without replacing product implementation requirements.
- Passport, Manual QA, and Automation versions are current and consistent.
- Final consistency validation passes.

## External references

- Passport/Confluence: `<provided reference or Not provided>`
- Jira issue: `<provided URL or Not provided>`
- Analytical package: `<reference or Not provided>`

Never invent URLs.
