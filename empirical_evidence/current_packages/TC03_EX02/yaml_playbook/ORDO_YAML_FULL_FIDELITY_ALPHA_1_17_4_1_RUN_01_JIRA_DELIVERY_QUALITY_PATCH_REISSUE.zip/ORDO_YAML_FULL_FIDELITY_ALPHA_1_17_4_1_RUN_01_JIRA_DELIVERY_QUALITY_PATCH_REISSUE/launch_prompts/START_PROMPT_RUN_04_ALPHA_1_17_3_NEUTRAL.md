You are executing RUN_04 of the Ordo Database Change YAML Full-Fidelity package Alpha 1.17.3.

RUN_ID = RUN_04

MANDATORY PRE-FLIGHT
1. Verify `SHA256SUMS.txt`; stop with `NO_CHANGE` on mismatch.
2. Run `python validation/preflight_alpha_1_13_full_fidelity.py .`.
3. Run all available versioned regression scripts in ascending version order.
4. Run `python validation/validate_alpha_1_17_3_run_04_fact_lock_patch.py .`.
5. Stop with `NO_CHANGE` on any failure.

RUN_04 EXECUTION
1. Materialize only RUN_04.
2. Execute the canonical 126-step playbook from T001.
3. Before every Jira generation or regeneration, reload the selected-run input and current confirmed Passport.
4. Copy exactly: `document_id`, `record_key`, `field_path`, `old_value`, `new_value`, `operation_status`, `event_type`, `change_id`, and `occurred_at`.
5. Do not reconstruct corrected facts from memory. The selected-run input overrides earlier or conflicting values.
6. After saving Jira, run:
   - `validate_jira_delivery_content.py`;
   - `validate_jira_implementation_output.py`;
   - `validate_jira_delivery_quality_v3.py`;
   - `validate_jira_authoritative_fact_lock_v4.py <selected-run-input> <jira-file>`.
7. On `JIRA_AUTHORITATIVE_FACT_DRIFT`, invalidate the current Jira version, reload authoritative facts, regenerate, rerun all Jira validators, and do not approve the failed version.
8. Preserve Alpha 1.17.2 product/verification/evidence separation and DEL↔AC alignment.
9. Never invent repository bindings, facts, PASS receipts, approvals, or live execution results.
10. Emit concise progress lines: `Крок <ID> — <коротка суть> — <статус>`.
11. Do not self-score.

EXPECTED SUCCESS TERMINAL
`T_COMPLETED / GO`

Respond in Ukrainian.
