You are executing RUN_04 of the Ordo Database Change YAML Full-Fidelity package Alpha 1.17.2.

RUN_ID = RUN_04

INPUT PACKAGE
ORDO_YAML_FULL_FIDELITY_ALPHA_1_17_2_RUN_04_JIRA_QUALITY_PATCH.zip

CANONICAL PROCESS SOURCE
playbook/PLAYBOOK.yaml

MANDATORY PRE-FLIGHT
1. Verify `SHA256SUMS.txt`; stop with `NO_CHANGE` on mismatch.
2. Run `python validation/preflight_alpha_1_13_full_fidelity.py .`.
3. Run all available versioned regression scripts in ascending version order.
4. Run `python validation/validate_alpha_1_17_1_run_02_completion.py .`.
5. Run `python validation/validate_alpha_1_17_2_run_04_jira_patch.py .`.
6. Stop with `NO_CHANGE` on any preflight or regression failure.

RUN_04 EXECUTION REQUIREMENTS
1. Execute the canonical 126-step playbook from T001 for RUN_04 only.
2. Preserve correction, invalidation, regeneration, revalidation and reapproval semantics.
3. Generate Jira with `templates/TEMPLATE_JIRA_TASK_V4.md` and `prompts/hp.artifact.jira.generate_and_review.v4.md`.
4. Separate Jira delivery rows into:
   - product implementation requirements;
   - verification deliverables;
   - evidence and package requirements.
5. Every product DEL must state target component/domain boundary, action, concrete output or prohibited side effect, measurable behavior and binding status.
6. If exact repository/module/class/function is unavailable, do not invent it. Record discovery owner, action, closure evidence and work allowed before closure.
7. Every product DEL must link to at least one semantically aligned AC; every AC must link to at least one DEL.
8. Run all Jira validators, including:
   - `validate_jira_delivery_content.py`;
   - `validate_jira_implementation_output.py`;
   - `validate_jira_delivery_quality_v3.py`.
9. On FAIL, invalidate the Jira version, regenerate, rerun all validators and approve only the current PASS version.
10. Emit concise progress lines: `Крок <ID> — <коротка суть> — <статус>`.
11. Do not invent facts, bindings, validator PASS, approvals or live execution results.
12. Return complete route-authorized artifacts and evidence.
13. Do not self-score.

EXPECTED SUCCESS TERMINAL
T_COMPLETED / GO

Respond in Ukrainian.
