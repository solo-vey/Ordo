# Ordo YAML Full-Fidelity Alpha 1.17.4.1

Corrected reissue of the local RUN_01 Jira delivery-quality patch.

The canonical process remains 126 steps. Business semantics are unchanged.

The release preflight is now applicability-aware: RUN_04 release-identity validators remain in the package as historical/inherited validators, but they are not release-blocking for this RUN_01-targeted package. Inherited Jira quality and authoritative fact-lock capabilities remain required.

Run exactly:

```bash
bash scripts/run_full_release_validation.sh
```

Launch prompt: `launch_prompts/START_PROMPT_RUN_01_ALPHA_1_17_4_1_NEUTRAL.md`.
