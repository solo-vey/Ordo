#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json,time
root=Path(__file__).resolve().parents[1]
commands=[
 ['validation/preflight_alpha_1_13_full_fidelity.py','.'],
 ['validation/run_alpha_1_14_regression.py'],
 ['validation/run_alpha_1_16_regression.py'],
 ['validation/run_alpha_1_16_1_regression.py'],
 ['validation/run_alpha_1_16_2_regression.py'],
 ['validation/run_alpha_1_16_3_regression.py'],
 ['validation/run_alpha_1_16_4_regression.py'],
 ['validation/run_alpha_1_16_5_regression.py'],
 ['validation/run_alpha_1_16_7_regression.py'],
 ['validation/run_alpha_1_16_8_regression.py'],
 ['validation/run_alpha_1_16_9_regression.py'],
 ['validation/validate_alpha_1_17_1_run_02_completion.py','.'],
 ['validation/validate_jira_run_01_delivery_quality_v5.py','.'],
 ['validation/validate_release_applicability_1_17_4_1.py','.'],
]
results=[]; failed=[]
for parts in commands:
    cmd=[sys.executable,*parts]
    started=time.time()
    try:
        p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=180)
        item={'command':' '.join(parts),'return_code':p.returncode,'duration_seconds':round(time.time()-started,3),'stdout_tail':p.stdout[-4000:],'stderr_tail':p.stderr[-4000:]}
    except subprocess.TimeoutExpired as e:
        item={'command':' '.join(parts),'return_code':124,'duration_seconds':round(time.time()-started,3),'stdout_tail':(e.stdout or '')[-4000:] if isinstance(e.stdout,str) else '', 'stderr_tail':(e.stderr or '')[-4000:] if isinstance(e.stderr,str) else '', 'error':'TIMEOUT'}
    results.append(item)
    status='PASS' if item['return_code']==0 else 'FAIL'
    print(f"{item['command']} — {status} ({item['duration_seconds']}s)",flush=True)
    if item['return_code']!=0:
        failed.append(item['command'])
        break
report={'schema_version':'ordo.alpha_1_17_4_1.full_release_validation.v1','package_version':'1.17.4.1','results':results,'failed':failed,'result':'PASS' if not failed else 'FAIL'}
(root/'validation/ALPHA_1_17_4_1_FULL_RELEASE_VALIDATION_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':report['result'],'checks_completed':len(results),'failed':failed},ensure_ascii=False))
sys.exit(0 if not failed else 1)
