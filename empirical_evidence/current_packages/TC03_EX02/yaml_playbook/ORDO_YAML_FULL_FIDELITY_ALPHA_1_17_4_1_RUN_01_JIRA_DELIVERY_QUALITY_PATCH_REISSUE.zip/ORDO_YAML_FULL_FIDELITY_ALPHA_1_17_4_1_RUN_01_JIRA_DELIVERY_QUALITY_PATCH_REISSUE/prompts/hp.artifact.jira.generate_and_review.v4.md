# Database-change Jira artifact generation and review v4

## Purpose

Generate a delivery-focused Jira task derived from the confirmed Passport and selected RUN facts.

Jira is not a copy of the Passport. It may refer to the Passport for detailed domain contracts,
unit/provider test specifications, and full traceability matrices. Unit-test specifications do not
need to be repeated in Jira.

Section order and physical placement are not quality criteria. Quality depends on whether all
required information is present, concrete, internally consistent, and usable for delivery.

## Current-pass sources

Reload before generation:
1. `templates/TEMPLATE_JIRA_TASK_V4.md`;
2. the current confirmed Passport;
3. `runtime/SELECTED_RUN_CONFIRMED_INPUT.yaml`;
4. confirmed functional/manual/automation catalogs;
5. relevant operational/runtime contracts;
6. `contracts/JIRA_DELIVERY_QUALITY_CONTRACT_V3.yaml`.

## Mandatory content

### A. Delivery decomposition

Create atomic delivery requirements for each applicable implementation concern:

- operation/status filter;
- target field-path filter;
- normalization and comparison;
- no-op decision;
- required-data validation;
- exact output mapping;
- date mapping;
- duplicate identity/prevention;
- diagnostics and observability;
- production binding/code discovery;
- manual QA handoff;
- automation handoff;
- documentation and source references.

Each delivery row must contain:

- stable delivery ID;
- concrete expected output;
- affected behavior/component;
- authoritative source or Passport reference;
- dependency/blocker, if any;
- completion evidence;
- delivery status.

Do not use a single generic “implement and test” row.

### B. Acceptance criteria

Create one or more atomic acceptance criteria for every confirmed behavior.

Each criterion must contain:

- stable AC ID;
- concern/behavior;
- Given or input/precondition;
- When or action/decision;
- Then exact expected observable result;
- evidence or verification reference;
- blocker applicability.

At minimum cover, when applicable:

- successful creation;
- unsupported operation/status;
- unrelated field;
- normalized same-value no-op;
- missing required mapping/data;
- exact payload mapping;
- date mapping;
- duplicate behavior;
- null/missing/empty boundary behavior;
- diagnostics;
- documentation and traceability.

Acceptance criteria must not be a short aggregate sentence covering unrelated behaviors.

### C. Functional delivery coverage

Include every confirmed functional test ID or reference the complete Passport functional catalog
with an explicit Jira coverage table. For each functional behavior record:

- requirement;
- expected result;
- related delivery IDs;
- Manual QA allocation;
- Automation allocation;
- current status or blocker.

### D. Dependencies and blocker closure

For every dependency or blocker include:

- exact missing evidence or capability;
- affected delivery IDs and acceptance criteria;
- owner or discovery action;
- closure criterion: the concrete evidence that will resolve it;
- what may proceed while it remains open;
- whether it blocks implementation, verification, or only live execution.

A blocker without a closure criterion is incomplete.

### E. Definition of Done

The DoD must explicitly require:

- all blocking delivery rows completed;
- all applicable ACs verified or correctly blocked/deferred;
- Passport reference current;
- code/repository binding recorded when required;
- Manual QA handoff complete;
- Automation handoff complete or explicitly deferred;
- observability verified;
- evidence links/statuses recorded;
- unresolved blockers visible;
- cross-document consistency check passed.

## Allowed Passport references

The following are valid and must not be penalized:

- references to full unit/provider specifications in Passport;
- references to full mapping tables in Passport;
- references to detailed traceability in Passport;
- references to confirmed domain definitions in Passport.

A reference must identify the relevant Passport section, table, or stable ID. A vague “see Passport”
without a target is not sufficient.

## Forbidden shortcuts

- generic delivery rows;
- aggregate acceptance criteria spanning unrelated behavior;
- hidden dependency;
- blocker without closure criterion;
- completion claim without evidence;
- invented repository paths, classes, URLs, runtime results, or commands;
- treating section order as a quality requirement;
- requiring Jira to duplicate unit-test specifications.


## Mandatory delivery-group separation (Alpha 1.17.2)

Create three distinct groups:

1. **Product implementation requirements** — code/domain behavior only.
2. **Verification deliverables** — Manual QA, Automation, and validator work.
3. **Evidence and package requirements** — receipts, traceability, and package objects.

A verification or package row cannot substitute for a missing product implementation row.

## Mandatory implementation binding disclosure

For each product DEL include:

- target component type or domain boundary;
- implementation action;
- concrete output or prohibited side effect;
- measurable behavior;
- exact binding status.

If repository/module/class/function is unavailable, do not invent it. Instead include:

- `binding_status: unavailable` or `to_be_discovered`;
- discovery owner;
- discovery action;
- closure evidence;
- work allowed before closure.

## Mandatory DEL ↔ AC alignment

- Every product DEL must link to at least one AC.
- Every AC must link to at least one DEL.
- The linked DEL and AC must describe the same target, behavior, and observable result.
- Do not pair an event-mapper DEL with an unrelated-field no-op AC.
- Do not pair a Manual QA deliverable with a product behavior AC.

Before saving, create a DEL ↔ AC traceability table and review every pair for semantic alignment.

## Review gates

Pass only when:

- `jira_required_content_present`;
- `jira_delivery_rows_atomic`;
- `jira_acceptance_criteria_atomic_and_verifiable`;
- `jira_functional_delivery_coverage_complete`;
- `jira_passport_references_specific`;
- `jira_dependencies_visible`;
- `jira_blocker_closure_criteria_complete`;
- `jira_dod_evidence_based`;
- `jira_no_invented_bindings`.

Do not fail because unit-test rows are absent or because sections appear in a different order.

## Implementation-output specificity
Each DEL must independently state the target component/domain object, implementation action, concrete output or prohibited side effect, and measurable behavior.
A reference to Passport, Manual QA, Automation, or a TC ID is supplementary and cannot replace implementation content.


## Canonical DEL examples

Required level:
```markdown
| DEL-001 | Implement processing-state change handling for `item.processingState`; persist exactly one change record and emit exactly one processing-state-changed event, while creating zero error records. | Passport TC-001 |
```

Forbidden reference-only form:
```markdown
| DEL-001 | Implement according to Passport TC-001 and corresponding tests. | Passport TC-001 |
```

Before rendering, perform a line-by-line self-review of every DEL and AC. For each DEL explicitly identify target, action, concrete output or prohibited side effect, and measurable result. References are ignored when judging whether these slots are complete.


## Validation/correction loop requirement (Alpha 1.16.7)
After rendering, run every required validator on the exact saved artifact. If any validator fails, do not present or approve the artifact: invalidate that version, regenerate a new version, rerun all required validators, and present only the version whose immutable receipt records PASS, return code 0, and the same SHA-256.

## Mandatory correction-loop execution

A validator FAIL is a control-flow transition, not a report-only status.

On FAIL:
1. invalidate the current artifact version;
2. record the validator IDs, artifact version and SHA-256 in `runtime/CORRECTION_REGISTRY.json`;
3. return immediately to the owning generation step;
4. create a new artifact version;
5. rerun all required validators;
6. do not continue to presentation, another artifact, cross-artifact gates or packaging while this correction remains unresolved.

Case-local identifiers used for negative, unrelated-field or duplicate-cycle fixtures must be declared explicitly as `derived_case_literals` or `derived_case_literal:` entries. Undeclared conflicting literals are forbidden.
