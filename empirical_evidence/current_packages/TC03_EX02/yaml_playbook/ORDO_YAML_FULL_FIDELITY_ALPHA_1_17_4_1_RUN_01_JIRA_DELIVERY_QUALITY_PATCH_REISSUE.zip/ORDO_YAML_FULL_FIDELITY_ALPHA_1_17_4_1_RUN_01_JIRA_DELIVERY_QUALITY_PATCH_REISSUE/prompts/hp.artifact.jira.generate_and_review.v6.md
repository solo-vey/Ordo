# Jira generation and review — v6 (RUN_01 delivery quality)

Generate a delivery-ready Jira task from the current approved Passport and the authoritative selected-run facts.

## Mandatory structure

1. Product implementation requirements
2. Verification deliverables
3. Evidence and package requirements
4. Acceptance criteria
5. Definition of Done

## Product requirement rule

Every product `DEL-nnn` must state:

- component boundary;
- implementation target;
- implementation action;
- expected output;
- prohibited side effects;
- binding status.

When repository/module/class/function binding is unavailable, do not invent it. Mark the binding unresolved and state discovery owner, discovery action, closure evidence, and work allowed before closure.

## DEL ↔ AC rule

Every product DEL must have at least one AC that explicitly references it. Every AC must reference a DEL. The AC must verify the same behavior described by the DEL, not an unrelated behavior.

## Authoritative fact lock

Reload selected-run facts before generation and every regeneration. Preserve document ID, record key, field path, old value, new value, operation status, event type, change ID, and occurred-at exactly. Fact drift blocks approval.

## Definition of Done

Include delivery readiness: resolved component or explicit discovery dependency, code-change boundary, unit/integration verification, backward compatibility, error handling/observability, and measurable acceptance criteria.

Do not use Manual QA, Automation, or package evidence as substitutes for product implementation requirements.
