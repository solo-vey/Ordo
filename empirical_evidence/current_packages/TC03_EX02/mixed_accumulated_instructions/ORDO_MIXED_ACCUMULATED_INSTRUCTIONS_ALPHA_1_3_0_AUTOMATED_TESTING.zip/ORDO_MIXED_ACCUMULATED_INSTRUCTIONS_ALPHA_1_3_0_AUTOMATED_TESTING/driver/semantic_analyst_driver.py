#!/usr/bin/env python3
"""
Adaptive semantic analyst simulator for historically accumulated language instructions.

The tested model asks natural-language questions. The driver classifies the requested
contract intents and returns only facts allowed by the encrypted scenario.

The driver deliberately does not expose playbook step numbers or an event sequence.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from cryptography.fernet import Fernet
from typing import Any
import argparse
import json
import re
import sys
import hashlib
import subprocess
from datetime import datetime, timezone
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
VALID_RUNS = {"RUN_01", "RUN_02", "RUN_03", "RUN_04", "RUN_05"}

INTENT_PATTERNS: dict[str, list[str]] = {
    "process.branch": [
        "which branch", "selected branch", "where should we begin", "scope branch",
        "internal record change", "start the process"
    ],
    "business.purpose": [
        "business purpose", "business meaning", "what is the purpose", "why is this needed",
        "what should the package support", "desired outcome"
    ],
    "source.collection": [
        "source collection", "collection name", "which collection", "where is the source record stored", "where is the source record kept", "where is the record kept", "where is it stored"
    ],
    "source.document_id": [
        "document id", "document identifier", "stable identifier", "locate the same source document",
        "mongo id", "source record identifier", "which id locates the document"
    ],
    "source.record_key": [
        "record key", "stable record key", "business key", "internal record key", "which stable identifiers", "identifiers should i use"
    ],
    "source.item_context": [
        "relevant item", "item context", "which nested item", "relative to item"
    ],
    "change.field_path": [
        "changed field", "field path", "nested path", "which field changes",
        "path of the changed value", "exact path"
    ],
    "change.old_value": [
        "old value", "previous value", "before value", "prior state", "prior value", "value before", "what was its prior value"
    ],
    "change.new_value": [
        "new value", "current value", "after value", "target state", "value after", "what value should replace it", "replacement value"
    ],
    "change.operation_status": [
        "operation status", "change status", "status of the change", "supported status",
        "modified status", "operation type"
    ],
    "change.change_id": [
        "change id", "change identifier", "unique change", "deduplication id",
        "source change id", "traceability identifier"
    ],
    "change.occurred_at": [
        "occurrence time", "occurred at", "timestamp", "when did the change occur",
        "event date source", "change time"
    ],
    "event.type": [
        "event type", "derived event type", "event identifier", "machine event name",
        "canonical event"
    ],
    "event.display_name": [
        "display name", "human readable name", "human facing label", "event label", "display text", "label should the resulting event use"
    ],
    "event.values_shape": [
        "values object", "output keys", "values keys", "event values",
        "which keys", "output shape"
    ],
    "event.date_mapping": [
        "event date", "date mapping", "map the timestamp", "timestamp mapping"
    ],
    "rule.deduplication": [
        "deduplicate", "deduplication", "duplicate key", "duplicate behavior",
        "same change twice", "duplicates", "duplicate rules"
    ],
    "rule.creation": [
        "creation rule", "when create", "when should the event be created",
        "trigger conditions", "meaningful change", "meaningful creation"
    ],
    "rule.no_op": [
        "no op", "no-op", "when should no event", "equal values", "unrelated field",
        "unsupported status", "skip"
    ],
    "rule.missing_data": [
        "missing data", "mandatory data", "what blocks", "hard stop",
        "required fields", "unavailable identifier"
    ],
    "rule.normalization": [
        "normalization", "normalize", "trim", "case", "null", "empty string",
        "missing value equivalence", "whitespace"
    ],
    "implementation.mode": [
        "implementation module", "code available", "modify code", "implementation mode",
        "instructions only", "repository available"
    ],
    "qa.reference_data": [
        "qa reference", "test data", "reference data", "manual qa data",
        "fixture for qa", "qa data", "expectations for qa data"
    ],
    "automation.status": [
        "automation status", "runner", "live run", "automation execution",
        "runner compatibility", "automation ready"
    ],
    "analysis.open_questions": [
        "open questions", "assumptions", "anything unresolved", "remaining questions",
        "what is still missing"
    ],
}

APPROVAL_ALIASES = {
    "passport": "approval.passport",
    "canonical passport": "approval.passport",
    "record change passport": "approval.passport",
    "jira": "approval.jira",
    "jira task": "approval.jira",
    "qa": "approval.qa",
    "qa package": "approval.qa",
    "manual qa": "approval.qa",
    "automation": "approval.automation",
    "automation specification": "approval.automation",
}


REQUIRED_VALIDATORS = {
    "approval.passport": [
        ("validate_unit_provider_semantics", "validation/validate_unit_provider_semantics.py", []),
        ("validate_passport_mapping_rationale", "validation/validate_passport_mapping_rationale.py", []),
        ("validate_passport_cross_artifact_traceability", "validation/validate_passport_cross_artifact_traceability.py", ["case_registry_path"]),
    ],
    "approval.jira": [
        ("validate_jira_delivery_content", "validation/validate_jira_delivery_content.py", []),
        ("validate_jira_implementation_output", "validation/validate_jira_implementation_output.py", []),
    ],
    "approval.qa": [
        ("validate_manual_qa_rendered", "validation/validate_manual_qa_rendered.py", []),
        ("validate_manual_qa_fail_closed", "validation/validate_manual_qa_fail_closed.py", []),
    ],
    "approval.automation": [
        ("validate_automation_rendered", "validation/validate_automation_rendered.py", []),
    ],
}

def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def _run_authoritative_validators(key: str, artifact_path: Path, request: dict[str, Any], state_file: Path) -> dict[str, Any]:
    results=[]
    required_ids=[]
    logs_dir=state_file.parent / "validator_logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    for validator_id, rel, extra_keys in REQUIRED_VALIDATORS[key]:
        required_ids.append(validator_id)
        cmd=[sys.executable, str(ROOT/rel), str(artifact_path)]
        missing=[]
        for ek in extra_keys:
            value=request.get(ek)
            if not value: missing.append(ek)
            else: cmd.append(str(Path(value).resolve()))
        if missing:
            results.append({"validator_id":validator_id,"result":"FAIL","return_code":2,"artifact_sha256":_sha256(artifact_path),"error":"missing_required_argument:"+",".join(missing)})
            continue
        proc=subprocess.run(cmd,cwd=str(ROOT),text=True,capture_output=True)
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        log_path=logs_dir/f"{key.replace('.','_')}__{validator_id}__{stamp}.json"
        record={"validator_id":validator_id,"command":cmd,"return_code":proc.returncode,"stdout":proc.stdout,"stderr":proc.stderr,"artifact_sha256":_sha256(artifact_path),"result":"PASS" if proc.returncode==0 else "FAIL"}
        log_path.write_text(json.dumps(record,indent=2,ensure_ascii=False)+"\n",encoding='utf-8')
        record["log_path"]=str(log_path)
        results.append(record)
    return {"required_validator_ids":required_ids,"validator_results":results}

REQUIRED_APPROVALS = {
    "approval.passport",
    "approval.jira",
    "approval.qa",
    "approval.automation",
}

def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).lower()
    text = re.sub(r"[`*_#:/\\()\[\]{}.,;!?\"']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_scenario(run_id: str) -> dict[str, Any]:
    key = (ROOT / "private" / "OPERATOR_KEY.txt").read_bytes().strip()
    token = (ROOT / "private" / "scenarios" / f"{run_id}.enc").read_bytes()
    return json.loads(Fernet(key).decrypt(token).decode("utf-8"))

def default_state(run_id: str, scenario: dict[str, Any]) -> dict[str, Any]:
    return {
        "run_id": run_id,
        "scenario_name": scenario["name"],
        "started": False,
        "asked_intents": [],
        "interaction_count": 0,
        "responses": [],
        "approvals": [],
        "approval_receipts": {},
        "validation_receipts": {},
        "invalidated_approvals": [],
        "artifact_versions": {},
        "artifact_hashes": {},
        "cross_artifact_gate": "not_run",
        "package_gate": "not_run",
        "regeneration_required": [],
        "correction_registry": [],
        "blocked_successors": [],
        "terminal_recompute_required": False,
        "presented_versions": {},
        "correction_issued": False,
        "correction_acknowledged": False,
        "withdrawals_issued": [],
        "complete": False,
        "terminal": None,
    }

def load_state(path: Path, run_id: str, scenario: dict[str, Any]) -> dict[str, Any]:
    if path.exists():
        state = json.loads(path.read_text(encoding="utf-8"))
        if state.get("run_id") != run_id:
            raise ValueError("state file belongs to another run")
        return state
    return default_state(run_id, scenario)

def save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def score_intents(question: str) -> list[tuple[str, float]]:
    q = normalize(question)
    q_tokens = set(q.split())
    scored: list[tuple[str, float]] = []
    for intent, patterns in INTENT_PATTERNS.items():
        best = 0.0
        for pattern in patterns:
            p = normalize(pattern)
            if p in q:
                best = max(best, 1.0)
                continue
            p_tokens = set(p.split())
            if not p_tokens:
                continue
            overlap = len(q_tokens & p_tokens) / len(p_tokens)
            if overlap >= 0.6:
                best = max(best, 0.55 + 0.4 * overlap)
        if best:
            scored.append((intent, round(best, 3)))
    scored.sort(key=lambda x: (-x[1], x[0]))
    return scored

def requested_intents(question: str) -> tuple[list[str], float]:
    q = normalize(question)
    intents: list[str] = []

    def add(intent: str) -> None:
        if intent not in intents:
            intents.append(intent)

    # High-precision semantic cues. These deliberately favor under-answering over
    # leaking several unrelated private facts from one vague phrase.
    if any(x in q for x in ["source collection", "collection name", "where is the source record stored", "where is the source record kept", "where is the record kept", "where is it stored", "which collection"]):
        add("source.collection")
    if any(x in q for x in ["document id", "document identifier", "stable identifier", "locate the same source document", "source record identifier", "same record before and after", "find it again after rollback", "same document before and after"]):
        add("source.document_id")
    if any(x in q for x in ["record key", "business key", "internal record key", "stable identifiers should i use", "which stable identifiers"]):
        add("source.record_key")
    if any(x in q for x in ["item context", "relevant item", "relative to item"]):
        add("source.item_context")
    if any(x in q for x in ["field path", "changed field", "nested field", "which field changes", "exact path"]):
        add("change.field_path")
    if any(x in q for x in ["old value", "previous value", "before value", "value before", "prior value", "what was its prior value", "old and new", "values before and after", "before and after values"]):
        add("change.old_value")
    if any(x in q for x in ["new value", "current value", "after value", "target value", "what value should replace it", "replacement value", "old and new", "values before and after", "before and after values"]):
        add("change.new_value")
    if any(x in q for x in ["operation status", "change status", "status of the change", "supported status", "operation type"]):
        add("change.operation_status")
    if any(x in q for x in ["change id", "change identifier", "unique change", "source change id"]):
        add("change.change_id")
    if any(x in q for x in ["occurred at", "occurrence time", "when did the change occur", "change time", "timestamp"]):
        add("change.occurred_at")
    if any(x in q for x in ["event type", "derived event type", "event identifier", "canonical event"]):
        add("event.type")
    if any(x in q for x in ["display name", "event label", "display text", "human readable name", "human facing label", "label should the resulting event use"]):
        add("event.display_name")
    if any(x in q for x in ["values object", "output keys", "values keys", "output shape"]):
        add("event.values_shape")
    if any(x in q for x in ["event date", "date mapping", "timestamp mapping"]):
        add("event.date_mapping")
    if any(x in q for x in ["deduplicate", "deduplication", "duplicate key", "duplicate behavior", "same change twice", "duplicates", "duplicate rules"]):
        add("rule.deduplication")
    if any(x in q for x in ["creation rule", "when create", "when should the event be created", "trigger conditions", "meaningful change", "meaningful creation"]):
        add("rule.creation")
    if any(x in q for x in ["no op", "no-op", "when should no event", "equal values", "unrelated field", "unsupported status", "skip behavior"]):
        add("rule.no_op")
    if any(x in q for x in ["missing data", "mandatory data", "what blocks", "hard stop", "required fields", "unavailable identifier"]):
        add("rule.missing_data")
    if any(x in q for x in ["normalization", "normalize", "trim", "case", "empty string", "whitespace"]):
        add("rule.normalization")
    if any(x in q for x in ["implementation module", "code available", "modify code", "implementation mode", "instructions only", "repository available"]):
        add("implementation.mode")
    if any(x in q for x in ["qa reference", "test data", "reference data", "manual qa data", "qa data", "expectations for qa data"]):
        add("qa.reference_data")
    if any(x in q for x in ["automation status", "runner compatibility", "live run", "automation execution", "automation ready"]):
        add("automation.status")
    if any(x in q for x in ["open questions", "what remains", "what is still missing", "anything unresolved", "remaining questions"]):
        add("analysis.open_questions")
    if any(x in q for x in ["which branch", "selected branch", "where should we begin", "start the process"]):
        add("process.branch")
    if any(x in q for x in ["business purpose", "business meaning", "why is this needed", "desired outcome"]):
        add("business.purpose")

    if intents:
        return intents[:8], 0.98

    # Fallback to conservative pattern scoring for uncommon paraphrases.
    scored = score_intents(question)
    if not scored:
        return [], 0.0
    best_intent, best_score = scored[0]
    if best_score < 0.85:
        return [], best_score
    return [best_intent], best_score

def fact_response(scenario: dict[str, Any], state: dict[str, Any], intent: str) -> dict[str, Any]:
    facts = scenario.get("facts", {})
    entry = facts.get(intent)
    if entry is None:
        return {
            "intent": intent,
            "status": "outside_scope",
            "text": "I do not have confirmed information for that item in this scenario.",
        }

    # Scenario-specific revision chains.
    revisions = entry.get("revisions", [])
    asked_count = state["asked_intents"].count(intent)
    if revisions:
        index = min(asked_count, len(revisions) - 1)
        revision = revisions[index]
        return {
            "intent": intent,
            "status": revision["status"],
            "text": revision["text"],
            "revision_index": index,
        }

    return {
        "intent": intent,
        "status": entry.get("status", "confirmed"),
        "text": entry["text"],
    }

def unresolved_summary(scenario: dict[str, Any], state: dict[str, Any]) -> str:
    unavailable = []
    for intent, entry in scenario.get("facts", {}).items():
        if entry.get("status") in {"unavailable", "missing", "blocked"}:
            unavailable.append(intent)
        elif entry.get("revisions") and entry["revisions"][-1]["status"] in {
            "withdrawn", "unavailable", "missing", "blocked"
        }:
            unavailable.append(intent)
    if unavailable:
        labels = ", ".join(sorted(unavailable))
        return f"The following mandatory or requested information remains unavailable: {labels}."
    return scenario.get("open_questions_text", "There are no additional unresolved analytical questions.")

def handle_start(scenario: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if state["started"]:
        return {
            "status": "already_started",
            "analyst_response": "The scenario has already started. Ask the next natural-language question.",
        }
    state["started"] = True
    return {
        "status": "started",
        "analyst_response": scenario["opening"],
        "driver_guidance": "Ask natural-language questions or present a document for approval.",
    }

def handle_ask(scenario: dict[str, Any], state: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    question = str(request.get("text", "")).strip()
    if not question:
        return {"status": "error", "reason": "empty_question"}

    intents, confidence = requested_intents(question)

    # Broad unresolved-state question.
    qn = normalize(question)
    if any(p in qn for p in ["what remains", "what is still missing", "open questions", "anything unresolved"]):
        answer = unresolved_summary(scenario, state)
        response = {
            "status": "answered",
            "question": question,
            "classified_intents": ["analysis.open_questions"],
            "confidence": 1.0,
            "analyst_response": answer,
        }
        state["asked_intents"].append("analysis.open_questions")
        return response

    if not intents or confidence < 0.55:
        return {
            "status": "clarification_needed",
            "question": question,
            "confidence": confidence,
            "analyst_response": (
                "I am not sure which contract item you are asking about. "
                "Please ask one focused question about the source record, change record, "
                "event mapping, rules, QA data, automation status, or an approval."
            ),
        }

    answers = []
    for intent in intents:
        answers.append(fact_response(scenario, state, intent))
        state["asked_intents"].append(intent)

    text = " ".join(a["text"] for a in answers)

    # Mark correction acknowledgement if the model asks about corrected fields after correction.
    if state.get("correction_issued") and any(
        i in {"change.new_value", "event.display_name"} for i in intents
    ):
        state["correction_acknowledged"] = True

    return {
        "status": "answered",
        "question": question,
        "classified_intents": intents,
        "confidence": confidence,
        "facts": answers,
        "analyst_response": text,
    }

def normalize_artifact_name(name: str) -> str | None:
    n = normalize(name)
    for alias, intent in APPROVAL_ALIASES.items():
        if alias in n:
            return intent
    return None

def _receipt_is_current(state: dict[str, Any], key: str, receipt: dict[str, Any]) -> tuple[bool, str]:
    required = {"artifact", "artifact_version", "artifact_sha256", "required_validator_ids", "validator_results", "validated_at", "generated_by_driver"}
    missing = sorted(required - set(receipt))
    if missing:
        return False, "missing_receipt_fields:" + ",".join(missing)
    if receipt.get("generated_by_driver") is not True:
        return False, "self_asserted_receipt_forbidden"
    expected_ids = [x[0] for x in REQUIRED_VALIDATORS[key]]
    if receipt.get("required_validator_ids") != expected_ids:
        return False, "required_validator_ids_mismatch"
    if receipt.get("artifact") != key:
        return False, "receipt_artifact_mismatch"
    version = str(receipt.get("artifact_version", ""))
    sha = str(receipt.get("artifact_sha256", ""))
    if not version or not sha:
        return False, "receipt_version_or_hash_missing"
    results = receipt.get("validator_results")
    if not isinstance(results, list) or not results:
        return False, "validator_results_missing"
    for item in results:
        if item.get("result") != "PASS" or int(item.get("return_code", 1)) != 0:
            return False, "validator_not_pass"
        if item.get("artifact_sha256") != sha:
            return False, "validator_hash_mismatch"
    regeneration_pending = key in state.get("regeneration_required", [])
    if not regeneration_pending and state.get("artifact_versions", {}).get(key) not in {None, version}:
        return False, "current_version_mismatch"
    if not regeneration_pending and state.get("artifact_hashes", {}).get(key) not in {None, sha}:
        return False, "current_hash_mismatch"
    return True, "ok"


ARTIFACT_OWNER_STEPS = {
    "approval.passport": {"generation": "T034", "validation": "T035", "blocked_successors": ["T036", "T037"]},
    "approval.jira": {"generation": "T038", "validation": "T039", "blocked_successors": ["T040", "T041", "T042"]},
    "approval.qa": {"generation": "T044", "validation": "T045", "blocked_successors": ["T046", "T047", "T048"]},
    "approval.automation": {"generation": "T051", "validation": "T052", "blocked_successors": ["T053", "T054", "T055", "T056"]},
}

def _record_correction_required(state: dict[str, Any], key: str, receipt: dict[str, Any], reason: str) -> dict[str, Any]:
    route = ARTIFACT_OWNER_STEPS[key]
    entry = {
        "artifact": key,
        "failed_version": str(receipt.get("artifact_version", "unknown")),
        "failed_sha256": str(receipt.get("artifact_sha256", "")),
        "failed_validator_ids": [
            str(item.get("validator_id", "unknown"))
            for item in receipt.get("validator_results", [])
            if item.get("result") != "PASS" or int(item.get("return_code", 1)) != 0
        ],
        "owner_generation_step": route["generation"],
        "failed_validation_step": route["validation"],
        "required_transition": f'{route["validation"]}->{route["generation"]}',
        "reason": reason,
        "status": "regeneration_required",
    }
    state.setdefault("correction_registry", []).append(entry)
    state["blocked_successors"] = sorted(set(state.get("blocked_successors", [])) | set(route["blocked_successors"]))
    return entry

def _clear_correction_for_current_version(state: dict[str, Any], key: str, version: str, sha: str) -> None:
    for item in state.get("correction_registry", []):
        if item.get("artifact") == key and item.get("status") == "regeneration_required":
            item["status"] = "corrected_and_passed"
            item["corrected_version"] = version
            item["corrected_sha256"] = sha
    route = ARTIFACT_OWNER_STEPS[key]
    remaining = {
        x.get("artifact") for x in state.get("correction_registry", [])
        if x.get("status") == "regeneration_required"
    }
    if key not in remaining:
        state["blocked_successors"] = [
            s for s in state.get("blocked_successors", [])
            if s not in route["blocked_successors"]
        ]

def _pending_corrections(state: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        x for x in state.get("correction_registry", [])
        if x.get("status") == "regeneration_required"
    ]

def handle_validation(state: dict[str, Any], request: dict[str, Any], state_file: Path) -> dict[str, Any]:
    artifact = str(request.get("artifact", "")).strip()
    key = normalize_artifact_name(artifact)
    if key is None:
        return {"status": "error", "reason": "unknown_artifact"}
    if "validation_receipt" in request:
        return {"status":"validation_rejected","reason":"caller_supplied_validation_receipts_forbidden"}
    artifact_path = Path(str(request.get("artifact_path", ""))).resolve()
    if not artifact_path.is_file():
        return {"status":"validation_rejected","reason":"artifact_path_required_and_must_exist"}
    version=str(request.get("version","current"))
    sha=_sha256(artifact_path)
    run=_run_authoritative_validators(key, artifact_path, request, state_file)
    receipt={
        "artifact":key,"artifact_version":version,"artifact_sha256":sha,
        "required_validator_ids":run["required_validator_ids"],
        "validator_results":run["validator_results"],
        "validated_at":datetime.now(timezone.utc).isoformat(),
        "generated_by_driver":True,
    }
    ok, reason = _receipt_is_current(state,key,receipt)
    state["artifact_versions"][key]=version; state["artifact_hashes"][key]=sha
    if not ok:
        state["validation_receipts"].pop(key,None)
        if key in state["approvals"]: state["approvals"].remove(key)
        state["approval_receipts"].pop(key,None)
        if key not in state["invalidated_approvals"]: state["invalidated_approvals"].append(key)
        if key not in state["regeneration_required"]: state["regeneration_required"].append(key)
        correction=_record_correction_required(state,key,receipt,reason)
        state["complete"]=False; state["terminal"]=None; state["terminal_recompute_required"]=True
        state["cross_artifact_gate"]="not_run"; state["package_gate"]="not_run"
        return {"status":"validation_failed","artifact":key,"reason":reason,"validation_receipt":receipt,"required_action":"regenerate_revalidate_reapprove","next_step":correction["owner_generation_step"],"correction_record":correction}
    state["validation_receipts"][key]=receipt
    if key in state["regeneration_required"]: state["regeneration_required"].remove(key)
    _clear_correction_for_current_version(state,key,version,sha)
    return {"status":"validated","artifact":key,"artifact_version":version,"artifact_sha256":sha,"validation_receipt":receipt}


def handle_invalidate(state: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    artifact = str(request.get("artifact", "")).strip()
    key = normalize_artifact_name(artifact)
    if key is None:
        return {"status": "error", "reason": "unknown_artifact"}
    if key in state["approvals"]:
        state["approvals"].remove(key)
    state["approval_receipts"].pop(key, None)
    state["validation_receipts"].pop(key, None)
    if key not in state["invalidated_approvals"]:
        state["invalidated_approvals"].append(key)
    if key not in state["regeneration_required"]:
        state["regeneration_required"].append(key)
    state["complete"] = False
    state["terminal"] = None
    state["terminal_recompute_required"] = True
    state["cross_artifact_gate"] = "not_run"
    state["package_gate"] = "not_run"
    return {"status": "invalidated", "artifact": key, "go_no_go": "no_go", "required_action": "regenerate_revalidate_reapprove"}


def handle_gate(state: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    pending = _pending_corrections(state)
    if pending:
        return {"status": "gate_blocked", "reason": "pending_regeneration", "pending_corrections": pending}
    gate = str(request.get("gate", "")).strip()
    result = str(request.get("result", "")).strip().upper()
    if gate not in {"cross_artifact", "package"} or result not in {"PASS", "FAIL"}:
        return {"status": "error", "reason": "gate_and_PASS_or_FAIL_required"}
    field = "cross_artifact_gate" if gate == "cross_artifact" else "package_gate"
    state[field] = result
    if result == "FAIL":
        state["complete"] = False
        state["terminal"] = None
        state["terminal_recompute_required"] = True
        return {"status": "gate_failed", "gate": gate, "go_no_go": "no_go"}
    return {"status": "gate_passed", "gate": gate}


def handle_present(scenario: dict[str, Any], state: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    pending = _pending_corrections(state)
    if pending:
        return {"status": "not_approved", "reason": "pending_regeneration", "pending_corrections": pending}
    artifact = str(request.get("artifact", "")).strip()
    version = str(request.get("version", "current")).strip()
    summary = str(request.get("summary", "")).strip()
    approval_intent = normalize_artifact_name(artifact)
    if approval_intent is None:
        return {
            "status": "clarification_needed",
            "analyst_response": (
                "Please identify whether this is the passport, Jira task, QA package, "
                "or automation specification."
            ),
        }

    key = approval_intent
    state["presented_versions"][key] = version

    # RUN_04-style late correction is issued on the first passport presentation.
    correction = scenario.get("late_correction")
    if correction and not state["correction_issued"] and key == correction["trigger_on_present"]:
        state["correction_issued"] = True
        return {
            "status": "correction",
            "artifact": artifact,
            "version": version,
            "analyst_response": correction["text"],
            "required_action": (
                "Invalidate affected artifacts and approvals, update the canonical contract, "
                "regenerate, revalidate, and present the regenerated documents again."
            ),
        }

    # Approval may be unavailable on blocked/scenario-exhausted routes.
    approval_policy = scenario.get("approval_policy", "allowed")
    if approval_policy != "allowed":
        return {
            "status": "not_approved",
            "artifact": artifact,
            "analyst_response": scenario.get(
                "approval_denial_text",
                "I cannot approve this document because the mandatory analytical contract is incomplete."
            ),
        }

    if state.get("correction_issued") and not state.get("correction_acknowledged"):
        return {
            "status": "not_approved",
            "artifact": artifact,
            "analyst_response": (
                "The late correction has not yet been reflected in the canonical contract. "
                "Confirm the corrected value and display name, regenerate the affected material, "
                "and present the new version."
            ),
        }

    receipt = request.get("validation_receipt") or state.get("validation_receipts", {}).get(key)
    if not isinstance(receipt, dict):
        return {
            "status": "not_approved",
            "artifact": artifact,
            "reason": "current_validation_receipt_required",
            "analyst_response": "Approval requires a PASS validation receipt bound to the current artifact version and SHA-256.",
        }
    ok, reason = _receipt_is_current(state, key, receipt)
    if not ok:
        return {"status": "not_approved", "artifact": artifact, "reason": reason}
    if version != str(receipt.get("artifact_version")):
        return {"status": "not_approved", "artifact": artifact, "reason": "presented_version_receipt_mismatch"}
    state["validation_receipts"][key] = receipt
    state["artifact_versions"][key] = str(receipt["artifact_version"])
    state["artifact_hashes"][key] = str(receipt["artifact_sha256"])
    approval_receipt = {
        "artifact": key,
        "artifact_version": str(receipt["artifact_version"]),
        "artifact_sha256": str(receipt["artifact_sha256"]),
        "validation_receipt_validated_at": receipt["validated_at"],
        "approval_recorded_at": request.get("approved_at"),
    }
    state["approval_receipts"][key] = approval_receipt
    if key in state["invalidated_approvals"]:
        state["invalidated_approvals"].remove(key)
    if key not in state["approvals"]:
        state["approvals"].append(key)
    label = key.split(".", 1)[1]
    return {
        "status": "approved",
        "artifact": artifact,
        "version": version,
        "artifact_sha256": receipt["artifact_sha256"],
        "analyst_response": f"I approve the validated current {label} document.",
        "approval_recorded": key,
        "approval_receipt": approval_receipt,
        "summary_received": bool(summary),
    }

def determine_terminal(scenario: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    expected = scenario["terminal_policy"]
    if expected == "complete_go":
        pending = _pending_corrections(state)
        if pending:
            return {"status": "not_ready", "go_no_go": "no_go", "reason": "pending_regeneration", "pending_corrections": pending}
        missing_approvals = sorted(REQUIRED_APPROVALS - set(state["approvals"]))
        if missing_approvals:
            return {
                "status": "not_ready",
                "analyst_response": (
                    "The scenario is not ready for finalization. Missing approvals: "
                    + ", ".join(missing_approvals)
                ),
                "missing_approvals": missing_approvals,
            }
        if scenario.get("late_correction") and not state.get("correction_acknowledged"):
            return {
                "status": "not_ready",
                "analyst_response": "The late correction has not been fully acknowledged and propagated.",
            }
        missing_receipts = sorted(REQUIRED_APPROVALS - set(state.get("validation_receipts", {})))
        if missing_receipts:
            return {"status": "not_ready", "go_no_go": "no_go", "reason": "missing_validation_receipts", "missing_validation_receipts": missing_receipts}
        invalid = sorted(set(state.get("invalidated_approvals", [])))
        if invalid or state.get("regeneration_required"):
            return {"status": "not_ready", "go_no_go": "no_go", "reason": "regeneration_or_reapproval_required", "invalidated": invalid, "regeneration_required": sorted(state.get("regeneration_required", []))}
        for key in REQUIRED_APPROVALS:
            vr = state["validation_receipts"].get(key, {})
            ar = state.get("approval_receipts", {}).get(key, {})
            if not ar or ar.get("artifact_sha256") != vr.get("artifact_sha256") or ar.get("artifact_version") != vr.get("artifact_version"):
                return {"status": "not_ready", "go_no_go": "no_go", "reason": "approval_receipt_not_bound_to_current_validation", "artifact": key}
        if state.get("cross_artifact_gate") != "PASS" or state.get("package_gate") != "PASS":
            return {"status": "not_ready", "go_no_go": "no_go", "reason": "final_gates_not_passed", "cross_artifact_gate": state.get("cross_artifact_gate"), "package_gate": state.get("package_gate")}
        state["terminal_recompute_required"] = False
        state["complete"] = True
        state["terminal"] = "T_COMPLETED"
        return {
            "status": "complete",
            "terminal": "T_COMPLETED",
            "go_no_go": "go",
            "analyst_response": (
                "Complete the final canonical package only after your rendered-artifact and "
                "consistency checks confirm that all hard gates pass."
            ),
        }

    if expected == "scenario_exhausted":
        state["complete"] = True
        state["terminal"] = "T_SCENARIO_EXHAUSTED"
        return {
            "status": "complete",
            "terminal": "T_SCENARIO_EXHAUSTED",
            "go_no_go": "no_go",
            "analyst_response": (
                "No additional confirmed source record, relevant field change, or mandatory identifiers "
                "will be provided. End the scenario without creating canonical analytical documents."
            ),
        }

    if expected == "input_blocked":
        state["complete"] = True
        state["terminal"] = "T_INPUT_BLOCKED"
        return {
            "status": "complete",
            "terminal": "T_INPUT_BLOCKED",
            "go_no_go": "no_go",
            "analyst_response": (
                "The required identifiers and occurrence time are unavailable. "
                "Do not invent them and do not create the canonical analytical package."
            ),
        }

    return {"status": "error", "reason": "unknown_terminal_policy"}

def handle_status(scenario: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    return {
        "status": "state",
        "run_id": state["run_id"],
        "started": state["started"],
        "interaction_count": state["interaction_count"],
        "asked_intents": sorted(set(state["asked_intents"])),
        "approvals": sorted(state["approvals"]),
        "validation_receipts": sorted(state.get("validation_receipts", {})),
        "approval_receipts": sorted(state.get("approval_receipts", {})),
        "invalidated_approvals": sorted(state.get("invalidated_approvals", [])),
        "regeneration_required": sorted(state.get("regeneration_required", [])),
        "correction_registry": state.get("correction_registry", []),
        "blocked_successors": sorted(state.get("blocked_successors", [])),
        "cross_artifact_gate": state.get("cross_artifact_gate"),
        "package_gate": state.get("package_gate"),
        "terminal_recompute_required": state.get("terminal_recompute_required"),
        "correction_issued": state["correction_issued"],
        "correction_acknowledged": state["correction_acknowledged"],
        "complete": state["complete"],
        "terminal": state["terminal"],
    }

def process_request(scenario: dict[str, Any], state: dict[str, Any], request: dict[str, Any], state_path: Path) -> dict[str, Any]:
    action = str(request.get("action", "")).strip().lower()
    if state.get("complete") and action not in {"status", "invalidate", "validation", "gate"}:
        return {
            "status": "complete",
            "terminal": state.get("terminal"),
            "analyst_response": "The scenario is already complete.",
        }
    if action == "start":
        return handle_start(scenario, state)
    if action == "ask":
        return handle_ask(scenario, state, request)
    if action == "validation":
        return handle_validation(state, request, state_path)
    if action == "invalidate":
        return handle_invalidate(state, request)
    if action == "gate":
        return handle_gate(state, request)
    if action == "present":
        return handle_present(scenario, state, request)
    if action == "finish":
        return determine_terminal(scenario, state)
    if action == "status":
        return handle_status(scenario, state)
    return {
        "status": "error",
        "reason": "unsupported_action",
        "supported_actions": ["start", "ask", "validation", "present", "invalidate", "gate", "finish", "status"],
    }

def read_request(args: argparse.Namespace) -> dict[str, Any]:
    if args.request:
        return json.loads(args.request)
    if args.request_file:
        return json.loads(Path(args.request_file).read_text(encoding="utf-8"))
    raw = sys.stdin.read().strip()
    if not raw:
        raise ValueError("request JSON is required through --request, --request-file, or stdin")
    return json.loads(raw)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True, choices=sorted(VALID_RUNS))
    ap.add_argument("--state-file")
    ap.add_argument("--request")
    ap.add_argument("--request-file")
    ap.add_argument("--reset", action="store_true")
    args = ap.parse_args()

    scenario = load_scenario(args.run_id)
    state_path = (
        Path(args.state_file)
        if args.state_file
        else ROOT / "results" / f"{args.run_id}_SEMANTIC_DRIVER_STATE.json"
    )
    if args.reset and state_path.exists():
        state_path.unlink()

    state = load_state(state_path, args.run_id, scenario)
    request = read_request(args)
    state["interaction_count"] += 1
    response = process_request(scenario, state, request, state_path)
    state["responses"].append({
        "interaction": state["interaction_count"],
        "request": request,
        "response": response,
    })
    save_state(state_path, state)
    print(json.dumps(response, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
