# YAML spec format

`history-qa-runner` читає YAML-spec із root keys:

```yaml
suite:
  alias: LU_CHANGE_EXAMPLE
  description: "Автоматизована перевірка історичної події"
  status: automation-ready

environment:
  base_url_env: HISTORY_QA_BASE_URL
  mongo_uri_env: HISTORY_QA_MONGO_URI
  mongo_data_database_env: HISTORY_QA_MONGO_DATA_DATABASE
  mongo_history_database_env: HISTORY_QA_MONGO_HISTORY_DATABASE
  client_secret_env: HISTORY_QA_CLIENT_SECRET
  auth_type_env: HISTORY_QA_AUTH_TYPE
  token_env: HISTORY_QA_TOKEN

defaults:
  source_collection: cards
  changes_collection: changes
  events_collection: events
  errors_collection: change_errors
  source_database: dossier
  changes_database: dossier
  errors_database: dossier
  events_database: history
  trigger_history_endpoint: /api/history
  timeout_seconds: 60
  poll_interval_seconds: 2

test_cases:
  - id: QA-TC-01
    title: "..."
    type: positive
    status: automation-ready
```

`environment` є описовим контрактом для людини. Реальні значення беруться тільки з environment variables. HTTP headers не треба описувати в YAML: runner сам додає `Authorization` і `ClientSecret` за `ENVIRONMENT_CONTRACT.md`.

## Статуси TC

Runner виконує тільки TC зі статусом `automation-ready`. Інші TC позначаються як runtime status `skipped`, але їх YAML-declared status зберігається у кроці `declared_status` і окремо рахується у summary.

Приклад для TC зі статусом `automation-blocked`:

```json
{
  "name": "declared_status",
  "status": "skipped",
  "details": {
    "status": "automation-blocked"
  }
}
```

Такі TC не є failed runtime execution, але вони мають відображатися як `declared_blocked` у консольному та HTML summary.

## Змінні TC

Кожний TC може мати початкові змінні:

```yaml
variables:
  ROOT_ID: "c_c204ad07-22d1-11f1-8032-5955027482c1"
  COMPANY_PROFILE_MONGO_ID: "69b83e3aa194013118aa83c7"
  MEMBER_ENTITY_ID: "p_test_history_qa_director"
```

Змінні доступні в `setup`, `action`, `post_action`, `expected_change_absent`, `change_record`, `processing`, `expected_events`, `expected_errors`, `rollback`, `cleanup`.

Підстановка:

```yaml
mongoId: "$MEMBER_MONGO_ID"
name: "prefix-$MEMBER_ENTITY_ID-suffix"
```

Якщо все значення дорівнює `$NAME`, runner підставляє raw value. Якщо `$NAME` є частиною рядка, runner підставляє `str(value)`.

`$CHANGE_ID` автоматично створюється після `change_record.find`. Якщо `change_record.assign` містить `CHANGE_ID: "_id"`, поведінка така сама.

## Workflow TC

Нові необов’язкові секції:

```yaml
setup:
  - ...
post_action:
  - ...
cleanup:
  - ...
variables:
  ...
```

`setup` виконується перед основним `action`. `post_action` виконується після успішного main `action` і перед `change_record`.

`rollback` і `cleanup` виконуються тільки для `automation-ready` TC, які реально почали execution і могли створити side effects. Для `automation-draft`, `automation-blocked`, skipped/non-ready TC, placeholder-blocked TC і `dry-run` finalizers не запускаються.

Порядок виконання:

1. `variables`
2. `preflight_source`, якщо є `source.mongo_id`
3. `setup[]`
4. `source`, якщо є
5. `action`
6. `post_action[]`, якщо є
7. `expected_change_absent`, якщо TC перевіряє no-op / expected-no-change scenario
8. або стандартний ланцюжок: `change_record` → `processing` → `expected_events` / `expected_events_absent`
9. `expected_errors`
11. `rollback`, якщо є
12. `cleanup[]`, якщо є

Після `setup`, `action`, `post_action`, `rollback` і `cleanup` runner може додатково логувати source snapshot-и. Для QA REST endpoint-ів, які публікують повний документ у product queue, старий Mongo `_id` може бути видалений, а замість нього може з’явитися новий row з новим `_id`. Для повторних запусків використовується `source.lookup` + `source.id_policy: replace_allowed`.


## Source lookup і replacement tracking

Для REST endpoint-ів на кшталт `/api/test/product-queue/publish-mongo-patch` зміна може виконуватися не як in-place update. Backend може реконструювати документ, опублікувати його в product queue, після чого старий row у `cards` видаляється, а новий row створюється з новим Mongo `_id`.

Тому `source.mongo_id` не є стабільним ідентифікатором для повторних запусків. Основний контракт для таких TC — знайти актуальний row через `source.lookup` перед кожним запуском і після кожного REST-кроку:

```yaml
source:
  collection: cards
  precheck: true
  id_policy: replace_allowed
  lookup:
    find:
      dms_id: $DMS_ID
      root_id: $ROOT_ID
      type: $TYPE
      sub_type: $SUB_TYPE
      source: $SOURCE
    match:
      item.name: $BENEFICIARY_NAME
      item.type: $BENEFICIARY_TYPE
      item.position: $BENEFICIARY_POSITION
      item.entity_ids:
        contains: $ENTITY_ID
```

Правила:

- Якщо `source.lookup` заданий, runner на старті TC шукає актуальний source row через `lookup.find` і `lookup.match`; `source.mongo_id` не required.
- Якщо знайдено рівно один row, runner встановлює `ORIGINAL_SOURCE_MONGO_ID` і `CURRENT_SOURCE_MONGO_ID`.
- Після REST-кроків runner знову виконує `source.lookup` і оновлює `CURRENT_SOURCE_MONGO_ID`, якщо row був перестворений з новим `_id`.
- Якщо `source.lookup` не заданий, runner працює в legacy/bootstrap mode через `source.mongo_id`.
- `source.replacement` можна використовувати як override для складних випадків; якщо `replacement` відсутній, для replacement використовується `lookup`.
- Якщо lookup/replacement не знайшов row — помилка `source_lookup_not_found` / `source_replacement_not_found`.
- Якщо знайдено більше одного row — помилка `source_lookup_ambiguous` / `source_replacement_ambiguous`.

`lookup.find` має бути широким Mongo query, а `lookup.match` — точним matcher-ом по стабільних `item.*` полях. Це потрібно тому, що в одному `dms_id/root_id/type/sub_type/source` може бути декілька `companyMember`. Не використовуйте в `match` поле, яке змінюється самим TC.

У REST body потрібно писати:

```yaml
body:
  mongoId: $CURRENT_SOURCE_MONGO_ID
```

Для зворотної сумісності runner може переписати top-level `body.mongoId` на `CURRENT_SOURCE_MONGO_ID` і покаже це в report як `runtime_mongo_id_rewrite`, але це страховка, а не рекомендований контракт.

## Step type: `rest`

`rest` step використовується для `setup`, `action`, `post_action`, `processing`, `rollback`, `cleanup`.

```yaml
- type: rest
  method: POST
  endpoint: /api/test/product-queue/publish-mongo-add-row
  expected_status: 200
  optional: false
  body:
    operation: append
    collection: cards
    referenceMongoId: "$COMPANY_PROFILE_MONGO_ID"
  assign:
    RESPONSE_DMS_ID: "dmsId"
```

Поля:

| Поле | Обов’язкове | Опис |
|---|---:|---|
| `type` | ні | За замовчуванням `rest`. |
| `method` | ні | За замовчуванням `POST`. |
| `endpoint` | так | Відносний URL або повний `https://...` URL. Якщо endpoint відносний, runner обирає base URL за phase: data-import для `setup/action/post_action/rollback/cleanup`, create-history для `processing`. |
| `body` | ні | JSON body. |
| `expected_status` | ні | Default: будь-який `2xx`. Може бути число або список чисел. |
| `optional` | ні | Якщо `true`, failure стає warning і не перекриває результат. |
| `assign` | ні | Dotted path-и з response JSON у runtime variables. |

## Step type: `mongo_find`

`mongo_find` шукає документ у Mongo й присвоює значення змінним. Mongo-кроки в runner read-only: вони не виконують insert/update/delete.

```yaml
- type: mongo_find
  collection: cards
  database: dossier   # optional; за замовчуванням cards/changes/change_errors читаються з HISTORY_QA_MONGO_DATA_DATABASE
  find:
    root_id: "$ROOT_ID"
    type: companyMember
    sub_type: EDR
    item.entity_ids: "$MEMBER_ENTITY_ID"
  sort:
    date_modify: -1
  assign:
    MEMBER_MONGO_ID: "_id"
    MEMBER_NAME: "item.name"
  optional: false
```

Поведінка:

1. Підставляє змінні в `collection`, `find`, `sort`, `assign`.
2. Виконує Mongo query.
3. Застосовує `sort`, якщо заданий.
4. Бере перший документ.
5. Кожний `assign` читає dotted path із документа.
6. `_id` перетворюється в string.
7. Якщо документ або assign path не знайдено і `optional: true`, step повертає warning.
8. Якщо `optional` не true, тест падає.

Dotted path підтримує dict/list і list index:

```text
_id
item.name
item.entity_ids
beneficiaryInfo.interests.0.share.minimum
```

## Mongo database routing

Runner підтримує два Mongo database-и для поточного dev layout:

```text
dossier.cards
dossier.changes
dossier.change_errors
history.events
```

Environment variables:

```text
HISTORY_QA_MONGO_DATA_DATABASE=dossier
HISTORY_QA_MONGO_HISTORY_DATABASE=history
```

Backward-compatible single-DB режим лишається доступним через `HISTORY_QA_MONGO_DATABASE`.

У YAML можна перевизначити database на рівні defaults або конкретного block/step:

```yaml
defaults:
  changes_database: dossier
  events_database: history

expected_events:
  - collection: events
    database: history
    find:
      source_change_id: "$CHANGE_ID"
```

## `action`

Старий формат лишається валідним:

```yaml
action:
  method: POST
  endpoint: /api/test/product-queue/publish-mongo-patch
  body:
    operation: append
    collection: cards
    mongoId: "$MEMBER_MONGO_ID"
```

Якщо `type` не вказано, runner вважає `type: rest`.


## `post_action`

`post_action` — optional list of steps, які виконуються після успішного main `action` і перед `change_record` lookup. Використовуй його для `add row` сценаріїв, коли main `action` створює тимчасовий Mongo row, а runner має знайти його `_id` перед cleanup.

```yaml
post_action:
  - type: mongo_find
    collection: cards
    find:
      root_id: "$ROOT_ID"
      type: companyMember
      sub_type: EDR
      item.entity_ids: "$MEMBER_ENTITY_ID"
    sort:
      date_modify: -1
    assign:
      MEMBER_MONGO_ID: "_id"
```

Підтримані step types такі самі, як у `setup` і `cleanup`: `rest`, `mongo_find` та `variable_patch`. Змінні, assigned у `post_action`, доступні в `change_record`, `processing`, `expected_events`, `expected_errors`, `rollback` і `cleanup`.

Якщо main `action` падає, `post_action` не виконується. Якщо non-optional `post_action` step падає, основний сценарій зупиняється, але `cleanup` усе одно виконується у `finally`. Якщо `post_action` step має `optional: true`, failure записується як warning і тест продовжується.

## `change_record`

```yaml
change_record:
  collection: changes
  find:
    data.root_id: "$ROOT_ID"
    data.type: companyMember
    data.sub_type: EDR
    data.status: deleted
  sort:
    date: -1
  assign:
    CHANGE_ID: "_id"
  expect:
    data.status: deleted
```

Runner завжди зберігає `_id` знайденого change record як `CHANGE_ID`.

## `processing`

```yaml
processing:
  type: rest
  method: POST
  endpoint: /api/history
```

Дозволені типи:

| Тип | Опис |
|---|---|
| `rest` | Runner викликає REST endpoint. |
| `none` | Processing не запускається. |
| `external` | Processing виконується зовнішнім job-ом; runner тільки чекає результат. |



### `change_record.expect` helpers

`change_record.expect` supports normal dotted-path equality checks and delta helpers:

```yaml
change_record:
  collection: changes
  find:
    data.root_id: $ROOT_ID
  expect:
    delta_contains_field: name
```

For nested list/object paths, use prefix matching:

```yaml
change_record:
  expect:
    delta_contains_prefix: beneficiaryInfo.interests
```

`delta_contains_prefix` passes when at least one `delta[].field` starts with the configured prefix, for example `beneficiaryInfo.interests[0].share.min`.

## `expected_change_absent`

`expected_change_absent` використовується для no-op / expected-no-change сценаріїв, де правильний результат після REST `action` — відсутність нового `ChangeRecord` із певним `delta.field`.

У такому TC runner не вимагає `$CHANGE_ID`, не запускає `processing` і не вимагає `expected_events` або `expected_events_absent`. TC може завершитися успішно після `action`, якщо новий matching change із забороненим delta field не зʼявився.

```yaml
expected_change_absent:
  database: dossier
  collection: changes
  timeout_seconds: 3
  poll_interval_seconds: 1
  find:
    data.root_id: "$ROOT_ID"
    data.type: "$TYPE"
    data.sub_type: "$SUB_TYPE"
    data.status: modified
  delta_absent_field: contacts.fax
```

Поля:

| Поле | Обов’язкове | Опис |
|---|---:|---|
| `database` / `db` | ні | Mongo database. Якщо не задано, використовується `defaults.changes_database` або routing за collection. |
| `collection` | ні | Mongo collection. За замовчуванням `defaults.changes_collection` або `changes`. |
| `timeout_seconds` | ні | Скільки часу poll-ити після action. |
| `poll_interval_seconds` | ні | Інтервал polling. |
| `find` | так | Базовий Mongo filter для candidate `ChangeRecord`. |
| `delta_absent_field` | ні | Якщо задано, fail тільки якщо новий matching `ChangeRecord` містить це поле в `delta[].field`. Якщо не задано — fail при будь-якому новому matching `ChangeRecord`. |
| `sort` | ні | За замовчуванням `{date: -1, _id: -1}`. |
| `limit` | ні | Скільки candidate records перевіряти за один polling iteration. За замовчуванням `50`. |

### Baseline behavior

Перед `action` runner фіксує baseline для `expected_change_absent`:

- UTC timestamp старту перевірки;
- останній matching change `_id`;
- останню matching change `date`, якщо вона є.

Після `action` runner poll-ить тільки records, які вважаються новими після baseline. Для першої реалізації строгий contract такий:

```text
Якщо після baseline знайдено matching ChangeRecord із delta.field == delta_absent_field → failed.
Якщо не знайдено matching ChangeRecord із таким delta.field → passed.
```

Це дозволяє мати широкий `find`, але уточнювати, яку саме зміну не можна допустити.

### Приклад no-op TC

```yaml
- id: AUTO-TC-02
  title: No-op patch факсу не створює LU_CHANGE_FAX
  status: automation-ready
  variables:
    COLLECTION: cards
    ROOT_ID: c_c204ad07-22d1-11f1-8032-5955027482c1
    DMS_ID: UACA409857303
    TYPE: companyProfile
    SUB_TYPE: EDR

  setup:
    - type: mongo_find
      name: find_current_source_row
      database: dossier
      collection: cards
      find:
        root_id: "$ROOT_ID"
        dms_id: "$DMS_ID"
        type: "$TYPE"
        sub_type: "$SUB_TYPE"
      assign:
        CURRENT_SOURCE_MONGO_ID: _id
        CURRENT_ITEM: item
        OLD_FAX: item.contacts.fax

    - type: variable_patch
      name: build_noop_item
      source_variable: CURRENT_ITEM
      assign_variable: MODIFIED_ITEM
      operations:
        - path: contacts.fax
          value: "$OLD_FAX"

  action:
    type: rest
    method: POST
    endpoint: /api/test/product-queue/publish-mongo-modify
    body:
      collection: "$COLLECTION"
      mongoId: "$CURRENT_SOURCE_MONGO_ID"
      operation: append
      preview: false
      gzip: true
      item: "$MODIFIED_ITEM"

  expected_change_absent:
    database: dossier
    collection: changes
    timeout_seconds: 3
    poll_interval_seconds: 1
    find:
      data.root_id: "$ROOT_ID"
      data.type: "$TYPE"
      data.sub_type: "$SUB_TYPE"
      data.status: modified
    delta_absent_field: contacts.fax
```

У report для passed case step має `matching_change_found: false`; для failed case містить `found_change_snapshot`, `delta_fields`, baseline і query.

## `expected_events`

```yaml
expected_events:
  - collection: events
    find:
      root_id: "$ROOT_ID"
      source_change_id: "$CHANGE_ID"
      item.alias: LU_REMOVE_OFFICER
    expect:
      item.values.old#name: "$MEMBER_NAME"
```

`collection` необов’язковий; default — `defaults.events_collection` або `events`.

## `expected_events_absent`

```yaml
expected_events_absent:
  - find:
      root_id: "$ROOT_ID"
      source_change_id: "$CHANGE_ID"
      item.alias: LU_ADD_OFFICER
```

## `expected_errors`

Відсутність помилок для поточного change:

```yaml
expected_errors:
  none_for_change: true
```

Очікувана помилка:

```yaml
expected_errors:
  expected:
    - collection: change_errors
      find:
        originalChangeId: "$CHANGE_ID"
      expect:
        errorType: PAYLOAD_PARSE_ERROR
```

## Rollback і cleanup

`rollback` збережений для backward compatibility і виконується перед `cleanup`.

```yaml
rollback:
  type: rest
  method: POST
  endpoint: /api/test/product-queue/publish-mongo-patch
  body:
    operation: append
    collection: cards
    mongoId: "$MONGO_ID"
    operations:
      - path: exampleField
        value: "$OLD_VALUE"
```

`cleanup` прибирає тимчасові rows:

```yaml
cleanup:
  - type: rest
    method: POST
    endpoint: /internal/api/test/product-queue/publish-mongo-delete
    optional: true
    body:
      operation: append
      collection: cards
      mongoId: "$MEMBER_MONGO_ID"
      preview: false
      gzip: true
```

Якщо optional cleanup падає, основний результат не змінюється, але warning потрапляє в report.

Safety rule: `rollback` і `cleanup` не виконуються для TC, які були пропущені або заблоковані до старту реального execution: `status != automation-ready`, required placeholders, validation-only / `dry-run`. Якщо execution почався і після цього впав `post_action`, `change_record`, `processing` або `expected_events`, cleanup все одно виконується.

## Dry-run

`--dry-run` не виконує REST/Mongo. Він перевіряє:

- синтаксис `setup` / `post_action` / `cleanup`;
- required поля `rest` і `mongo_find`;
- структуру `assign`;
- unresolved variables;
- placeholders `<...>`.

Dry-run не блокує змінні, які будуть assigned у попередніх фазах: `setup[*].assign` для `action`, `action.assign` для `post_action`, `post_action[*].assign` для `expected_change_absent`, `change_record` і `cleanup`, `change_record.assign` / `$CHANGE_ID` для `processing`, `expected_events`, `expected_errors`, `rollback` і `cleanup`.

Dry-run не вважає змінні з `cleanup.assign` доступними для попередніх фаз.


## Console progress

The runner prints progress by default. Set `HISTORY_QA_PROGRESS=false` to silence console progress while keeping JSON/HTML reports.


## REST base URL routing

Runner підтримує split backend configuration:

```env
HISTORY_QA_DATA_IMPORT_BASE_URL=https://api-in-dev.ligazakon.net/compliance/data-import/v1.1
HISTORY_QA_HISTORY_BASE_URL=https://api-in-dev.ligazakon.net/compliance/create-history/v1.1
```

Default routing:

| Phase | Base URL |
|---|---|
| `setup`, `action`, `post_action`, `rollback`, `cleanup` REST | `HISTORY_QA_DATA_IMPORT_BASE_URL` або fallback `HISTORY_QA_BASE_URL` |
| `processing` REST | `HISTORY_QA_HISTORY_BASE_URL` або fallback `HISTORY_QA_BASE_URL` |

Для окремого REST block можна явно задати:

```yaml
base_url_env: HISTORY_QA_HISTORY_BASE_URL
```

або:

```yaml
service: history
```

Зазвичай це не потрібно: для `processing` runner автоматично використовує history base URL.

## Step type: `variable_patch`

`variable_patch` будує нове JSON-like значення на основі runtime variable. Step бере значення зі змінної, робить `deep copy`, застосовує одну або кілька `set`-операцій по dotted path і записує результат у нову runtime variable.

Типовий сценарій: знайти актуальний replaceable source row через `mongo_find`, взяти повний `item`, змінити вкладене поле в копії `item` і передати повний змінений `item` у `/api/test/product-queue/publish-mongo-modify`.

### Поля

| Поле | Обов’язкове | Опис |
|---|---:|---|
| `type` | так | Має бути `variable_patch`. |
| `name` | ні | Людська назва кроку для читабельності spec-а. |
| `source_variable` | так | Назва runtime variable, з якої береться source JSON-like value. |
| `assign_variable` | так | Назва runtime variable, у яку записується patched copy. |
| `operations` | так | Non-empty list set-операцій. |
| `create_missing` | ні | `false` за замовчуванням. Якщо `true`, дозволяє створювати missing dict keys, але не list indexes. |

Кожна operation має поля:

| Поле | Обов’язкове | Опис |
|---|---:|---|
| `path` | так | Dotted path для зміни. |
| `value` | так | Нове значення. Може містити `$VARIABLE`. |

### Path format

Path format такий самий, як у `dotted_get`:

- dict key через `.`;
- list index як numeric segment.

Приклад:

```yaml
- type: variable_patch
  name: build_modified_item
  source_variable: CURRENT_ITEM
  assign_variable: MODIFIED_ITEM
  operations:
    - path: beneficiaryInfo.interests.0.share.min
      value: "$NEW_SHARE_MIN"
```

Цей path змінює реальний елемент масиву `interests[0]`, якщо `CURRENT_ITEM` має структуру:

```json
{
  "beneficiaryInfo": {
    "interests": [
      {
        "share": {
          "min": "100"
        }
      }
    ]
  }
}
```

### Помилки

Step падає, якщо:

- `source_variable` не заданий або такої змінної немає;
- `assign_variable` не заданий;
- `operations` відсутній або порожній;
- operation не має `path` або `value`;
- `path` порожній;
- path очікує dict/list, але бачить scalar;
- dict key відсутній і `create_missing: false`;
- list segment не numeric;
- list index out of range.

`create_missing: true` створює тільки missing dict keys. Missing list indexes не створюються автоматично.

### Replaceable source row: `mongo_find → variable_patch → publish-mongo-modify`

```yaml
setup:
  - type: mongo_find
    name: find_current_beneficiary_row
    collection: cards
    find:
      root_id: "$ROOT_ID"
      dms_id: "$DMS_ID"
      type: companyMember
      sub_type: EDR
      source: UACA
      item.memberType: beneficiary
      item.entity_ids: "$BENEFICIARY_ENTITY_ID"
    sort:
      date_modify: -1
      _id: -1
    assign:
      CURRENT_SOURCE_MONGO_ID: "_id"
      CURRENT_ITEM: "item"
      OLD_SHARE_MIN: "item.beneficiaryInfo.interests.0.share.min"

  - type: variable_patch
    name: build_modified_item
    source_variable: CURRENT_ITEM
    assign_variable: MODIFIED_ITEM
    operations:
      - path: beneficiaryInfo.interests.0.share.min
        value: "$NEW_SHARE_MIN"

action:
  type: rest
  method: POST
  endpoint: /api/test/product-queue/publish-mongo-modify
  body:
    collection: cards
    mongoId: "$CURRENT_SOURCE_MONGO_ID"
    preview: false
    gzip: true
    item: "$MODIFIED_ITEM"
```

Rollback через повний `item`:

```yaml
rollback:
  - type: variable_patch
    name: build_rollback_item
    source_variable: MODIFIED_ITEM
    assign_variable: ROLLBACK_ITEM
    operations:
      - path: beneficiaryInfo.interests.0.share.min
        value: "$OLD_SHARE_MIN"

  - type: rest
    name: rollback_modified_item
    method: POST
    endpoint: /api/test/product-queue/publish-mongo-modify
    body:
      collection: cards
      mongoId: "$CURRENT_SOURCE_MONGO_ID"
      preview: false
      gzip: true
      item: "$ROLLBACK_ITEM"
```

Dry-run враховує `variable_patch.assign_variable` як assigned variable для наступних кроків. `source_variable` має бути відомою змінною до цього step-а.
