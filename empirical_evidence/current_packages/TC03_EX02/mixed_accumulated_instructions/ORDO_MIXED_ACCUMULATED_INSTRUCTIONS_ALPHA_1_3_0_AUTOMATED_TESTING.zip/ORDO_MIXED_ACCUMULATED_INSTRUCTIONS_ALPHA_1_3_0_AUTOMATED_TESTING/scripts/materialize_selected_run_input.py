#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from cryptography.fernet import Fernet
import argparse, json, yaml

ROOT = Path(__file__).resolve().parents[1]
VALID_RUNS = {"RUN_01","RUN_02","RUN_03","RUN_04","RUN_05"}

def scenario(run_id):
    key=(ROOT/'private/OPERATOR_KEY.txt').read_bytes().strip()
    token=(ROOT/'private/scenarios'/f'{run_id}.enc').read_bytes()
    return json.loads(Fernet(key).decrypt(token).decode('utf-8'))

def value_from_text(text, prefix=None):
    t=text.strip().rstrip('.')
    if prefix and t.lower().startswith(prefix.lower()):
        t=t[len(prefix):].strip()
    return t

def first_fact(sc, key):
    e=sc.get('facts',{}).get(key)
    if not e: return {'status':'missing','text':None}
    if e.get('revisions'):
        r=e['revisions'][0]
        return {'status':r.get('status','confirmed'),'text':r.get('text')}
    return {'status':e.get('status','confirmed'),'text':e.get('text')}

def parse(sc, key, default=None):
    f=first_fact(sc,key); text=f.get('text') or ''
    if f['status'] not in {'confirmed','corrected'}: return {'status':f['status'],'value':None,'evidence':text}
    patterns={
      'source.collection': r'(?:collection is)\s+([^\.]+)',
      'source.document_id': r'(?:identifier is)\s+([^\.]+)',
      'source.record_key': r'(?:key is)\s+([^\.]+)',
      'source.item_context': r'(?:context is)\s+([^\.]+)',
      'change.field_path': r'(?:path is)\s+([^\.]+(?:\.[^\.]+)?)',
      'change.old_value': r'(?:value is)\s+([^\.]+)',
      'change.new_value': r'(?:value is)\s+([^\.]+)',
      'change.operation_status': r'(?:status is)\s+([^\.]+)',
      'change.change_id': r'(?:identifier is)\s+([^\.]+)',
      'change.occurred_at': r'(?:at)\s+([^\.]+Z)',
      'event.type': r'(?:type is)\s+([^\.]+)',
      'event.display_name': r'(?:display name)\s+([^\.]+)',
    }
    import re
    m=re.search(patterns.get(key,r'$^'), text, re.I)
    v=m.group(1).strip() if m else default
    return {'status':f['status'],'value':v,'evidence':text}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--run-id',required=True,choices=sorted(VALID_RUNS)); ap.add_argument('--output',default='runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml'); args=ap.parse_args()
    sc=scenario(args.run_id)
    get=lambda k,d=None: parse(sc,k,d)
    vals={k:get(k) for k in ['source.collection','source.document_id','source.record_key','source.item_context','change.field_path','change.old_value','change.new_value','change.operation_status','change.change_id','change.occurred_at','event.type','event.display_name']}
    def vv(k): return vals[k]['value']
    facts={k:{'status':first_fact(sc,k)['status'],'evidence':first_fact(sc,k)['text']} for k in sc.get('facts',{})}
    positive=sc.get('terminal_policy')=='complete_go'
    business={
      'rule_id': 'RULE_PROCESSING_STATE_CHANGED' if positive else None,
      'event_type': vv('event.type'),
      'event_display_name': vv('event.display_name'),
      'source_database_type':'mongodb',
      'source_collection':vv('source.collection'),
      'source_document_id':vv('source.document_id'),
      'record_key':vv('source.record_key'),
      'item_context':vv('source.item_context'),
      'field_path':vv('change.field_path'),
      'operation':vv('change.operation_status'),
      'change_id':vv('change.change_id'),
      'occurred_at':vv('change.occurred_at'),
      'old_value':vv('change.old_value'),
      'new_value':vv('change.new_value'),
      'normalization': first_fact(sc,'rule.normalization').get('text'),
      'payload_empty_fallback':'-',
      'duplicate_policy':'reject_same_change_id_and_event_type',
      'missing_data_policy':first_fact(sc,'rule.missing_data').get('text'),
      'implementation_module_available':False,
    }
    fixtures={
      'source_fixture': {
        'collection': business['source_collection'], 'document_id':business['source_document_id'], 'record_key':business['record_key'],
        'field_path':business['field_path'], 'initial_value':business['old_value']},
      'change_fixture': {
        'documentId':business['source_document_id'],'recordKey':business['record_key'],'operationStatus':business['operation'],
        'fieldPath':business['field_path'],'oldValue':business['old_value'],'newValue':business['new_value'],
        'changeId':business['change_id'],'occurredAt':business['occurred_at']},
      'expected_event': {'event_type':business['event_type'],'event_date':business['occurred_at'],'record_key':business['record_key'],'field_path':business['field_path'],'old_value':business['old_value'],'new_value':business['new_value'],'rule_id':business['rule_id']},
      'expected_counts': {'change_records':1 if positive else None,'events':1 if positive else None,'errors':0 if positive else None}
    }
    doc={
      'schema_version':'ordo.database_change.selected_run_input.v3','run_id':args.run_id,'scenario':sc.get('name'),
      'status':'ready' if positive else 'terminal_input_state','terminal_policy':sc.get('terminal_policy'),
      'business_contract':business,'exact_fixtures':fixtures,
      'request_schemas':{
        'source_mutation':{'method':'POST','path':'/api/test/database-change/publish','body_fields':['documentId','recordKey','operationStatus','fieldPath','oldValue','newValue','changeId','occurredAt']},
        'processor_invocation':{'method':'POST','path':'/api/database-change/process','body_fields':['changeId','ruleId']}
      },
      'runner_contract':{'path':'contracts/DATABASE_CHANGE_AUTOMATION_RUNNER_CONTRACT.yaml','runner_type':'declarative_database_change_runner','live_execution_claim_allowed':False},
      'operational_contract':'contracts/DATABASE_CHANGE_OPERATIONAL_QA_CONTRACT.yaml',
      'fact_statuses':facts,'driver_evidence_source':f'private/scenarios/{args.run_id}.enc',
      'required_input_sufficiency':{'positive_route':positive,'all_required_exact_bindings_present': positive and all(business.get(k) not in (None,'') for k in ['rule_id','event_type','source_collection','source_document_id','record_key','field_path','operation','change_id','occurred_at','old_value','new_value'])}
    }
    out=ROOT/args.output; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(yaml.safe_dump(doc,sort_keys=False,allow_unicode=True),encoding='utf-8')
    print(json.dumps({'status':'PASS','run_id':args.run_id,'output':str(out if out.is_absolute() else out.relative_to(ROOT)),'positive_route':positive,'all_required_exact_bindings_present':doc['required_input_sufficiency']['all_required_exact_bindings_present']},indent=2))
if __name__=='__main__': main()
