# Mixed Accumulated Compiler Profile v1.2

## Transformation objective

Transform YAML Playbook Alpha 1.17.0 into one cumulative analyst-facing corpus while preserving behavioral semantics and removing the formal ordered-step presentation.

## Rules

1. Source lock is immutable and identified by SHA-256 `78d5887ba5f655ee61df3a16ec3893e6dcd1d2a3aa26cf3bddc798acc004c6c8`.
2. Every YAML semantic unit must appear exactly once in the provenance mapping.
3. Model-visible text must not expose a numbered 126-position runtime, explicit `next` node graph, transition table, or state-machine reconstruction.
4. Questions and actions become accumulated working instructions grouped by analyst concern rather than source order.
5. Branch outcomes, state effects, hard stops, correction rules and artifact gates remain visible in natural working language.
6. Exact contracts, templates and validators remain separate authoritative support files.
7. Driver interaction is semantic-adaptive; the Driver, not the model, executes validators and creates receipts.
8. No improvements may be imported from another variant except those already present in the declared YAML source or common benchmark package.

## Declared representation difference

The release preserves required behavior but intentionally removes fixed position IDs and execution order from the model-visible corpus. This is the controlled variable being benchmarked.


Alpha 1.3.0 profile: preserve temporal asymmetry, keep early documents less mature, add local correction layers, and move benchmark/run/evaluator control out of the model-visible analyst corpus.
