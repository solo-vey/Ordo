# Типи представлення playbook для benchmark-порівняння

## YAML Playbook
Максимально структурований і технічний як щодо даних, так і щодо процесу. Містить формальні стани, переходи, умови, gates, mutations і machine-readable contracts.

## Structured Instructions
Процес залишається структурованим, але описується переважно текстово й без YAML-shaped control structures. Дані, класи, атрибути, шаблони, validator IDs і contracts залишаються технічно точними.

## Mixed Accumulated Instructions
Той самий цільовий процес подається як історично накопичений робочий корпус аналітика. У ньому є quick starts, guides, templates, QA notes, incident fixes, operational reminders, ранні спрощення та пізні уточнення. Корпус не розкриває структуроване походження й не пояснює свою історичну стилізацію виконавцю.

## Domain Adapted All-in-One
Майже оригінальні інструкції аналітика, адаптовані шляхом прибирання доменної специфіки. Це природний reference corpus, а не продукт формальної трансформації process model.

## Загальний принцип benchmark
Усі представлення повинні реалізовувати однакову функціональну поведінку, але відрізнятися способом подачі процесу. Оцінюється не лише semantic coverage, а й те, як форма інструкцій впливає на виконання, документи, correction behavior і terminal decisions.

## Mixed Accumulated Instructions — temporal layering clarification (Alpha 1.3.0)

The analyst corpus and the benchmark/control layer are separate artifacts. Blind-run enumeration, evaluator instructions, route authorization, self-scoring restrictions, exact benchmark-only artifact counts, provenance, and generation methodology belong in launch prompts, Driver/package contracts, validators, or evidence governance—not in the accumulated analyst corpus.

The corpus preserves temporal asymmetry. Early documents retain simpler terminology and older practices; later QA notes and correction memos explain why those practices changed. Late truth must not be globally backported into every early section. Repeated rules should differ by function rather than repeat an identical compiled block.
