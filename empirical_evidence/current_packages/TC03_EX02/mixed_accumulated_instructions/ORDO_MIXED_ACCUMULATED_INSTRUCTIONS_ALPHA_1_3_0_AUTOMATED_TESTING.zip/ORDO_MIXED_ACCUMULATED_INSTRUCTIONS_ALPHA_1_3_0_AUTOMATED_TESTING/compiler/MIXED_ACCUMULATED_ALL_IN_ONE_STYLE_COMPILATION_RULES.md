# Правила формування Mixed Accumulated Instructions

## Призначення

Mixed Accumulated Instructions — це представлення процесу у вигляді реалістичного робочого корпусу аналітика. Воно зберігає функціональну поведінку детермінованого playbook, але для виконавця виглядає як документація, яку команда накопичувала та уточнювала протягом тривалого часу.

Фінальний виконавчий корпус розміщується в одному файлі `model_input/MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md`. Усередині дозволені межі умовних робочих документів `# FILE: ...`, але виконавець отримує один накопичений файл.

## Головна відмінність від інших представлень

- **YAML Playbook** формалізує дані та процес машинними структурами.
- **Structured Instructions** подають процес послідовно й текстово, зберігаючи технічну точність даних, контрактів і шаблонів.
- **Mixed Accumulated Instructions** відтворюють той самий процес як історично сформований набір робочих матеріалів: quick start, guides, templates, QA notes, incident corrections, operational reminders і пізні уточнення.
- **Domain Adapted All-in-One** походить від майже оригінальних інструкцій аналітика після усунення доменної специфіки.

## Обов’язкові правила побудови

1. **Не розкривати походження корпусу.** У model-visible файлі не можна згадувати YAML-джерело, compiler, synthetic history, benchmark, evaluator, provenance mapping, controlled redundancy або те, що документ спеціально стилізовано.
2. **Писати як аналітик, а не як compiler.** Спочатку сформувати просту бізнес-версію процесу, потім накопичувально додавати технічні та QA-уточнення як реакцію на правдоподібні помилки.
3. **Не показувати машинну модель процесу.** Заборонені повна transition table, state-machine registry, формальний перелік усіх source nodes, variable dictionary або покрокове відтворення YAML-структури.
4. **Один виконавчий корпус.** Усі критичні model-visible правила мають бути відновлюваними з `MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md`; приховані contracts і validators лише підсилюють виконання.
5. **Історична еволюція.** Корпус формується внутрішніми хвилями: базовий flow → практичні уточнення → QA → automation → incidents → correction/invalidation → late runtime fixes. Ці хвилі не описуються читачу як метод генерації.
6. **Накопичення, а не повне переписування.** Частину ранніх спрощень можна залишити, але пізнє уточнення повинно природно звузити або виправити їх.
7. **Контрольована надлишковість без метапояснення.** Критичні правила повторюються в різних ролях і форматах: workflow, checklist, template note, validation guide, incident memo. Формулювання не копіюються механічно.
8. **Тільки розв’язувані суперечності.** Допускається раннє спрощене правило та пізніше точне уточнення. Не допускаються два рівноправні взаємовиключні terminal rules.
9. **Різні голоси й гранулярність.** Частина розділів формальна, частина практична, частина checklist або коротка correction note. Стиль може трохи відрізнятися, але не перетворюватися на хаос.
10. **Природний порядок.** Quick start і базовий workflow з’являються раніше; templates, QA notes, technical details, troubleshooting та late corrections можуть бути розташовані нерівномірно, як у живій документації.
11. **Технічні деталі вводяться поступово.** Hash/version binding, Driver receipts, invalidation, revalidation, reapproval, duplicate handling та terminal evidence мають виглядати як наслідки практичних проблем.
12. **Критичні інваріанти не губляться.** Preflight failure, fail-closed route, заборона вигадування mandatory facts, Driver-owned validation, current-hash approval, invalidation, regeneration, revalidation, route-specific outputs і заборона mixing RUN повинні бути присутні щонайменше у двох природних формах.
13. **Приклади не є authority.** Fixture або старий recipe не можна переносити в поточний RUN без підтвердження Driver.
14. **Розмір і насиченість.** Орієнтир — 85–115% розміру відповідного Domain Adapted All-in-One corpus. Приблизно 70–85% тексту повинно нести безпосередню користь, 10–20% може повторювати правила в іншому контексті, 5–10% може бути ранніми спрощеннями, пізніше уточненими.
15. **Повернений пакет має бути самодостатнім.** Усі support contracts, на які посилаються артефакти, мають бути включені або однозначно доступні; validation evidence зберігає validator ID, command, return code, stdout/stderr і artifact hash.

## Внутрішній процес формування

1. Витягнути бізнес-мету, ролі, артефакти, mandatory facts, blockers, correction routes і terminal outcomes.
2. Створити базовий quick start та простий happy path без повної технічної формалізації.
3. Уявно прогнати типові сценарії та визначити місця неправильної інтерпретації.
4. Після кожного типового збою додати локальний робочий документ або уточнення, а не переписувати весь корпус.
5. Поступово додати templates, QA recipes, automation notes, validation/approval rules, incident notes і late corrections.
6. Перевірити, що читач може відновити правильну дію без доступу до прихованого джерела.
7. Перевірити, що жоден model-visible фрагмент не пояснює, як корпус був створений.

## Обов’язкові перевірки

### Функціональна повнота

- happy path проходиться;
- blocked, NO_CHANGE і scenario-exhausted routes розрізняються;
- correction, invalidation, revalidation та reapproval відновлювані;
- mandatory artifacts і terminal restrictions зрозумілі;
- Driver-owned validation не можна підмінити narrative PASS.

### Реалістичність корпусу

- є різні типи робочих матеріалів;
- видно локальні реакції на помилки та QA review;
- не весь текст однаково відполірований;
- повтори мають різний контекст;
- ранні спрощення пізніше уточнюються;
- немає механічної структури source playbook.

### Приховування походження

Model-visible corpus не містить:

- пояснення генерації або компіляції;
- згадки про приховане структуроване джерело;
- benchmark/evaluator metadata;
- provenance або source mapping;
- слів про synthetic history чи навмисні повтори;
- підказок, що хаотичність була сконструйована.

### Безпечність виконання

- неможливо легітимно self-approve artifact;
- failed validator не можна переписати як PASS;
- stale approval не переживає зміну artifact;
- після mandatory preflight failure не створюються canonical artifacts;
- unavailable facts і capabilities не вигадуються;
- різні RUN не змішуються.


## Temporal layering and control-layer separation — mandatory from Alpha 1.3.0

### 1. Separate the analyst corpus from benchmark control

The accumulated analyst corpus must contain working knowledge, examples, templates, QA notes, corrections, and operational lessons that could naturally belong to a real team.

The following belong outside the corpus, in launch prompts, Driver contracts, package policies, or validators:

- blind-run enumeration;
- benchmark notices;
- exact benchmark-only artifact counts;
- route authorization vocabulary;
- evaluator instructions;
- self-scoring restrictions;
- provenance and compiler explanations;
- package-generation rationale.

A process invariant may still appear in the corpus when it is a normal operational practice, such as stale approval invalidation or validator evidence. It must be written as a lesson or working rule, not as benchmark orchestration.

### 2. Do not backport late knowledge into early documents

Build genuine temporal asymmetry:

- early quick-start material may use broader terms and ask for information that later became standardized;
- middle guides explain recurring errors;
- later notes narrow or replace earlier practice;
- old examples may remain as historical structure references;
- critical late corrections must identify the old practice they supersede.

Do not globally normalize all old sections after a late correction. The final corpus should preserve visible evolution.

### 3. Preserve local history, not a global changelog

Use local markers such as:

- after QA review;
- this was often missed;
- earlier packages used a placeholder;
- after a stale approval incident;
- for new cases use the following rule;
- the old example remains only as a structure reference.

Do not add a clean version history or a synthetic timeline.

### 4. Vary repeated rules by function

A critical rule may appear in multiple places, but each appearance should serve a different purpose:

- architecture explains why;
- workflow explains when;
- QA guide explains how to verify;
- troubleshooting describes a common failure;
- late correction states the new mandatory practice.

Mechanical repetition of an identical paragraph is a compilation defect.

### 5. Avoid global terminology normalization

Allow early terms such as `change type` or “тип зміни” to remain where natural. Introduce the authoritative field, for example `change.status`, in later technical or QA clarification. Do not perform corpus-wide search-and-replace that makes every historical section use the same mature formulation.

### 6. Avoid global precedence notices

Do not place a universal override notice at the top of the corpus. Resolve precedence naturally through local correction notes, current templates, validator behavior, and statements such as “for new cases use this rule.” Benchmark-level precedence remains outside the analyst corpus.

### 7. Required validation evidence

The release validator must confirm:

- no visible benchmark/control notice in the corpus;
- no run enumeration or evaluator vocabulary;
- early and late sections show measurable terminology/practice asymmetry;
- at least three local correction notes exist;
- late notes explicitly supersede or narrow earlier practice;
- exact repeated-block ratio stays below the accepted threshold;
- critical invariants remain executable after control-layer separation.
