# ORDO Mixed Accumulated Instructions Alpha 1.3.0

This package is a YAML-derived `PV-HISTORICAL` benchmark variant for the database-change artifact-set test case.

The model reads one cumulative mixed instruction corpus rather than a numbered playbook. Runtime interaction is semantic-adaptive. The immutable YAML source is retained only for provenance and package validation and is forbidden to the tested model.

## Entry files

- Model-visible corpus: `model_input/MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md`
- Neutral launch prompt: `launch_prompts/START_PROMPT_MIXED_ACCUMULATED_ANY_RUN_ALPHA_1_3_0_NEUTRAL.md`
- Driver: `driver/semantic_analyst_driver.py`
- Package validator: `validation/validate_mixed_accumulated_package.py`

## Preflight

```bash
python validation/validate_mixed_accumulated_package.py .
python validation/validate_driver_analyst_enforcement.py .
```

Source SHA-256: `78d5887ba5f655ee61df3a16ec3893e6dcd1d2a3aa26cf3bddc798acc004c6c8`
