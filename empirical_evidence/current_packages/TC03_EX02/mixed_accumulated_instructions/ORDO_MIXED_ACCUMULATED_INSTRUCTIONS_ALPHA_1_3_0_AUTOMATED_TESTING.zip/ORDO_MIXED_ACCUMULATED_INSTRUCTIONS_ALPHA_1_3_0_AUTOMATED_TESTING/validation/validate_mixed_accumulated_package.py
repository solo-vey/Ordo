#!/usr/bin/env python3
from pathlib import Path
import sys, json, yaml, hashlib, re
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errs=[]
req=['model_input/MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md','source_lock/PLAYBOOK_ALPHA_1_17_0_SOURCE_ONLY.yaml','provenance/SOURCE_TO_ACCUMULATED_MAPPING.json','driver/semantic_analyst_driver.py','launch_prompts/START_PROMPT_MIXED_ACCUMULATED_ANY_RUN_ALPHA_1_3_0_NEUTRAL.md','MODEL_VISIBLE_FILE_POLICY.json']
for p in req:
 if not (root/p).is_file(): errs.append('missing:'+p)
if not errs:
 src=(root/req[1]).read_bytes(); d=yaml.safe_load(src); m=json.loads((root/req[2]).read_text()); c=(root/req[0]).read_text()
 if len(d.get('steps',[]))!=126: errs.append('source_step_count_not_126')
 if m.get('source_step_count')!=126 or len(m.get('entries',[]))!=126: errs.append('mapping_count_not_126')
 if m.get('source_sha256')!=hashlib.sha256(src).hexdigest(): errs.append('source_sha_mismatch')
 ids=[x.get('source_step_id') for x in m.get('entries',[])]
 if len(ids)!=len(set(ids)): errs.append('duplicate_source_steps')
 if re.search(r'^### Position\s+\d+',c,re.M): errs.append('formal_position_list_exposed')
 if '`T001`' in c or 'Required positions: 126' in c: errs.append('structured_runtime_leak')
 if ('self-authored PASS receipts' not in c and 'власним PASS' not in c): errs.append('driver_enforcement_instruction_missing')
 if (root/req[0]).stat().st_size<400000: errs.append('corpus_not_reference_scale')
 if c.count('# FILE:')<8: errs.append('insufficient_pseudo_file_accumulation')
 if '42_VALIDATION_RECEIPTS_AND_REAPPROVAL' not in c: errs.append('late_corrections_missing')
 for phrase in ['source_lock/','reconstructed from','benchmark artifacts','provenance-only','126-position','Transformation and precedence notice']:
  if phrase.lower() in c.lower(): errs.append('origin_disclosure:'+phrase)
print(json.dumps({'status':'PASS' if not errs else 'FAIL','errors':errs,'source_steps':126,'mapping_entries':126,'corpus_bytes':(root/req[0]).stat().st_size if (root/req[0]).exists() else 0},indent=2))
sys.exit(1 if errs else 0)
