#!/usr/bin/env python3
from pathlib import Path
import subprocess, tempfile, json, sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
driver=root/'driver/semantic_analyst_driver.py'
errors=[]
text=driver.read_text()
for token in ['caller_supplied_validation_receipts_forbidden','generated_by_driver','required_validator_ids','capture_output=True','validator_logs']:
    if token not in text: errors.append('MISSING_ENFORCEMENT:'+token)
# malformed Jira must not validate; fabricated receipt must be rejected
with tempfile.TemporaryDirectory() as td:
    td=Path(td); art=td/'jira.md'; art.write_text('# weak jira\n- generic prose\n')
    st=td/'state.json'
    req=td/'req.json'; req.write_text(json.dumps({'action':'validation','artifact':'jira','artifact_path':str(art),'version':'v1'}))
    p=subprocess.run([sys.executable,str(driver),'--run-id','RUN_01','--state-file',str(st),'--request-file',str(req)],cwd=root,text=True,capture_output=True)
    try: out=json.loads(p.stdout)
    except: out={}
    if out.get('status')!='validation_failed': errors.append('MALFORMED_JIRA_NOT_REJECTED:'+p.stdout[-500:])
    req2=td/'req2.json'; req2.write_text(json.dumps({'action':'validation','artifact':'jira','validation_receipt':{'artifact':'approval.jira'}}))
    p2=subprocess.run([sys.executable,str(driver),'--run-id','RUN_01','--state-file',str(st),'--request-file',str(req2)],cwd=root,text=True,capture_output=True)
    try: out2=json.loads(p2.stdout)
    except: out2={}
    if out2.get('reason')!='caller_supplied_validation_receipts_forbidden': errors.append('FABRICATED_RECEIPT_NOT_REJECTED')
print(json.dumps({'validator':'driver_analyst_enforcement_v1','errors':errors,'result':'PASS' if not errors else 'FAIL'},indent=2))
sys.exit(0 if not errors else 1)
