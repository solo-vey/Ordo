#!/usr/bin/env python3
from pathlib import Path
import sys,json,re,hashlib
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
f=root/'model_input/MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md'
errors=[]; metrics={}
if not f.is_file():
    errors.append('CORPUS_MISSING'); text=''
else:
    text=f.read_text(encoding='utf-8',errors='replace')
    lower=text.lower()
    forbidden={
      'VISIBLE_BENCHMARK':'benchmark',
      'VISIBLE_BLIND_RUN':'blind run',
      'VISIBLE_EVALUATOR':'evaluator',
      'VISIBLE_PROVENANCE':'provenance mapping',
      'VISIBLE_COMPILER':'compiler output',
      'VISIBLE_SYNTHETIC':'synthetic historical',
      'VISIBLE_CONTROLLED_REDUNDANCY':'controlled redundancy',
      'VISIBLE_ROUTE_AUTH':'route-authorized',
      'VISIBLE_SELF_SCORE':'self-score',
    }
    for code,phrase in forbidden.items():
        if phrase in lower: errors.append(code)
    if re.search(r'\bRUN_0[1-5]\b',text): errors.append('RUN_ENUMERATION_VISIBLE')
    # Early quick-start must not already contain the mature standard endpoint rule.
    early=text.split('# FILE: 24_QA_PACKAGE_TEMPLATE.md',1)[0]
    late=text.split('# FILE: 39_ENDPOINT_PRACTICE_CORRECTION_AFTER_QA.md',1)[-1] if '# FILE: 39_ENDPOINT_PRACTICE_CORRECTION_AFTER_QA.md' in text else ''
    if '/internal/api/test/product-queue/publish-source-record-patch' in early[:12000]: errors.append('LATE_ENDPOINT_RULE_BACKPORTED_TO_QUICK_START')
    if 'endpoint часто просили щоразу' not in late: errors.append('ENDPOINT_EVOLUTION_NOTE_MISSING')
    if 'change.status' not in late: errors.append('LATE_AUTHORITATIVE_TERMINOLOGY_MISSING')
    if 'старе погодження' not in late and 'попереднє погодження' not in late: errors.append('STALE_APPROVAL_HISTORY_MISSING')
    correction_files=len(re.findall(r'^# FILE: (?:39_|40_|41_|42_|OPERATIONS_NOTE)',text,re.M))
    metrics['local_correction_files']=correction_files
    if correction_files<4: errors.append('TOO_FEW_LOCAL_CORRECTION_LAYERS')
    # Detect excessive identical mature endpoint block duplication.
    mature='Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint**'
    count=text.count(mature)
    metrics['identical_mature_endpoint_block_count']=count
    if count>4: errors.append('MECHANICAL_ENDPOINT_BLOCK_REPETITION')
    # Global override notices at the beginning are not allowed.
    intro='\n'.join(text.splitlines()[:80]).lower()
    for phrase in ['takes precedence','має пріоритет','для поточного запуску','current run','старі рецепти не замінюють']:
        if phrase in intro: errors.append('GLOBAL_PRECEDENCE_NOTICE:'+phrase)
print(json.dumps({'validator':'historical_layering_and_control_separation_v1','result':'PASS' if not errors else 'FAIL','errors':errors,'metrics':metrics},ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
