#!/usr/bin/env python3
from pathlib import Path
import sys,json,re
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
f=root/'model_input/MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md'
errors=[]
if not f.is_file(): errors.append('CORPUS_MISSING')
else:
 text=f.read_text(encoding='utf-8',errors='replace')
 lower=text.lower()
 forbidden=[
  ('ORIGIN_SOURCE_LOCK','source_lock/'),
  ('ORIGIN_COMPILER','compiler output'),
  ('ORIGIN_RECONSTRUCTED','reconstructed from'),
  ('ORIGIN_BENCHMARK','benchmark artifacts'),
  ('ORIGIN_PROVENANCE','provenance-only'),
  ('ORIGIN_SYNTHETIC','synthetic historical'),
  ('ORIGIN_CONTROLLED_REDUNDANCY','controlled redundancy'),
  ('ORIGIN_126_POSITION','126-position'),
  ('ORIGIN_TRANSFORMATION_NOTICE','transformation and precedence notice'),
 ]
 for code,phrase in forbidden:
  if phrase in lower: errors.append(code)
 if text.count('# FILE:')<8: errors.append('TOO_FEW_WORKING_DOCUMENT_BOUNDARIES')
 if f.stat().st_size<400000: errors.append('CORPUS_BELOW_REFERENCE_SCALE')
 # Critical invariants need repeated natural coverage.
 checks={
  'DRIVER_VALIDATION':['driver-generated','driver must execute authoritative validators'],
  'NO_SELF_PASS':['self-authored pass','не можна замінити текстовим коментарем'],
  'INVALIDATION':['інваліду','invalidate'],
    'FAIL_CLOSED':['fail-closed','обов’язковий факт недоступний'],
 }
 for code,terms in checks.items():
  count=sum(lower.count(t.lower()) for t in terms)
  if count<2: errors.append('INSUFFICIENT_REPEATED_INVARIANT:'+code)
 # Machine-form process exposure. Domain/config YAML mentions are allowed; source-process disclosure is not.
 if re.search(r'^### Position\s+\d+',text,re.M): errors.append('FORMAL_POSITION_LIST_EXPOSED')
 print(json.dumps({'validator':'historical_corpus_realism_v1','result':'PASS' if not errors else 'FAIL','errors':errors,'corpus_bytes':f.stat().st_size if f.exists() else 0,'pseudo_files':text.count('# FILE:') if f.exists() else 0},indent=2,ensure_ascii=False))
 sys.exit(1 if errors else 0)
