#!/usr/bin/env python3
from pathlib import Path
import subprocess, tempfile, json, yaml, sys, shutil
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required=['rule_id','event_type','source_collection','source_document_id','record_key','field_path','operation','change_id','occurred_at','old_value','new_value']
report={'status':'PASS','runs':{},'checks':[]}
for run in ['RUN_01','RUN_02','RUN_03','RUN_04','RUN_05']:
    with tempfile.TemporaryDirectory() as td:
        out=Path(td)/f'{run}.yaml'
        p=subprocess.run([sys.executable,str(ROOT/'scripts/materialize_selected_run_input.py'),'--run-id',run,'--output',str(out)],cwd=ROOT,text=True,capture_output=True)
        item={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
        if p.returncode!=0 or not out.exists(): report['status']='FAIL'; item['status']='FAIL'; report['runs'][run]=item; continue
        d=yaml.safe_load(out.read_text())
        positive=d.get('terminal_policy')=='complete_go'
        missing=[k for k in required if d.get('business_contract',{}).get(k) in (None,'')]
        item.update({'status':'PASS','positive_route':positive,'missing_required':missing})
        if positive and missing: item['status']='FAIL'; report['status']='FAIL'
        if positive:
            ef=d.get('exact_fixtures',{})
            if not ef.get('source_fixture') or not ef.get('change_fixture') or not ef.get('expected_event'):
                item['status']='FAIL'; report['status']='FAIL'; item['fixture_error']='missing exact fixtures'
            rs=d.get('request_schemas',{})
            if not rs.get('source_mutation') or not rs.get('processor_invocation'):
                item['status']='FAIL'; report['status']='FAIL'; item['request_schema_error']='missing request schemas'
            rp=ROOT/d.get('runner_contract',{}).get('path','')
            if not rp.exists(): item['status']='FAIL'; report['status']='FAIL'; item['runner_contract_error']=str(rp)
        report['runs'][run]=item
# shipped mutable driver state is forbidden
states=list((ROOT/'results').glob('RUN_*_SEMANTIC_DRIVER_STATE.json')) if (ROOT/'results').exists() else []
report['checks'].append({'name':'no_preinitialized_driver_state','status':'PASS' if not states else 'FAIL','files':[str(x.relative_to(ROOT)) for x in states]})
if states: report['status']='FAIL'
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(0 if report['status']=='PASS' else 1)
