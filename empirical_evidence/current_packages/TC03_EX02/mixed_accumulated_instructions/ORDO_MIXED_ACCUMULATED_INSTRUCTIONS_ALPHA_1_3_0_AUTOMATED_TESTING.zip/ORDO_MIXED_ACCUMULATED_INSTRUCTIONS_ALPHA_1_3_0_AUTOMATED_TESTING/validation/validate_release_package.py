#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,zipfile,tempfile,subprocess,sys

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def verify(root):
 errors=[]
 sums=root/'SHA256SUMS.txt'
 if not sums.is_file(): return ['SHA256SUMS_MISSING']
 for line in sums.read_text().splitlines():
  if not line.strip(): continue
  try: exp,rel=line.split('  ',1)
  except ValueError: errors.append('BAD_SUM_LINE:'+line); continue
  p=root/rel
  if not p.is_file(): errors.append('MISSING:'+rel)
  elif sha(p)!=exp: errors.append('HASH_MISMATCH:'+rel)
 req=[
  'model_input/MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md',
  'compiler/MIXED_ACCUMULATED_ALL_IN_ONE_STYLE_COMPILATION_RULES.md',
  'source_lock/PLAYBOOK_ALPHA_1_17_0_SOURCE_ONLY.yaml',
  'provenance/SOURCE_TO_ACCUMULATED_MAPPING.json',
  'driver/semantic_analyst_driver.py',
  'launch_prompts/START_PROMPT_MIXED_ACCUMULATED_ANY_RUN_ALPHA_1_3_0_NEUTRAL.md',
  'MODEL_VISIBLE_FILE_POLICY.json'
 ]
 for rel in req:
  if not (root/rel).is_file(): errors.append('REQUIRED_MISSING:'+rel)
 if not errors:
  for script in ['validation/validate_mixed_accumulated_package.py','validation/validate_historical_corpus_realism.py','validation/validate_historical_layering_and_control_separation.py','validation/validate_driver_analyst_enforcement.py']:
   p=subprocess.run([sys.executable,str(root/script),str(root)],cwd=root,text=True,capture_output=True)
   if p.returncode!=0: errors.append('VALIDATOR_FAIL:'+script+':'+(p.stdout+p.stderr)[-1000:])
 return errors

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('package'); a=ap.parse_args(); z=Path(a.package); errors=[]
 if not zipfile.is_zipfile(z): errors.append('ZIP_INVALID')
 else:
  with tempfile.TemporaryDirectory() as td:
   with zipfile.ZipFile(z) as f:
    bad=f.testzip()
    if bad: errors.append('ZIP_BAD_ENTRY:'+bad)
    f.extractall(td)
   roots=[p for p in Path(td).iterdir() if p.is_dir()]
   if len(roots)!=1: errors.append('ZIP_ROOT_COUNT:'+str(len(roots)))
   else: errors += verify(roots[0])
 print(json.dumps({'validator':'mixed_accumulated_release_package_v1_3','package':str(z),'sha256':sha(z) if z.is_file() else None,'errors':errors,'result':'PASS' if not errors else 'FAIL'},indent=2))
 return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main())
