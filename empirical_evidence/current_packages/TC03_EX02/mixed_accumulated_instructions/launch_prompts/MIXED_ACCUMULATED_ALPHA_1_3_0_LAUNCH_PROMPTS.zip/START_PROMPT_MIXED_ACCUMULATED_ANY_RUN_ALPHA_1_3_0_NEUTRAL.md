# Start Prompt — Analyst Working Instructions Alpha 1.3.0

Execute one isolated run using the supplied package. Set `RUN_ID` to exactly one of `RUN_01`–`RUN_05`.

## Mandatory preflight

From the extracted package root:

```bash
python validation/validate_mixed_accumulated_package.py .
python validation/validate_historical_corpus_realism.py .
python validation/validate_historical_layering_and_control_separation.py .
python validation/validate_driver_analyst_enforcement.py .
python validation/validate_selected_run_input_sufficiency.py .
```

Also verify every entry in `SHA256SUMS.txt`. On any failure, stop with `NO_CHANGE`; do not create canonical business artifacts or approvals.

## Input boundary

1. Read exactly `model_input/MIXED_ACCUMULATED_ANALYST_INSTRUCTIONS.md` as the analyst working instructions.
2. Do not inspect `source_lock/`, `private/`, `provenance/`, `compiler/`, `documentation/`, evaluator material or Driver source.
3. Do not reconstruct a machine-readable playbook, fixed state table, transition graph or complete numbered algorithm.
4. Do not use facts or outputs from another RUN.

## Driver execution

Start with:

```bash
python driver/semantic_analyst_driver.py --run-id <RUN_ID> --request '{"action":"start"}'
```

Use focused natural-language questions and the Driver interfaces. For every artifact, the Driver must run authoritative validators and create the validation receipt. Do not create or edit PASS receipts yourself.

Preserve `confirmed`, `proposed`, `fixture-only`, `withdrawn`, `superseded` and `unavailable` distinctions. Do not invent mandatory facts or unsupported runner capabilities. Apply correction, invalidation, regeneration, revalidation and reapproval when required.

## Output

Return one ZIP named `<RUN_ID>_DATABASE_CHANGE_ARTIFACT_SET_RESULT.zip`. Include complete current-run evidence and only route-authorized artifacts. `SHA256SUMS.txt` must cover package contents without hashing itself. Do not self-score.
