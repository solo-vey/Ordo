# Previous accumulated-instruction package superseded

Alpha 1.2.0 is superseded for the independent accumulated-instructions benchmark because its
model-visible corpus was only about 40 KB and remained too concise and deliberately organized.

Alpha 1.3.0 is the new baseline for this comparison. It does not invalidate the separately
classified prompt-only compilation evidence series.
