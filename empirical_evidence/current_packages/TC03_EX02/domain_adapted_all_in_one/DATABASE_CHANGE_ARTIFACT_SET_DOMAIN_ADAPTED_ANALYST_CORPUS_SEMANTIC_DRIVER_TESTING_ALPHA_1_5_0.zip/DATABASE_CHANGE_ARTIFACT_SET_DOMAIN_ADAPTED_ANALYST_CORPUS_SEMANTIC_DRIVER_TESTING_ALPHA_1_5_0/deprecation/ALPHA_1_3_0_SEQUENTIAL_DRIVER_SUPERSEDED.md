# Alpha 1.3.0 sequential Driver superseded

The Alpha 1.3.0 instruction corpus remains conceptually valid, but its sequential event feeder is
not adequate for a model that determines its own question order.

Use Alpha 1.4.0 with the adaptive semantic analyst simulator for all five accumulated-instruction runs.
