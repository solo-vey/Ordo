# Policy: Adaptive Semantic Driver for Non-Isomorphic Language Instructions

Status: accepted for future testing packages.

## Decision

When a language-instruction corpus does not directly mirror the playbook's steps or transition
order, a sequential event feeder is not an adequate analyst simulator.

Such packages must use an adaptive semantic Driver that:

- receives the tested model's natural-language question;
- classifies the requested contract intent;
- returns only facts allowed by the private scenario;
- supports paraphrases and repeated questions;
- distinguishes confirmed, tentative, withdrawn, superseded, unavailable and irrelevant facts;
- supports late corrections and invalidation;
- issues approvals only when explicitly requested and permitted;
- supports blocked, scenario-exhausted and successful terminal behavior;
- logs question, classified intent, confidence and response;
- does not expose playbook step numbers to the tested model.

## Applicability

Use this method for:

- historically accumulated analyst instructions;
- large all-in-one instruction corpora;
- instructions with repeated, overlapping or non-linear guidance;
- any baseline where the tested model must determine its own question order.

A sequential event Driver remains acceptable only for a test whose protocol intentionally fixes
the event order independently of the model's questions.

## Benchmark validity

The semantic mapping is operator-private. It must not be added as a model-visible table such as
“question X maps to step 7,” because that would leak playbook structure and convert the baseline
back toward prompt-only compilation.

## Evidence boundary

The adaptive Driver evaluates whether the model can recover and execute the process from the
instruction corpus. It should not provide unsolicited facts merely because they are next in a
hidden sequence.
