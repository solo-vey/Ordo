# Style profile for historically accumulated analyst instructions

Operator-only.

The model-visible corpus was rebuilt to reproduce these characteristics:

- all-in-one file assembled from many pseudo-documents;
- overall size comparable to the supplied historical corpus;
- repeated rules in quick starts, process notes, templates, QA guides and checklists;
- late clarifications added after concrete failure patterns;
- technical controls embedded in analytical and document-writing guidance;
- overlapping lifecycle descriptions instead of one canonical sequence;
- long explanations and examples that could be shorter but reflect gradual accumulation;
- local redundancy and uneven granularity;
- no explicit 126-step inventory;
- no analytical/technical step split;
- no state machine or YAML process contract.

The purpose is to test whether the model can reconstruct the intended behavior from a large,
historically accumulated instruction corpus rather than from a clean prompt-only compilation.
