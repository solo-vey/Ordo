# Domain Adaptation Report

Source corpus: `HISTORY_EVENT_ASSISTANT_V25_ALL_IN_ONE.md`
Source bytes: 469604
Adapted bytes: 481987
Source pseudo-files: 40
Adapted pseudo-files: 40

## Method

The package preserves the original all-in-one corpus structure and most prose. Adaptation is
primarily lexical and architectural: historical-event terminology, concrete provider/class names,
aliases, Mongo collections, endpoints and output objects were mapped into the neutral internal
record-change domain. A short precedence notice was added to prevent illustrative legacy recipes
from overriding the fixed benchmark contract supplied by the semantic Driver.

## Driver

The Alpha 1.4 semantic Driver and five encrypted scenarios are reused because their private facts
already use the neutral record-change domain. No playbook step numbers are exposed.
