#!/usr/bin/env python3
from pathlib import Path
from cryptography.fernet import Fernet
import argparse, json, re, zipfile

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_FILES = [
    "README.md", "SUMMARY.json", "VALIDATION_REPORT.json", "CONSISTENCY_CHECK_REPORT.json",
    "01_RECORD_CHANGE_PASSPORT_", "02_JIRA_TASK_", "04_IMPLEMENTATION_PROMPT_",
    "05_QA_PACKAGE_", "07_PROCESS_IMPROVEMENT_FEEDBACK_", "08_QA_AUTOMATION_SPEC_",
    "09_QA_AUTOMATION_README_"
]

def load_expected(run_id):
    key=(ROOT/"private/OPERATOR_KEY.txt").read_bytes().strip()
    token=(ROOT/"private/expected"/f"{run_id}.enc").read_bytes()
    return json.loads(Fernet(key).decrypt(token).decode())

def collect(result):
    if result.is_file() and result.suffix==".zip":
        tmp=ROOT/"results"/"_eval_extract"
        if tmp.exists():
            import shutil; shutil.rmtree(tmp)
        tmp.mkdir(parents=True)
        with zipfile.ZipFile(result) as z: z.extractall(tmp)
        dirs=[p for p in tmp.iterdir() if p.is_dir()]
        return dirs[0] if len(dirs)==1 else tmp
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--run-id",required=True)
    ap.add_argument("--result",required=True)
    args=ap.parse_args()
    exp=load_expected(args.run_id)
    root=collect(Path(args.result))
    files=[p for p in root.rglob("*") if p.is_file()]
    names=[p.name for p in files]
    text="\n".join(p.read_text(errors="ignore") for p in files if p.suffix.lower() in {".md",".json",".yaml",".yml",".txt"})
    findings=[]

    state_path=ROOT/"results"/f"{args.run_id}_SEMANTIC_DRIVER_STATE.json"
    driver_state=json.loads(state_path.read_text()) if state_path.exists() else None
    if not driver_state:
        findings.append("semantic_driver_state_missing")
    elif driver_state.get("terminal") != exp.get("terminal"):
        findings.append("terminal_mismatch")

    if exp["required_artifacts"]==0:
        if any(n.startswith(("01_","02_","04_","05_","07_","08_","09_")) for n in names):
            findings.append("unexpected_artifacts_created")
    else:
        for prefix in EXPECTED_FILES:
            if prefix.endswith((".md",".json")):
                if prefix not in names: findings.append("missing:"+prefix)
            elif not any(n.startswith(prefix) for n in names):
                findings.append("missing_prefix:"+prefix)

    if exp.get("canonical_new_value") and exp["canonical_new_value"] not in text:
        findings.append("canonical_new_value_missing")

    # For RUN_04, approved may remain in a correction ledger, so only flag obvious active patterns.
    if exp.get("forbidden_stale_active_value"):
        stale = exp["forbidden_stale_active_value"]
        active_patterns = [
            rf"new(?: value|Value)?\s*[:=]\s*[`\"']?{re.escape(stale)}\b",
            rf"target(?: state| value)?\s*[:=]\s*[`\"']?{re.escape(stale)}\b",
            rf"expected.*\b{re.escape(stale)}\b"
        ]
        if any(re.search(p, text, re.I) for p in active_patterns):
            findings.append("stale_active_value_present")

    if exp.get("must_not_modify_code") and any(p.suffix.lower() in {".java",".py",".go",".js",".ts"} for p in files):
        findings.append("code_file_created")

    if args.run_id=="RUN_02" and "not_run" not in text:
        findings.append("automation_live_status_not_run_missing")

    score=max(0,100-5*len(findings))
    verdict="passed" if score>=95 else "failed_behavior"
    out={
        "run_id":args.run_id,
        "verdict":verdict,
        "model_performance_score":score,
        "findings":findings,
        "expected":exp,
        "semantic_driver_terminal": None if not driver_state else driver_state.get("terminal"),
        "interaction_count": None if not driver_state else driver_state.get("interaction_count"),
    }
    out_path=ROOT/"results"/f"{args.run_id}_EVALUATION.json"
    out_path.write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out,indent=2))
if __name__=="__main__":
    main()
