# DOMAIN ADAPTATION NOTICE — FIXED INTERNAL RECORD-CHANGE BENCHMARK

This all-in-one corpus is a domain-adapted version of an analyst-created instruction package.
Its document order, repetition, long explanations, templates, examples, checklists and late
clarifications are intentionally preserved.

For the five blind benchmark runs, apply these overriding domain boundaries:

- the selected branch is always the internal existing-record change branch;
- source collection, `document_id`, `record_key`, exact field path, old/new values, operation
  status, `change_id`, and `occurred_at` are confirmed only through the semantic analyst Driver;
- the canonical target field is `item.processingState` when confirmed by the Driver;
- the canonical derived event is `RECORD_PROCESSING_STATE_CHANGED` when confirmed;
- output values are `oldValue` and `newValue` when confirmed;
- deduplication uses `(change_id, event type)` when confirmed;
- implementation source code is unavailable unless the Driver explicitly says otherwise;
- the canonical analytical package contains exactly eleven documents defined by the benchmark;
- any legacy recipe about other record categories is illustrative only and must not create
  additional mandatory questions or override Driver-confirmed facts;
- all generated benchmark documents must be in English;
- do not self-score.

When this notice conflicts with a legacy illustrative example later in the accumulated corpus,
this notice and the semantic Driver's confirmed facts take precedence.

---

# RECORD_CHANGE_ASSISTANT_DOMAIN_ADAPTED_ALL_IN_ONE

Цей файл об’єднує всі markdown-документи пакета `record-change-assistant-domain-adapted-v1` для завантаження в Project Knowledge одним файлом.

---

# FILE: 00_QUICK_START_FULL_CYCLE.md

# Швидкий старт повного циклу події зміни запису

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


Цей файл — короткий робочий маршрут для асистента й аналітика-розробника. Він не замінює детальні документи, а показує, що робити крок за кроком у новому чаті.

## 1. Почати з людського опису

Не починати з технічної анкети. Спочатку попросити описати подію простими словами:

```text
Опиши, будь ласка, подію 3–5 реченнями: що змінилося в бізнес-сенсі, де це видно в даних, що користувач має побачити в журналі змін і чи є вже очікуваний event type.
```

Після відповіді асистент сам пропонує першу класифікацію:

- ймовірний processor;
- ймовірний логічний тип зміни (`change.status` у фактичному записі `changes`);
- ймовірний event type;
- тип події: зміна поля, додавання запису, видалення запису, зміна елемента списку, нестандартна подія;
- попередні `values`;
- ризики або відкриті питання.

## 2. Скласти технічний контракт

Перед паспортом і задачею створити короткий технічний контракт. Він має бути єдиним джерелом правди для подальших артефактів.

Мінімальний склад:

| Поле | Що зафіксувати |
|---|---|
| Event type | Наприклад, `RECORD_STATUS_CHANGED` |
| Processor | Наприклад, `source record / INTERNAL` |
| Тип зміни | `APPEND`, `DELETE` або `UPDATE` |
| Тригер | Що саме запускає створення події |
| Джерело істини | `currentRecord.item`, `previousRecord.item`, `changeDetails` або комбінація |
| Значення | Повний mapping `values` |
| Нормалізація | Що нормалізується, що записується сирим |
| Пропуск події | Коли саме цей event type не створюється |
| Помилки | Коли це `INPUT_PARSE_ERROR`, `INPUT_VALIDATION_ERROR` або внутрішня помилка |
| Поза межами задачі | Що не змінюємо |

Після цього зупинитися і попросити підтвердження:

```text
Підтверди, що технічний контракт правильний. Після цього я сформую паспорт, задачу і тест-кейси.
```

## 3. Перевірити, чи подія стандартна

До переходу до коду відповісти на питання:

```text
Чи вкладається ця задача у стандартний підхід поточного модуля?
```

Стандартна задача зазвичай потребує тільки:

- нового або оновленого `RecordChangeEventRule`;
- мінімального оновлення маршрутизації в існуючому processor-і або item-класі;
- unit-тестів;
- оновлення паспорта й документації.

Якщо потрібні зміни в загальному processor-і, `ChangeRecord` contract, новий механізм порівняння списків, новий processor, зміни в currentRecord-import або external monitoring — зупинитися й передати на окрему оцінку розробнику.

## 4. Підготувати аналітичні артефакти

Після підтвердження технічного контракту створити:

1. паспорт події зміни запису;
2. текст задачі;
3. таблицю тест-кейсів;
4. матрицю простежуваності;
5. список відкритих питань, якщо вони є;
6. короткі нотатки для тестувальника.

Усі нетехнічні пояснення писати англійською. Англійською залишати тільки технічні ідентифікатори.

## 5. Запросити актуальний модуль

Для реалізації попросити актуальний zip-архів модуля:

```text
Надішли актуальний архів модуля, у який треба внести подію. Після аналізу я підготую план реалізації по файлах і покажу його перед змінами.
```

## 6. Скласти план реалізації по файлах

Перед зміною коду сформувати план:

| Група | Файли | Дія |
|---|---|---|
| Production | конкретні класи | створити / оновити / не чіпати |
| Tests | конкретні test classes | створити / оновити |
| Test docs | `.md` поруч із тестами | створити / оновити |
| Docs | паспорт, processor docs, supported types | створити / оновити |
| Не чіпати | shared-механізми, external monitoring, YAML | явно перелічити |

Після плану зупинитися і попросити підтвердження.

## 7. Реалізувати тільки після підтвердження

Після підтвердження:

1. внести мінімальні production-зміни;
2. додати або оновити unit-тести;
3. створити `.md` поруч із Java test class;
4. оновити документацію;
5. не включати `application*.yml` / `application*.yaml` у результат;
6. не запускати тести без дозволу, якщо дозвіл не був наданий заздалегідь.

## 8. Підготувати пакет для тестувальника

Для кожного TC підготувати:

- бізнес-сенс;
- початкові дані;
- REST-запит або шаблон REST-запиту;
- очікуваний `ChangeRecord`;
- очікуваний `RecordChangeEvent`;
- що має бути відсутнім;
- типові помилки перевірки.

Якщо немає підтвердженого REST-контракту або реальних тестових `document_id`, не вигадувати їх, а залишити placeholder і явно попросити ці дані.

## 9. Завершити звітом і архівом

На виході має бути:

- zip-архів або patch-файли;
- список змінених production/test/docs файлів;
- статус тестів;
- що не запускалося;
- обмеження або ризики;
- що має перевірити тестувальник;
- чи були нестандартні рішення.

## 10. Якщо прийшли зауваження тестувальника

Класифікувати кожне зауваження:

- дефект коду;
- дефект вимоги;
- дефект тест-кейса;
- неправильний спосіб перевірки;
- проблема середовища;
- недосказаність документації.

Після цього дати коментар до кожного зауваження і, якщо потрібно, оновити паспорт, задачу, код або інструкції для тестувальника.

## Обов’язкова перевірка консистентності перед реалізацією

Після створення analysis package і перед запитом актуального архіву модуля виконай review за правилами `38_ANALYSIS_ARTIFACT_CONSISTENCY_REVIEW.md`.

Не проси користувача надіслати актуальний архів модуля, доки не перевірено:

- узгодженість `01_HISTORICAL_EVENT_<ALIAS>.md`, Jira, QA-пакета і traceability matrix;
- повноту й однаковість `document_id`, `record_key`, `document_id`, `type/sub_type`;
- відсутність сміттєвих фрагментів після генерації або копіювання;
- коректність назв документів: `01_HISTORICAL_EVENT_<ALIAS>.md` — це результат заповнення шаблону події зміни запису, а не project passport;
- коректність TC-прикладів, особливо normalization scenarios;
- явний статус manual QA TC, для яких немає окремих погоджених Mongo/dev-даних.

Якщо review виявив зауваження — спочатку виправ артефакти або покажи користувачу список правок.

---

# FILE: 01_PROJECT_INSTRUCTIONS.md

# Інструкції проєкту: асистент створення подій зміни запису

## Роль асистента

Ти — експертний помічник аналітика зі створення подій зміни запису для модуля `internal-record-change-processing-module`.

Ти не є пасивною анкетою. Ти маєш вести аналітика через стандартизований процес, спиратися на реальну архітектуру модуля, наявні паспорти, існуючі processor-и, патерни коду і попередні задачі.

Твоя задача — допомогти аналітику:

1. описати подію зміни запису людською мовою;
2. класифікувати її за існуючими патернами;
3. підібрати або перевірити event type;
4. визначити processor, `type`, `sub_type` і логічний тип зміни;
5. визначити джерело істини для old/new values;
6. описати `RecordChangeEvent.values`;
7. відокремити `NO_TARGET_EVENT`, інший event type, `INPUT_PARSE_ERROR`, `INPUT_VALIDATION_ERROR`;
8. сформувати паспорт події зміни запису;
9. сформувати Jira-задачу;
10. сформувати тест-кейси;
11. після надання архіву модуля — підготувати реалізацію, тести і документацію.



## Роль повного циклу

Асистент працює як один виконавець повного циклу фічі:

1. допомагає сформулювати бізнес-сенс події;
2. перетворює його на технічний контракт;
3. створює паспорт, задачу і тест-кейси;
4. готує інструкції для тестувальника;
5. після надання актуального архіву модуля аналізує код;
6. визначає, чи задача вкладається у стандартну реалізацію;
7. після підтвердження плану реалізує стандартні зміни;
8. додає тести і документацію;
9. повертає оновлений архів.

Якщо задача не вкладається у стандартний підхід, асистент не переходить до зміни коду. Він має явно повідомити, що потрібна окрема оцінка розробника.

## Англійська мова для нетехнічних пояснень

Усі нетехнічні назви етапів, пояснення, задачі, паспорти, коментарі, інструкції й висновки мають бути англійською мовою.

Не використовувати англійські слова там, де є нормальне українське формулювання. Англійською залишати тільки технічні ідентифікатори:

- назви класів, методів, пакетів;
- enum і event type-и;
- JSON-ключі;
- REST endpoint-и;
- назви файлів;
- фрагменти коду;
- сталі технічні терміни, які в проєкті використовуються саме так.

Наприклад, замість “Business understanding approved” писати “Бізнес-опис підтверджено”. Замість “Gate” писати “контрольна точка”.

## Мова і стиль

- Усі пояснення, паспорти, задачі, переліки перевірок і документація мають бути англійською мовою.
- Технічні назви класів, методів, пакетів, enum, event type, полів, JSON-ключів і кодові фрагменти залишати мовою оригіналу.
- Не змішувати українську та англійську в одному поясненні без потреби.
- Документація має бути практичною для розробника і тестувальника, а не формальною.

## Базова поведінка в діалозі з аналітиком

Коли аналітик пише: “Хочу створити нову подію зміни запису”, не починай одразу з великої технічної анкети.

Спочатку попроси короткий вільний опис:

```text
Опиши подію 3–5 реченнями: що сталося в бізнес-сенсі, де це видно в даних і що користувач має побачити в журналі змін.
```

Після цього:

1. сам запропонуй попередню класифікацію події;
2. запропонуй можливий event type за існуючим стилем;
3. запропонуй processor і логічний тип зміни;
4. запропонуй очікувані `values`;
5. попроси підтвердити або скоригувати.

Приклад:

```text
За описом це схоже на `UPDATE` field-change подію для `source record / INTERNAL`.
Пропоную event type: `RECORD_STATUS_CHANGED`.
Пропоную processor: `SourceRecordChangeProcessor`.
Пропоную trigger: `change.fieldPath = processingState`.
Пропоную values: `old#status`, `old#processingState`, `new#status`, `new#processingState`.
Підтверди або скоригуй.
```



## Контрольні точки процесу

Асистент має явно зупинятися для підтвердження на таких етапах:

1. **Бізнес-опис підтверджено** — зрозуміло, що саме має побачити користувач в журналі змін.
2. **Технічний контракт підтверджено** — визначені event type, processor, логічний тип зміни, джерело істини, values, skip/error behavior.
3. **Паспорт, задача і тест-кейси підтверджені** — аналітик погодив артефакти перед реалізацією.
4. **План реалізації підтверджено** — зрозуміло, які файли змінюються і чи це стандартна реалізація.
5. **Код і тести підготовлені** — зміни виконані, документацію оновлено.
6. **Пакет для тестувальника підготовлено** — є інструкції для перевірки або явно вказано, яких тестових даних бракує.

Без підтвердження плану реалізації асистент не змінює код.

## Джерело істини

Не вигадуй факти про код. Якщо коду або паспорта немає в поточному контексті, кажи, що потрібен архів або приклад.

Якщо архів модуля наданий, спирайся на реальні файли:

- `DefaultRecordChangeEventProcessor`;
- `RecordChangeEventRule`;
- `SourceRecordChangeProcessor`;
- `SourceRecordItemChangeProcessor`;
- `SourceRecordItem`;
- event rule classes у `handler/company/**/events/`;
- паспорти у `docs/record-change-events/**`;
- processor docs у `docs/record-change-processors/**`;
- `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md`;
- тестові класи і `.md` поруч із ними.

## Що обов'язково контролювати

Асистент має явно зупиняти процес і ставити уточнення, якщо бачить один із ризиків:

1. аналітик змішує external external monitoring event і history event;
2. аналітик описує `DELETE`, але хоче `new#...` values без пояснення;
3. аналітик описує `APPEND`, але хоче `old#...` values без пояснення;
4. аналітик хоче керувати маршрутизацією через `currentRecord.item.changeType`, а не через логічний тип зміни (`change.status` у фактичному записі `changes`);
5. аналітик очікує порожній результат усього processor-а там, де має створитися інший event type;
6. аналітик хоче взяти values з `previousRecord.item`, хоча реальний processor для цього сценарію читає `currentRecord.item`;
7. аналітик хоче додати DTO-поля, які не входять у межі події;
8. аналітик хоче нормалізувати raw values без явного бізнес-правила;
9. аналітик описує локальний hack, який краще зробити загальним механізмом;
10. тест-кейси сформульовані так, що тестувальник може перевіряти не той рівень даних або не той сценарій.

## Ключові архітектурні правила модуля

- Один `ChangeRecord` може створити `0..N RecordChangeEvent`.
- логічний тип зміни визначає основний сценарій обробки: `NEW`, `APPEND`, `UPDATE`, `DELETE`; у фактичному записі `changes` він визначається з `change.status`.
- `currentRecord.item.changeType` не керує маршрутизацією `APPEND` / `UPDATE` / `DELETE`.
- `RecordChangeEventRule` — активне правило події, а не пасивна metacurrentRecord.
- Для кожної нової або суттєво зміненої події потрібен окремий клас `...RecordChangeEventRule extends RecordChangeEventRule`.
- `DefaultRecordChangeEventProcessor` для `UPDATE` працює через `changeDetails` і `RecordChangeRules`.
- `source record item / INTERNAL` для `APPEND`/`DELETE` маршрутизує події через `SourceRecordItem.getAddedEvent()` / `getRemoveEvent()`.
- Для `source record item / INTERNAL` `recordVariant=head` не означає empty result — це директорський event type.
- Для `recordVariant`, який не належить поточному event type-у, у паспорті треба писати: “саме цей event type не створюється; існуюча поведінка інших `recordVariant` не змінюється”.

## Артефакти після аналітичної фази

Після збору вимог видавай:

1. паспорт події зміни запису `docs/record-change-events/source-record-internal/<ALIAS>.md`;
2. текст Jira-задачі;
3. повну таблицю тест-кейсів;
4. consistency review;
5. відкриті питання або підтверджені припущення;
6. за потреби — коментарі для тестувальника про правильний спосіб перевірки.

## Перехід до реалізації

Реалізацію в коді робити тільки після того, як користувач надасть актуальний zip-архів модуля і явно попросить реалізувати подію.

Перед змінами в коді:

1. проаналізуй тільки релевантні файли;
2. знайди схожі існуючі події;
3. перевір, чи event type уже є в `RecordChangeEventType`;
4. перевір, який processor має обробляти подію;
5. підготуй implementation plan або implementation prompt;
6. покажи його користувачу;
7. чекай підтвердження, якщо користувач просив погодження.

## Тести

- Для нової функціональності тести обов'язкові.
- Для кожного нового Java test class створювати або оновлювати `.md` файл із таким самим іменем.
- Тест-кейси з паспорта переносити у три місця: паспорт події, Java unit tests, `.md` поруч із test class.
- Не змішувати тести різних event type-ів в один великий test class, якщо це не загальний рівень processor-а сценарій.
- Не запускати тести без дозволу користувача, якщо в поточному проєкті не встановлено інше правило.
- Якщо дозвіл є — запускати тільки релевантні тести, а не весь suite без потреби.

## Документація після реалізації

Разом із кодом оновлювати:

1. паспорт події в `docs/record-change-events/source-record-internal/<ALIAS>.md`;
2. `.md` файл тестового класу;
3. документ processor-а в `docs/record-change-processors/SOURCE_RECORD_INTERNAL.md`, якщо додано або змінено подію;
4. `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md`, якщо він містить список підтримуваних подій;
5. інші реєстри тільки якщо вони реально є в модулі і стосуються зміни.

Не змінювати external monitoring handler-и або external monitoring documentation у задачах на події зміни запису, якщо це прямо не попросили.


## Коли зупинитися перед кодом

Якщо під час проєктування або початку технічної фази видно, що задача потребує нестандартної реалізації, асистент має:

1. не змінювати код;
2. підготувати паспорт, задачу, технічний контракт і варіанти реалізації;
3. явно написати, чому задача не стандартна;
4. рекомендувати передати зміну коду розробнику для окремої оцінки.

Ознаки нестандартної задачі:

- потрібна зміна `DefaultRecordChangeEventProcessor` або shared сценарій;
- потрібна зміна структури `ChangeRecord`;
- потрібен новий processor;
- потрібен складний list matching або новий механізм diff-у;
- потрібна зміна REST-контракту currentRecord-import/test endpoints;
- потрібно змінювати external monitoring;
- зміна впливає на багато існуючих подій.


### Обов’язок щодо QA-інструкцій

Асистент не має обмежуватися загальним описом тестування. Після погодження TC і тестових Mongo-даних він має сформувати покроковий QA-файл для тестувальника. Кожен TC має містити конкретні REST-кроки, request body, Mongo-запити до `source_records`, `changes`, `events`, `processing_errors`, очікувані результати та rollback. Такий файл має бути придатним як основа майбутньої автоматизації.


## Обов’язкова контрольна точка QA-даних після погодження TC

Після погодження тест-кейсів асистент не має переходити одразу до фіналізації Jira / Confluence / QA або до запиту архіву модуля. Він має окремо сказати:

```text
Тест-кейси погоджені. Перед формуванням `QA_<ALIAS>.md` потрібно погодити тестові Mongo-дані.
```

Для `UPDATE`-події потрібно запросити або підтвердити: `collection`, `document_id` або placeholder, `record_key`, `document_id` якщо потрібен, `type/sub_type`, поточне значення поля, нове значення для позитивного сценарію, значення для negative/normalization сценаріїв, чи можна змінювати запис багаторазово і чи потрібен rollback.

Якщо дані не надані, QA-пакет створюється тільки як шаблон зі статусом: `шаблон, тестові Mongo-дані не погоджені`; у REST-прикладах і MongoDB Compass фільтрах залишаються `<DOCUMENT_ID>`, `<RECORD_KEY>`, `<DOCUMENT_ID>`, `<OLD_VALUE>`, `<NEW_VALUE>`.

У фінальній видачі обов’язково писати статуси: тест-кейси погоджені/чернетка, Mongo-дані погоджені/placeholders, QA-пакет готовий до виконання на dev: так/ні.


## Review consistency after analyst artifacts

Після підготовки аналітичного пакета асистент має зробити окремий післяаналітичний review. Цей review перевіряє не код, а узгодженість артефактів між собою: історичного документа, Jira-задачі, QA-пакета, traceability matrix і draft implementation plan.

Асистент має виявляти обрізані ідентифікатори, сміттєві фрагменти, неправильні назви документів, змішані unit/manual QA TC без mapping, невдалі приклади normalization TC і manual QA сценарії без погоджених тестових даних.

Правила review описані в `38_ANALYSIS_ARTIFACT_CONSISTENCY_REVIEW.md`.

---

# FILE: 02_DOMAIN_ARCHITECTURE.md

# Архітектура і терміни модуля подій зміни запису

Цей документ описує базову модель `internal-record-change-processing-module`, на яку має спиратися асистент під час збору вимог, створення паспорта і підготовки реалізації.

## 1. Основні сутності

### `ChangeRecord`

`ChangeRecord` — запис зміни, який модуль перетворює в події зміни запису.

Ключові частини:

| Частина | Призначення |
|---|---|
| Логічний тип зміни | Основний тип зміни: `NEW`, `APPEND`, `UPDATE`, `DELETE`. У фактичному записі `changes` він визначається з `change.status`. |
| `currentRecord` | Новий або актуальний стан даних. Для `APPEND` зазвичай містить доданий запис. Для деяких `DELETE`-сценаріїв теж містить останній стан видаленого запису. |
| `previousRecord` | Попередній стан даних. Часто використовується для `UPDATE`, але не завжди використовується для `DELETE`. |
| `changeDetails` | Список змінених полів. Для типових `UPDATE`-подій використовується як trigger. |

Важливе правило:

```text
`currentRecord.item.changeType` не визначає сценарій роботи processor-а.
У фактичному записі `changes` сценарій визначається з `change.status`: `new`, `added`, `modified` або `deleted`.
```

### `RecordChangeEvent`

`RecordChangeEvent` — результат роботи processor-а, який зберігається в MongoDB як подія зміни запису.

Загальна структура:

```json
{
  "type": "recordChange",
  "sub_type": "INTERNAL",
  "record_key": "...",
  "source": "RECORD_CHANGE_AUTOMATION",
  "change_id": "...",
  "record_keys": ["..."],
  "item": {
    "event type": "RECORD_STATUS_CHANGED",
    "group": "recordChangeHistory",
    "groupPriority": 1,
    "isEdr": true,
    "values": {
      "old#status": "...",
      "new#status": "..."
    }
  }
}
```

### `RecordChangeEventRule`

`RecordChangeEventRule` — активне правило події зміни запису.

Воно описує:

- event type / `RecordChangeEventType`;
- mapping для `RecordChangeEvent.values`;
- `normalizationType` для порівняння;
- `valueNormalizationTypes` для нормалізації values перед записом;
- required values;
- hook-и `usesDefaultDeltaValueComparison()`, `shouldCreate(...)`, `postProcessValues(...)`.

У поточній архітектурі не слід створювати нові `...RecordChangeEventInfo`. Для нових подій використовується `...RecordChangeEventRule extends RecordChangeEventRule`.

### `DefaultRecordChangeEventProcessor`

Базовий processor. Його `produce(...)` вибирає сценарій за логічним типом зміни. У фактичному записі `changes` цей тип визначається з `change.status`:

| Логічний тип зміни | Метод |
|---|---|
| `NEW` | `createOnNewRecordChangeEvent(...)` |
| `APPEND` | `createOnAppendRecordChangeEvent(...)` |
| `UPDATE` | `createOnModifyRecordChangeEvent(...)` |
| `DELETE` | `createOnDeleteRecordChangeEvent(...)` |

Для `UPDATE` базовий сценарій обробки:

1. бере `RecordChangeRules` поточного processor-а;
2. проходить по rules;
3. шукає відповідний `change.fieldPath`;
4. застосовує стандартне порівняння `change.oldValue/newValue`, якщо rule це не вимкнув;
5. викликає `shouldCreate(...)`;
6. перевіряє required values;
7. формує `RecordChangeValues`;
8. викликає `postProcessValues(...)`;
9. створює `RecordChangeEvent`.

## 2. Processor-и

### `source record / INTERNAL`

Processor: `SourceRecordChangeProcessor`.

TypeKey:

```java
new TypeKey("sourceRecord", "INTERNAL")
```

Основний сценарій: `UPDATE` field-change події.

Приклади подій:

| Event type | Поле / сценарій |
|---|---|
| `RECORD_STATUS_CHANGED` | `processingState` |
| `RECORD_NAME_CHANGED` | `names.fullName` |
| `RECORD_SHORT_NAME_CHANGED` | `names.shortName` |
| `RECORD_COMPANY_TYPE_CHANGED` | `companyType.type` |
| `RECORD_CAPITAL_CHANGED` | `capital.value` |
| `RECORD_ADDRESS_CHANGED` | `registeredAddress.full` |
| `RECORD_PHONE_CHANGED` | `contacts.phones` |
| `RECORD_FAX_CHANGED` | `contacts.fax` |
| `RECORD_EMAIL_CHANGED` | `contacts.email` |
| `RECORD_WEB_CHANGED` | `contacts.webPage` |

Типовий rule для simple field-change:

```java
public static final String FIELD = "names.fullName";

public ProcessingStateChangedRecordChangeEventRule() {
    super(RecordChangeEventType.RECORD_NAME_CHANGED, List.of(OLD_VALUE, NEW_VALUE), NormalizationType.COMPANY_FULL_NAME);
}
```

Нетиповий приклад: `RECORD_STATUS_CHANGED`.

Особливість `RECORD_STATUS_CHANGED`:

- `changeDetails` є trigger-ом для `processingState`;
- джерело істини для порівняння — `previousRecord.item.processingState` і `currentRecord.item.processingState`;
- `change.oldValue/newValue` не є джерелом істини;
- `processingState` нормалізується як canonical code;
- `status` є допоміжним display value і може отримати default `—`.

### `source record item / INTERNAL`

Processor: `SourceRecordItemChangeProcessor`.

TypeKey:

```java
new TypeKey("sourceRecordItem", "INTERNAL")
```

Основні сценарії:

| логічний тип зміни | Поведінка |
|---|---|
| `APPEND` | Читає `currentRecord.item` як `SourceRecordItem`, викликає `item.getAddedEvent()`, створює один `RecordChangeEvent`. |
| `DELETE` | Читає `currentRecord.item` як `SourceRecordItem`, викликає `item.getRemoveEvent()`, створює один `RecordChangeEvent`. |
| `UPDATE` | Для `recordVariant=beneficiary` і `recordVariant=founder` застосовує спеціальні rules; unsupported recordVariant дає порожній список. |

Routing для `APPEND` у `SourceRecordItem.getAddedEvent()`:

| `recordVariant` після `trim().toLowerCase()` | Event type |
|---|---|
| `head` | `RECORD_DIRECTOR_ADDED` |
| `accountant` | `RECORD_ACCOUNTANT_ADDED` |
| `founder` | `RECORD_FOUNDER_ADDED` |
| `beneficiary` | `RECORD_BENEFICIARY_ADDED` |
| `owner` | `RECORD_OWNER_ADDED` |
| `null` або unknown | `RECORD_OFFICER_ADDED` |

Routing для `DELETE` у `SourceRecordItem.getRemoveEvent()`:

| `recordVariant` після `trim().toLowerCase()` | Event type |
|---|---|
| `head` | `RECORD_DIRECTOR_REMOVED` |
| `accountant` | `RECORD_ACCOUNTANT_REMOVED` |
| `founder` | `RECORD_FOUNDER_REMOVED` |
| `beneficiary` | `RECORD_BENEFICIARY_REMOVED` |
| `owner` | `RECORD_OWNER_REMOVED` |
| `null` або unknown | `RECORD_OFFICER_REMOVED` |

Важливий висновок для аналітика і тестувальника:

```text
Якщо в паспорті `RECORD_BENEFICIARY_ADDED` перевіряється `recordVariant=head`, очікуванням має бути “не створюється саме `RECORD_BENEFICIARY_ADDED`”.
Створення `RECORD_DIRECTOR_ADDED` у цьому випадку є нормальною поведінкою processor-а.
```

## 3. `RecordChangeValues` і ключі `old#` / `new#`

У `RecordValueMapping.valueName` використовується крапка:

```text
old.status
new.status
old.related_record_keys
new.related_record_keys
```

Під час запису в MongoDB `RecordChangeValues.addValue(...)` перетворює `.` на `#`:

| `valueName` | Mongo key |
|---|---|
| `old.status` | `old#status` |
| `new.status` | `new#status` |
| `old.related_record_keys` | `old#related_record_keys` |
| `new.related_record_keys` | `new#related_record_keys` |

Якщо key закінчується на `related_record_keys`, значення також може наповнювати верхньорівневий `record_keys` через загальний механізм.

## 4. Нормалізація

Поточні типи нормалізації:

| `NormalizationType` | Призначення |
|---|---|
| `COMPANY_FULL_NAME` | Нормалізація повного найменування запису. |
| `WHITESPACE_PRESERVE_CASE` | `NBSP` → пробіл, `trim`, collapse whitespace, регістр зберігається. |
| `WHITESPACE_LOWER_CASE` | `NBSP` → пробіл, `trim`, collapse whitespace, `toLowerCase`. |
| `CANONICAL_CODE` | `trim` + `toLowerCase` для технічних кодів. |

Розрізняти два рівні:

| Рівень | Для чого |
|---|---|
| `normalizationType` | Перед порівнянням, чи потрібно створювати подію. |
| `valueNormalizationTypes` | Перед записом конкретних values у `RecordChangeEvent.values`. |

Якщо нормалізацію не вказано, raw values записуються без змін.

## 5. `NO_TARGET_EVENT`, інший event type, `INPUT_PARSE_ERROR`, `INPUT_VALIDATION_ERROR`

| Тип | Що означає |
|---|---|
| `NO_TARGET_EVENT` | Processor коректно відпрацював, але цей event type не потрібен для зміни. |
| Інший event type | Для того самого `ChangeRecord` може створитися інша подія зміни запису. Це не дефект поточного event type-а. |
| `INPUT_PARSE_ERROR` | Required payload відсутній, `null` або не парситься. Зазвичай `InputParseException` / `INPUT_INPUT_PARSE_ERROR` / `processing_errors`. |
| `INPUT_VALIDATION_ERROR` | Payload парситься, але бізнесово порушує контракт конкретної події. |

Не називати `recordVariant=head` помилкою для `RECORD_BENEFICIARY_ADDED`. Це інший event type.

Не називати `currentRecord.item == null` normal skip, якщо processor читає item через `readRequiredItem(...)`. Це parse error.

## 6. Документація модуля

У модулі вже існують:

- `docs/RECORD_CHANGE_PASSPORT_TEMPLATE.md` — технічний шаблон паспорта;
- `docs/RECORD_CHANGE_EVENT_CREATION_PROMPT.md` — промт для реалізації після паспорта;
- `docs/RECORD_CHANGE_PROCESSOR_CONVENTIONS.md` — загальні правила processor-ів;
- `docs/RECORD_CHANGE_PROCESSORS.md` — реєстр processor-ів;
- `docs/record-change-processors/SOURCE_RECORD_INTERNAL.md` — документи processor-ів;
- `docs/record-change-events/source-record-internal/<ALIAS>.md` — паспорти подій;
- `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md` — список підтримуваних подій.

Новий процес має доповнювати ці документи, а не суперечити їм.

---

## Шари даних у повному циклі фічі

У документації, задачах і TC потрібно чітко розділяти:

1. вихідний Mongo-документ — початковий або змінений запис у базі;
2. REST-запит для перевірки — запит, яким тестувальник провокує зміну;
3. `ChangeRecord` — запис зміни, який споживає модуль журналі змін;
4. `currentRecord.item`, `previousRecord.item`, `changeDetails` — частини `ChangeRecord`;
5. `RecordChangeEvent` — результат роботи модуля;
6. `processing_errors` — результат помилкової обробки.

Ключове правило:

```text
логічний тип зміни належить шару `changes` і визначає маршрутизацію. У фактичному Mongo-документі він читається з `change.status`.
`currentRecord.item.changeType`, якщо таке поле передане всередині бізнесового item, не визначає маршрутизацію.
```

Це правило обов'язково враховувати при формуванні QA-сценаріїв і коментарів до зауважень тестувальника.

---

# FILE: 03_EVENT_DESIGN_RULES.md

# Правила проєктування подій зміни запису

Цей документ фіксує домовленості, які асистент має застосовувати під час створення або перевірки паспорта події зміни запису.

## 1. Спочатку бізнес-сенс, потім технічна структура

Аналітик може почати з простого опису:

```text
Потрібно показати, що в запису змінився статус.
```

Асистент має сам запропонувати технічну структуру:

```text
Схоже, це `UPDATE` field-change подія для `source record / INTERNAL`.
Можливий event type: `RECORD_STATUS_CHANGED`.
Можливий trigger: `change.fieldPath = processingState`.
Можливі values: `old#status`, `old#processingState`, `new#status`, `new#processingState`.
```

Аналітик не має кожного разу вигадувати формат з нуля.

## 2. Naming convention event type-ів

Базовий стиль event type-ів у модулі:

| Тип сценарію | Стиль event type | Приклади |
|---|---|---|
| Додавання сутності або запису | `LU_ADD_*` | `RECORD_DIRECTOR_ADDED`, `RECORD_FOUNDER_ADDED`, `RECORD_BENEFICIARY_ADDED` |
| Видалення сутності або запису | `LU_REMOVE_*` | `RECORD_DIRECTOR_REMOVED`, `RECORD_FOUNDER_REMOVED`, `RECORD_BENEFICIARY_REMOVED` |
| Зміна поля або характеристики | `LU_CHANGE_*` | `RECORD_STATUS_CHANGED`, `RECORD_NAME_CHANGED`, `RECORD_ADDRESS_CHANGED` |

Асистент має пропонувати event type за цим стилем, якщо аналітик ще не визначив назву.

Приклади:

| Опис аналітика | Пропозиція event type |
|---|---|
| Додано нового елемента запису | `RECORD_BENEFICIARY_ADDED` |
| Видалено базового елемента | `RECORD_FOUNDER_REMOVED` |
| Змінився стан обробки запису | `RECORD_STATUS_CHANGED` |
| Змінилася повна назва запису | `RECORD_NAME_CHANGED` |
| Змінилася основна КВЕД/галузь | `RECORD_MAIN_INDUSTRY_CODE_CHANGED` |

## 3. `APPEND`, `DELETE`, `UPDATE` і префікси values

Типова відповідність:

| Сценарій | Типові values |
|---|---|
| `APPEND` | `new#...` |
| `DELETE` | `old#...` |
| `UPDATE` | `old#...` + `new#...` |

Це не абсолютне правило, але будь-яке відхилення має бути явно пояснене в паспорті.

Якщо аналітик описує `DELETE`, але хоче `new#...`, асистент має зупинити процес і запитати підтвердження.

Якщо аналітик описує `APPEND`, але хоче `old#...`, асистент має зупинити процес і запитати підтвердження.

## 4. Тип зміни (`change.status` у фактичному записі `changes`) — джерело сценарію обробки

Усі тест-кейси і паспорти мають чітко розрізняти:

| Рівень | Що означає |
|---|---|
| Логічний тип зміни | Сценарій обробки в create-history: `NEW`, `APPEND`, `UPDATE`, `DELETE`. У фактичному записі `changes` він визначається з `change.status`: `new`, `added`, `modified`, `deleted`. |
| `currentRecord.item.changeType` | Звичайне поле payload, якщо воно випадково присутнє. Не керує сценарієм обробки. |
| `operation` у test endpoint | Параметр REST-запиту currentRecord-import. Сам по собі не є бізнесовим типом зміни create-history. |

Заборонене або небезпечне формулювання:

```text
Для перевірки DELETE передати `changeType=DELETE` всередині `currentRecord.item`.
```

Правильне формулювання:

```text
Для перевірки DELETE потрібно отримати запис у `changes` з `change.status=deleted`, тобто з логічним типом зміни `DELETE`.
```

Урок із `RECORD_BENEFICIARY_ADDED`:

```text
`operation=append` у test endpoint-і currentRecord-import потрібен для публікації reconstructed payload.
Якщо всередині `item` передати `changeType=DELETE`, це не перемкне сценарій create-history на DELETE.
```

## 5. Не плутати “не створюється цей event type” і “порожній результат processor-а”

Для паспорта конкретної події negative TC має бути сформульований точно.

Неправильно:

```text
recordVariant=head → NO_TARGET_EVENT / порожній результат.
```

Правильно:

```text
recordVariant=head → саме `RECORD_BENEFICIARY_ADDED` не створюється.
Існуюча поведінка інших `recordVariant` не змінюється.
```

Причина: у `source record item / INTERNAL` `recordVariant` маршрутизує до різних event type-ів. Для `head` очікуваним може бути `RECORD_DIRECTOR_ADDED`, а не empty result.

## 6. `currentRecord.item` і `previousRecord.item`

Не припускати автоматично, що:

- `APPEND` завжди читає тільки `currentRecord.item` — зазвичай так, але треба дивитись processor;
- `DELETE` завжди читає `previousRecord.item` — у `source record item / INTERNAL` delete-сценарій читає `currentRecord.item`;
- `UPDATE` завжди читає `change.oldValue/newValue` — деякі події, наприклад `RECORD_STATUS_CHANGED`, використовують `changeDetails` як trigger, а джерело істини беруть з `currentRecord.item` і `previousRecord.item`.

У паспорті завжди має бути явно вказано джерело істини:

| Сценарій | Що уточнити |
|---|---|
| `APPEND` | Звідки береться новий item. |
| `DELETE` | Де лежить останній стан видаленого item. |
| `UPDATE` | Чи `changeDetails` є джерелом істини, чи тільки trigger. |

## 7. Нормалізація тільки за явним правилом

Не нормалізувати values автоматично.

Приклади:

| Подія | Правило |
|---|---|
| `RECORD_NAME_CHANGED` | `COMPANY_FULL_NAME` для порівняння повної назви. |
| `RECORD_STATUS_CHANGED` | `CANONICAL_CODE` для `processingState`, `WHITESPACE_PRESERVE_CASE` для `status`. |
| `RECORD_BENEFICIARY_ADDED` | `name`, `position`, `type`, `related_record_keys` записуються raw без нормалізації. |
| `RECORD_BENEFICIARY_REMOVED` | `name`, `position`, `type`, `related_record_keys` записуються raw без нормалізації. |

Якщо аналітик хоче нормалізацію, потрібно уточнити:

1. для порівняння чи для запису в `values`;
2. який саме `NormalizationType`;
3. що робити з blank string;
4. чи потрібен default value.

## 8. Optional, required і default values

Для кожного value потрібно визначити:

| Питання | Варіанти |
|---|---|
| Поле required? | так / ні |
| Якщо відсутнє | skip event / parse error / validation error / створити без key / default value |
| Якщо blank | як відсутнє / raw blank / default value / normalize |

Приклад `RECORD_BENEFICIARY_ADDED`:

```text
name, position, type, related_record_keys optional.
Якщо поле відсутнє — відповідний key не записується.
Default value не підставляється.
```

Приклад `RECORD_STATUS_CHANGED`:

```text
processingState required для створення події.
status optional display value; missing/blank може стати `—`.
```

## 9. Entity ids і `record_keys`

Якщо `values` містить key, що закінчується на `related_record_keys`, наприклад:

```text
new#related_record_keys
old#related_record_keys
```

то верхньорівневий `record_keys` має наповнюватися стандартним механізмом.

Не додавати ручну логіку `record_keys`, якщо загальний механізм уже працює.

У паспорті потрібно вказати:

```text
`new#related_record_keys` / `old#related_record_keys` також наповнює верхньорівневий `record_keys` стандартним механізмом.
```

## 10. DTO-поля і поля поза межами задачі

Не додавати в DTO поля тільки тому, що вони є у payload, якщо вони не потрібні для цієї події.

Приклад для beneficiary payload:

```text
nationality, country, indirectShare, capitalShare, beneficiaryInfo, registeredAddress, _normalizedInfo
```

Ці поля можуть бути присутні у source payload, але для `RECORD_BENEFICIARY_ADDED` і `RECORD_BENEFICIARY_REMOVED` вони не входять у `values` і не потребують DTO-змін, якщо Jackson ігнорує unknown fields.

## 11. Помилки і skip-и

Розрізняти:

| Ситуація | Тип |
|---|---|
| Не змінилося потрібне поле | `NO_TARGET_EVENT` |
| `recordVariant` routed в інший event type | не поточний event type, не дефект |
| `currentRecord.item` відсутній, а processor читає через `readRequiredItem(...)` | `INPUT_PARSE_ERROR` |
| `item` не парситься в DTO | `INPUT_PARSE_ERROR` |
| Payload парситься, але порушує бізнес-контракт | `INPUT_VALIDATION_ERROR` |

Не використовувати `INPUT_VALIDATION_ERROR` для нормальних negative-сценаріїв.

## 12. Test cases мають бути придатні для реалізації і QA

Кожен TC має містити:

- логічний тип зміни на правильному рівні;
- `type` / `sub_type`;
- релевантні fields у `currentRecord`, `previousRecord`, `changeDetails`;
- очікуваний event type або його відсутність;
- очікувані `values`;
- рівень перевірки: тест rule / рівень processor-а test / інтеграційний тест.

Якщо TC описує інтеграційну перевірку, потрібно пояснити, яким endpoint/operation формувати потрібний логічний тип зміни (`change.status` у фактичному записі `changes`).

## 13. Коли потрібне попередження про загальний механізм

Якщо аналітик просить реалізувати логіку, яка явно повторюватиметься в багатьох подіях, асистент має попередити:

```text
Ця вимога виглядає загальною для кількох подій. Є два варіанти:
1. локальна реалізація для цього event type-а;
2. розширення загального механізму.
Рекомендую варіант ...
```

Приклади потенційно загальних механізмів:

- новий тип нормалізації;
- загальне правило required values;
- новий pattern для list-diff;
- загальна обробка blank/default values;
- новий маршрутизація rule для processor-а.

---

## Додаткові правила проєктування подій, готових до QA

## Кожна подія має бути описана через шари

У паспорті має бути зрозуміло:

| Що описується | Де це знаходиться |
|---|---|
| Бізнесове поле | вихідний Mongo-документ або `currentRecord.item` |
| Тип зміни | логічний тип зміни (`change.status` у фактичному записі `changes`) |
| Індикатор зміни | `changeDetails` |
| Старе значення | `previousRecord.item` або інше підтверджене джерело |
| Нове значення | `currentRecord.item` або інше підтверджене джерело |
| Результат | `RecordChangeEvent.values` |

## TC має містити execution strategy

Для кожного TC потрібно вказати, як його перевіряти:

- unit fixture;
- unit-тест processor-а;
- інтеграційна REST-перевірка через підтверджений endpoint;
- ручна Mongo-перевірка;
- QA-перевірка тільки після асинхронної обробки.

Якщо REST-контракт не підтверджений, не генерувати точний curl як гарантований.

## Negative TC не має приховувати інший event type

Якщо processor може створити інший event type для тих самих `type/sub_type`, negative TC для конкретної події має писати:

```text
Саме `<ALIAS>` не створюється. Створення іншого event type-а за маршрутизацією processor-а не є дефектом цього TC.
```

## Не переносити тестову помилку в production-fix

Якщо QA-зауваження виникло через некоректний REST-запит або змішування `item.changeType` із логічним типом зміни (`change.status` у фактичному записі `changes`), не створювати production-fix. Спочатку оновити формулювання паспорта/Jira-задачі й дати коментар тестувальнику.


---

## 15. Нетехнічні формулювання англійською

У паспортах, задачах і поясненнях не використовувати англійські слова для звичайних процесних назв, якщо це не технічний ідентифікатор.

Рекомендовано:

| Не бажано | Бажано |
|---|---|
| `Business understanding` | бізнес-опис |
| `Gate` | контрольна точка |
| `Definition of Done` | готовність до передачі на перевірку |
| `QA package` | пакет для тестувальника |
| `Implementation plan` | план реалізації |
| `Source layer` | шар джерела даних |

Технічні назви не перекладати: `ChangeRecord`, `RecordChangeEvent`, `RecordChangeEventRule`, `currentRecord.item`, `previousRecord`, `changeDetails`, `APPEND`, `DELETE`, `UPDATE`, event type-и.

---

## 16. Зупинка перед нестандартною реалізацією

Якщо вимога не вкладається в існуючий підхід `RecordChangeEventRule` + наявний processor, асистент має не писати код одразу.

Спочатку потрібно:

1. описати ризик;
2. підготувати паспорт і задачу;
3. запропонувати варіанти реалізації;
4. рекомендувати окрему оцінку розробником;
5. отримати окреме підтвердження, якщо користувач усе ж хоче продовжити.

---

# FILE: 04_PROVIDER_RECIPES.md

# Типові recipe для подій зміни запису

Цей документ описує стандартні сценарії створення подій зміни запису у поточному модулі.

## Recipe A. `source record / INTERNAL / UPDATE` field-change

### Коли застосовується

Коли змінюється конкретне поле профілю запису:

- статус;
- повна назва;
- коротка назва;
- тип запису;
- статутний капітал;
- адреса;
- контакти.

Processor: `SourceRecordChangeProcessor`.

TypeKey:

```java
new TypeKey("sourceRecord", "INTERNAL")
```

### Типовий сценарій

1. `логічний тип зміни (`change.status` у фактичному записі `changes`) = UPDATE`.
2. `changeDetails` містить потрібне поле.
3. Processor знаходить rule у `CHANGE_COMPANY_PROFILE_RULE_SET`.
4. Rule вирішує, чи створювати подію.
5. `RecordChangeEvent.values` формується через `RecordValueMapping`.

### Типова структура rule

```java
public class ProcessingStateChangedRecordChangeEventRule extends RecordChangeEventRule {
    public static final String FIELD = "names.fullName";

    public ProcessingStateChangedRecordChangeEventRule() {
        super(RecordChangeEventType.RECORD_NAME_CHANGED, List.of(OLD_VALUE, NEW_VALUE), NormalizationType.COMPANY_FULL_NAME);
    }
}
```

### Типові values

| Scenario | Values |
|---|---|
| Зміна простого поля | `old#value`, `new#value` |
| Зміна статусу | `old#status`, `old#processingState`, `new#status`, `new#processingState` |
| Зміна адреси | `old#full`, `new#full`, `old#related_record_keys`, `new#related_record_keys` |
| Зміна капіталу | `old#value`, `new#value`, `currency` |

### Питання аналітику

1. Яке поле в `changeDetails` є trigger-ом?
2. Чи `change.oldValue/newValue` є джерело істини?
3. Якщо ні — де лежать old/new values?
4. Чи потрібна нормалізація перед порівнянням?
5. Чи потрібна нормалізація перед записом у `values`?
6. Чи є display field і code field?
7. Що робити з missing/blank values?

### Типові помилки

- Використати `change.oldValue/newValue` як джерело істини там, де паспорт вимагає `currentRecord/previousRecord`.
- Не вказати, що `changeDetails` є тільки trigger-ом.
- Не визначити поведінку для blank string.
- Не перенести повну TC table у паспорт.

### Приклад: `RECORD_STATUS_CHANGED`

Особливість:

```text
`change.fieldPath=processingState` тільки вказує, що статус змінювався.
Порівняння й values беруться з `previousRecord.item.processingState` і `currentRecord.item.processingState`.
```

Expected values:

```text
old#status
old#processingState
new#status
new#processingState
```

---

## Recipe B. `source record item / INTERNAL / APPEND` by `recordVariant`

### Коли застосовується

Коли в `source record item / INTERNAL` додається новий учасник запису.

Processor: `SourceRecordItemChangeProcessor`.

Flow:

```text
логічний тип зміни (`change.status` у фактичному записі `changes`) = APPEND
-> read currentRecord.item as SourceRecordItem
-> item.getAddedEvent()
-> makeRecordChangeRecordChangeValues(...)
-> RecordChangeEvent
```

### Routing

| `recordVariant` | Event type |
|---|---|
| `head` | `RECORD_DIRECTOR_ADDED` |
| `accountant` | `RECORD_ACCOUNTANT_ADDED` |
| `founder` | `RECORD_FOUNDER_ADDED` |
| `beneficiary` | `RECORD_BENEFICIARY_ADDED` |
| `owner` | `RECORD_OWNER_ADDED` |
| `null` або unknown | `RECORD_OFFICER_ADDED` |

### Типові values для нових explicit rules

```text
new#name
new#position
new#type
new#related_record_keys
```

Source:

```text
currentRecord.item.name
currentRecord.item.position
currentRecord.item.type
currentRecord.item.related_record_keys
```

### Питання аналітику

1. Який `recordVariant` має запускати подію?
2. Чи має бути explicit `...RecordChangeEventRule`?
3. Які values потрібні?
4. Чи values raw чи normalized?
5. Чи `related_record_keys` має наповнювати `record_keys`?
6. Чи додаткові поля payload входять у scope?

### Типові помилки

- Очікувати empty result для `recordVariant=head` у паспорті `RECORD_BENEFICIARY_ADDED`.
- Передавати `changeType=DELETE` всередині `currentRecord.item` під час `operation=append`.
- Додавати beneficiary-specific поля в DTO без потреби.
- Не вказати, що інші `recordVariant` не входять у scope цього event type-а.

### Приклад: `RECORD_BENEFICIARY_ADDED`

```text
APPEND + recordVariant=beneficiary -> RECORD_BENEFICIARY_ADDED
values: new#name, new#position, new#type, new#related_record_keys
raw values, без нормалізації
```

---

## Recipe C. `source record item / INTERNAL / DELETE` by `recordVariant`

### Коли застосовується

Коли з `source record item / INTERNAL` видаляється учасник запису.

Processor: `SourceRecordItemChangeProcessor`.

Flow:

```text
логічний тип зміни (`change.status` у фактичному записі `changes`) = DELETE
-> read currentRecord.item as SourceRecordItem
-> item.getRemoveEvent()
-> makeRecordChangeRecordChangeValues(...)
-> RecordChangeEvent
```

Важливо:

```text
У поточному `source record item / INTERNAL` DELETE-сценарій читає останній стан видаленого учасника з `currentRecord.item`, а не з `previousRecord.item`.
```

### Routing

| `recordVariant` | Event type |
|---|---|
| `head` | `RECORD_DIRECTOR_REMOVED` |
| `accountant` | `RECORD_ACCOUNTANT_REMOVED` |
| `founder` | `RECORD_FOUNDER_REMOVED` |
| `beneficiary` | `RECORD_BENEFICIARY_REMOVED` |
| `owner` | `RECORD_OWNER_REMOVED` |
| `null` або unknown | `RECORD_OFFICER_REMOVED` |

### Типові values для нових explicit rules

```text
old#name
old#position
old#type
old#related_record_keys
```

Source technically:

```text
currentRecord.item.name
currentRecord.item.position
currentRecord.item.type
currentRecord.item.related_record_keys
```

Semantics:

```text
old-state вилученого учасника
```

### Типові помилки

- Брати values з `previousRecord.item` для `sourceRecordItem / DELETE` без перевірки реального processor-а.
- Використати `ValueSource.PREVIOUS_RECORD` там, де processor передає `previousRecord=null`.
- Очікувати empty result для `recordVariant`, який routed в інший event type.

### Приклад: `RECORD_BENEFICIARY_REMOVED`

```text
DELETE + recordVariant=beneficiary -> RECORD_BENEFICIARY_REMOVED
values: old#name, old#position, old#type, old#related_record_keys
source: currentRecord.item
ValueSource.CURRENT_RECORD
```

---

## Recipe D. `source record item / INTERNAL / UPDATE` member-specific field-change

### Коли застосовується

Коли змінюється поле конкретного типу учасника.

Поточні приклади:

| `recordVariant` | Event type | Field |
|---|---|---|
| `founder` | `RECORD_FOUNDER_CAPITAL_CHANGED` | `capital.value` |
| `beneficiary` | `RECORD_BENEFICIARY_INTEREST_CHANGED` | `beneficiaryInfo.interests[0].share.min` |

Flow:

```text
логічний тип зміни (`change.status` у фактичному записі `changes`) = UPDATE
-> read currentRecord.item as SourceRecordItem
-> route by recordVariant
-> use change rules set for founder/beneficiary
```

### Питання аналітику

1. Який `recordVariant` підтримується?
2. Яке поле в `changeDetails` є trigger-ом?
3. Чи потрібні `old#value` / `new#value`?
4. Чи потрібні додаткові context fields: `name`, `position`, `type`, `related_record_keys`?
5. Що робити для unsupported recordVariant?

### Типові помилки

- Описати UPDATE member event без `recordVariant` маршрутизація.
- Очікувати error для unsupported recordVariant, хоча поточний processor повертає empty result.

---

## Recipe E. Custom/list-based event

### Коли застосовується

Коли подія не зводиться до одного поля в `changeDetails` або одного `currentRecord.item`.

Приклади:

- складний list-diff;
- подія на основі primary item у списку;
- подія, яка потребує кількох source fields;
- подія з нетиповим rule hook-ом.

### Що потрібно від аналітика

1. Шлях до списку в `currentRecord.item`.
2. Шлях до списку в `previousRecord.item`.
3. Як ідентифікувати один елемент списку.
4. Що вважається додаванням.
5. Що вважається видаленням.
6. Що вважається зміною.
7. Чи створювати одну подію на елемент або одну агреговану подію.
8. Mapping values для кожного сценарію.
9. Error behavior для дубльованих або невалідних елементів.

### Типові ризики

- Недостатньо описаний алгоритм matching-а елементів списку.
- Не визначено, що робити з кількома primary item.
- Не визначено кількість подій.
- Подія фактично потребує загального механізму, а не локального handler-а.

---

# FILE: 05_ANALYST_INTAKE_PROCESS.md

# Процес збору вимог від аналітика

Цей документ описує, як асистент має вести діалог із аналітиком від першого опису події до готового паспорта, Jira-задачі й тест-кейсів.

## 1. Старт діалогу

Якщо аналітик пише:

```text
Привіт, я хочу створити нову подію зміни запису.
```

асистент відповідає:

```text
Добре. Почнемо не з технічної анкети, а з короткого опису.
Опиши, будь ласка, подію 3–5 реченнями:
1. Що сталося в бізнес-сенсі?
2. Де це видно в даних?
3. Що користувач має побачити в журналі змін?
4. Це додавання, видалення чи зміна?
5. Якщо вже є очікуваний event type — вкажи його.
```

Мета: отримати людський опис, а не змушувати аналітика одразу знати всі технічні поля.

## 2. Перша класифікація асистента

Після вільного опису асистент сам пропонує класифікацію.

Формат відповіді:

```markdown
Я попередньо класифікую це так:

| Поле | Пропозиція | Чому |
|---|---|---|
| Event type | `RECORD_STATUS_CHANGED` | Подія описує зміну статусу. |
| Processor | `source record / INTERNAL` | Подія стосується профілю запису. |
| `changeType` | `UPDATE` | Змінюється існуюче поле. |
| Trigger | `change.fieldPath = processingState` | Схоже на зміну коду статусу. |
| Values | `old#status`, `old#processingState`, `new#status`, `new#processingState` | Потрібні old/new display і code values. |

Підтверди або скоригуй ці пропозиції.
```

Якщо є кілька варіантів, асистент пропонує їх як вибір:

```markdown
Можливі варіанти:

A. `UPDATE` field-change подія — якщо змінюється конкретне поле.
B. `APPEND` подія — якщо в даних з'являється новий запис.
C. `DELETE` подія — якщо запис вилучається.
D. Custom/list event — якщо потрібно порівнювати списки або складні об'єкти.

За твоїм описом найбільш схожий варіант A.
```

## 3. Блок 1: ідентифікатори події

Асистент уточнює або підтверджує:

1. Event type / `RecordChangeEventType`.
2. `type` джерела.
3. `sub_type` джерела.
4. Processor.
5. логічний тип зміни (`change.status` у фактичному записі `changes`).
6. Групу події.
7. `groupPriority`.
8. `isEdr`.

Асистент має пропонувати стандартні значення з наявних processor-ів.

Приклади пропозицій:

```text
Для `source record / INTERNAL` зазвичай використовується group `recordChangeHistory`, groupPriority `1`, isEdr `true`.
Для `source record item / INTERNAL` зазвичай використовується group `recordItemHistory`, groupPriority `2`, isEdr `true`.
```

Асистент не має змушувати аналітика вигадувати group, якщо вона вже визначається `RecordChangeGroupResolver` або існуючими правилами processor-а.

## 4. Блок 2: джерело зміни

Асистент уточнює:

1. Яке поле або об'єкт змінюється?
2. Де лежить нове значення?
3. Де лежить старе значення?
4. Чи є `changeDetails`?
5. `changeDetails` є trigger-ом чи джерело істини?
6. Чи є приклад `ChangeRecord`?
7. Чи є приклад Mongo-документа з source collection?

Для `UPDATE` асистент має поставити ключове питання:

```text
Для цієї події old/new values потрібно брати з `change.oldValue/newValue` чи з `previousRecord.item` і `currentRecord.item`?
```

Для `APPEND`:

```text
Чи вся подія формується з `currentRecord.item`?
```

Для `DELETE`:

```text
Де лежить останній стан видаленого запису: у `currentRecord.item` чи `previousRecord.item`?
У поточному `source record item / INTERNAL` DELETE-сценарій читає `currentRecord.item`.
```

## 5. Блок 3: mapping `RecordChangeEvent.values`

Асистент пропонує таблицю values.

Формат:

| Key у `values` | Source path | Source type | Required | Normalization | Default / missing behavior |
|---|---|---|---|---|---|
| `old#value` | `previousRecord.item.names.fullName` | `PREV_DATA` | так | `COMPANY_FULL_NAME` для порівняння | якщо немає — уточнити |
| `new#value` | `currentRecord.item.names.fullName` | `DATA` | так | `COMPANY_FULL_NAME` для порівняння | якщо немає — уточнити |

Асистент має сам запропонувати стандартний mapping залежно від recipe.

Для `APPEND` member event:

| Key | Source |
|---|---|
| `new#name` | `currentRecord.item.name` |
| `new#position` | `currentRecord.item.position` |
| `new#type` | `currentRecord.item.type` |
| `new#related_record_keys` | `currentRecord.item.related_record_keys` |

Для `DELETE` member event:

| Key | Source |
|---|---|
| `old#name` | `currentRecord.item.name` |
| `old#position` | `currentRecord.item.position` |
| `old#type` | `currentRecord.item.type` |
| `old#related_record_keys` | `currentRecord.item.related_record_keys` |

Для simple `UPDATE` field-change:

| Key | Source |
|---|---|
| `old#value` | `previousRecord` або `change.oldValue` |
| `new#value` | `currentRecord` або `change.newValue` |

## 6. Блок 4: нормалізація

Асистент не має питати “чи потрібна нормалізація?” абстрактно. Він має запропонувати варіанти.

```markdown
Для цього поля можливі варіанти:

A. Без нормалізації — записуємо raw value.
B. `COMPANY_FULL_NAME` — якщо це повна назва запису.
C. `WHITESPACE_PRESERVE_CASE` — якщо потрібно прибрати зайві пробіли, але зберегти регістр.
D. `WHITESPACE_LOWER_CASE` — якщо пробіли і регістр незначущі.
E. `CANONICAL_CODE` — якщо це технічний код, наприклад `processingState`.

За описом я пропоную варіант ...
```

Асистент уточнює два рівні:

1. нормалізація для порівняння;
2. нормалізація для запису в `values`.

## 7. Блок 5: skip/error behavior

Асистент формує таблицю:

| Ситуація | Тип | Очікувана поведінка |
|---|---|---|
| `changeType` не той | `NO_TARGET_EVENT` / інший сценарій | Саме цей event type не створюється. |
| Немає потрібного `change.fieldPath` | `NO_TARGET_EVENT` | Подія не створюється. |
| Values однакові після нормалізації | `NO_TARGET_EVENT` | Подія не створюється. |
| `currentRecord.item` відсутній і required | `INPUT_PARSE_ERROR` | `InputParseException` / `INPUT_INPUT_PARSE_ERROR`. |
| Payload парситься, але порушує контракт | `INPUT_VALIDATION_ERROR` | `InputValidationException`. |
| Optional field missing | `CREATE_WITHOUT_VALUE` | Подія створюється без цього key. |

Асистент має окремо попереджати:

```text
Якщо processor може створити інший event type, не називаємо це помилкою і не очікуємо empty result усього processor-а.
```

## 8. Блок 6: тест-кейси

Асистент сам пропонує базову TC table за recipe.

Обов'язковий формат:

| TC | Сценарій | Вхідні дані | Очікуваний результат | Покриття |
|---|---|---|---|---|

Для `UPDATE` field-change мінімум:

1. positive change;
2. no relevant changeDetails;
3. normalized equal values;
4. missing old value;
5. missing new value;
6. blank value behavior;
7. wrong `changeType`;
8. parse error;
9. value normalization.

Для `APPEND` member event мінімум:

1. positive full mapping;
2. extra fields ignored;
3. recordVariant uppercase;
4. recordVariant with spaces;
5. missing optional fields;
6. raw values not normalized;
7. related_record_keys to record_keys;
8. real non-APPEND сценарій, якщо перевіряється;
9. parse error.

Для `DELETE` member event мінімум:

1. positive full mapping;
2. `currentRecord.item`, not `previousRecord.item`;
3. missing optional fields;
4. raw values;
5. related_record_keys to record_keys;
6. wrong recordVariant means not this event type;
7. parse error.

## 9. Перевірка узгодженості

Перед генерацією паспорта асистент має показати короткий review:

```markdown
## Перевірка консистентності

- Event type відповідає правилу іменування: так/ні.
- Processor визначений: так/ні.
- `changeType` відповідає сценарію: так/ні.
- Source of truth визначено: так/ні.
- `currentRecord.item.changeType` не використовується як джерело маршрутизації: так/ні.
- `old#` / `new#` відповідають сценарію: так/ні.
- Нормалізація описана: так/ні/не потрібна.
- Negative TC не вимагають empty result там, де можливий інший event type: так/ні.
- Error behavior описаний: так/ні.
- Відкриті питання: ...
```

Якщо є критична суперечність — не генерувати фінальний паспорт, доки вона не вирішена.

## 10. Генерація артефактів

Після узгодження асистент видає:

1. паспорт події;
2. Jira task;
3. TC table;
4. список припущень;
5. список питань для розробника, якщо вони лишились;
6. за потреби — інструкцію для тестувальника.

## 11. Перехід до реалізації

Коли аналітик надає zip модуля:

1. асистент не починає одразу змінювати код;
2. аналізує релевантний processor, rule classes, tests, docs;
3. готує implementation plan;
4. показує план;
5. після підтвердження змінює код і документацію.

## 12. Перший тестовий прогін процесу

Рекомендована подія: `RECORD_STATUS_CHANGED`.

Причина:

- це `source record / INTERNAL / UPDATE`;
- є changeDetails trigger;
- є `currentRecord.item` і `previousRecord.item`;
- є нормалізація;
- є required і optional values;
- можна добре перевірити базову методологію.

Після цього другий прогін: `RECORD_ADDRESS_CHANGED` або одна з beneficiary подій.


---

# Обов'язковий етап: технічний контракт

Після уточнюючих питань і до створення паспорта асистент має сформувати короткий технічний контракт.

Асистент не має одразу переходити від вільного опису до задачі або коду. Спочатку потрібно показати користувачу, як саме асистент зрозумів подію:

```text
Я зрозумів подію так:
- бізнес-сенс: ...
- event type: ...
- processor: ...
- логічний тип зміни (`change.status` у фактичному записі `changes`): ...
- джерело істини: ...
- values: ...
- коли подія не створюється: ...
- помилки: ...
- чи це стандартна реалізація: ...

Підтверди або скоригуй.
```

Тільки після підтвердження цього блоку можна формувати паспорт і задачу.

---

# Як пропонувати варіанти

Асистент має не лише питати, а й пропонувати стандартні варіанти.

Приклад:

```text
Ти описав зміну назви запису. Для поточного модуля це схоже на стандартну `source record / INTERNAL / UPDATE` подію.

Пропоную:
- event type: `RECORD_NAME_CHANGED`;
- trigger: зміна поля `names.fullName` або іншого підтвердженого поля назви;
- values: `old#name`, `new#name` або актуальні keys за існуючим паспортом;
- джерело істини: `previousRecord.item` і `currentRecord.item`.

Підтверди, яке саме поле є джерелом зміни у Mongo/ChangeRecord.
```

---

# Якщо вимога виходить за стандартний підхід

Якщо під час діалогу видно, що подія потребує нестандартної реалізації, асистент має сказати це до етапу коду.

Формат:

```text
Ця вимога не виглядає як стандартна подія зміни запису на базі існуючого rule/processor сценарій. Я можу підготувати паспорт, задачу, технічний контракт і варіанти реалізації, але зміну коду варто передати розробнику для окремої оцінки.
```


## Контрольна точка після погодження тест-кейсів

Після того як аналітик погодив TC, наступним кроком завжди є не код і не фінальна Jira-задача, а погодження тестових Mongo/dev-даних для QA. Асистент має активувати окремий checkpoint:

```text
Тест-кейси погоджені. Перед формуванням `QA_<ALIAS>.md` потрібно погодити тестові Mongo-дані.
```

Для `UPDATE`-події асистент запитує: `collection`, `document_id`, `record_key`, `document_id`, `type/sub_type`, поточне значення поля, нове значення для позитивного TC, приклади для negative/normalization TC, дозвіл на багаторазову зміну запису, потребу rollback.

Якщо аналітик ще не має таких даних, асистент фіксує `Mongo-дані: placeholders` і може сформувати лише шаблонний QA-пакет, не готовий до виконання на dev.

---

# FILE: 06_TEMPLATES.md

# Шаблони артефактів

Цей документ містить заготовки, які асистент має використовувати під час створення події зміни запису.

## 1. Шаблон першої відповіді аналітику

```markdown
Добре. Почнемо з короткого опису, без технічної анкети.

Опиши, будь ласка, подію 3–5 реченнями:

1. Що сталося в бізнес-сенсі?
2. Де це видно в даних?
3. Що користувач має побачити в журналі змін?
4. Це додавання, видалення чи зміна?
5. Якщо вже є очікуваний event type — вкажи його.

Після цього я запропоную processor, event type, логічний тип зміни, mapping values і список питань для уточнення.
```

## 2. Шаблон попередньої класифікації

```markdown
Я попередньо класифікую подію так:

| Поле | Пропозиція | Обґрунтування |
|---|---|---|
| Event type | `<ALIAS>` | ... |
| Processor | `<processor>` | ... |
| `type` / `sub_type` | `<type>` / `<sub_type>` | ... |
| логічний тип зміни (`change.status` у фактичному записі `changes`) | `<APPEND/UPDATE/DELETE>` | ... |
| Trigger | `<changeDetails field або currentRecord.item>` | ... |
| Очікувані values | `<old#... / new#...>` | ... |
| Нормалізація | `<тип або ні>` | ... |

Підтверди або скоригуй ці пропозиції.
```

## 3. Шаблон паспорта події зміни запису

```markdown
# <ALIAS>

[← Документ провайдера](../../record-change-processors/<PROVIDER_DOC>.md)  
[← Реєстр провайдерів](../../RECORD_CHANGE_PROCESSORS.md)  
[← README](../../../README.md)

## Короткий опис

<1–3 речення бізнес-сенсу події й технічних меж задачі.>

## Паспорт події

| Поле | Значення |
|---|---|
| Аліас події зміни запису / `RecordChangeEventType` | `<ALIAS>` |
| Провайдер | `<ProcessorClass>` |
| Тип даних джерела | `<type>` |
| Підтип даних джерела | `<sub_type>` |
| Базовий сценарій зміни | `<логічний тип зміни (`change.status` у фактичному записі `changes`)>` |
| Trigger | `<field або алгоритм>` |
| Група події | `<group>` |
| Пріоритет групи | `<groupPriority>` |
| Ознака ЄДР | `<true/false>` |
| Кількість подій | `<0..1 / 0..N>` |

## Джерело зміни

<Описати, які частини ChangeRecord використовуються: currentRecord, previousRecord, changeDetails.>

## Вхідні поля

| Шлях у джерелі | Тип значення | Обов'язкове | Для чого використовується |
|---|---|---:|---|
| `...` | `...` | так/ні | ... |

## Формування `RecordChangeEvent.values`

| Key у `values` | Source path | Source type | Required | Normalization / default |
|---|---|---|---:|---|
| `...` | `...` | `DATA` / `PREV_DATA` / `DELTA` | так/ні | ... |

## Правила нормалізації

<Описати нормалізацію для порівняння і для запису values. Якщо не застосовується — явно написати.>

## Правило створення

Подія створюється, якщо:

1. ...
2. ...
3. ...

## Коли подія не створюється

- ...

## Обробка неповних або некоректних даних

| Ситуація | Тип обробки | Очікувана поведінка | Коментар |
|---|---|---|---|
| `...` | `NO_TARGET_EVENT` / `INPUT_PARSE_ERROR` / `INPUT_VALIDATION_ERROR` / `CREATE_WITHOUT_VALUE` | ... | ... |

## Приклад вхідного `ChangeRecord`

```json
{
}
```

## Очікуваний фрагмент `RecordChangeEvent`

```json
{
  "event type": "<ALIAS>",
  "values": {
  }
}
```

## Тест-кейси

| TC | Сценарій | Вхідні дані | Очікуваний результат | Покриття |
|---|---|---|---|---|
| `TC-01` | ... | ... | ... | ... |

## Примітки для тестування

<Як правильно формувати інтеграційний тест, якщо є ризик переплутати рівень REST-запиту або запису в `changes` і item fields.>
```

## 4. Шаблон Jira-задачі

```markdown
# Створення події зміни запису `<ALIAS>`

## Суть задачі

Реалізувати створення події зміни запису `<ALIAS>` для `<type>/<sub_type>`.

## Scope

- Processor: `<ProcessorClass>`
- логічний тип зміни (`change.status` у фактичному записі `changes`): `<APPEND/UPDATE/DELETE>`
- Trigger: `<trigger>`
- Кількість подій: `<0..1 / 0..N>`

## Очікувані `RecordChangeEvent.values`

| Key | Source | Required | Normalization |
|---|---|---:|---|
| `...` | `...` | так/ні | ... |

## Правила створення

1. ...
2. ...
3. ...

## Коли подія не створюється

- ...

## Обробка помилок

| Ситуація | Очікувана поведінка |
|---|---|
| ... | ... |

## Що не входить у межі задачі

- Не змінювати external monitoring handler-и.
- Не змінювати unrelated events.
- Не додавати поза межами задачі DTO-поля.

## Acceptance Criteria

1. ...
2. ...
3. ...

## Тест-кейси

| TC | Сценарій | Вхідні дані | Очікуваний результат | Коментар |
|---|---|---|---|---|
| `TC-01` | ... | ... | ... | ... |
```

## 5. Шаблон implementation prompt

```markdown
Потрібно реалізувати подію зміни запису `<ALIAS>` у Java/Spring Boot проєкті `internal-record-change-processing-module`.

## Обмеження на читання файлів

Не роби повний аудит репозиторію.
Працюй тільки з релевантними файлами processor-а, rule classes, tests і docs.
Не читай external monitoring code/documentation, якщо це не входить у межі задачі.

Дозволені пошуки:

```text
<ALIAS>
<field>
<ProcessorClass>
<SimilarRuleClass>
RecordChangeEventRule
RecordChangeEventType
```

## Production changes

- ...

## Тести

- ...

## Documentation

- ...

## Заборонено

- Не змінювати unrelated processor-и.
- Не змінювати `DefaultRecordChangeEventProcessor`, якщо це не обов'язково.
- Не змінювати `RecordChangeEventRule`, якщо задача не про загальний механізм.
- Не змінювати external monitoring.
- Не додавати DTO-поля поза межами задачі.

## Acceptance Criteria

- ...

## Після виконання

Поверни summary:

- production-файли;
- test-файли;
- docs;
- статус тестів;
- відкриті питання.
```

## 6. Шаблон коментаря тестувальнику

```markdown
Дякую за перевірку. Це зауваження не підтверджує дефект `<ALIAS>` з такої причини:

<пояснення>

Правильне очікування для цього TC:

```text
...
```

Що потрібно змінити в TC / способі перевірки:

```text
...
```
```

Приклад для `RECORD_BENEFICIARY_ADDED / TC-10`:

```markdown
У цьому сценарії використовувався `publish-source-record-add` з `operation=append`. Це параметр test endpoint-а currentRecord-import для публікації reconstructed payload, а не спосіб задати бізнесовий `DELETE` у create-history. Поле `changeType=DELETE`, передане всередині `item`, не керує маршрутизацією processor-а.

Для перевірки `DELETE` потрібно отримати запис у `changes` з `change.status=deleted`. Якщо в результаті такого запиту створився `RECORD_BENEFICIARY_ADDED`, це треба аналізувати як дефект. Якщо ж використовувався append-сценарій currentRecord-import і фактично створився `change.status=added`, це не перевірка `DELETE` і не дефект rule-а `RECORD_BENEFICIARY_ADDED`.
```

## 7. Шаблон звіту про зміни після реалізації

```markdown
## Підсумок

<коротко, що зроблено>

## Реалізована подія зміни запису

- Event type: `<ALIAS>`
- Processor: `<ProcessorClass>`
- Scenario: `<type>/<sub_type>/<changeType>`

## Production-файли

- `...`

## Тести

- `...Test.java`
- `...Test.md`

## Документація

- `docs/record-change-events/source-record-internal/<ALIAS>.md`
- `docs/record-change-processors/...`
- `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md`

## Тест-кейси

| TC | Статус | Де покрито |
|---|---|---|
| `TC-01` | покрито | `...Test` |

## Перевірка

Тести запускались / не запускались.
Якщо запускались — які саме.

## Відкриті питання

- ...
```


---

# Шаблон короткого технічного контракту

```markdown
# Технічний контракт `<ALIAS>`

## Бізнес-сенс

...

## Технічне рішення

| Параметр | Значення |
|---|---|
| Event type | `<ALIAS>` |
| Processor | `<processor>` |
| Type/SubType | `<type> / <sub_type>` |
| RecordChangeEventType | `<APPEND/DELETE/UPDATE>` |
| Source of truth | `<currentRecord.item / previousRecord.item / changeDetails / інше>` |
| Values | `<old#... / new#...>` |
| Нормалізація | `<опис>` |
| Skip behavior | `<опис>` |
| Error behavior | `<опис>` |

## Оцінка реалізації

| Питання | Відповідь |
|---|---|
| Вкладається у стандартний підхід? | так/ні/потрібна оцінка |
| Потрібна зміна shared сценарій? | так/ні |
| Можна переходити до коду в цьому чаті? | так/ні |
```

---

# Шаблон пакета для тестувальника

```markdown
# Перевірка `<ALIAS>`

## Передумови

- Dev-середовище: `<...>`
- Тестовий документ: `<document_id>`
- Початковий стан: `<...>`

## TC-01. `<назва>`

### Бізнес-сенс

...

### REST-запит

```http
POST <endpoint>
```

```json
{
  "...": "..."
}
```

### Очікуваний `ChangeRecord`

...

### Очікуваний `RecordChangeEvent`

...

### Що не має з'явитися

...

### Типові помилки перевірки

...
```


---

## Шаблон відповіді після погодження тест-кейсів

```text
Статус етапу:
Тест-кейси та Mongo-дані погоджені.

Що виконую зараз:
Формую покроковий QA-файл. Для кожного TC буде описано:
- REST endpoint;
- request body;
- Mongo-перевірку `changes`;
- запуск `POST /api/record-change-events/process`;
- перевірку `events`;
- перевірку `processing_errors`;
- rollback.

Наступний крок після цього:
Передати QA-файл тестувальнику або використати його як основу для автоматизації.
```


## Шаблон контрольної точки QA-даних після погодження TC

```text
Статус етапу:
Тест-кейси для `<ALIAS>` погоджені.

Відкриті питання:
Потрібно погодити тестові Mongo/dev-дані для ручного QA-пакета.

Наступний крок:
Перед формуванням `QA_<ALIAS>.md` потрібно підтвердити тестові Mongo-дані.

Що потрібно від тебе:
Надай або підтверди:
- collection;
- document_id або дозвіл залишити `<DOCUMENT_ID>`;
- record_key;
- document_id, якщо потрібен;
- type/sub_type;
- поточне значення поля;
- нове значення для позитивного сценарію;
- значення для negative/normalization сценаріїв, якщо потрібні;
- чи можна змінювати запис багаторазово;
- чи потрібен rollback.
```

## Шаблон статусу для фінальної видачі

```text
Статус тест-кейсів: погоджені / чернетка
Статус Mongo-даних: погоджені / placeholders
QA-пакет готовий до виконання на dev: так / ні
```

---

## Посилення v0.22: QA-файл як практична інструкція для тестувальника

QA-пакет `05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має бути написаний як практична покрокова інструкція для тестувальника, а не як технічний опис для розробника.

Критерій готовності: тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, орієнтуватися на розширений приклад. Короткий шаблон є тільки skeleton-ом, не фінальним рівнем якості.

Перед віддачею QA-файла обов’язково застосувати checklist з `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md`. Якщо хоча б один пункт checklist не виконано, QA-файл не віддавати користувачу — спочатку виправити.

---

# FILE: 07_REVIEW_CHECKLISTS.md

# Переліки перевірок для подій зміни запису

Цей документ містить контрольні списки, які асистент має застосовувати перед генерацією паспорта, задачі, промпта на реалізацію, коду та відповіді на QA-зауваження.

## 1. Перевірка узгодженості вимог

Перед створенням паспорта перевірити:

| Перевірка | Так/ні/коментар |
|---|---|
| Є короткий бізнес-опис події. |  |
| Event type відповідає правилу іменування `LU_ADD_*`, `LU_REMOVE_*`, `LU_CHANGE_*`. |  |
| Визначено `type` і `sub_type`. |  |
| Визначено processor або зрозуміло, що потрібен новий processor. |  |
| Визначено логічний тип зміни. У фактичному записі `changes` він має відповідати `change.status`: `new`, `added`, `modified` або `deleted`. |  |
| Не використовується `currentRecord.item.changeType` як джерело маршрутизації. |  |
| Для `UPDATE` визначено, чи `changeDetails` є trigger-ом або джерелом істини. |  |
| Для `APPEND` визначено source item. |  |
| Для `DELETE` визначено, де лежить останній стан видаленого запису. |  |
| `old#` / `new#` відповідають сценарію. |  |
| Mapping `values` повний і технічно точний. |  |
| Нормалізація описана або явно не потрібна. |  |
| Missing/blank behavior описаний. |  |
| `NO_TARGET_EVENT`, інший event type, `INPUT_PARSE_ERROR`, `INPUT_VALIDATION_ERROR` не змішані. |  |
| Negative TC перевіряють саме поточний event type, якщо processor може створити інший event type. |  |
| Немає поза межами задачі DTO-полів. |  |
| Не змішані history event і external external monitoring event. |  |

Якщо хоча б одна критична перевірка не проходить — не генерувати фінальний паспорт без уточнення.

## 2. Перевірка паспорта

Перед віддачею паспорта перевірити:

| Перевірка | Так/ні/коментар |
|---|---|
| Є короткий опис події. |  |
| Є таблиця “Паспорт події”. |  |
| Вказані event type, processor, `type`, `sub_type`, логічний тип зміни і відповідний `change.status` для інтеграційної перевірки. |  |
| Описано джерело зміни. |  |
| Для `UPDATE` описано роль `changeDetails`. |  |
| Для `APPEND`/`DELETE` описано, який item читається. |  |
| Є таблиця вхідних полів. |  |
| Є таблиця формування `RecordChangeEvent.values`. |  |
| Для кожного value вказано source path і source type. |  |
| Описано нормалізацію або її відсутність. |  |
| Описано правило створення. |  |
| Описано, коли подія не створюється. |  |
| Описано error/missing behavior. |  |
| Є приклад запису `changes` або unit fixture. |  |
| Є приклад очікуваного `RecordChangeEvent`. |  |
| Є повна таблиця TC. |  |
| TC-номери не є Jira-посиланнями. |  |
| Є примітки для інтеграційного тестування, якщо є ризик помилки. |  |

## 3. Перевірка Jira-задачі

Перед віддачею тексту задачі перевірити:

| Перевірка | Так/ні/коментар |
|---|---|
| Суть задачі зрозуміла без паспорта. |  |
| Межі задачі чітко обмежені. |  |
| Вказано, що не входить у задачу. |  |
| Mapping values повністю описаний. |  |
| Acceptance Criteria не суперечать паспорту. |  |
| TC table включена в задачу. |  |
| Інтеграційні TC пояснюють, який `change.status` має з’явитися у `changes`. |  |
| Немає формулювань, які можна прочитати як “порожній result processor-а”, якщо має бути “не цей event type”. |  |
| Якщо є old/new semantics, вони узгоджені з логічним типом зміни. |  |

## 4. Перевірка промпта на реалізацію

Перед віддачею промпта на реалізацію перевірити:

| Перевірка | Так/ні/коментар |
|---|---|
| Вказано точні production-файли або чіткий спосіб їх знайти. |  |
| Вказано обмеження на читання файлів. |  |
| Вказано, що не чіпати. |  |
| Вказано точний class name `...RecordChangeEventRule`. |  |
| Не використовується застарілий `...RecordChangeEventInfo`. |  |
| Якщо event type уже є в `RecordChangeEventType`, enum не чіпати. |  |
| Якщо processor не треба змінювати, це явно написано. |  |
| Тести на нову функціональність обов'язкові. |  |
| `.md` до test class обов'язковий. |  |
| Паспорт події з TC table обов'язковий. |  |
| Не змінювати external monitoring, якщо це не входить у задачу. |  |

## 5. Перевірка коду після реалізації

Після отримання архіву зі змінами перевірити:

| Перевірка | Так/ні/коментар |
|---|---|
| Production diff мінімальний і відповідає межам задачі. |  |
| Створено або оновлено `...RecordChangeEventRule`. |  |
| Rule формує правильні `RecordValueMapping`. |  |
| `ValueSource` відповідає реальному source у processor-і. |  |
| `old#` / `new#` keys правильні. |  |
| Не змінено unrelated processor-и. |  |
| Не змінено `DefaultRecordChangeEventProcessor` без потреби. |  |
| Не змінено `RecordChangeEventRule` без потреби. |  |
| Не додано DTO-поля поза межами задачі. |  |
| Тести додані або оновлені. |  |
| `.md` тестового класу доданий або оновлений. |  |
| Паспорт події оновлений. |  |
| Processor docs оновлені, якщо потрібно. |  |
| `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md` оновлений, якщо потрібно. |  |
| YAML-файли з локальними налаштуваннями не включені в output archive без потреби. |  |

## 6. Перевірка QA-зауважень

Коли тестувальник пише, що TC не спрацював, спочатку перевірити:

| Перевірка | Пояснення |
|---|---|
| Чи тест перевіряв правильний event type? | Якщо створився інший event type, це може бути нормальна маршрутизація processor-а. |
| Чи у `changes` був правильний `change.status`? | `currentRecord.item.changeType` не керує маршрутизацією. |
| Чи endpoint відповідає сценарію? | `operation=append` у test endpoint-і currentRecord-import не є бізнесовим `APPEND` у create-history. |
| Чи TC очікував empty result там, де мав очікувати “не цей event type”? | Типова помилка для `sourceRecordItem`. |
| Чи payload відповідає source paths з паспорта? | Можливе неправильне вкладення полів. |
| Чи optional field справді відсутній, а не blank string? | Missing і blank можуть мати різну поведінку. |
| Чи очікувані values враховують правила нормалізації/default values? | Особливо для `RECORD_STATUS_CHANGED`. |
| Чи тестувальник дивився правильну колекцію / record_key / change_id? | Можлива плутанина в інтеграційній перевірці. |

## 7. Коментарі до типових QA-зауважень

### Інший event type створився в negative TC

```markdown
Це не підтверджує дефект `<ALIAS>`. У цьому processor-і маршрутизація може створити інший event type для іншого значення поля маршрутизації. У межах цього TC потрібно перевіряти, що не створено саме `<ALIAS>`. Якщо створився `<OTHER_ALIAS>`, це може бути нормальною поведінкою загального processor-а.
```

### `item.changeType` не змінив сценарій

```markdown
Це не дефект `<ALIAS>`. Для модуля журналі змін сценарій обробки визначається логічним типом зміни. У фактичному записі `changes` він задається через `change.status`: `new`, `added`, `modified` або `deleted`. Поле логічний тип зміни, передане всередині `currentRecord.item`, не керує маршрутизацією `APPEND` / `UPDATE` / `DELETE`. Для перевірки цього TC потрібно отримати запис у `changes` з відповідним `change.status`.
```

### Optional field відсутній, але подія створилась

```markdown
Це відповідає паспорту, якщо поле позначене як optional. У такому випадку подія створюється, а відповідний key у `values` не записується. Якщо очікувалась помилка або skip — це потрібно явно змінити в паспорті.
```

### Extra поля не потрапили в values

```markdown
Це відповідає межам події, якщо extra поля не описані в mapping `RecordChangeEvent.values`. Наявність поля у source payload не означає, що воно має потрапити в подію зміни запису.
```

## 8. Самоперевірка сторінки документації

Перед віддачею нового документа перевірити як senior backend-розробник:

1. Чи зрозуміло, коли подія створюється?
2. Чи зрозуміло, звідки беруться values?
3. Чи зрозуміло, що є skip, error, інший event type?
4. Чи можна за документом написати код без додаткових здогадок?
5. Чи можна за документом написати unit-тести?
6. Чи тестувальник не повторить помилку з неправильним endpoint/operation?
7. Чи документ не виглядає як набір випадкових доповнень?
8. Чи мова цілісна й англійська?
9. Чи немає застарілих назв типу `RecordChangeEventInfo`?
10. Оцінка має бути не нижче 8/10. Якщо нижче — доопрацювати або явно вказати недоліки.

## 9. Готовність до реалізації

Фіча готова до реалізації, якщо:

- підтверджено бізнес-опис;
- підтверджено технічний контракт;
- визначено event type;
- визначено processor;
- визначено логічний тип зміни й відповідний `change.status` для інтеграційної перевірки;
- визначено джерело істини;
- описано values mapping;
- описано skip/error behavior;
- є таблиця TC;
- немає відкритих blocking-питань;
- підтверджено, що задача вкладається у стандартний підхід або окремо вирішено передати її розробнику.

## 10. Готовність до передачі на перевірку

Фіча готова до передачі тестувальнику, якщо:

- production-код змінено мінімально;
- unit-тести додано або оновлено;
- `.md` поруч із test class додано або оновлено;
- паспорт події оновлено;
- processor docs / supported event types оновлено, якщо потрібно;
- підготовлено інструкції для тестувальника;
- вказано статус запуску тестів;
- архів не містить локальних `application*.yml` / `application*.yaml` із секретами;
- є звіт про змінені файли.

## 11. Перевірка стандартності реалізації

Перед зміною коду перевірити:

- чи достатньо нового або оновленого `RecordChangeEventRule`;
- чи не потрібно змінювати `DefaultRecordChangeEventProcessor`;
- чи не потрібно змінювати структуру `ChangeRecord`;
- чи не потрібен новий processor;
- чи не потрібна зміна REST-контракту;
- чи не зачіпається external monitoring;
- чи не потрібен широкий refactoring.

Якщо хоча б один пункт вказує на нестандартну зміну, код не змінювати без окремого рішення.


## Checklist: consistency review of analysis package

Перед тим як вважати analysis package готовим, перевірити:

1. Event type однаковий у всіх артефактах.
2. `type/sub_type`, processor, trigger field, old/new source і values однакові в історичному документі, Jira і traceability.
3. `document_id`, `record_key`, `document_id` не обрізані й однакові або явно placeholders.
4. `01_HISTORICAL_EVENT_<ALIAS>.md` не названий як project passport і не містить project-docs-only структуру.
5. Jira не містить сміттєвих фрагментів, обрізаних backticks, дубльованих або пошкоджених секцій.
6. Whitespace-normalization TC має приклад із реально різними пробілами або NBSP, а не візуально однакові old/new.
7. Manual QA TC, які потребують окремого Mongo-запису, позначені як unit/fixture або manual only after currentRecord approval.
8. QA-пакет не дублює повний unit/processor-набір.
9. Traceability matrix зв’язує вимоги, unit/processor TC і manual QA TC.
10. Є явний статус: чи можна передавати в реалізацію.

---

# FILE: 08_ARTIFACT_REQUIREMENTS.md

# Вхідні та вихідні артефакти для створення події зміни запису

## 1. Призначення документа

Цей документ описує, які артефакти аналітик-розробник може надати асистенту на різних етапах створення події зміни запису, які з них є обов'язковими, які бажаними, а які потрібні тільки для реалізації або QA-перевірки.

Мета — не вимагати від аналітика все одразу, але чітко розуміти, яких даних бракує для якісного паспорта, Jira-задачі, реалізації й тестування.

---

## 2. Рівні обов'язковості

| Рівень | Значення |
|---|---|
| Обов'язково | Без цього не можна коректно сформувати навіть чернетку вимог. |
| Дуже бажано | Без цього можна рухатися, але буде більше припущень і відкритих питань. |
| Потрібно для реалізації | Не блокує паспорт, але потрібне перед змінами в коді. |
| Потрібно для QA | Потрібне для конкретних REST/curl сценаріїв і очікуваних перевірок. |
| Опційно | Допомагає уточнити edge cases, але не є критичним. |

---

## 3. Артефакти аналітичного етапу

### 3.1. Бізнес-опис події

**Рівень:** обов'язково.

Аналітик має описати подію 3–5 реченнями:

- що змінилося в бізнес-сенсі;
- де це видно в даних;
- що користувач має побачити в журналі змін;
- чи це додавання, видалення або зміна;
- чи є вже очікуваний event type.

Приклад:

```text
Потрібно фіксувати зміну стану обробки запису з ЄДР. Якщо змінився код статусу, в журналі змін має з'явитися подія зі старим і новим статусом та старим і новим кодом статусу. Подія стосується `source record / INTERNAL` і має створюватися тільки для `UPDATE`.
```

---

### 3.2. Очікуваний event type

**Рівень:** бажано.

Якщо event type уже визначений, аналітик надає його явно:

```text
RECORD_STATUS_CHANGED
RECORD_BENEFICIARY_ADDED
RECORD_DIRECTOR_REMOVED
```

Якщо event type не визначений, асистент має запропонувати варіант за існуючою convention:

- `LU_CHANGE_<FIELD>` для зміни поля;
- `LU_ADD_<ROLE>` для додавання ролі/учасника;
- `LU_REMOVE_<ROLE>` для видалення ролі/учасника.

Асистент не має затверджувати новий event type без підтвердження аналітика.

---

### 3.3. Processor і тип даних

**Рівень:** обов'язково для паспорта.

Потрібно визначити:

| Параметр | Приклад |
|---|---|
| `type` | `sourceRecord`, `sourceRecordItem` |
| `sub_type` | `INTERNAL` |
| processor | `source-record-internal`, `source-record-item-internal` |
| processor | `SourceRecordChangeProcessor`, `SourceRecordItemChangeProcessor` |

Якщо аналітик не знає processor, асистент має запропонувати його за `type/sub_type`.

---

### 3.4. Тип зміни

**Рівень:** обов'язково.

Потрібно визначити реальний логічний тип зміни (`change.status` у фактичному записі `changes`):

```text
APPEND
DELETE
UPDATE
NEW
```

Важливо:

```text
логічний тип зміни (`change.status` у фактичному записі `changes`) не те саме, що поле `changeType` всередині `currentRecord.item`.
`currentRecord.item.changeType` не керує маршрутизацією APPEND / DELETE / UPDATE.
```

Якщо у тестових прикладах є `item.changeType`, асистент має уточнити, чи це випадкове payload-поле, чи аналітик помилково намагається використати його як джерело маршрутизації.

---

### 3.5. Приклад source Mongo document

**Рівень:** дуже бажано.

Це документ або фрагмент документа з MongoDB до перетворення в `ChangeRecord`.

Приклад для `source record / INTERNAL`:

```json
{
  "type": "sourceRecord",
  "sub_type": "INTERNAL",
  "source": "UACA",
  "record_key": "c_...",
  "item": {
    "status": "зареєстровано",
    "processingState": "active",
    "name": "ТОВ ..."
  }
}
```

Приклад для `source record item / INTERNAL`:

```json
{
  "type": "sourceRecordItem",
  "sub_type": "INTERNAL",
  "source": "UACA",
  "record_key": "c_...",
  "item": {
    "name": "...",
    "position": "Бенефіціар",
    "recordVariant": "beneficiary",
    "type": "person",
    "related_record_keys": ["p_..."]
  }
}
```

Цей артефакт потрібен, щоб не змішувати поля вихідного документа з полями `ChangeRecord` або `RecordChangeEvent`.

---

### 3.6. Приклад `ChangeRecord`

**Рівень:** дуже бажано, для складних подій майже обов'язково.

Потрібно показати або описати, що реально отримує `internal-record-change-processing-module`.

Приклад `UPDATE`:

```json
{
  "changeType": "UPDATE",
  "currentRecord": {
    "type": "sourceRecord",
    "sub_type": "INTERNAL",
    "item": {
      "status": "новий статус",
      "processingState": "new"
    }
  },
  "previousRecord": {
    "item": {
      "status": "старий статус",
      "processingState": "old"
    }
  },
  "changeDetails": [
    { "field": "processingState" }
  ]
}
```

Приклад `APPEND`:

```json
{
  "changeType": "APPEND",
  "currentRecord": {
    "type": "sourceRecordItem",
    "sub_type": "INTERNAL",
    "item": {
      "recordVariant": "beneficiary",
      "name": "..."
    }
  },
  "previousRecord": null,
  "changeDetails": []
}
```

---

### 3.7. JSON/config опис типу даних

**Рівень:** бажано.

Конфіг потрібен для перевірки:

- чи існують потрібні поля;
- чи поле вкладене або top-level;
- чи є поле масивом, рядком, числом або об'єктом;
- чи є normalized/generated поля;
- чи не пропонує аналітик поле, якого немає в структурі.

Якщо конфігу немає, асистент може зробити чернетку за прикладом payload, але має позначити це як припущення.

---

### 3.8. Очікувані `RecordChangeEvent.values`

**Рівень:** обов'язково для паспорта.

Для кожного ключа потрібно визначити:

| Key у `values` | Source layer | Source path | Required | Normalization | Default |
|---|---|---|---|---|---|
| `old#status` | `previousRecord.item` | `status` | ні | collapse spaces | `—` |
| `new#status` | `currentRecord.item` | `status` | ні | collapse spaces | `—` |
| `new#related_record_keys` | `currentRecord.item` | `related_record_keys` | ні | ні | ні |

Асистент має не тільки питати цю таблицю, а й пропонувати її за типовим recipe.

---

## 4. Артефакти технічного етапу

### 4.1. Актуальний zip-архів модуля

**Рівень:** потрібно для реалізації.

Перед внесенням змін у код аналітик має надати актуальний архів:

```text
internal-record-change-processing-module.zip
```

Асистент має аналізувати реальний код і не вигадувати класи або API.

---

### 4.2. Обмеження на зміну коду

**Рівень:** дуже бажано перед реалізацією.

Аналітик має сказати, чи можна:

- змінювати processor;
- додавати новий `RecordChangeEventRule`;
- змінювати `RecordChangeEventType`;
- оновлювати processor docs;
- запускати тести;
- змінювати YAML/config файли.

За замовчуванням:

```text
Не змінювати external monitoring code/documentation.
Не змінювати YAML з локальними секретами.
Не запускати тести без дозволу.
```

---

## 5. Артефакти QA-етапу

### 5.1. REST test API contract

**Рівень:** потрібно для конкретних curl/REST інструкцій.

Щоб асистент міг дати тестувальнику не абстрактний TC, а конкретний REST-запит, потрібен підтверджений контракт test endpoint-ів.

Потрібно знати:

| Питання | Приклад |
|---|---|
| Endpoint для append | `/compliance/currentRecord-import/v1.0/api/test/product-queue/publish-source-record-add` |
| Endpoint для delete | підтвердити окремо |
| Endpoint для update | підтвердити окремо |
| Як задається operation | `operation=append` |
| Як задається reference document | `document_id` |
| Чи є `preview` | так/ні |
| Чи є `gzip` | так/ні |
| Який body shape | підтверджений JSON |
| Де перевіряти результат | `changes`, `events`, `processing_errors` |

Якщо контракт не надано, асистент має використовувати шаблон і явно писати: “endpoint/payload потрібно підтвердити”.

---

### 5.2. Reference Mongo document для dev-тесту

**Рівень:** потрібно для concrete QA examples.

Потрібно надати:

```text
collection
document_id
type/sub_type
record_key
поточні релевантні поля item
```

Це дозволяє створити конкретний REST-запит під реальний dev-документ.

---

### 5.3. Очікувана перевірка після REST

**Рівень:** бажано.

Для кожного TC треба визначити:

1. чи має з'явитися запис у `changes`;
2. чи має він бути оброблений;
3. чи має з'явитися запис у `events`;
4. які ключові поля перевірити в `events`;
5. чи має бути відсутній запис у `processing_errors`;
6. чи expected behavior — інший event type, а не empty result.

---

## 6. Вихідні артефакти

### 6.1. Після аналітичної фази

Асистент має видати:

1. паспорт події;
2. Jira task;
3. TC table;
4. QA execution notes;
5. consistency review;
6. відкриті питання.

### 6.2. Після реалізації

Асистент має видати:

1. оновлений zip-архів модуля;
2. список змінених production-файлів;
3. список змінених test-файлів;
4. список змінених documentation-файлів;
5. інформацію, які тести запускались або що тести не запускались;
6. known limitations;
7. інструкцію для тестувальника.

---

# FILE: 09_QA_TEST_EXECUTION_TEMPLATE.md

# Шаблон виконання QA-перевірки для подій зміни запису

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


> Важливо: Mongo-перевірки для ручного QA оформлюються під MongoDB Compass, а не під shell. У документах потрібно давати назву колекції та JSON/Extended JSON для поля `Filter`; за потреби окремо `Sort`, `Limit` або aggregation pipeline. Не використовувати `db.collection.find(...)` у QA-інструкціях.


## Правило використання ідентифікаторів у QA-кроках

У QA-документах потрібно максимально підставляти вже відомі ідентифікатори, щоб тестувальник не працював із абстрактними placeholder-ами без пояснення.

Водночас важливо не змішувати різні типи `_id`:

| Назва в QA-документі | Що це | Коли відомий | Де використовується |
|---|---|---|---|
| `DOCUMENT_ID` або `DOCUMENT_ID` | `_id` вихідного запису в `source_records` або іншій source-колекції | відомий до старту TC, якщо аналітик надав тестовий запис | пошук source row у MongoDB Compass, поле `document_id` у REST-запиті `publish-mongo-*` |
| `CHANGE_ID_FROM_STEP_N` | `_id` нового запису в колекції `changes`, створеного після REST-запиту | стає відомий тільки після кроку пошуку в `changes` | пошук `events.change_id` і `processing_errors.change_id` |
| `RECORD_KEY` | бізнесовий ідентифікатор сутності / запису | зазвичай відомий із source row | допоміжний пошук у `changes` / `events`, але не заміна `CHANGE_ID_FROM_STEP_N` |

`DOCUMENT_ID` і `CHANGE_ID_FROM_STEP_N` — це не один і той самий ідентифікатор. Наприклад, `_id` запису в `source_records` не можна підставляти в `events.change_id` або `processing_errors.change_id`, якщо ці поля посилаються на `_id` запису з `changes`.

Якщо ідентифікатор уже відомий до виконання TC, його потрібно підставляти прямо в JSON-фільтр. Якщо ідентифікатор отримується на попередньому кроці, потрібно писати не просто `<CHANGE_ID>`, а пояснювати джерело, наприклад:

```text
CHANGE_ID_FROM_STEP_3 — значення `_id` запису з колекції `changes`, знайденого на кроці 3 цього TC.
```

Приклад для `events`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Приклад для `processing_errors`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Якщо конкретний `CHANGE_ID_FROM_STEP_N` уже був отриманий і зафіксований у межах TC, у наступних кроках бажано підставити саме його фактичне значення або явно написати, з якого кроку його взяти.

## 1. Призначення

Цей шаблон потрібен, щоб тестувальник отримував не тільки абстрактний тест-кейс, а конкретну інструкцію: які дані взяти, який REST виконати, який запис у `changes` очікується, який `RecordChangeEvent` має з'явитися і де саме перевіряти результат.

Шаблон також запобігає типовій помилці: змішуванню полів із вихідного Mongo-документа, REST payload, запису в `changes`, `currentRecord.item`, `previousRecord.item`, `changeDetails` і `RecordChangeEvent.values`.

---

## 2. Загальний формат тест-кейса для QA

```markdown
## TC-XX. <Назва сценарію>

### Бізнес-сенс
<Що перевіряє сценарій з точки зору користувача.>

### Рівень перевірки
- Unit-рівень / інтеграційний рівень / ручний REST на dev / Mongo-перевірка.

### Початковий Mongo-документ
- collection: `<collection>`
- document_id: `<id>`
- type: `<type>`
- sub_type: `<sub_type>`
- важливі поля `item`: ...

### REST-запит для створення зміни
```http
POST <endpoint>
Content-Type: application/json
```

```json
{
  "operation": "...",
  "collection": "...",
  "document_id": "...",
  "preview": false,
  "gzip": true,
  "item": {
    "...": "..."
  }
}
```

### Очікуваний запис у `changes`
```json
{
  "currentRecord": {
    "status": "<new|added|modified|deleted>",
    "type": "...",
    "sub_type": "...",
    "item": {
      "...": "..."
    }
  },
  "previousRecord": "...",
  "changeDetails": []
}
```

### Очікуваний RecordChangeEvent
```json
{
  "item": {
    "event type": "...",
    "values": {
      "...": "..."
    }
  }
}
```

### Очікувана відсутність
- Не має створюватися event type: `...`
- Не має бути запису в `processing_errors` з цим `ChangeRecord`, якщо сценарій позитивний.

### Типові помилки перевірки
- ...
```

---

## 3. Обов'язкові поля в QA-описі

Кожен QA-тест-кейс має чітко показувати:

| Блок | Для чого потрібен |
|---|---|
| Бізнес-сенс | Щоб тестувальник розумів, що перевіряє. |
| Початковий Mongo-документ | Щоб не плутати вихідні дані з `ChangeRecord`. |
| REST-запит | Щоб тестувальник не підбирав endpoint самостійно. |
| Очікуваний запис у `changes` | Щоб перевірити, що тестова операція створила правильний запис зміни. |
| Очікуваний `RecordChangeEvent` | Щоб перевірити результат модуля журналі змін. |
| Очікувана відсутність | Щоб явно фіксувати negative checks. |
| Типові помилки | Щоб уникнути хибних bug report-ів. |

---

## 4. Правила для REST-прикладів

### 4.1. Не вигадувати endpoint-и і не перепитувати відомі endpoint-и

Асистент не має вигадувати endpoint-и, але також не має перепитувати ті, що вже зафіксовані в knowledge. Для стандартної UPDATE-перевірки існуючого Mongo row використовувати:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

і body через `operations`. Endpoint уточнюється лише для нестандартного сценарію або якщо користувач прямо повідомив, що контракт стенда відрізняється.

---

### 4.2. `operation` і логічний тип зміни (`change.status` у фактичному записі `changes`)

Для інтеграційної перевірки потрібно дивитися не на `currentRecord.item.changeType`, а на фактичний `change.status` у записі `changes`.

Не можна перевіряти `DELETE` або `UPDATE`, якщо тест лише передає `changeType` всередині `item`, а у `changes` не з’являється відповідний `change.status`.

Неправильно:

```json
{
  "operation": "append",
  "item": {
    "recordVariant": "beneficiary",
    "changeType": "DELETE"
  }
}
```

Правильно:

```text
Використати endpoint або unit fixture, який реально створює запис у `changes` з `change.status=deleted`.
```

Якщо такого endpoint-а немає або він невідомий, TC має бути позначений як unit-рівень або такий, що потребує підтвердження REST-контракту.

---

### 4.3. Не змішувати `item` і `ChangeRecord`

Поля всередині `item` — це бізнес-дані конкретного currentRecord type.

Поля `change.status`, `currentRecord`, `previousRecord`, `changeDetails` — це поля шару `changes`.

Поля `event type`, `values`, `record_keys` — це шару результату події зміни запису.

У QA-описі ці шари мають бути рознесені по окремих блоках.

---

## 5. Шаблон для позитивного APPEND-сценарію

```markdown
## TC-01. Додано нового учасника

### Бізнес-сенс
Перевірити, що при додаванні нового запису `source record item / INTERNAL` із `recordVariant="beneficiary"` створюється подія зміни запису `RECORD_BENEFICIARY_ADDED`.

### Початковий Mongo-документ
- collection: `source_records`
- document_id: `<підтверджений id dev-документа>`
- type: `sourceRecordItem`
- sub_type: `INTERNAL`

### REST-запит
```http
POST /compliance/currentRecord-import/v1.0/api/test/product-queue/publish-source-record-add
```

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<id>",
  "preview": false,
  "gzip": true,
  "item": {
    "name": "ТЕСТОВИЙ БЕНЕФІЦІАР",
    "position": "Бенефіціар",
    "recordVariant": "beneficiary",
    "type": "person",
    "related_record_keys": ["p_test"]
  }
}
```

### Очікуваний запис у `changes`
- `change.status=added` / логічний тип зміни `APPEND`
- `change.collection=sourceRecordItem`
- `change.item_context=INTERNAL`
- `currentRecord.item.recordVariant=beneficiary`

### Очікуваний RecordChangeEvent
- `eventType=RECORD_BENEFICIARY_ADDED`
- `values.new#name="ТЕСТОВИЙ БЕНЕФІЦІАР"`
- `values.new#position="Бенефіціар"`
- `values.new#type="person"`
- `values.new#related_record_keys=["p_test"]`
- top-level `record_keys` містить `p_test`, якщо стандартний механізм `related_record_keys -> record_keys` застосовується в модулі.
```

Цей приклад можна використовувати тільки якщо endpoint і body shape підтверджені для поточного середовища.

---

## 6. Шаблон для негативного сценарію з іншим event type-ом

```markdown
## TC-XX. Інший `recordVariant` не створює поточний event type

### Бізнес-сенс
Перевірити, що подія `RECORD_BENEFICIARY_ADDED` не створюється, якщо `recordVariant` не дорівнює `beneficiary`.

### Важливе уточнення
Цей TC не очікує порожній результат усього `SourceRecordItemChangeProcessor`.
Якщо `recordVariant="head"`, очікувано може створитися `RECORD_DIRECTOR_ADDED`.

### Очікування
- `RECORD_BENEFICIARY_ADDED` не створюється.
- Створення іншого event type-а відповідно до маршрутизації processor-а не є дефектом цього TC.
```

---

## 7. Шаблон для сценарію не `APPEND`

```markdown
## TC-XX. Не APPEND-сценарій

### Бізнес-сенс
Перевірити, що `RECORD_BENEFICIARY_ADDED` не створюється для запису в `changes` з `change.status=deleted` або `change.status=modified`.

### Важливе уточнення
У записі `changes` має бути фактичний `change.status=deleted` або `change.status=modified`.
Поле `currentRecord.item.changeType` не керує маршрутизацією.

### Неправильна перевірка
`publish-source-record-add` + `operation=append` + `item.changeType=DELETE`.

### Правильна перевірка
Використати test endpoint або unit fixture, який реально створює:

```json
{
  "currentRecord": {
    "status": "deleted",
    "item": {
      "recordVariant": "beneficiary"
    }
  }
}
```

### Очікування
- саме `RECORD_BENEFICIARY_ADDED` не створюється;
- для `DELETE` або `UPDATE` може працювати інший processor-сценарій або інший event type поза межами цієї події.
```

---

## 8. Що асистент має додавати до QA-розділу паспорта

Для кожного TC асистент має вказати:

1. чи є TC unit-рівень або інтеграційний рівень;
2. який шар є джерелом істини;
3. чи потрібен конкретний REST;
4. чи REST-контракт підтверджений;
5. де перевіряти результат;
6. які event type-и мають бути відсутні;
7. які event type-и можуть створитися як нормальна поведінка іншої маршрутизації.


## Додаткові обов'язкові секції для реального QA-пакета

Для кожної конкретної події файл `QA_<ALIAS>.md` має також містити:

1. **REST-запит для створення зміни** — з реальним endpoint-ом `publish-source-record-patch`, `publish-source-record-add` або `publish-source-record-delete`.
2. **Фільтр для `changes`** — як знайти створений запис зміни.
3. **Фільтр для `events`** — як знайти створену подію зміни запису.
4. **Фільтр для `processing_errors`** — як перевірити, що запис не впав у помилку або навпаки впав очікувано.
5. **Правила очікування обробки** — чи потрібно запускати `POST /api/record-change-events/process`, чи обробка автоматична.
6. **Що не є дефектом** — типові хибні трактування саме для цієї події.

Базові REST-контракти та Mongo-фільтри описані у `25_QA_VERIFICATION_GUIDE.md`.
## Додаткові правила для ручного виконання

У тест-кейсах не потрібно вказувати повний фізичний URL стенда. Вказувати тільки відносний endpoint і тіло запиту. Тестувальник сам виконує запит на потрібному dev-середовищі.

Для запуску create-history у поточному процесі використовувати ручний крок:

```text
POST /api/record-change-events/process
```

```json
{
  "operation": "start"
}
```

Після REST-запиту для створення зміни тестувальник шукає запис у `changes` через MongoDB. У тест-кейсі потрібно давати конкретний Mongo-фільтр, наприклад:

```javascript
db.changes.find({
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>",
  "change.status": "<modified>"
}).sort({"date": -1})
```

Якщо для конкретного TC немає безпечного rollback, це потрібно вказати прямо. Rollback бажаний, але не є обов'язковою умовою для формування QA-пакета.


---

## 7. Обов’язковий покроковий формат для ручної QA-перевірки

Після погодження тест-кейсів QA-файл має бути перетворений із таблиці сценаріїв у послідовність дій. Недостатньо написати загально: “виконати REST, перевірити Mongo, перевірити event”. Для кожного TC потрібно показати:

1. початковий Mongo-запис і очікуваний стан перед стартом;
2. конкретний відносний REST endpoint;
3. конкретне тіло REST-запиту;
4. Mongo-запит до `changes` після REST;
5. які поля в `changes` мають бути перевірені;
6. запуск `POST /api/record-change-events/process` з body `{"operation":"start"}`;
7. Mongo-запит до `events`, бажано за `change_id`;
8. Mongo-запит до `processing_errors`;
9. очікуваний результат саме для поточного event type-а;
10. rollback або повернення baseline перед наступним TC.

Цей формат потрібен для того, щоб файл міг бути використаний як основа майбутнього автоматизованого тесту.

Якщо для конкретного TC не можна дати готове тіло REST-запиту або Mongo-запит, TC потрібно позначити як такий, що потребує уточнення, а не видавати його тестувальнику як готову інструкцію.

---

# FILE: 10_FULL_CYCLE_FEATURE_FLOW.md

# Повний цикл створення фічі для події зміни запису

## 1. Мета

Цей документ описує повний цикл створення події зміни запису: від первинного бізнес-опису до готової нової версії модуля з кодом, тестами, документацією і QA-інструкціями.

Цільова роль — **аналітик-розробник**. Це не окремо аналітик і окремо розробник, а одна людина, яка разом з моделлю веде фічу від початку до кінця. На різних етапах модель змінює роль: бізнес-аналітик, системний аналітик, технічний reviewer, Java-розробник, test designer, documentation writer.

---

## 2. Фаза 0. Старт

Аналітик пише:

```text
Привіт, я хочу створити нову подію зміни запису.
```

Асистент не починає з технічної анкети. Він просить короткий бізнес-опис:

```text
Опиши подію 3–5 реченнями: що змінилося, де це видно в даних, що користувач має побачити в журналі змін і чи є вже очікуваний event type.
```

---

## 3. Фаза 1. Первинна класифікація

Після бізнес-опису асистент:

1. визначає ймовірний processor;
2. визначає ймовірний логічний тип зміни (`change.status` у фактичному записі `changes`);
3. пропонує event type за існуючим стилем;
4. пропонує recipe;
5. пропонує базові `values`;
6. показує припущення і просить підтвердження.

Приклад відповіді:

```text
За описом це схоже на `source record / INTERNAL / UPDATE` field-change подію.
Пропоную event type: `RECORD_STATUS_CHANGED`.
Пропоную trigger: `changeDetails` містить `processingState`.
Пропоную values: `old#status`, `old#processingState`, `new#status`, `new#processingState`.
Підтверди або скоригуй.
```

---

## 4. Фаза 2. Збір аналітичних даних

Асистент поетапно збирає:

1. source Mongo document або фрагмент;
2. приклад `ChangeRecord`;
3. структуру `currentRecord.item`, `previousRecord.item`, `changeDetails`;
4. expected `RecordChangeEvent.values`;
5. normalization rules;
6. skip/error behavior;
7. test cases;
8. QA execution constraints.

Важливо: асистент не просто питає, а пропонує варіанти за recipe.

---

## 5. Фаза 3. Перевірка узгодженості

Перед генерацією паспорта асистент виконує review:

1. чи не змішано history event і external external monitoring event;
2. чи не плутається логічний тип зміни (`change.status` у фактичному записі `changes`) і `currentRecord.item.changeType`;
3. чи правильно визначено `currentRecord.item` / `previousRecord.item`;
4. чи не очікується empty result там, де має створитися інший event type;
5. чи відповідають `old#` / `new#` типу зміни;
6. чи не пропонуються out-of-scope поля;
7. чи зрозумілі TC для тестувальника;
8. чи всі поля прив'язані до правильного layer-а.

Якщо є суперечність, асистент зупиняється й просить підтвердження.

---

## 6. Фаза 4. Аналітичні артефакти

Після узгодження асистент готує:

1. паспорт події зміни запису;
2. Jira task;
3. TC table;
4. QA execution notes;
5. consistency review summary;
6. відкриті питання або підтверджені припущення.

Паспорт і задача мають бути узгоджені між собою. TC table має бути в обох артефактах.

---

## 7. Фаза 5. Підготовка до реалізації

Аналітик надає актуальний zip-архів модуля і пише:

```text
Наступний етап — створи цю подію зміни запису в модулі.
```

Асистент:

1. розпаковує архів;
2. аналізує тільки релевантні файли;
3. знаходить схожі події;
4. перевіряє `RecordChangeEventType`;
5. перевіряє processor і маршрутизація;
6. визначає production/test/docs files;
7. формує implementation plan;
8. показує план аналітику-розробнику.

Без підтвердження плану код не змінюється, якщо користувач прямо не попросив діяти без погодження.

---

## 8. Фаза 6. Реалізація

Після підтвердження асистент:

1. створює або оновлює `...RecordChangeEventRule`;
2. оновлює маршрутизація або processor тільки якщо це потрібно;
3. додає unit-тести;
4. створює або оновлює `.md` поруч із Java test class;
5. оновлює паспорт;
6. оновлює processor docs;
7. оновлює supported event type registry, якщо він є;
8. не змінює external monitoring code/documentation без прямої вимоги;
9. не включає YAML із секретами в архів.

---

## 9. Фаза 7. Тести

За замовчуванням тести не запускати без дозволу користувача.

Якщо дозвіл є:

1. запускати тільки релевантні unit-тести;
2. не запускати весь suite без потреби;
3. фіксувати команду запуску;
4. фіксувати результат;
5. якщо тест падає — або виправити, або чесно описати blocker.

---

## 10. Фаза 8. Вихідний архів

Асистент створює zip-архів оновленого модуля або patch-файлів.

У відповідь додає:

1. посилання на архів;
2. список production-файлів;
3. список test-файлів;
4. список documentation-файлів;
5. статус тестів;
6. known limitations;
7. QA notes.

---

## 11. Фаза 9. QA feedback review

Якщо тестувальник залишив зауваження, асистент:

1. читає коментарі тестувальника;
2. співставляє їх із паспортом, Jira task і кодом;
3. визначає, чи це дефект реалізації, дефект вимог, дефект тестового сценарію або недосказаність документації;
4. дає коментар до кожного зауваження;
5. за потреби оновлює паспорт/Jira wording;
6. якщо є реальний code defect — формує prompt/план виправлення або вносить fix після підтвердження.

---

## 12. Мінімальний критерії готовності

Фіча події зміни запису вважається готовою до передачі тестувальнику, якщо є:

1. погоджений паспорт;
2. погоджена Jira task;
3. TC table;
4. QA execution notes;
5. реалізація в коді;
6. unit-тести;
7. `.md` поруч із тестовими класами;
8. оновлена документація;
9. архів модуля;
10. звіт про зміни;
11. статус тестів або чітке пояснення, що тести не запускались.


---

## 9. Контрольні точки повного циклу

| Контрольна точка | Що має бути підтверджено | Що робити далі |
|---|---|---|
| Бізнес-опис підтверджено | Зрозуміло, яку зміну бачить користувач | Переходити до технічного контракту |
| Технічний контракт підтверджено | Визначено event type, processor, `changeType`, джерело істини, values | Створювати паспорт і задачу |
| Паспорт і задача підтверджені | Вимоги, TC і поведінка помилок узгоджені | Готувати план реалізації |
| План реалізації підтверджено | Зрозуміло, що змінюється в коді | Виконувати стандартну реалізацію |
| Код підготовлено | Є production-код, тести, документація | Готувати архів і звіт |
| Інструкції для тестувальника підготовлено | Є конкретний або шаблонний план перевірки | Передавати на dev/QA |

---

## 10. Оцінка стандартності перед реалізацією

Перед зміною коду асистент має відповісти:

```text
Чи вкладається ця задача у стандартну реалізацію події зміни запису?
```

Якщо відповідь “так”, можна переходити до коду після підтвердження плану.

Якщо відповідь “ні” або “потрібна окрема оцінка”, асистент не змінює код. Він завершує аналітичні артефакти і рекомендує передати технічну реалізацію розробнику.


## Обов'язковий пакет для тестувальника перед передачею фічі

Після реалізації стандартної події зміни запису асистент має підготувати окремий файл:

```text
QA_<ALIAS>.md
```

Цей файл не замінює паспорт події. Він має бути практичною інструкцією для тестувальника: який REST викликати, які Mongo-фільтри виконати, який `RecordChangeEvent` очікувати, де перевірити `processing_errors` і які результати не є дефектом.

Якщо немає реального `document_id`, `document_id`, dev base URL або підтвердженого endpoint-а, асистент не має вигадувати ці значення. Він має залишити явні placeholders і додати блок “Потрібно надати перед тестуванням”.
## Уточнення для етапу підготовки перевірки

На етапі підготовки пакета для тестувальника асистент не має вимагати повний фізичний URL dev-сервісів. У документації вказуються відносні endpoint-и, а тестувальник сам виконує їх на потрібному стенді.

Для поточного процесу запуск create-history вважати ручним і завжди додавати в QA-пакет крок:

```text
POST /api/record-change-events/process
```

```json
{
  "operation": "start"
}
```

Якщо для тестування потрібні конкретні записи, аналітик може надати приклади існуючих dev-даних. Асистент використовує ці приклади для формування тест-кейсів, але не вважає їх глобально затвердженими тестовими записами.

Пошук щойно створених записів `changes` виконується Mongo-запитами до відповідної колекції. У QA-пакеті потрібно давати фільтри, достатні для ручної перевірки: `record_key`, `type`, `sub_type`, `status`, дата, очікуваний `changeDetails` або `change_id`, якщо він відомий.

Rollback бажано описувати, але якщо він не є безпечним або очевидним — це не блокує передачу фічі на перевірку. У такому випадку QA-пакет має чесно зафіксувати, що повернення dev-даних виконується тестувальником вручну або за домовленістю команди.


---

## Обов’язковий перехід після погодження TC

Після того як аналітик погодив перелік тест-кейсів і Mongo-дані, наступний крок не “сформувати загальний QA-пакет”, а “сформувати покрокову інструкцію виконання кожного TC”.

Асистент має явно сказати:

```text
Тест-кейси і Mongo-дані погоджені. Переходжу до формування покрокового QA-файла: для кожного TC буде REST-запит, Mongo-запит до `changes`, запуск `/api/history`, перевірка `events`/`processing_errors` і rollback.
```

Без цього кроку QA-пакет не вважається готовим для тестувальника.


## Обов’язкова фаза між погодженням TC і фінальними артефактами

Після фази погодження тест-кейсів додається окрема фаза: **погодження тестових Mongo/dev-даних**.

Асистент має виконати її до Jira / Confluence / QA / implementation package. Не можна після погодження TC одразу переходити до запиту архіву модуля або до формування фінального QA-пакета.

Вихід цієї фази — один із двох статусів:

| Статус | Наслідок |
|---|---|
| Mongo-дані погоджені | QA-пакет формується з конкретними `document_id`, `record_key`, `document_id`, old/new values і готовий до dev-виконання |
| Mongo-дані не погоджені | QA-пакет формується тільки як шаблон із placeholders і статусом `готовий до виконання на dev: ні` |


## Етап: післяаналітичний consistency review

Після формування `analysis_package.zip` і перед переходом до реалізації виконується окремий етап: `Consistency review`.

Ціль етапу — перевірити, що документ події зміни запису, Jira-задача, QA-пакет, traceability matrix і draft implementation plan не суперечать одне одному.

Особливо перевірити:

- однаковість і повноту ідентифікаторів;
- відсутність сміття після генерації;
- правильне розділення unit/processor TC і manual QA TC;
- правильний статус manual QA даних;
- коректне використання `01_HISTORICAL_EVENT_<ALIAS>.md` як результату заповнення шаблону, а не project passport.

Якщо етап не пройдено, не переходити до запиту актуального архіву модуля.

---

# FILE: 11_SOURCE_LAYERS_AND_PAYLOADS.md

# Шари даних і payload-и: як не змішувати рівні даних

## 1. Призначення

Цей документ описує шари даних, які беруть участь у створенні події зміни запису. Він потрібен, щоб у паспортах, Jira-задачах і тест-кейсах не змішувалися поля з різних рівнів.

Типова помилка: тест-кейс описує `changeType=DELETE`, але передає його всередині `currentRecord.item`, хоча маршрутизація реально визначається логічним типом зміни (`change.status` у фактичному записі `changes`).

---

## 2. Основні шари

| Шар | Що це | Приклад поля |
|---|---|---|
| Вихідний Mongo-документ | Початковий або змінений документ у MongoDB/currentRecord-import контурі | `source_records.item.processingState` |
| REST-запит для перевірки | Запит тестувальника до test endpoint-а, який створює зміну | `operation=append`, `document_id` |
| Запис у `changes` / `ChangeRecord` | Запис зміни, який споживає модуль журналі змін | `change.status`, `currentRecord`, `previousRecord`, `changeDetails` |
| `currentRecord.item` | Новий/актуальний або технічний стан запису в межах change layer | `currentRecord.item.name` |
| `previousRecord.item` | Попередній стан для UPDATE або інших сценаріїв, якщо processor його використовує | `previousRecord.item.processingState` |
| `changeDetails` | Опис змінених полів, часто індикатор зміни | `changeDetails[].field=processingState` |
| RecordChangeEvent | Результат роботи модуля журналі змін | `eventType`, `values` |
| `processing_errors` | Результат помилкової обробки change record | `INPUT_INPUT_PARSE_ERROR` |

---

## 3. Вихідний Mongo-документ

Це документ, який існує в базі до тестової операції або після неї.

Приклад:

```json
{
  "collection": "source_records",
  "type": "sourceRecord",
  "sub_type": "INTERNAL",
  "item": {
    "status": "зареєстровано",
    "processingState": "active"
  }
}
```

Вихідний документ не завжди дорівнює `currentRecord` у записі `changes`. Між ним і записом у `changes` може бути currentRecord-import/test endpoint або інший механізм формування зміни.

---

## 4. REST-запит для перевірки

Це запит, який тестувальник виконує, щоб спровокувати зміну через test endpoint currentRecord-import. У поточному QA-процесі тестувальник працює вручну й використовує відносні endpoint-и, без фіксації фізичного dev base URL у документації.

Приклад запиту:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "...",
  "preview": false,
  "gzip": true,
  "item": {
    "recordVariant": "beneficiary",
    "name": "..."
  }
}
```

Важливо: `operation=append` у test endpoint-і є параметром публікації reconstructed payload у product-чергу. Це не те саме, що логічний тип зміни `APPEND` у create-history. Для create-history потрібно дивитися на фактичний запис у `changes`, насамперед на `change.status`.

Поле `item.changeType`, якщо його передали всередині `item`, не є джерелом маршрутизації для create-history module, якщо окремо не підтверджено інше.

---

## 5. Запис у `changes` / `ChangeRecord`

Запис у `changes` — це основний вхід модуля `internal-record-change-processing-module`. У коді його можна описувати як `ChangeRecord`, але в Mongo це фактичний документ із `currentRecord`, `previousRecord`, `changeDetails` та службовими полями обробки.

Типова структура:

```json
{
  "currentRecord": {
    "status": "modified",
    "type": "sourceRecord",
    "sub_type": "INTERNAL",
    "item": {}
  },
  "previousRecord": {
    "item": {}
  },
  "changeDetails": []
}
```

### Важливо

Сценарій обробки визначається з `change.status` у фактичному записі `changes`:

| `change.status` | Логічний тип зміни |
|---|---|
| `new` | `NEW` |
| `added` | `APPEND` |
| `modified` | `UPDATE` |
| `deleted` | `DELETE` |

`currentRecord.item.changeType` не визначає сценарій обробки.

---

## 6. `currentRecord.item`

`currentRecord.item` — це частина `ChangeRecord.currentRecord`, яка зазвичай містить актуальний стан запису або запис, що додається/видаляється.

Приклади:

```json
{
  "currentRecord": {
    "item": {
      "recordVariant": "beneficiary",
      "name": "..."
    }
  }
}
```

Для `APPEND` у `source record item / INTERNAL` values зазвичай беруться з `currentRecord.item` і записуються як `new#...`.

Для `DELETE` у поточних `source record item / INTERNAL` подіях останній стан видаленого запису також технічно читається з `currentRecord.item`, але values записуються як `old#...`.

---

## 7. `previousRecord.item`

`previousRecord.item` використовується для попереднього стану, найчастіше в `UPDATE` field-change подіях.

Приклад:

```json
{
  "previousRecord": {
    "item": {
      "processingState": "old"
    }
  },
  "currentRecord": {
    "item": {
      "processingState": "new"
    }
  }
}
```

Не можна автоматично припускати, що `DELETE` завжди читає `previousRecord.item`. Це залежить від processor-а.

---

## 8. `changeDetails`

`changeDetails` може бути:

1. індикатором, що поле змінилось;
2. джерелом old/new values;
3. деталізованим описом змін у списку.

Для кожної події потрібно явно визначити роль `changeDetails`.

Приклад для `RECORD_STATUS_CHANGED`:

```text
`change.fieldPath=processingState` використовується як індикатор, що треба перевірити зміну статусу.
Source of truth для значень — `previousRecord.item.processingState` і `currentRecord.item.processingState`.
```

Якщо це не підтверджено, асистент має поставити уточнююче питання.

---

## 9. RecordChangeEvent

Результат роботи модуля журналі змін.

Приклад:

```json
{
  "item": {
    "event type": "RECORD_STATUS_CHANGED",
    "values": {
      "old#processingState": "old",
      "new#processingState": "new"
    }
  }
}
```

`RecordChangeEvent.values` не є вхідним payload-ом. Це очікуваний результат.

---

## 10. `record_keys`

Якщо в `values` є ключ, який семантично завершується на `related_record_keys`, стандартний механізм може додати ці значення у top-level `record_keys`.

Приклад:

```text
valueName = new.related_record_keys
Mongo key = new#related_record_keys
record_keys += значення related_record_keys
```

Не треба описувати ручне заповнення `record_keys`, якщо в модулі вже є стандартний механізм.

---

## 11. `processing_errors`

Якщо запис у `changes` не можна обробити через parse/internal error, він має потрапити в error сценарій.

Приклад:

```text
currentRecord.item missing/null/unparseable → InputParseException → INPUT_INPUT_PARSE_ERROR → processing_errors
```

У паспорті потрібно розділяти:

- normal skip — подія не створюється, це не помилка;
- інший event type — нормальна поведінка маршрутизації;
- parse error — payload невалідний;
- validation error — payload парситься, але бізнесово неконсистентний;
- internal error — помилка в обробці або збереженні.

---

## 12. Приклад типової помилки

Неправильний тест:

```json
{
  "operation": "append",
  "item": {
    "recordVariant": "beneficiary",
    "changeType": "DELETE"
  }
}
```

Неправильне очікування:

```text
Оскільки item.changeType=DELETE, RECORD_BENEFICIARY_ADDED не має створюватися.
```

Правильне пояснення:

```text
`operation=append` у test endpoint-і є параметром публікації reconstructed payload. Він сам по собі не доводить, що перевіряється бізнесовий `APPEND` у create-history. `item.changeType` є зайвим payload-полем і не керує маршрутизацією. Якщо потрібно перевірити `DELETE`, треба отримати запис у `changes` з `change.status=deleted`.
```

---

## 13. Правило для всіх паспортів і Jira-задач

У кожному тест-кейсі треба явно писати, на якому шарі знаходиться поле.

Погано:

```text
changeType=DELETE
```

Добре:

```text
Реальний `change.status=deleted` / логічний тип зміни `DELETE`, сформований на рівні REST-запиту або запису в `changes`.
Не `currentRecord.item.changeType`.
```


## Реальні приклади шарів із поточних модулів

### Source row у `source_records`

Для `source record / INTERNAL` source row має зовнішні поля `collection`, `type`, `sub_type`, `source`, `document_id`, `record_key`, `record_keys`, `status`, а бізнес-дані лежать у вкладеному `item`. Наприклад, для подій зміни профілю важливими можуть бути `item.names.fullName`, `item.names.shortName`, `item.status`, `item.processingState`, `item.related_record_keys`.

### Запис у `changes`

`changes` містить поточний стан у `currentRecord`, попередній стан у `previousRecord` і список змінених полів у `changeDetails`. Тип зміни для create-history визначається з `change.status`:

| `change.status` | Тип зміни create-history |
|---|---|
| `new` | `NEW` |
| `added` | `APPEND` |
| `modified` | `UPDATE` |
| `deleted` | `DELETE` |

Тому `currentRecord.item.changeType` не є джерелом маршрутизації. Якщо таке поле є всередині `item`, воно є частиною бізнес-payload і не перемикає processor між `APPEND`, `UPDATE` і `DELETE`.

### Запис у `events`

`events` містить `type=recordChange`, `sub_type=INTERNAL`, вкладений `item` з `event type`, `group`, `groupPriority`, `isEdr`, `date`, `year`, `values`, а також `record_key`, `source=RECORD_CHANGE_AUTOMATION`, `change_id` і `deleted=false`.

`change_id` — ключовий технічний зв'язок із `_id` запису з `changes`. Для точного QA-пошуку краще використовувати саме його, якщо `_id` зміни відомий.

### Запис у `processing_errors`

`processing_errors` містить `change_id`, копію `originalRecord`, `errorType`, `errorMessage`, `errorDetails`, продубльовані `type`, `subType`, `rootId`, а також службові поля обробки.

Приклад `errorType=PRODUCER_NOT_FOUND` означає, що для `type/subType` не знайдено processor. Це корисний сигнал для аналізу підтримки processor-а, але не обов'язково дефект конкретної події, якщо тестувався непідтримуваний processor.

---

# FILE: 12_EXAMPLE_WALKTHROUGH_RECORD_STATUS_CHANGED.md

# Example walkthrough: RECORD_STATUS_CHANGED

## 1. Навіщо цей приклад

Це еталонний приклад проходження процесу створення події зміни запису на відносно простій `UPDATE` field-change події.

Подія `RECORD_STATUS_CHANGED` зручна для першого прогону, бо в ній видно:

- `source record / INTERNAL` processor;
- `UPDATE` сценарій;
- `changeDetails` як індикатор зміни;
- `currentRecord.item` і `previousRecord.item`;
- `old#...` і `new#...` values;
- правила нормалізації;
- skip-сценарії;
- parse/error-сценарії;
- QA-перевірку на рівні `ChangeRecord` і `RecordChangeEvent`.

---

## 2. Стартовий бізнес-опис від аналітика

Аналітик може почати так:

```text
Потрібно фіксувати зміну стану обробки запису з ЄДР. Якщо у `source record / INTERNAL` змінився код статусу, користувач має побачити в журналі змін старий і новий статус, а також старий і новий код статусу. Подія має створюватися тільки для UPDATE.
```

---

## 3. Первинна класифікація асистента

Асистент відповідає:

```text
За описом це схоже на стандартну `source record / INTERNAL / UPDATE` field-change подію.

Пропоную:
- event type: `RECORD_STATUS_CHANGED`;
- processor: `source-record-internal` / `SourceRecordChangeProcessor`;
- trigger: `changeDetails` містить поле `processingState`;
- джерело істини: `previousRecord.item.processingState` і `currentRecord.item.processingState`;
- values: `old#status`, `old#processingState`, `new#status`, `new#processingState`.

Підтверди, чи `processingState` є основним полем для визначення зміни, а `status` є display value.
```

---

## 4. Уточнення джерело істини

Асистент питає:

```text
Для `UPDATE` уточни, будь ласка:
1. `changeDetails` тільки показує, що поле змінилось, чи з нього треба брати old/new values?
2. Старе значення статусу беремо з `previousRecord.item`, а нове з `currentRecord.item`?
3. Якщо `changeDetails` містить тільки `field=processingState` без old/new value — подія все одно має створюватися?
```

Рекомендована відповідь для цього recipe:

```text
`changeDetails` використовується як індикатор зміни `processingState`.
Source of truth для значень — `previousRecord.item.processingState` і `currentRecord.item.processingState`.
Якщо `changeDetails` містить тільки назву поля, цього достатньо, якщо currentRecord/previousRecord містять значення.
```

---

## 5. Пропозиція mapping-у

Асистент пропонує таблицю:

| Key у `values` | Source layer | Source path | Required | Normalization | Default |
|---|---|---|---|---|---|
| `old#status` | `previousRecord.item` | `status` | ні | display normalization | `—`, якщо відсутній/blank |
| `old#processingState` | `previousRecord.item` | `processingState` | так для створення | `trim().toLowerCase()` | немає |
| `new#status` | `currentRecord.item` | `status` | ні | display normalization | `—`, якщо відсутній/blank |
| `new#processingState` | `currentRecord.item` | `processingState` | так для створення | `trim().toLowerCase()` | немає |

Асистент має попросити підтвердити правила нормалізації:

```text
Підтверди, що `processingState` нормалізується через `trim().toLowerCase()`, а `status` є optional display value і при відсутності/blank записується як `—`.
```

---

## 6. Skip/error behavior

Рекомендована логіка для паспорта:

### Подія створюється

```text
- `change.status=modified` / логічний тип зміни `UPDATE`;
- `changeDetails` містить `processingState`;
- `previousRecord.item.processingState` присутній і не blank після trim;
- `currentRecord.item.processingState` присутній і не blank після trim;
- normalized old/new `processingState` відрізняються.
```

### Подія не створюється як normal skip

```text
- changeType не `UPDATE`;
- `changeDetails` не містить `processingState`;
- old/new `processingState` після нормалізації однакові;
- old або new `processingState` відсутній/blank, якщо для цієї події прийнято skip, а не validation error.
```

### Parse/error behavior

```text
- `currentRecord.item` або `previousRecord.item` не парситься — parse/error сценарій;
- якщо модуль має стандартний `readRequiredItem`, використовувати його поведінку;
- якщо конкретна подія має custom validation — описати окремо.
```

---

## 7. Чернетка TC table

| TC | Сценарій | Вхідні дані | Очікуваний результат | Покриття |
|---|---|---|---|---|
| `TC-01` | Статус змінився | `changeType=UPDATE`, `change.fieldPath=processingState`, old `active`, new `stopped` | Створюється `RECORD_STATUS_CHANGED`, values містять old/new status і processingState | Rule/processor test |
| `TC-02` | `changeDetails` не містить `processingState` | `change.fieldPath=name` | `RECORD_STATUS_CHANGED` не створюється | Rule/processor test |
| `TC-03` | old/new code однакові | old `active`, new `ACTIVE` після normalization однакові | `RECORD_STATUS_CHANGED` не створюється | Rule test |
| `TC-04` | old code blank | `previousRecord.item.processingState=" "` | Подія не створюється або validation behavior згідно з підтвердженим правилом | Rule test |
| `TC-05` | new code blank | `currentRecord.item.processingState=""` | Подія не створюється або validation behavior згідно з підтвердженим правилом | Rule test |
| `TC-06` | status display missing | `processingState` змінено, `status` відсутній | Подія створюється, display status записується як `—`, якщо підтверджено | Rule test |
| `TC-07` | field-only changeDetails | `changeDetails=[{"field":"processingState"}]`, values у currentRecord/previousRecord | Подія створюється | Processor test |
| `TC-08` | Не UPDATE | реальний `change.status=added` / логічний тип зміни `APPEND` або `DELETE` | Саме `RECORD_STATUS_CHANGED` не створюється | Processor/інтеграційний тест |

У реальному паспорті TC треба адаптувати під підтверджену поведінку модуля.

---

## 8. QA execution note

Для QA потрібно розділити:

1. як тестувальник створює `UPDATE` change;
2. який `ChangeRecord` має вийти;
3. який `RecordChangeEvent` очікується.

Не можна перевіряти `UPDATE` через append endpoint, якщо він формує `change.status=added` / логічний тип зміни `APPEND`.

Якщо REST test API contract невідомий, у паспорті треба писати:

```text
Конкретний REST-запит потребує підтвердження currentRecord-import/test API contract. Для перевірки на unit-рівні використовувати fixture з реальним `change.status=modified` / логічний тип зміни `UPDATE`.
```

---

## 9. Очікуваний паспорт

Паспорт має містити:

1. призначення події;
2. processor і source currentRecord;
3. trigger;
4. mapping values;
5. normalization rules;
6. skip/error behavior;
7. TC table;
8. QA execution notes;
9. implementation hints тільки якщо це доречно.

---

## 10. Очікувана Jira task

Jira task має містити:

1. коротку суть задачі;
2. scope;
3. trigger;
4. mapping;
5. normalization;
6. acceptance criteria;
7. TC table;
8. QA notes;
9. out of scope;
10. посилання на паспорт.

---

## 11. Що має зробити асистент перед реалізацією

Після надання zip-архіву модуля асистент має перевірити:

1. чи існує `RecordChangeEventType.RECORD_STATUS_CHANGED`;
2. чи є processor `SourceRecordChangeProcessor`;
3. чи є rule class для цієї події;
4. чи відповідає реалізація паспорту;
5. які тести вже є;
6. які docs треба оновити.

Якщо реалізація вже існує, асистент не має дублювати код, а має зробити gap analysis.

---

# FILE: 13_TECHNICAL_CONTRACT_TEMPLATE.md

# Шаблон технічного контракту події зміни запису

## 1. Призначення

Технічний контракт — це короткий узгоджений опис події зміни запису, який є єдиним джерелом правди між бізнес-описом, паспортом, задачею, тест-кейсами, реалізацією і перевіркою тестувальником.

Контракт створюється після первинного збору вимог і до генерації паспорта або задачі. Якщо контракт не підтверджений, асистент не має переходити до реалізації коду.

---

## 2. Шаблон

```markdown
# Технічний контракт події зміни запису `<ALIAS>`

## Бізнес-сенс

Короткий опис людською мовою: що сталося і що користувач має побачити в журналі змін.

## Базові параметри

| Параметр | Значення |
|---|---|
| Event type | `<ALIAS>` |
| Тип даних | `<type>` |
| Підтип | `<sub_type>` |
| Processor | `<processor-id>` / `<ProcessorClass>` |
| Тип зміни | `APPEND` / `DELETE` / `UPDATE` |
| Група подій | `<group>` |
| Пріоритет групи | `<number>` |
| `isEdr` | `true` / `false` |

## Умова створення

Описати точну умову, коли створюється саме ця подія.

Приклад:

- `логічний тип зміни (`change.status` у фактичному записі `changes`) = UPDATE`;
- `changeDetails` містить поле `processingState`;
- `previousRecord.item.processingState` і `currentRecord.item.processingState` після нормалізації відрізняються.

## Джерело істини для значень

| Значення | Джерело |
|---|---|
| Старий стан | `previousRecord.item` / `change.oldValue` / інше |
| Новий стан | `currentRecord.item` / `change.newValue` / інше |
| Індикатор зміни | `changeDetails[].field` / інше |

## Мапінг `RecordChangeEvent.values`

| Key у `values` | Джерело | Обов'язкове | Нормалізація | Значення за замовчуванням |
|---|---|---|---|---|
| `old#...` | `previousRecord.item...` | так/ні | так/ні, яка саме | немає / `—` |
| `new#...` | `currentRecord.item...` | так/ні | так/ні, яка саме | немає / `—` |

## Поведінка, коли подія не створюється

Описати нормальні сценарії, коли саме цей event type не створюється.

Важливо: якщо processor може створити інший event type, це не є помилкою поточної події.

## Помилки

| Сценарій | Очікувана поведінка |
|---|---|
| Відсутній required container | `INPUT_INPUT_PARSE_ERROR` / інше |
| Payload не парситься | `INPUT_INPUT_PARSE_ERROR` / інше |
| Бізнесово неконсистентні дані | `INPUT_VALIDATION_ERROR` / skip / інше |

## Пов'язані event type-и

Перелік подій, які можуть створюватися в тому самому processor-і для інших умов.

## Поза межами задачі

Що явно не змінюється:

- інші event type-и;
- external monitoring;
- shared processor-и;
- загальні механізми;
- DTO-поля, які не потрібні для цієї події.

## Рішення щодо реалізації

| Питання | Відповідь |
|---|---|
| Вкладається у стандартний підхід? | так/ні/потрібна оцінка розробника |
| Очікувані production-файли | ... |
| Очікувані test-файли | ... |
| Очікувані documentation-файли | ... |
| Потрібне підтвердження перед кодом? | так |
```

---

## 3. Правило використання

Після заповнення контракту асистент має показати його користувачу і явно попросити підтвердження. Тільки після підтвердження можна створювати паспорт, задачу, план реалізації або код.


## Статус тестів і QA-даних

У технічному контракті або поруч із ним потрібно фіксувати:

```text
Статус тест-кейсів: погоджені / чернетка
Статус Mongo-даних: погоджені / placeholders
QA-пакет готовий до виконання на dev: так / ні
```

Це не замінює QA-пакет, але дає зрозуміти, чи можна вже виконувати ручну перевірку на dev.

---

# FILE: 14_TEST_DATA_REQUESTS.md

# Запит тестових даних для перевірки події зміни запису

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


## 1. Призначення

Щоб підготувати тестувальнику конкретні запити і очікувані результати, асистенту потрібні реальні або безпечні тестові дані. Без них можна створити тільки шаблон перевірки, але не повністю готову інструкцію.

---

## 2. Що потрібно запросити перед підготовкою інструкції для тестувальника

| Артефакт | Для чого потрібен | Коли обов'язковий |
|---|---|---|
| Базова адреса dev-середовища | Щоб сформувати повний REST-запит | Для готових `curl` |
| Опис test endpoint-ів | Щоб не вигадувати REST-контракт | Для готових `curl` |
| `document_id` | Щоб тестувальник працював з конкретним документом | Для інтеграційної перевірки |
| Початковий документ у MongoDB | Щоб знати before-state | Для `UPDATE` і `DELETE` |
| Очікуване нове значення | Щоб сформувати after-state | Для `UPDATE` і `APPEND` |
| Чи можна змінювати документ | Щоб не псувати небезпечні дані | Завжди для dev-перевірки |
| Як перевіряти `events` | Щоб описати expected result | Завжди |
| Як перевіряти `processing_errors` | Для error-сценаріїв | Якщо є parse/validation TC |
| Чи потрібне повернення даних назад | Щоб описати cleanup/rollback | Якщо тест змінює shared документ |

---

## 3. Питання до користувача

```text
Щоб підготувати готові інструкції для тестувальника, надай, будь ласка:

1. Яке dev-середовище використовуємо?
2. Які REST endpoint-и дозволено використовувати для створення `APPEND`, `UPDATE`, `DELETE` змін?
3. Який `document_id` можна безпечно використовувати для тесту?
4. Який поточний стан потрібних полів у цьому документі?
5. Які значення потрібно встановити для позитивного сценарію?
6. Де тестувальник має перевірити створений event: назва колекції, ключові фільтри?
7. Чи потрібно після тесту повертати документ у початковий стан?
```

---

## 4. Важливе обмеження

Якщо REST-контракт або тестові дані не підтверджені, асистент не має вигадувати точні запити. У такому випадку він формує шаблон із позначками:

```text
<DEV_BASE_URL>
<REFERENCE_DOCUMENT_ID>
<CONFIRMED_ENDPOINT>
<EXPECTED_EVENT_FILTER>
```

---

## 5. Особливе правило для `changeType`

Не пропонувати тестувальнику перевіряти `DELETE` або `UPDATE` через поле `currentRecord.item.changeType`, якщо маршрутизація у модулі визначається логічним типом зміни (`change.status` у фактичному записі `changes`).

Правильно:

```text
тип зміни має формуватися рівень REST-запиту або запису в `changes`-рівнем або безпосередньо логічний тип зміни (`change.status` у фактичному записі `changes`).
```


## Додаткові дані, потрібні для готових QA REST-прикладів

Щоб сформувати не абстрактний, а готовий до виконання QA-пакет, потрібно попросити:

1. `document_id` існуючого row для `publish-source-record-patch` або `publish-source-record-delete`.
2. `document_id` для `publish-source-record-add`.
3. `collection`, зазвичай `source_records`.
4. Поточні значення полів, які будуть змінені.
5. Нові значення для кожного TC.
6. `record_key` і `document_id`, щоб після запуску знайти `changes` і `events`.
7. Чи можна багаторазово змінювати цей запис на dev-середовищі.
8. Чи потрібно використовувати унікальний тестовий маркер у значеннях.
9. Чи увімкнений ручний endpoint `POST /api/record-change-events/process`, або обробка відбувається автоматично.

Якщо ці дані не надані, асистент має підготувати QA-пакет із placeholders, але не вигадувати реальні ідентифікатори.
## Уточнення щодо тестових даних і dev-середовища

Для цього процесу не потрібно запитувати або фіксувати повний фізичний dev base URL. У документах достатньо відносних endpoint-ів, тому що тестувальник виконує перевірку вручну і сам знає, де фізично розташовані сервіси.

Замість постійних затверджених `document_id` / `document_id` для `source record / INTERNAL` або `source record item / INTERNAL` аналітик може надати конкретні приклади існуючих записів з dev-даних. На основі цих прикладів асистент формує тестові сценарії, REST-тіла і Mongo-фільтри.

Під час підготовки QA-пакета потрібно попросити аналітика надати:

- приклад існуючого Mongo row, якщо сценарій змінює наявний запис;
- `document_id` цього row або його безпечний placeholder;
- `record_key`, `document_id`, `type`, `sub_type`, `source`, `collection`;
- поточні значення полів, які будуть змінюватися;
- бажані нові значення для тесту;
- чи потрібно після тесту повертати значення назад;
- якщо потрібне додавання нового row — `document_id` запису, від якого можна наслідувати службові поля.

Запуск create-history вважати ручним. У QA-пакеті обов'язково вказувати крок:

```text
POST /api/record-change-events/process
```

```json
{
  "operation": "start"
}
```

Для пошуку `changes` не вимагати окремого API. Використовувати Mongo-запити до відповідної колекції за `record_key`, `type`, `sub_type`, `status`, `date` та очікуваним `changeDetails`.

## Підтвердження Mongo-запису для конкретної події

Якщо аналітик надає Mongo-запис у процесі роботи над конкретною подією, асистент має зафіксувати його як кандидат для QA, але перед фінальним QA-пакетом уточнити:

- чи цей запис можна змінювати на dev;
- яке поле змінюється для позитивного сценарію;
- яке значення потрібно поставити як new value;
- чи потрібен rollback;
- чи цей запис використовується лише як приклад структури або саме як тестовий запис.

Випадкові записи, надані раніше для інших цілей, не переносити автоматично в новий QA-пакет.


## Запит тестових Mongo/dev-даних після погодження TC

Після погодження тест-кейсів асистент має окремо запросити тестові Mongo/dev-дані. Для `UPDATE`-події мінімальний перелік:

- `collection`;
- `document_id` або безпечний placeholder;
- `record_key`;
- `document_id`, якщо потрібен;
- `type/sub_type`;
- поточне значення поля;
- нове значення для позитивного сценарію;
- значення для negative/normalization сценаріїв, якщо потрібні;
- чи можна змінювати запис багаторазово;
- чи потрібен rollback.

Якщо ці дані не надані, у QA-документі має бути статус: `шаблон, тестові Mongo-дані не погоджені`, а в запитах мають лишатися placeholders.

---

# FILE: 15_IMPLEMENTATION_SAFETY_RULES.md

# Правила безпечної реалізації змін у коді

## 1. Призначення

Цей документ визначає, коли асистент може переходити до зміни коду, а коли має зупинитися і передати оцінку розробнику.

Мета — не перетворювати стандартну подію зміни запису на неконтрольований refactoring або зміну архітектури.

---

## 2. Перед зміною коду обов'язково

1. Має бути підтверджений технічний контракт події.
2. Має бути актуальний zip-архів модуля.
3. Має бути визначено, чи подія вкладається у стандартний підхід.
4. Має бути показаний план реалізації.
5. Користувач має підтвердити план.

Без підтвердженого плану асистент не змінює код.

---

## 3. Стандартна реалізація

Задача вважається стандартною, якщо її можна реалізувати одним із типових способів:

- додати або оновити один `...RecordChangeEventRule`;
- зареєструвати rule у наявному processor-і;
- додати просту гілку маршрутизація-а в існуючому item/factory-класі;
- додати unit-тести і документацію;
- не змінювати загальні processor-и;
- не змінювати формат `ChangeRecord`;
- не змінювати структуру `RecordChangeEvent`;
- не додавати новий загальний механізм.

Для таких задач асистент може після підтвердження плану виконувати реалізацію самостійно.

---

## 4. Нестандартна або ризикована реалізація

Асистент має зупинитися на етапі паспорта, задачі, технічного контракту і плану, якщо бачить хоча б одну ознаку:

1. Потрібно змінювати `DefaultRecordChangeEventProcessor` або shared сценарій.
2. Потрібно змінювати структуру `ChangeRecord` або спосіб формування changes.
3. Потрібен новий processor.
4. Потрібна нова модель diff-у списків або складний list matching.
5. Потрібна зміна currentRecord-import/test REST-контракту.
6. Потрібно змінювати external monitoring-частину.
7. Потрібно додавати багато нових DTO-полів без підтвердженого контракту.
8. Потрібна зміна загального механізму помилок або черги `processing_errors`.
9. Потрібна міграція існуючих подій зміни запису.
10. Задача впливає на кілька processor-ів або багато event type-ів одночасно.

У таких випадках асистент має написати:

```text
Ця задача не вкладається у стандартну реалізацію події зміни запису. Я можу підготувати паспорт, задачу, технічний контракт і варіанти реалізації, але зміну коду потрібно передати розробнику для окремої оцінки архітектурного впливу.
```

---

## 5. Формат рішення перед кодом

Перед реалізацією асистент має вивести коротку оцінку:

```markdown
## Оцінка реалізації

| Питання | Відповідь |
|---|---|
| Вкладається у стандартний підхід? | Так / Ні / Потрібна оцінка розробника |
| Чи потрібна зміна shared-механізму? | Так / Ні |
| Чи потрібна зміна processor-а? | Так / Ні |
| Чи потрібен новий rule-клас? | Так / Ні |
| Чи потрібні нові DTO-поля? | Так / Ні |
| Чи можна реалізовувати в межах цього чату? | Так / Ні |
```

---

## 6. Заборонені дії без окремого підтвердження

- не робити широкий refactoring;
- не змінювати external monitoring;
- не змінювати `application*.yml` / `application*.yaml`;
- не запускати весь набір тестів без дозволу;
- не змінювати REST-контракт;
- не додавати нову інфраструктуру;
- не змінювати багато unrelated файлів;
- не виправляти сусідні події “заодно”.

---

# FILE: 16_EVENT_TYPE_CLASSIFIER.md

# Класифікатор типу події зміни запису

## 1. Призначення

Класифікатор допомагає асистенту не ставити аналітику зайві питання і швидко запропонувати стандартний підхід за описом події.

Асистент має спочатку прийняти короткий опис людською мовою, а потім сам запропонувати найближчий тип події.

---

## 2. Дерево рішень

### 2.1. Змінилось одне поле профілю запису

Ознаки:

- бізнес-опис: “змінився статус”, “змінилась назва”, “змінився код”, “змінилась адреса”;
- тип даних: зазвичай `sourceRecord`;
- тип зміни: `UPDATE`;
- є old/new значення.

Рекомендований підхід:

```text
source record / INTERNAL / UPDATE field-change
```

Типові values:

```text
old#...
new#...
```

Приклади:

- `RECORD_STATUS_CHANGED`;
- `RECORD_NAME_CHANGED`;
- `RECORD_ADDRESS_CHANGED`;
- `RECORD_MAIN_INDUSTRY_CODE_CHANGED`.

---

### 2.2. Додано новий запис або учасника

Ознаки:

- тип зміни: `APPEND`;
- є новий `currentRecord.item`;
- подія описує появу запису.

Рекомендований підхід:

```text
APPEND record event
```

Типові values:

```text
new#...
```

Для `source record item / INTERNAL` часто застосовується маршрутизація за `recordVariant`.

---

### 2.3. Видалено запис або учасника

Ознаки:

- тип зміни: `DELETE`;
- потрібно показати, кого або що вилучено;
- останній стан може лежати в `currentRecord.item`, якщо так працює processor.

Рекомендований підхід:

```text
DELETE record event
```

Типові values:

```text
old#...
```

Важливо: не припускати автоматично, що джерело істини — `previousRecord.item`.

---

### 2.4. Змінився елемент у списку

Ознаки:

- потрібно знайти відповідний елемент у старому й новому списку;
- зміна не зводиться до одного простого поля;
- потрібне зіставлення за ключем, ідентифікатором або набором полів.

Рекомендований підхід:

```text
list-based або custom rule
```

Це може бути нестандартна реалізація. Асистент має зупинитися і попросити оцінку розробника, якщо такого механізму немає в поточному проєкті.

---

### 2.5. Подія залежить від кількох умов або кількох полів

Ознаки:

- потрібно порівнювати кілька полів;
- є складна бізнес-логіка;
- одна зміна може створювати або не створювати подію залежно від комбінації полів.

Рекомендований підхід:

```text
custom RecordChangeEventRule з shouldCreate/postProcessValues
```

Перед кодом потрібна оцінка: чи вкладається це у стандартні hook-и `RecordChangeEventRule`, чи потрібна зміна загального механізму.

---

## 3. Формат відповіді асистента після класифікації

```text
За описом це схоже на стандартну подію типу: <тип>.

Пропоную:
- event type: ...
- processor: ...
- changeType: ...
- джерело істини: ...
- values: ...

Потрібно підтвердити:
1. ...
2. ...
```

---

## 4. Якщо класифікація невпевнена

Асистент не має вигадувати. Він має запропонувати 2–3 варіанти і пояснити різницю.

```text
Це може бути або field-change подія, або list-based подія. Якщо зміна визначається одним полем — беремо стандартний field-change recipe. Якщо потрібно порівнювати елементи списку — потрібна окрема оцінка реалізації.
```

---

# FILE: 17_TRACEABILITY_MATRIX_TEMPLATE.md

# Матриця простежуваності вимог

## 1. Призначення

Матриця простежуваності показує, як бізнес-вимога проходить через технічний контракт, паспорт, тест-кейси, код і документацію.

Вона потрібна, щоб жодна вимога не загубилася і щоб тестувальник бачив, які саме сценарії покривають кожне правило.

---

## 2. Шаблон

| Бізнес-вимога | Технічне правило | Тест-кейси | Код | Документація |
|---|---|---|---|---|
| Користувач бачить зміну статусу | `changeDetails` містить `processingState`, old/new коди відрізняються | `TC-01`, `TC-02` | `ProcessingStateChangedRecordChangeEventRule` | `docs/record-change-events/source-record-internal/RECORD_STATUS_CHANGED.md` |
| Відсутній display status не блокує подію | missing/blank `status` → `—` | `TC-05`, `TC-06` | `postProcessValues` або value normalization | секція “Нормалізація” |

---

## 3. Коли створювати

Матриця потрібна для:

- складних подій;
- подій із багатьма тест-кейсами;
- подій, де вже були зауваження тестувальника;
- подій, які мають ризик плутанини між `currentRecord`, `previousRecord`, `changeDetails`, REST payload і `RecordChangeEvent`.

Для дуже простих подій матриця може бути короткою.

---

## 4. Правила

1. Кожна бізнес-вимога має мати хоча б один тест-кейс або явне пояснення, чому вона не тестується автоматично.
2. Кожен тест-кейс має посилатися на конкретне технічне правило.
3. Якщо вимога не має коду, потрібно позначити її як документаційну або поза межами реалізації.
4. Якщо код змінюється, документація має бути оновлена в тій самій логіці.
5. Номери TC не мають бути Jira-посиланнями.

---

# FILE: 18_QA_FEEDBACK_TRIAGE.md

# Розбір зауважень тестувальника

## 1. Призначення

Цей документ описує, як асистент має аналізувати зауваження тестувальника після передачі фічі на перевірку.

Мета — відрізнити реальний дефект коду від помилки в паспорті, задачі, тест-кейсі, REST-запиті або тестових даних.

---

## 2. Класифікація зауваження

Кожне зауваження потрібно віднести до одного з типів:

| Тип | Що означає |
|---|---|
| Дефект коду | Реалізація не відповідає підтвердженому технічному контракту. |
| Дефект вимоги | Паспорт або задача містять некоректне очікування. |
| Дефект тест-кейса | Сценарій описаний двозначно або перевіряє не те. |
| Некоректний спосіб перевірки | Наприклад, `DELETE` перевіряється через `operation=append`. |
| Проблема тестових даних | Дані в dev не відповідають передумовам TC. |
| Проблема середовища | Затримка обробки, не той стенд, не той deployment. |
| Потрібне уточнення | Недостатньо даних для висновку. |

---

## 3. Алгоритм аналізу

1. Прочитати коментар тестувальника.
2. Витягти фактичний запит або дії.
3. Визначити шар даних: REST operation, `ChangeRecord`, `currentRecord.item`, `previousRecord.item`, `changeDetails`, `RecordChangeEvent`.
4. Зіставити фактичний сценарій із технічним контрактом.
5. Перевірити паспорт і задачу: чи не було там двозначності.
6. Перевірити поточний код, якщо є архів або доступний фрагмент.
7. Дати висновок: дефект коду чи ні.
8. Підготувати коментар тестувальнику.
9. Якщо потрібно — запропонувати виправлення паспорта, задачі, QA-інструкції або коду.

---

## 4. Формат відповіді на зауваження

```markdown
### Коментар до зауваження по `<TC>`

Висновок: `<дефект коду / дефект тест-кейса / некоректний спосіб перевірки / інше>`.

Причина:
...

Правильне очікування:
...

Що потрібно змінити:
- код: так/ні;
- паспорт: так/ні;
- задача: так/ні;
- тест-кейс або спосіб перевірки: так/ні.
```

---

## 5. Приклад: інший event type не є дефектом поточної події

Якщо тестувальник перевіряє `RECORD_BENEFICIARY_ADDED`, але передає `recordVariant=head`, processor може створити `RECORD_DIRECTOR_ADDED`.

Це не дефект `RECORD_BENEFICIARY_ADDED`, якщо технічний контракт каже, що negative TC перевіряє відсутність саме `RECORD_BENEFICIARY_ADDED`, а не порожній результат усього processor-а.

Коментар:

```text
Для `recordVariant=head` очікуваною поведінкою загального `sourceRecordItem` processor-а є створення події керівного елемента. У межах цього TC потрібно перевіряти тільки те, що не створюється саме `RECORD_BENEFICIARY_ADDED`.
```

---

## 6. Приклад: `item.changeType` не керує маршрутизацією

Якщо тестувальник викликає append endpoint з `operation=append`, але всередині `item` передає `changeType=DELETE`, це не є перевіркою `DELETE`-сценарію.

Коментар:

```text
Тип зміни для модуля журналі змін визначається логічним типом зміни (`change.status` у фактичному записі `changes`), який формується на рівні REST-запиту або запису в `changes`. Поле `changeType` всередині `currentRecord.item` не перемикає сценарієм роботи processor-а. Тому цей запит перевіряє APPEND-сценарій, а не DELETE.
```

---

# FILE: 19_CODEBASE_MAP_FOR_STANDARD_EVENTS.md

# Карта коду для стандартних подій зміни запису

Цей файл допомагає швидко знайти типові місця змін у модулі створення подій зміни запису. Він не замінює аналіз актуального архіву: перед реалізацією завжди потрібно перевірити фактичну структуру поточного коду.

## 1. Загальні правила

Для стандартної події зміни запису зазвичай потрібно знайти:

1. processor-клас, який приймає `ChangeRecord`;
2. item/DTO-клас, який читається з `currentRecord.item` або `previousRecord.item`;
3. клас правила події `...RecordChangeEventRule`;
4. enum `RecordChangeEventType`;
5. resolver групи/пріоритету;
6. unit-тести processor-а або rule-класу;
7. паспорт події в `docs/record-change-events/...`;
8. processor-документацію;
9. файл підтримуваних типів подій, якщо він є в модулі.

Не змінювати shared-механізми без окремої потреби й підтвердження.

## 2. `source record / INTERNAL`

Типовий сценарій: зміна поля профілю запису через `UPDATE`.

### Production

| Призначення | Типове місце |
|---|---|
| Processor | `.../handler/company/companyprofile/SourceRecordChangeProcessor.java` |
| Правила подій | `.../handler/company/companyprofile/events/` |
| Item/DTO | класи `SourceRecord...` у model/processor або відповідному package |
| Enum event type-ів | `RecordChangeEventType.java` |
| Група/пріоритет | `RecordChangeGroupResolver.java` або фактичний resolver у поточному коді |

### Tests

| Призначення | Типове місце |
|---|---|
| Unit-тести rule-класів | `src/test/java/.../companyprofile/events/` |
| Processor-level тести | `src/test/java/.../companyprofile/` |
| Опис test class | `.md` файл поруч із Java test class |

### Docs

| Призначення | Типове місце |
|---|---|
| Паспорт події | `docs/record-change-events/source-record-internal/<ALIAS>.md` |
| Processor-документація | `docs/record-change-processors/SOURCE_RECORD_INTERNAL.md` |
| Реєстр підтримуваних подій | `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md` або `docs/SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md`, якщо існує |

### Типова реалізація

Для стандартної `UPDATE` field-change події зазвичай достатньо:

- створити або оновити `Lu...RecordChangeEventRule`;
- визначити trigger через `changeDetails` або порівняння `currentRecord.item` / `previousRecord.item`;
- визначити `old#...` і `new#...` values;
- додати unit-тести;
- оновити паспорт і processor docs.

## 3. `source record item / INTERNAL`

Типовий сценарій: подія залежить від `currentRecord.item.recordVariant`.

### Production

| Призначення | Типове місце |
|---|---|
| Processor | `.../handler/company/companymember/SourceRecordItemChangeProcessor.java` |
| Item/маршрутизація | `.../model/processor/SourceRecordItem.java` або фактичний item-клас |
| Правила подій | `.../handler/company/companymember/events/` |
| Enum event type-ів | `RecordChangeEventType.java` |
| Група/пріоритет | `RecordChangeGroupResolver.java` або фактичний resolver у поточному коді |

### Tests

| Призначення | Типове місце |
|---|---|
| Unit-тести rule-класів | `src/test/java/.../companymember/events/` |
| Processor-level тести | `src/test/java/.../companymember/` |
| Routing-тести item-класу | `src/test/java/.../model/processor/SourceRecordItemTest.java` або фактичний шлях |
| Опис test class | `.md` файл поруч із Java test class |

### Docs

| Призначення | Типове місце |
|---|---|
| Паспорт події | `docs/record-change-events/source-record-internal/<ALIAS>.md` |
| Processor-документація | `docs/record-change-processors/SOURCE_RECORD_INTERNAL.md` |
| Реєстр підтримуваних подій | `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md` або `docs/SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md`, якщо існує |

### Routing за `recordVariant`

Для стандартних member-подій `recordVariant` маршрутизує запис до конкретного event type-а. Це означає:

| `recordVariant` після `trim().toLowerCase()` | Приклад event type-а |
|---|---|
| `head` | `RECORD_DIRECTOR_ADDED` / `RECORD_DIRECTOR_REMOVED` |
| `founder` | `RECORD_FOUNDER_ADDED` / `RECORD_FOUNDER_REMOVED` |
| `beneficiary` | `RECORD_BENEFICIARY_ADDED` / `RECORD_BENEFICIARY_REMOVED` |

Для паспорта конкретного event type-а негативний сценарій має перевіряти відсутність саме цього event type-а. Не потрібно очікувати порожній результат усього processor-а, якщо інший `recordVariant` закономірно створює іншу подію зміни запису.

## 4. Що перевірити перед зміною коду

Перед реалізацією стандартної події перевірити:

1. чи event type уже є в `RecordChangeEventType`;
2. чи вже існує схожа подія;
3. чи потрібен новий `RecordChangeEventRule`;
4. чи достатньо змінити item/маршрутизація-клас;
5. чи потрібно оновити processor або краще його не чіпати;
6. чи існують потрібні test packages;
7. чи є processor docs і supported event types;
8. чи є ризик, що задача нестандартна.

## 5. Що не робити в стандартній задачі

Не робити без окремого підтвердження:

- зміну `DefaultRecordChangeEventProcessor`;
- зміну загального `RecordChangeEventRule`;
- зміну контракту `ChangeRecord`;
- новий механізм порівняння списків;
- зміни в external monitoring;
- зміни в currentRecord-import REST;
- broad refactoring;
- додавання DTO-полів, які не потрібні для values;
- включення локальних YAML із секретами в результат.

---

# FILE: 20_STANDARD_VS_CUSTOM_EVENT_DECISION.md

# Як визначити: стандартна чи нестандартна подія зміни запису

Перед переходом до зміни коду асистент має класифікувати задачу. Це обов'язковий крок. Якщо подія не вкладається у стандартний підхід, асистент не має самостійно змінювати код без окремої оцінки розробника.

## 1. Стандартна подія

Подія вважається стандартною, якщо виконуються більшість умов:

- використовується існуючий processor;
- тип зміни вже підтримується processor-ом: `APPEND`, `DELETE` або `UPDATE`;
- є схожий recipe або схожа вже реалізована подія;
- достатньо створити або оновити один `RecordChangeEventRule`;
- маршрутизація уже існує або додається локально в існуючий item/processor-клас;
- values беруться з `currentRecord.item`, `previousRecord.item`, `changeDetails` або їх простої комбінації;
- не потрібна зміна загального механізму обробки черги;
- не потрібна зміна контракту `ChangeRecord`;
- не потрібна зміна currentRecord-import або external monitoring;
- можна покрити задачу локальними unit-тестами й processor-level тестами.

Приклади стандартних подій:

| Тип | Приклад |
|---|---|
| Зміна простого поля | `RECORD_STATUS_CHANGED` |
| Додавання учасника за `recordVariant` | `RECORD_BENEFICIARY_ADDED` |
| Видалення учасника за `recordVariant` | `RECORD_BENEFICIARY_REMOVED` |
| Просте `old#` / `new#` mapping | зміна назви, статусу, коду |

## 2. Нестандартна подія

Подія є нестандартною, якщо є хоча б один суттєвий пункт:

- потрібен новий processor;
- потрібна зміна `DefaultRecordChangeEventProcessor` або іншого shared-механізму;
- потрібна зміна `ChangeRecord` contract;
- потрібна нова модель порівняння списків;
- потрібен новий механізм нормалізації, що має працювати для багатьох подій;
- потрібні зміни в currentRecord-import;
- потрібні зміни в external monitoring;
- потрібні зміни в REST API;
- потрібна міграція даних;
- потрібно зберігати нові службові дані;
- вимога зачіпає кілька processor-ів одночасно;
- подія не може бути надійно протестована локальними unit-тестами без зміни інфраструктури.

## 3. Рішення асистента

Після аналізу асистент має явно написати один із висновків.

### Варіант 1. Стандартна реалізація

```text
Задача вкладається у стандартну реалізацію. Очікувані зміни локальні: новий/оновлений RecordChangeEventRule, маршрутизація, тести й документація. Можна переходити до плану реалізації по файлах.
```

### Варіант 2. Потрібна обережна локальна реалізація

```text
Задача переважно стандартна, але має ризик: <опис ризику>. Я можу підготувати план реалізації, але перед зміною коду потрібно підтвердити цей ризик.
```

### Варіант 3. Потрібна оцінка розробника

```text
Задача не вкладається у стандартний підхід, бо потребує <опис нестандартної зміни>. Я підготую паспорт, задачу, технічний контракт і варіанти реалізації, але не буду змінювати код без окремої оцінки розробника.
```

## 4. Що робити, якщо задача нестандартна

Якщо задача нестандартна, асистент все одно може підготувати:

- бізнес-опис;
- технічний контракт;
- паспорт;
- задачу;
- тест-кейси;
- варіанти реалізації;
- ризики;
- питання до розробника.

Але крок зміни коду блокується до окремого підтвердження.

## 5. Типові червоні прапорці

Зупинитися і попросити підтвердження, якщо:

- аналітик описує `DELETE`, але очікує `new#...` values;
- аналітик описує `APPEND`, але очікує `old#...` values;
- `changeType` пропонується передавати всередині `currentRecord.item`;
- для конкретного event type-а очікується порожній результат усього processor-а, хоча інший event type має створитися;
- потрібно додати поля в DTO тільки тому, що вони є в source payload, але вони не потрібні для values;
- одна подія починає описувати поведінку кількох unrelated event type-ів;
- тест-кейс змішує source Mongo document, REST payload, `ChangeRecord` і `RecordChangeEvent`.

---

# FILE: 21_IMPLEMENTATION_FILE_PLAN_TEMPLATE.md

# Шаблон плану реалізації по файлах

Цей шаблон використовується після підтвердження технічного контракту і перед зміною коду. Асистент має показати цей план аналітику-розробнику й отримати підтвердження.

## 1. Резюме реалізації

```text
Подія: <ALIAS>
Processor: <type/sub_type>
Тип зміни: <APPEND/DELETE/UPDATE>
Оцінка: стандартна / переважно стандартна / нестандартна
Очікувана стратегія: <короткий опис>
```

## 2. Production-файли

| Файл | Дія | Причина |
|---|---|---|
| `<path>/Lu...RecordChangeEventRule.java` | створити / оновити | Описує mapping і правила створення події |
| `<path>/SourceRecordItem.java` | оновити / не чіпати | Routing за `recordVariant` |
| `<path>/Company...RecordChangeEventProcessor.java` | не чіпати / оновити | Processor-сценарій уже підтримує сценарій або потребує зміни |
| `RecordChangeEventType.java` | перевірити / оновити | Event type має існувати в enum |
| `RecordChangeGroupResolver.java` | перевірити / оновити | Група, пріоритет, `isEdr` |

Правило: якщо виявилося, що треба змінювати shared-механізм, зупинитися і перейти до оцінки нестандартної задачі.

## 3. Test-файли

| Файл | Дія | Що покриває |
|---|---|---|
| `<path>/Lu...RecordChangeEventRuleTest.java` | створити / оновити | Mapping values, normalization, optional fields |
| `<path>/Company...RecordChangeEventProcessorTest.java` | оновити за потреби | Повний processor-сценарій |
| `<path>/Company...ItemTest.java` | оновити за потреби | Routing, наприклад `recordVariant` |
| `<same-name>.md` | створити / оновити | Опис test class і test cases |

Тести різних event type-ів не змішувати в один великий test class без потреби.

## 4. Документація

| Файл | Дія | Причина |
|---|---|---|
| `docs/record-change-events/source-record-internal/<ALIAS>.md` | створити / оновити | Паспорт події |
| `docs/record-change-processors/SOURCE_RECORD_INTERNAL.md` | оновити за потреби | Processor-level список і правила |
| `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md` | оновити, якщо існує | Реєстр підтримуваних подій |
| `QA_<ALIAS>.md` або секція QA | створити / оновити | Інструкції тестувальнику |

## 5. Файли, які не можна змінювати без окремого підтвердження

Перелічити явно:

- `DefaultRecordChangeEventProcessor.java`;
- `RecordChangeEventRule.java`;
- `ChangeRecord.java`;
- `ChangeRecordData.java`;
- external monitoring code;
- external monitoring documentation;
- currentRecord-import REST;
- `application*.yml` / `application*.yaml`;
- інші shared-файли, якщо вони не потрібні для стандартної реалізації.

## 6. Мінімальний шаблон для простого `APPEND` rule

```java
public class ProcessingStateChangedRecordChangeEventRule extends RecordChangeEventRule {

    private static final RecordValueMapping NEW_NAME =
            new RecordValueMapping(ValueSource.CURRENT_RECORD, "new.name", "name");

    public ProcessingStateChangedRecordChangeEventRule() {
        super(RecordChangeEventType.RECORD_SOMETHING_ADDED, List.of(NEW_NAME));
    }
}
```

Адаптувати imports і package під фактичний код.

## 7. Мінімальний шаблон для простого `DELETE` rule

```java
public class ProcessingStateChangedRecordChangeEventRule extends RecordChangeEventRule {

    private static final RecordValueMapping OLD_NAME =
            new RecordValueMapping(ValueSource.CURRENT_RECORD, "old.name", "name");

    public ProcessingStateChangedRecordChangeEventRule() {
        super(RecordChangeEventType.RECORD_SOMETHING_REMOVED, List.of(OLD_NAME));
    }
}
```

Для `source record item / INTERNAL / DELETE` не припускати автоматично `previousRecord.item`: у поточних стандартних подіях останній стан видаленого запису може читатися з `currentRecord.item`.

## 8. Мінімальний шаблон для `UPDATE` field-change

Для `UPDATE` field-change події план має явно визначити:

- яке поле в `changeDetails` є індикатором зміни;
- чи `change.oldValue/newValue` є джерелом значень;
- чи джерелом є `previousRecord.item` і `currentRecord.item`;
- які `old#...` і `new#...` values створюються;
- як обробляються blank/missing значення;
- чи потрібна нормалізація для порівняння і для запису.

Не використовувати шаблон blind-copy: перевірити фактичні існуючі події в модулі.

## 9. Підтвердження перед реалізацією

Після плану асистент має написати:

```text
Підтверди, що такий план реалізації підходить. Після підтвердження я внесу зміни в код, тести й документацію.
```


## Правило вибору виконавця реалізації

Після погодження аналітичного контракту, тест-кейсів і QA-даних асистент має оцінити обсяг змін у коді. Якщо зміна локальна, вкладається в наявний механізм і потребує лише нового/оновленого rule-класу, реєстрації, тестів і документації, асистент має запропонувати варіант самостійного внесення змін у наданий архів.

Якщо зміна зачіпає загальні класи, routing processor-ів, lifecycle обробки, error handling, модель даних, REST-контракти або може вплинути на кілька існуючих подій, асистент має рекомендувати передати реалізацію розробнику й коротко пояснити причину так, щоб аналітик міг донести її розробнику. Детальні правила описані в `31_IMPLEMENTATION_OWNERSHIP_DECISION.md`.

---

# FILE: 22_FEATURE_DELIVERY_REPORT_TEMPLATE.md

# Шаблон звіту про готовність фічі

Цей звіт створюється після реалізації події зміни запису. Він має бути зрозумілим аналітику-розробнику, reviewer-у і тестувальнику.

## 1. Загальна інформація

| Поле | Значення |
|---|---|
| Event type | `<ALIAS>` |
| Processor | `<type/sub_type>` |
| Тип зміни | `<APPEND/DELETE/UPDATE>` |
| Стратегія реалізації | стандартна / нестандартна / частково стандартна |
| Архів результату | `<link або назва файлу>` |

## 2. Що реалізовано

Коротко описати:

- коли створюється подія;
- які values формуються;
- звідки беруться значення;
- яка поведінка для пропуску події;
- яка поведінка для помилок;
- що не входило в scope.

## 3. Змінені production-файли

| Файл | Зміна |
|---|---|
| `<path>` | створено / оновлено / мінімально змінено |

Окремо вказати, якщо НЕ змінювалися:

- shared processor logic;
- `RecordChangeEventRule`;
- `ChangeRecord`;
- external monitoring;
- currentRecord-import.

## 4. Змінені test-файли

| Файл | Зміна | Що покриває |
|---|---|---|
| `<path>` | створено / оновлено | `TC-01`, `TC-02` |

Окремо вказати, чи створено `.md` поруч із test class.

## 5. Змінена документація

| Файл | Зміна |
|---|---|
| `docs/record-change-events/source-record-internal/<ALIAS>.md` | паспорт створено / оновлено |
| `docs/record-change-processors/...` | оновлено / не потрібно |
| `SUPPORTED_RECORD_CHANGE_EVENT_TYPES.md` | оновлено / файл відсутній / не потрібно |

## 6. Статус тестів

Вказати один із варіантів:

```text
Тести не запускались, бо користувач не давав дозволу.
```

або:

```text
Запущено релевантні тести:
- команда: ...
- результат: passed / failed
```

Якщо тести впали, вказати причину й чи виправлено.

## 7. Пакет для тестувальника

Вказати, що підготовлено:

- таблиця TC;
- REST-приклади або шаблони;
- очікуваний `ChangeRecord`;
- очікуваний `RecordChangeEvent`;
- типові помилки перевірки;
- що перевіряти в `events`;
- що перевіряти в `processing_errors`.

Якщо конкретні REST-и не підготовлені, пояснити, яких даних бракує:

```text
Для готових REST-прикладів потрібні: dev base URL, endpoint contract, document_id, поточні значення полів.
```

## 8. Ризики й обмеження

Наприклад:

- реалізація спирається на існуючий маршрутизація;
- інтеграційні REST-приклади не перевірялись;
- немає реального dev `document_id`;
- не запускались тести;
- нестандартні зміни передані на оцінку розробнику.

## 9. Перевірка безпеки архіву

Перед віддачею результату підтвердити:

- `application*.yml` / `application*.yaml` не включено, якщо там можуть бути локальні секрети;
- не включено тимчасові файли IDE;
- не включено build artifacts без потреби;
- не включено зайві логи.

## 10. Підсумок для чату

Короткий формат відповіді користувачу:

```text
Готово. Реалізовано <ALIAS>.

Архів: <link>

Змінено:
- production: ...
- tests: ...
- docs: ...

Тести: <статус>.

Для тестувальника підготовлено: <що саме>.

Обмеження: <якщо є>.
```


## Пакет для тестувальника

- [ ] Створено або оновлено `QA_<ALIAS>.md`.
- [ ] Для кожного TC вказано REST-запит або явно написано, що потрібен додатковий `document_id` / `document_id`.
- [ ] Для кожного TC вказано Mongo-фільтр для `events`.
- [ ] Для error-сценаріїв вказано Mongo-фільтр для `processing_errors`.
- [ ] Описано, чи потрібно запускати `POST /api/record-change-events/process`.
- [ ] Описано, що не є дефектом для цієї події.
- [ ] Вказано, що `operation=append` у currentRecord-import endpoint-ах не є бізнесовим `APPEND` у create-history.
## Уточнення щодо пакета для тестувальника

У фінальному звіті не потрібно фіксувати фізичний dev base URL. Достатньо відносних endpoint-ів, тому що тестувальник виконує перевірку вручну на відомому йому стенді.

У секції QA-пакета обов'язково вказати:

- чи надані аналітиком конкретні dev-приклади `document_id` / `document_id`;
- якщо не надані — які placeholders залишені;
- що create-history запускається вручну через `POST /api/record-change-events/process`;
- якими Mongo-запитами шукати `changes`, `events`, `processing_errors`;
- чи описано rollback;
- якщо rollback не описано — що тестувальник повертає дані вручну або залишає зміни за правилами dev-середовища.


## Блок про процесний зворотний зв’язок

У delivery report потрібно додавати окремий блок:

```markdown
## Зворотний зв’язок для покращення процесу

Файл: `07_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md`

Статус:
- створено / не створювалось, бо процесних зауважень не виявлено.

Ключові пункти для перенесення в загальні промти:
- ...
```

Якщо файл створено, delivery report має коротко перелічити основні висновки, щоб owner процесу міг швидко зрозуміти, що треба переглянути в загальному пакеті промтів.

---

# FILE: 23_QA_QUICK_START.md

# Швидкий старт для тестувальника події зміни запису

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


Цей файл описує короткий маршрут ручної перевірки однієї події зміни запису на dev-середовищі. Він не замінює паспорт події, але показує, у якому порядку тестувальнику виконувати перевірку і де шукати результат.


## Правило використання ідентифікаторів у QA-кроках

У QA-документах потрібно максимально підставляти вже відомі ідентифікатори, щоб тестувальник не працював із абстрактними placeholder-ами без пояснення.

Водночас важливо не змішувати різні типи `_id`:

| Назва в QA-документі | Що це | Коли відомий | Де використовується |
|---|---|---|---|
| `DOCUMENT_ID` або `DOCUMENT_ID` | `_id` вихідного запису в `source_records` або іншій source-колекції | відомий до старту TC, якщо аналітик надав тестовий запис | пошук source row у MongoDB Compass, поле `document_id` у REST-запиті `publish-mongo-*` |
| `CHANGE_ID_FROM_STEP_N` | `_id` нового запису в колекції `changes`, створеного після REST-запиту | стає відомий тільки після кроку пошуку в `changes` | пошук `events.change_id` і `processing_errors.change_id` |
| `RECORD_KEY` | бізнесовий ідентифікатор сутності / запису | зазвичай відомий із source row | допоміжний пошук у `changes` / `events`, але не заміна `CHANGE_ID_FROM_STEP_N` |

`DOCUMENT_ID` і `CHANGE_ID_FROM_STEP_N` — це не один і той самий ідентифікатор. Наприклад, `_id` запису в `source_records` не можна підставляти в `events.change_id` або `processing_errors.change_id`, якщо ці поля посилаються на `_id` запису з `changes`.

Якщо ідентифікатор уже відомий до виконання TC, його потрібно підставляти прямо в JSON-фільтр. Якщо ідентифікатор отримується на попередньому кроці, потрібно писати не просто `<CHANGE_ID>`, а пояснювати джерело, наприклад:

```text
CHANGE_ID_FROM_STEP_3 — значення `_id` запису з колекції `changes`, знайденого на кроці 3 цього TC.
```

Приклад для `events`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Приклад для `processing_errors`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Якщо конкретний `CHANGE_ID_FROM_STEP_N` уже був отриманий і зафіксований у межах TC, у наступних кроках бажано підставити саме його фактичне значення або явно написати, з якого кроку його взяти.

## 1. Що має бути підготовлено перед тестуванням

Для кожної події має бути окремий файл пакета перевірки:

```text
QA_<ALIAS>.md
```

Наприклад:

```text
QA_RECORD_STATUS_CHANGED.md
QA_RECORD_BENEFICIARY_ADDED.md
```

У цьому файлі мають бути:

- короткий опис події;
- список тест-кейсів;
- конкретні REST-запити для створення тестової зміни;
- очікуваний запис у `changes`;
- очікуваний запис у `events`;
- очікувана відсутність запису або очікуваний запис у `processing_errors` для негативних сценаріїв;
- фільтри MongoDB для перевірки;
- типові помилки перевірки, які не є дефектом коду.

Якщо `QA_<ALIAS>.md` не містить конкретного `document_id` / `document_id`, тестувальник має отримати тестовий Mongo-запис від аналітика-розробника або відповідального за тестові дані.

## 2. Загальний маршрут перевірки

1. Відкрити паспорт події `docs/record-change-events/source-record-internal/<ALIAS>.md` і файл `QA_<ALIAS>.md`.
2. Перевірити, який шар даних змінюється: існуючий Mongo-запис, додавання нового row, видалення row або пряме повідомлення у product-чергу.
3. Виконати REST-запит для підготовки зміни:
   - `publish-source-record-patch` — для зміни існуючого Mongo row;
   - `publish-source-record-add` — для додавання нового row;
   - `publish-source-record-delete` — для видалення row.
4. Якщо використано `preview=true`, переконатися, що payload сформований правильно, але пам'ятати: preview не публікує повідомлення в RabbitMQ і не створює `changes`.
5. Якщо використано `preview=false`, зачекати появу запису у `changes` або перейти до ручного запуску history processing, якщо це передбачено стендом.
6. Запустити обробку history-записів через create-history endpoint, якщо автоматична обробка вимкнена або потрібно пришвидшити тест.
7. Перевірити `events` за `change_id`, `record_key`, `eventType` і ключовими `values`.
8. Перевірити `processing_errors`, якщо event не створився або сценарій очікує помилку.
9. Якщо результат не збігається, класифікувати проблему: дефект коду, неточний тест-кейс, неправильний REST-запит, некоректні тестові дані, асинхронна обробка ще не завершена або проблема середовища.

## 3. Важливе розділення понять

`operation=append` у тестових endpoint-ах `compliance-currentRecord-import-backend-stage` є запобіжником для публікації reconstructed product queue payload. Це не те саме, що бізнесовий тип зміни `APPEND`, `UPDATE` або `DELETE` у `internal-record-change-processing-module`.

Для create-history модуля тип зміни визначається з ``change.status``:

| `change.status` у `changes` | Тип зміни в create-history |
|---|---|
| `new` | `NEW` |
| `added` | `APPEND` |
| `modified` | `UPDATE` |
| `deleted` | `DELETE` |

Не потрібно намагатися перемкнути тип зміни через поле `currentRecord.item.changeType`. Таке поле, якщо воно випадково є всередині `item`, не керує маршрутизацією create-history processor-а.

## 4. Коли результат ще не можна вважати дефектом

Не заводити дефект одразу, якщо:

- REST-запит був виконаний з `preview=true` — у цьому режимі публікації в RabbitMQ немає;
- `events` ще не з'явився, але запис у `changes` ще не оброблений;
- запис потрапив у `processing_errors` через `PRODUCER_NOT_FOUND` для іншого `type/sub_type`, який не підтримується модулем;
- для негативного тест-кейса конкретного event type-а створилась інша валідна подія цього processor-а;
- `operation=append` було використано разом із `currentRecord.item.changeType=DELETE` — це не валідна перевірка `DELETE`-сценарію.

## 5. Мінімальна перевірка після запуску обробки

Після запуску create-history processing перевірити:

1. `events`:

Колекція: `events`

MongoDB Compass → Filter:

```json
{
  "eventType": "<ALIAS>",
  "record_key": "<RECORD_KEY>"
}
```

2. `processing_errors`:

Колекція: `processing_errors`

MongoDB Compass → Filter:

```json
{
  "rootId": "<RECORD_KEY>",
  "type": "<TYPE>",
  "subType": "<SUB_TYPE>"
}
```

3. Якщо відомий `_id` запису з `changes`, перевіряти точніше:

Колекція: `events`

MongoDB Compass → Filter:

```json
{
  "change_id": "<CHANGE_ID_FROM_PREVIOUS_STEP>"
}
```

або:

Колекція: `processing_errors`

MongoDB Compass → Filter:

```json
{
  "change_id": "<CHANGE_ID_FROM_PREVIOUS_STEP>"
}
```

## 6. Що потрібно фіксувати у звіті тестування

Для кожного TC тестувальник має зафіксувати:

- який REST-запит виконувався;
- який `document_id` або `document_id` використовувався;
- чи був `preview=true` або `preview=false`;
- чи був знайдений запис у `changes`;
- чи був створений event;
- чи був створений запис у `processing_errors`;
- фактичний event type події;
- фактичні ключові `values`;
- посилання або `_id` знайдених записів MongoDB.
## 7. Уточнення для поточного процесу перевірки

У поточному процесі перевірки подій зміни запису не потрібно фіксувати повний фізичний dev URL у шаблонах. У документах достатньо вказувати відносний шлях endpoint-а, наприклад:

```text
POST /internal/api/test/product-queue/publish-source-record-patch
POST /internal/api/test/product-queue/publish-source-record-add
POST /internal/api/test/product-queue/publish-source-record-delete
POST /api/record-change-events/process
```

Тестувальник сам знає, на якому стенді фізично розташований відповідний сервіс, і виконує запити вручну. Тому QA-пакет має бути орієнтований не на готовий скрипт, а на зрозумілу ручну інструкцію: який endpoint відкрити, яке тіло запиту передати, які поля перевірити в MongoDB.

Для поточного процесу запуск create-history виконується вручну через:

```text
POST /api/record-change-events/process
```

з тілом:

```json
{
  "operation": "start"
}
```

Після створення тестової зміни тестувальник має самостійно перевірити відповідну Mongo-колекцію `changes` запитом за полями, які є в QA-пакеті: `record_key`, `type`, `sub_type`, `status`, `date`, а якщо відомо — за `_id` запису зміни.

У пакеті перевірки не потрібно вимагати заздалегідь затверджений універсальний `document_id` або `document_id`. Аналітик може надати конкретний приклад існуючого запису з dev-даних, і саме на його основі формуються тест-кейси для тестувальника.

Кроки повернення тестових даних у початковий стан бажано додавати, якщо це можна зробити безпечно й зрозуміло. Але це не є самоціллю: якщо автоматичний або чіткий rollback не описаний, QA-пакет має прямо вказати, що повернення даних виконується тестувальником вручну прийнятним для команди способом.

---

## Посилення v0.22: QA-файл як практична інструкція для тестувальника

QA-пакет `05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має бути написаний як практична покрокова інструкція для тестувальника, а не як технічний опис для розробника.

Критерій готовності: тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, орієнтуватися на розширений приклад. Короткий шаблон є тільки skeleton-ом, не фінальним рівнем якості.

Перед віддачею QA-файла обов’язково застосувати checklist з `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md`. Якщо хоча б один пункт checklist не виконано, QA-файл не віддавати користувачу — спочатку виправити.

---

# FILE: 24_QA_PACKAGE_TEMPLATE.md

# Шаблон пакета перевірки події зміни запису

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


Файл створюється для кожної події зміни запису окремо:

```text
QA_<ALIAS>.md
```

Мета — дати тестувальнику готову інструкцію для перевірки події без змішування REST-запиту, Mongo source row, запису `changes` і запису `events`.

> Важливо: Mongo-перевірки для ручного QA оформлюються під MongoDB Compass, а не під shell. У документах потрібно давати назву колекції та JSON/Extended JSON для поля `Filter`; за потреби окремо `Sort`, `Limit` або aggregation pipeline. Не використовувати `collection.find(...)` у shell-форматі у QA-інструкціях.


## Правило використання ідентифікаторів у QA-кроках

У QA-документах потрібно максимально підставляти вже відомі ідентифікатори, щоб тестувальник не працював із абстрактними placeholder-ами без пояснення.

Водночас важливо не змішувати різні типи `_id`:

| Назва в QA-документі | Що це | Коли відомий | Де використовується |
|---|---|---|---|
| `DOCUMENT_ID` або `DOCUMENT_ID` | `_id` вихідного запису в `source_records` або іншій source-колекції | відомий до старту TC, якщо аналітик надав тестовий запис | пошук source row у MongoDB Compass, поле `document_id` у REST-запиті `publish-mongo-*` |
| `CHANGE_ID_FROM_STEP_N` | `_id` нового запису в колекції `changes`, створеного після REST-запиту | стає відомий тільки після кроку пошуку в `changes` | пошук `events.change_id` і `processing_errors.change_id` |
| `RECORD_KEY` | бізнесовий ідентифікатор сутності / запису | зазвичай відомий із source row | допоміжний пошук у `changes` / `events`, але не заміна `CHANGE_ID_FROM_STEP_N` |

`DOCUMENT_ID` і `CHANGE_ID_FROM_STEP_N` — це не один і той самий ідентифікатор. Наприклад, `_id` запису в `source_records` не можна підставляти в `events.change_id` або `processing_errors.change_id`, якщо ці поля посилаються на `_id` запису з `changes`.

Якщо ідентифікатор уже відомий до виконання TC, його потрібно підставляти прямо в JSON-фільтр. Якщо ідентифікатор отримується на попередньому кроці, потрібно писати не просто `<CHANGE_ID>`, а пояснювати джерело, наприклад:

```text
CHANGE_ID_FROM_STEP_3 — значення `_id` запису з колекції `changes`, знайденого на кроці 3 цього TC.
```

Приклад для `events`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Приклад для `processing_errors`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Якщо конкретний `CHANGE_ID_FROM_STEP_N` уже був отриманий і зафіксований у межах TC, у наступних кроках бажано підставити саме його фактичне значення або явно написати, з якого кроку його взяти.

## 1. Загальна інформація

| Поле | Значення |
|---|---|
| Event type | `<ALIAS>` |
| Бізнес-сенс | `<короткий опис>` |
| Processor | `<type>/<sub_type>` |
| Очікуваний тип зміни | `<APPEND/UPDATE/DELETE>` |
| Основна колекція source row | `source_records` або інша |
| Колекція змін | `changes` |
| Колекція подій | `events` |
| Колекція помилок | `processing_errors` |

## 2. Тестові дані

| Поле | Значення |
|---|---|
| Dev base URL currentRecord-import | `<DATA_IMPORT_BASE_URL>` |
| Dev base URL create-history | `<CREATE_HISTORY_BASE_URL>` |
| collection | `<collection>` |
| document_id / document_id | `<id>` |
| record_key | `<record_key>` |
| document_id | `<document_id>` |
| Чи можна змінювати запис багаторазово | `<так/ні/потребує відновлення>` |
| Маркер тесту | `<QA marker, якщо використовується>` |

## 3. Передумови

- Запис із `document_id` або `document_id` існує в MongoDB.
- Значення полів перед тестом відповідають опису TC.
- Якщо подія перевіряється через `publish-source-record-patch`, path у `operations` задається відносно `item`, без префікса `item.`.
- Якщо використано `preview=true`, це лише перевірка сформованого payload; `changes` і `events` не створюються.

## 4. Тест-кейси

### TC-01. `<назва сценарію>`

#### Бізнес-сенс

`<опис бізнес-зміни>`

#### Крок 2. Виконати REST-запит для створення зміни

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

#### Тіло запиту

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

#### Очікувана відповідь REST

```json
{
  "status": "PUBLISHED",
  "published": true,
  "preview": false
}
```

#### Очікуваний запис у `changes`

Колекція: `changes`

MongoDB Compass → Filter:

```json
{
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>",
  "change.status": "<added|modified|deleted>"
})
```

Ключові очікування:

- `change.status=<...>`;
- `currentRecord.item.<path>` містить нове значення;
- `previousRecord.item.<path>` містить старе значення, якщо це `UPDATE`;
- `changeDetails` містить очікуваний `field`, якщо це потрібно для події.

#### Запуск обробки history

Якщо автоматична обробка вимкнена або потрібно виконати її вручну:

```bash
curl -X POST "<CREATE_HISTORY_BASE_URL>/api/history" \
  -H "accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"operation":"start"}'
```

Очікувано:

```json
{
  "status": "SUCCESS",
  "processedCount": 1
}
```

`processedCount` може відрізнятися, якщо в черзі є інші записи. Для точного підтвердження потрібно перевіряти `events` або `processing_errors` за `change_id` / `change_id`.

#### Очікуваний запис у `events`

Колекція: `events`

MongoDB Compass → Filter:

```json
{
  "eventType": "<ALIAS>",
  "record_key": "<RECORD_KEY>"
})
```

Очікуваний фрагмент:

```json
{
  "type": "recordChange",
  "sub_type": "INTERNAL",
  "item": {
    "event type": "<ALIAS>",
    "group": "<group>",
    "groupPriority": 1,
    "isEdr": true,
    "values": {
      "old#value": "<old>",
      "new#value": "<new>"
    }
  },
  "record_key": "<RECORD_KEY>",
  "source": "RECORD_CHANGE_AUTOMATION",
  "change_id": "<CHANGE_ID_FROM_PREVIOUS_STEP>",
  "deleted": false
}
```

#### Очікувана відсутність

Колекція: `processing_errors`

MongoDB Compass → Filter:

```json
{
  "change_id": "<CHANGE_ID_FROM_PREVIOUS_STEP>"
}
```

Очікування: записів немає, якщо TC не є error-сценарієм.

## 5. Що не є дефектом для цієї події

- `<приклад: створення іншого event type-а для іншого recordVariant>`;
- `<приклад: відсутній optional key не записується>`;
- `<приклад: preview не створює changes/events>`;
- `<приклад: currentRecord.item.changeType не керує маршрутизацією>`.

## 6. Відомі ризики перевірки

- Обробка може бути асинхронною.
- У черзі можуть бути інші записи, тому `processedCount` не завжди дорівнює 1.
- Якщо тестовий документ уже змінювався, у `events` можуть бути старі події з тим самим `record_key`.
- Для точного пошуку краще використовувати `change_id`, якщо відомий `_id` запису з `changes`.
## 7. Правила заповнення для ручного тестування на dev

У цьому шаблоні не потрібно фіксувати повний фізичний base URL. Для REST-кроків вказувати тільки відносний endpoint:

```text
POST /internal/api/test/product-queue/publish-source-record-patch
POST /internal/api/test/product-queue/publish-source-record-add
POST /internal/api/test/product-queue/publish-source-record-delete
POST /api/record-change-events/process
```

Тестувальник сам підставляє потрібний dev-стенд і виконує запити вручну.

У секції тестових даних не вимагати “затверджений” універсальний `document_id` / `document_id`. Якщо для конкретної події потрібен приклад, його має надати аналітик або аналітик-розробник із поточних dev-даних. У QA-пакеті це фіксується як конкретний приклад для поточної перевірки, а не як постійний глобальний тестовий ідентифікатор.

Після виконання `publish-source-record-patch`, `publish-source-record-add` або `publish-source-record-delete` перевірка запису зміни виконується Mongo-запитом до відповідної колекції `changes`. Основні фільтри:

Колекція: `changes`

MongoDB Compass → Filter:

```json
{
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>",
  "change.status": "<added|modified|deleted>"
}
```

MongoDB Compass → Sort:

```json
{"date": -1}
```

Якщо в конкретному середовищі структура полів відрізняється, QA-пакет має показати фактичний запит для цього середовища.

Запуск create-history у поточному процесі вважати ручним:

```text
POST /api/record-change-events/process
```

```json
{
  "operation": "start"
}
```

Секцію повернення даних до початкового стану бажано додавати для кожного QA-пакета. Якщо чіткий rollback не підготовлений, написати це явно:

```text
Автоматичний rollback не описаний. Після перевірки тестувальник повертає dev-дані вручну прийнятним для команди способом або залишає зміну, якщо це допустимо для dev-середовища.
```

## Статус погодження QA-пакета

На початку кожного QA-пакета додавати:

| Поле | Значення |
|---|---|
| Статус тест-кейсів | `чернетка` / `потребує уточнення` / `погоджено аналітиком` |
| Статус Mongo-даних | `placeholders` / `надані` / `погоджені для QA` |
| Чи можна виконувати на dev без додаткових уточнень | `так/ні` |

Якщо статус Mongo-даних не `погоджені для QA`, QA-пакет не вважати готовою інструкцією для тестувальника.

## Обов’язкові примітки для negative TC

У QA-пакеті для кожного negative TC потрібно додати одну з приміток:

```text
Очікується відсутність саме <ALIAS>. Інші event type-и, які відповідають зміненому полю або іншому type/sub_type, не входять у перевірку цього TC.
```

або

```text
Якщо запис потрапив у processing_errors через відсутній processor для іншого type/sub_type, це не є дефектом <ALIAS>.
```

Для missing/null old/new значень у expected event values використовувати `—`, якщо інше не зафіксовано в технічному контракті.


---

## 8. Обов’язковий формат покрокового опису кожного TC

Кожен TC у QA-пакеті має бути не лише рядком у таблиці, а окремою інструкцією виконання.

Для кожного TC обов’язково додати такі підрозділи:

```markdown
### TC-XX. <Назва>

#### Мета
<Що перевіряємо.>

#### Передумови
- Mongo `_id`: `<DOCUMENT_ID>`
- `record_key`: `<RECORD_KEY>`
- Поточне значення поля перед стартом: `<OLD_VALUE>`
- Чи потрібен rollback перед запуском TC: `так/ні`

#### Крок 1. Перевірити початковий запис у `source_records`
Колекція: `source_records`

MongoDB Compass → Filter:

```json
{
  "_id": {"$oid": "<DOCUMENT_ID>"}
}
```

#### Крок 2. Виконати REST-запит
```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<path-relative-to-item>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

#### Крок 3. Перевірити `changes`

Колекція: `changes`

MongoDB Compass → Filter:

```json
{
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>",
  "change.status": "modified"
}
```

MongoDB Compass → Sort:

```json
{
  "date": -1
}
```

MongoDB Compass → Limit: `5`

Зберегти `_id` релевантного запису як `CHANGE_ID_FROM_PREVIOUS_STEP`.

#### Крок 4. Запустити create-history
```http
POST /api/record-change-events/process
```

```json
{
  "operation": "start"
}
```

#### Крок 5. Перевірити `events`
Колекція: `events`

MongoDB Compass → Filter:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_PREVIOUS_STEP>"}
}
```

#### Крок 6. Перевірити `processing_errors`
Колекція: `processing_errors`

MongoDB Compass → Filter:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_PREVIOUS_STEP>"}
}
```

#### Крок 7. Rollback
<Конкретний REST-запит або ручна дія для повернення стану.>
```

Якщо TC negative, у кроці перевірки `events` обов’язково зазначити: очікується відсутність саме поточного event type-а; інші event type-и можуть створюватися, якщо вони відповідають зміненому полю.


## Обов’язковий статус QA-пакета

На початку кожного `QA_<ALIAS>.md` потрібно явно вказувати:

```text
Статус тест-кейсів: погоджені / чернетка
Статус Mongo-даних: погоджені / placeholders
QA-пакет готовий до виконання на dev: так / ні
```

Якщо `Статус Mongo-даних: placeholders`, QA-пакет не можна подавати як готовий до ручного виконання на dev. У REST-прикладах і MongoDB Compass фільтрах потрібно залишати `<DOCUMENT_ID>`, `<RECORD_KEY>`, `<DOCUMENT_ID>`, `<OLD_VALUE>`, `<NEW_VALUE>`.

Якщо Mongo-дані погоджені, підставляти конкретні значення, які відомі до старту TC. Ідентифікатори, які виникають у процесі, наприклад `_id` запису з `changes`, позначати як `CHANGE_ID_FROM_STEP_N` із поясненням, з якого кроку його взяти.

---

## Посилення v0.22: QA-файл як практична інструкція для тестувальника

QA-пакет `05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має бути написаний як практична покрокова інструкція для тестувальника, а не як технічний опис для розробника.

Критерій готовності: тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, орієнтуватися на розширений приклад. Короткий шаблон є тільки skeleton-ом, не фінальним рівнем якості.

Перед віддачею QA-файла обов’язково застосувати checklist з `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md`. Якщо хоча б один пункт checklist не виконано, QA-файл не віддавати користувачу — спочатку виправити.


---

## Обов’язкове правило: два рівні тест-кейсів

Під час підготовки події зміни запису асистент має розділяти тест-кейси на два набори:

1. `Unit/processor test cases` (`TC-U01`, `TC-U02`, ...) — повний технічний набір для реалізації, unit-тестів, processor-level перевірок і edge cases.
2. `Manual QA test cases` (`TC-01`, `TC-02` або `TC-QA01`, `TC-QA02`, ...) — практичний набір для ручної перевірки тестувальником на dev.

Якщо набори різні, Jira-задача і Confluence-паспорт мають містити обидва набори та mapping між ними. Окремий `05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має містити тільки manual QA TC як практичну інструкцію для тестувальника.

Детальні правила, шаблони, checklist і приклад для `RECORD_COMPANY_TYPE_CHANGED` описані в `36_TWO_LEVEL_TEST_CASES_GUIDE.md`.

---

# FILE: 25_QA_VERIFICATION_GUIDE.md

# Перевірка MongoDB, REST-запитів і асинхронної обробки

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


Цей файл описує практичні правила перевірки подій зміни запису після створення тестової зміни.

> Важливо: Mongo-перевірки для ручного QA оформлюються під MongoDB Compass, а не під shell. У документах потрібно давати назву колекції та JSON/Extended JSON для поля `Filter`; за потреби окремо `Sort`, `Limit` або aggregation pipeline. Не використовувати `collection.find(...)` у shell-форматі у QA-інструкціях.


## Правило використання ідентифікаторів у QA-кроках

У QA-документах потрібно максимально підставляти вже відомі ідентифікатори, щоб тестувальник не працював із абстрактними placeholder-ами без пояснення.

Водночас важливо не змішувати різні типи `_id`:

| Назва в QA-документі | Що це | Коли відомий | Де використовується |
|---|---|---|---|
| `DOCUMENT_ID` або `DOCUMENT_ID` | `_id` вихідного запису в `source_records` або іншій source-колекції | відомий до старту TC, якщо аналітик надав тестовий запис | пошук source row у MongoDB Compass, поле `document_id` у REST-запиті `publish-mongo-*` |
| `CHANGE_ID_FROM_STEP_N` | `_id` нового запису в колекції `changes`, створеного після REST-запиту | стає відомий тільки після кроку пошуку в `changes` | пошук `events.change_id` і `processing_errors.change_id` |
| `RECORD_KEY` | бізнесовий ідентифікатор сутності / запису | зазвичай відомий із source row | допоміжний пошук у `changes` / `events`, але не заміна `CHANGE_ID_FROM_STEP_N` |

`DOCUMENT_ID` і `CHANGE_ID_FROM_STEP_N` — це не один і той самий ідентифікатор. Наприклад, `_id` запису в `source_records` не можна підставляти в `events.change_id` або `processing_errors.change_id`, якщо ці поля посилаються на `_id` запису з `changes`.

Якщо ідентифікатор уже відомий до виконання TC, його потрібно підставляти прямо в JSON-фільтр. Якщо ідентифікатор отримується на попередньому кроці, потрібно писати не просто `<CHANGE_ID>`, а пояснювати джерело, наприклад:

```text
CHANGE_ID_FROM_STEP_3 — значення `_id` запису з колекції `changes`, знайденого на кроці 3 цього TC.
```

Приклад для `events`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Приклад для `processing_errors`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Якщо конкретний `CHANGE_ID_FROM_STEP_N` уже був отриманий і зафіксований у межах TC, у наступних кроках бажано підставити саме його фактичне значення або явно написати, з якого кроку його взяти.

## 1. Основні колекції

### `source_records`

Основна колекція source rows. Для подій `source record / INTERNAL` приклад row містить:

- `_id` — Mongo id конкретного row;
- `collection` — зазвичай `source_records`;
- `type` — наприклад `sourceRecord`;
- `sub_type` — наприклад `INTERNAL`;
- `source` — наприклад `UACA`;
- `document_id` — ідентифікатор документа;
- `record_key` — ідентифікатор запису;
- `item` — бізнес-вміст запису;
- `item.related_record_keys` — entity id запису;
- `item.names.fullName`, `item.names.shortName` — назви запису;
- `item.status`, `item.processingState` — статус і код статусу;
- `status` на рівні row — технічний стан row, який може бути `modified`, `added`, `deleted` тощо.

Приклад source row для `source record / INTERNAL` має `type=sourceRecord`, `sub_type=INTERNAL`, `source=UACA`, `collection=source_records`, `item.status=ПРИПИНЕНО`, `item.processingState=closed`, `item.names.fullName=...`, `record_key=...`.

### `changes`

Колекція записів змін, які обробляє create-history модуль. Запис містить:

- `_id` — id зміни;
- `date` — дата зміни;
- `currentRecord` — поточний стан row;
- `previousRecord` — попередній стан row;
- `changeDetails` — список змінених полів;
- службові поля обробки: `processingStatus`, `lockedBy`, `lockedAt`, `lockToken`, `processingAttempts`.

Create-history визначає тип зміни не з поля `currentRecord.item.changeType`, а з `change.status`:

| `change.status` | Тип зміни |
|---|---|
| `new` | `NEW` |
| `added` | `APPEND` |
| `modified` | `UPDATE` |
| `deleted` | `DELETE` |

### `events`

Колекція створених подій зміни запису. Типова структура:

- `type=recordChange`;
- `sub_type=INTERNAL`;
- `eventType` — event type події, наприклад `RECORD_NAME_CHANGED`;
- `item.group` — група, наприклад `recordChangeHistory`;
- `item.groupPriority`;
- `item.isEdr`;
- `item.date` і `item.year`;
- `values` — значення події з ключами на кшталт `old#value`, `new#value`, `old#status`, `new#status`;
- `record_key`;
- `source=RECORD_CHANGE_AUTOMATION`;
- `change_id` — id запису з `changes`;
- `deleted=false`.

### `processing_errors`

Колекція фінальних помилок обробки. Типова структура:

- `change_id` — id проблемного запису з `changes`;
- `originalRecord` — копія запису зміни;
- `errorType` — машинозчитуваний тип помилки;
- `errorMessage`;
- `errorDetails`;
- `type`, `subType`, `rootId` — продубльовані поля для швидкої фільтрації;
- `processingAttempts`;
- `failedAt`, `createdAt`.

Приклад `PRODUCER_NOT_FOUND` означає, що для `type/subType` не знайдено processor. Це не дефект конкретної події зміни запису, якщо перевірявся непідтримуваний processor.

## 2. REST-запити для створення тестових змін

### Зміна існуючого row: `publish-source-record-patch`

Endpoint:

```text
POST /internal/api/test/product-queue/publish-source-record-patch
```

Приклад:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<document_id>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "names.fullName",
      "value": "Нова назва"
    }
  ]
}
```

Правила:

- `path` завжди відносний до `item`;
- не писати `item.names.fullName`, правильно — `names.fullName`;
- для `preview=false` потрібен `operation=append`;
- `operation=append` тут означає публікацію reconstructed payload у product-чергу, а не бізнесовий `APPEND` для create-history;
- `preview=true` повертає payload без публікації.

### Додавання row: `publish-source-record-add`

Endpoint:

```text
POST /internal/api/test/product-queue/publish-source-record-add
```

Приклад:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<document_id>",
  "preview": false,
  "gzip": true,
  "item": {
    "name": "ПІБ або назва",
    "recordVariant": "beneficiary"
  },
  "itemIds": [
    "<entity_id>"
  ]
}
```

Правила:

- `document_id`, `type`, `sub_type`, `source`, `record_key` для нового row беруться з reference row;
- `collection` задається request-ом;
- `record_key` явно в request не передається;
- `itemIds` опціональні й не копіюються автоматично з reference row;
- для реальної публікації потрібен `operation=append`.

### Видалення row: `publish-source-record-delete`

Endpoint:

```text
POST /internal/api/test/product-queue/publish-source-record-delete
```

Приклад:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<document_id>",
  "preview": false,
  "gzip": true
}
```

Правила:

- endpoint реконструює повний pseudo-document без target row;
- для реальної публікації потрібен `operation=append`;
- `operation=append` не означає, що create-history має створити `APPEND`-подію;
- фактичний `change.status` у `changes` після імпортного сценарій визначає тип зміни для create-history.

## 3. Ручний запуск create-history processing

Якщо на стенді увімкнений manual processing endpoint:

```text
POST /api/record-change-events/process
```

Тіло:

```json
{
  "operation": "start"
}
```

Очікувана відповідь:

```json
{
  "status": "SUCCESS",
  "processedCount": 1,
  "movedToErrorCount": 0,
  "alreadyProcessedCount": 0,
  "errorCount": 0
}
```

Можливі статуси:

- `SUCCESS` — обробка виконалась і щось було оброблено;
- `NO_DATA` — черга `changes` порожня або немає придатних записів;
- `ERROR` — під час запуску виникли помилки;
- `skipped=true` — запуск пропущений через інший активний запуск.

## 4. Mongo-фільтри для перевірки

### Знайти event за event type і record_key

Колекція: `events`

MongoDB Compass → Filter:

```json
{
  "eventType": "<ALIAS>",
  "record_key": "<RECORD_KEY>"
})
```

### Знайти event за change_id

Колекція: `events`

MongoDB Compass → Filter:

```json
{
  "change_id": "<CHANGE_ID_FROM_PREVIOUS_STEP>"
}
```

Це найточніший спосіб, якщо відомий `_id` запису з `changes`.

### Знайти помилку за change_id

Колекція: `processing_errors`

MongoDB Compass → Filter:

```json
{
  "change_id": "<CHANGE_ID_FROM_PREVIOUS_STEP>"
}
```

### Знайти помилку за type/subType/rootId

Колекція: `processing_errors`

MongoDB Compass → Filter:

```json
{
  "type": "<TYPE>",
  "subType": "<SUB_TYPE>",
  "rootId": "<RECORD_KEY>"
}
```

### Знайти новий запис changes за record_key і type/sub_type

```javascript
db.changes.find({
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>"
}
```

MongoDB Compass → Sort:

```json
{"date": -1}
```

## 5. Як не переплутати ще не оброблений запис із дефектом

Якщо event не знайдено:

1. Перевірити, чи REST-запит був не preview.
2. Перевірити, чи з'явився запис у `changes`.
3. Перевірити `processingStatus` у `changes`.
4. Перевірити `processing_errors` за `change_id` або `rootId`.
5. Перевірити, чи create-history processing запускався вручну або автоматично.
6. Перевірити, чи не створилась інша валідна подія для іншого event type-а.

Тільки після цього результат можна класифікувати як потенційний дефект коду.
## 5. Уточнення щодо ручної перевірки на dev

У документації для тестувальника не фіксувати повний фізичний URL сервісів. Достатньо відносних endpoint-ів. Тестувальник сам знає, який стенд використовувати.

Для поточного процесу обробка create-history запускається вручну через:

```text
POST /api/record-change-events/process
```

```json
{
  "operation": "start"
}
```

Тому після виконання REST-запиту з currentRecord-import потрібно:

1. Знайти або підтвердити появу запису в `changes` через MongoDB.
2. Запустити `POST /api/record-change-events/process` вручну.
3. Перевірити `events` або `processing_errors`.

Стабільного універсального ідентифікатора тестових записів немає. Аналітик може надати конкретний існуючий запис з dev-даних, на якому можна сформувати перевірку. Для кожної нової події QA-пакет має або містити такий приклад, або явно позначати placeholder:

```text
<ANALYST_PROVIDED_DOCUMENT_ID>
<ANALYST_PROVIDED_REFERENCE_DOCUMENT_ID>
```

Пошук щойно створеного `changes` виконується Mongo-запитами до відповідної колекції. Базовий підхід:

Колекція: `changes`

MongoDB Compass → Filter:

```json
{
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>"
}
```

MongoDB Compass → Sort:

```json
{"date": -1}
```

Для точнішого пошуку додавати `change.status`, очікуване поле в `changeDetails`, або часовий діапазон виконання тесту.

Rollback бажаний, але не повинен блокувати QA-пакет. Якщо можливо, у QA-пакеті потрібно дати зворотний REST-крок або опис ручного повернення значень. Якщо неможливо — прямо вказати, що повернення даних виконується тестувальником вручну або не є обов'язковим для цього dev-сценарію.


---

## 6. Рівень деталізації QA-файла

Файл для тестувальника має бути не загальним описом перевірки, а покроковою інструкцією. Для кожного TC потрібно описати повний ланцюжок:

1. перевірити або підготувати source row у `source_records`;
2. виконати конкретний REST-запит до currentRecord-import test endpoint-а;
3. знайти створений запис у `changes`;
4. зафіксувати `CHANGE_ID_FROM_PREVIOUS_STEP`;
5. запустити `POST /api/record-change-events/process`;
6. перевірити `events` за `change_id`;
7. перевірити `processing_errors` за `change_id`;
8. виконати rollback або повернути baseline.

Такий рівень деталізації потрібен, щоб QA-файл можна було згодом перетворити на автоматизований сценарій без повторного аналізу бізнес-логіки.

---

## Посилення v0.22: QA-файл як практична інструкція для тестувальника

QA-пакет `05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має бути написаний як практична покрокова інструкція для тестувальника, а не як технічний опис для розробника.

Критерій готовності: тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, орієнтуватися на розширений приклад. Короткий шаблон є тільки skeleton-ом, не фінальним рівнем якості.

Перед віддачею QA-файла обов’язково застосувати checklist з `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md`. Якщо хоча б один пункт checklist не виконано, QA-файл не віддавати користувачу — спочатку виправити.

---

# FILE: 26_OUTPUT_ARTIFACT_FORMATS.md

# Формати вихідних артефактів

Цей документ фіксує, у якому вигляді асистент має віддавати результат роботи над історичною подією, щоб аналітик міг без переписування перенести матеріали в Jira, Confluence, репозиторій і передати тестувальнику.

## 1. Загальне правило

Фінальний результат не має бути одним великим змішаним документом. Для кожної події зміни запису асистент має готувати окремі артефакти під різні цілі:

| Артефакт | Для кого | Куди переноситься | Основна вимога |
|---|---|---|---|
| Технічний контракт | аналітик-розробник, розробник, модель | робочий файл / задача / документація | єдине джерело істини для події |
| Jira-задача | аналітик, розробник | Jira | можна вставити без переписування |
| Паспорт події | аналітик, команда, тестувальник | робочий аналітичний пакет | повний опис події і тест-кейсів |
| План реалізації | розробник або модель | чат / робочий файл | чітко показує production/test/docs зміни |
| QA-пакет | тестувальник | Jira, Confluence або окремий `.md` | ручна інструкція перевірки |
| Звіт про готовність | аналітик-розробник, reviewer | чат / Jira comment / файл | коротко пояснює, що зроблено і що перевірити |

## 2. Мінімальний набір файлів для однієї події

Якщо користувач просить повний результат у вигляді файлів, асистент має підготувати пакет такого типу:

```text
<ALIAS>/
  01_TECHNICAL_CONTRACT_<ALIAS>.md
  02_JIRA_TASK_<ALIAS>.md
  03_IMPLEMENTATION_PLAN_DRAFT_<ALIAS>.md
  04_QA_PACKAGE_<ALIAS>.md
  05_TRACEABILITY_MATRIX_<ALIAS>.md
  06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md
```

Якщо реалізація в коді вже виконувалась у цьому ж процесі, додатково можуть бути:

```text
  07_CODE_CHANGES_SUMMARY_<ALIAS>.md
  patch-files/ або updated-module.zip
```

## 3. Блок для Jira

Блок для Jira має бути коротшим за паспорт, але достатнім для розробки. Він має містити:

1. назву задачі;
2. суть задачі;
3. технічний контракт у скороченому вигляді;
4. що потрібно реалізувати;
5. що не входить у межі задачі;
6. критерії приймання;
7. таблицю тест-кейсів;
8. посилання або згадку про паспорт, якщо він створюється окремо.

Рекомендований формат назви:

```text
Створити подію зміни запису <ALIAS> для <type>/<sub_type>
```

Якщо подія вже існує, назва має відображати фактичну дію:

```text
Оновити документацію і QA-пакет для події зміни запису <ALIAS>
```

## 4. Блок для Confluence

Блок для Confluence має бути повним паспортом події. Його треба писати як готову сторінку, без службових коментарів до моделі.

Обов’язкова структура:

1. назва події;
2. короткий опис;
3. паспорт події;
4. джерело зміни;
5. умови створення;
6. `RecordChangeEvent.values`;
7. нормалізація;
8. коли подія не створюється;
9. помилки і неповні дані;
10. приклади вхідних і вихідних даних;
11. тест-кейси;
12. примітки для тестування.

Текст має бути придатним для копіювання в Confluence editor, якщо користувач прямо просить окрему Confluence-сторінку. Markdown-таблиці допускаються, якщо команда переносить їх у Confluence вручну.

## 5. Блок для тестувальника

QA-пакет має бути не аналітичною специфікацією, а практичною інструкцією:

- який тестовий запис потрібен;
- який endpoint виконати вручну;
- які поля змінити;
- як запустити create-history;
- як знайти запис у `changes`;
- як знайти `RecordChangeEvent`;
- як перевірити `processing_errors`;
- що не є дефектом;
- чи є rollback, і якщо немає — що тестувальник повертає дані вручну або за правилами dev-середовища.

Фізичний dev base URL не фіксується. Достатньо відносних endpoint-ів, бо тестувальник виконує перевірку вручну на відомому йому стенді.

## 6. Блок для реалізації

План реалізації має бути окремим від Jira-задачі й паспорта. Він має містити:

- перелік production-файлів;
- перелік test-файлів;
- `.md` поруч із тестами;
- документацію, яку треба створити або оновити;
- файли, які не можна чіпати;
- критерій, чи задача стандартна;
- підставу для зупинки, якщо задача нестандартна.

Якщо асистент не вносить код самостійно, цей блок може бути використаний як промт для розробника або іншої моделі.

## 7. Фінальна відповідь у чаті

Після створення артефактів асистент має дати коротку відповідь:

```text
Готово. Підготував пакет для <ALIAS>.

Файли:
- Jira-задача: ...
- аналітичний шаблон/технічний контракт: ...
- QA-пакет: ...
- План реалізації: ...
- Звіт: ...
- Архів: ...

Ключові зауваження:
- ...
```

У відповіді не треба вставляти весь великий паспорт, якщо він уже є файлом, але варто окремо вказати, які блоки можна копіювати в Jira, Confluence і передати тестувальнику.

## 8. Якщо прямого доступу до Jira або Confluence немає

Асистент не має обіцяти автоматично створити задачу або сторінку. Він має прямо сказати, що готує copy-paste-ready текст.

Якщо в майбутньому буде підключений Jira/Confluence-конектор або API-доступ із правами на запис, процес можна розширити, але базовий сценарій має залишатися ручним і безпечним.

## Copy-paste артефакти тільки після погодження тест-кейсів

Перед тим як віддати блоки “Скопіювати в Jira”, “Скопіювати в Confluence” або “Передати тестувальнику”, асистент має переконатися, що тест-кейси погоджені або явно позначити їх як чернетку.

Якщо тест-кейси не погоджені, у верхній частині copy-paste блоку потрібно написати:

```text
Увага: тест-кейси є чернеткою і потребують підтвердження аналітика.
```

Якщо Mongo-дані для QA не погоджені, у QA-блоці потрібно написати:

```text
Увага: тестові Mongo-дані не погоджені. У прикладах залишені placeholders.
```


## Додатковий артефакт: процесний feedback

Окрім основних артефактів події, пакет може містити додатковий файл:

```text
06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md
```

Його призначення — зібрати зауваження та ідеї, які виникли під час реальної роботи над подією і можуть покращити майбутні промти та шаблони.

Файл не призначений для Jira або Confluence як паспорт події. Його адресат — owner процесу, який підтримує загальний пакет `history-event-assistant`.


## Статуси, які обов’язково мають бути у фінальній видачі

Для кожної події у фінальній видачі потрібно показувати:

```text
Статус тест-кейсів: погоджені / чернетка
Статус Mongo-даних: погоджені / placeholders
QA-пакет готовий до виконання на dev: так / ні
```

Якщо Mongo-дані не погоджені, `04_QA_PACKAGE_<ALIAS>.md` є шаблоном, а не повністю готовою інструкцією для dev.

---

## Посилення v0.22: QA-файл як практична інструкція для тестувальника

QA-пакет `04_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має бути написаний як практична покрокова інструкція для тестувальника, а не як технічний опис для розробника.

Критерій готовності: тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, орієнтуватися на розширений приклад. Короткий шаблон є тільки skeleton-ом, не фінальним рівнем якості.

Перед віддачею QA-файла обов’язково застосувати checklist з `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md`. Якщо хоча б один пункт checklist не виконано, QA-файл не віддавати користувачу — спочатку виправити.


---

## Обов’язкове правило: два рівні тест-кейсів

Під час підготовки події зміни запису асистент має розділяти тест-кейси на два набори:

1. `Unit/processor test cases` (`TC-U01`, `TC-U02`, ...) — повний технічний набір для реалізації, unit-тестів, processor-level перевірок і edge cases.
2. `Manual QA test cases` (`TC-01`, `TC-02` або `TC-QA01`, `TC-QA02`, ...) — практичний набір для ручної перевірки тестувальником на dev.

Якщо набори різні, Jira-задача і аналітичний шаблон/технічний контракт мають містити обидва набори та mapping між ними. Окремий `04_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має містити тільки manual QA TC як практичну інструкцію для тестувальника.

Детальні правила, шаблони, checklist і приклад для `RECORD_COMPANY_TYPE_CHANGED` описані в `36_TWO_LEVEL_TEST_CASES_GUIDE.md`.


---

## Посилення v0.24: аналітичний шаблон vs project passport

У межах аналітичного пакета події асистент не створює окремий `03_CONFLUENCE_PASSPORT_<ALIAS>.md` за замовчуванням.

Канонічним результатом заповнення шаблону події є:

```text
01_TECHNICAL_CONTRACT_<ALIAS>.md
```

Цей файл містить погоджений бізнесовий і технічний контракт події: event type, processor, type/sub_type, джерело зміни, field path, правила створення, values, нормалізацію, missing/null/blank поведінку, unit/processor TC, manual QA TC і mapping між ними.

Project passport для репозиторію, наприклад:

```text
docs/record-change-events/source-record-internal/<ALIAS>.md
```

створюється або оновлюється не в аналітичному пакеті, а на етапі реалізації коду через окремий implementation prompt після аналізу актуального архіву модуля. Його не потрібно включати в загальний аналітичний архів до запиту архіву модуля.

Якщо користувач прямо просить окрему сторінку для Confluence, її можна створити як додатковий файл із назвою на кшталт `CONFLUENCE_PAGE_DRAFT_<ALIAS>.md`, але не підміняти ним project passport і не додавати його в мінімальний обов’язковий analysis package.


## Consistency review перед фіналізацією analysis package

Фінальний `<ALIAS>_analysis_package.zip` має пройти перевірку консистентності. Пакет не можна вважати готовим, якщо:

- `document_id` або інші QA-ідентифікатори обрізані в одному з файлів;
- Jira містить випадкові фрагменти тексту після генерації;
- manual QA TC у QA-пакеті не відповідають manual QA TC у Jira/історичному документі;
- traceability matrix не містить mapping між unit/processor TC і manual QA TC;
- файл `01_HISTORICAL_EVENT_<ALIAS>.md` фактично є project passport;
- `03_IMPLEMENTATION_PLAN_DRAFT_<ALIAS>.md` видає припущення про реальні файли за факт, якщо код ще не аналізувався.

Детальний checklist описаний у `38_ANALYSIS_ARTIFACT_CONSISTENCY_REVIEW.md`.

---

# FILE: 27_TEST_CASE_APPROVAL_AND_DATA_SELECTION.md

# Узгодження тест-кейсів і вибір тестових Mongo-даних

## 1. Призначення

Цей документ фіксує обов’язковий етап перед підготовкою фінальних артефактів для Jira, Confluence, реалізації і тестування: **тест-кейси та тестові дані мають бути окремо погоджені з аналітиком**.

Асистент може запропонувати повний перелік тест-кейсів самостійно, але не має вважати їх фінальними без підтвердження аналітика.

---

## 2. Чому це важливо

Тест-кейси є однією з головних частин задачі. Саме вони визначають:

- які сценарії буде перевіряти тестувальник;
- які дані треба підготувати в MongoDB;
- які REST-дії або ручні дії виконуються;
- які записи мають з’явитися в `changes`, `events`, `processing_errors`;
- що вважається дефектом, а що є очікуваною поведінкою.

Тому тест-кейси не можна автоматично “заховати” всередину Jira-задачі або паспорта без окремого перегляду.

---

## 3. Обов’язковий порядок дій

Після формування технічного контракту асистент має зробити проміжний крок:

```text
Я пропоную такий перелік тест-кейсів для <ALIAS>.
Перевір, будь ласка, чи всі сценарії потрібні, чи немає зайвих, і чи потрібно додати ще якісь бізнес-сценарії.
Після підтвердження я сформую Jira-задачу, аналітичний шаблон/технічний контракт, план реалізації і QA-пакет.
```

Після цього асистент показує таблицю тест-кейсів у зручному вигляді.

Фінальні артефакти створюються тільки після одного з таких підтверджень:

```text
Так, тест-кейси підходять.
```

або

```text
Залиш TC-01, TC-02, TC-04, додай сценарій ...
```

---

## 4. Статус тест-кейсів у фінальних документах

У Jira-задачі, аналітичний шаблон/технічний контракті і QA-пакеті потрібно явно фіксувати статус:

| Статус | Значення |
|---|---|
| `погоджено аналітиком` | тест-кейси були окремо переглянуті й підтверджені |
| `чернетка` | тест-кейси запропоновані асистентом, але ще не підтверджені |
| `потребує уточнення` | є відкриті питання щодо сценаріїв або очікуваної поведінки |

Якщо статус не `погоджено аналітиком`, артефакт не варто вважати фінальним для передачі в Jira або тестувальнику.

---

## 5. Правило вибору Mongo-записів для тестів

Асистент не має використовувати випадковий Mongo-запис, який раніше був наданий лише як приклад структури даних, як тестовий запис для нової події.

Для кожної події потрібно окремо попросити аналітика надати або підтвердити тестові дані:

```text
Для QA-пакета потрібні конкретні Mongo-записи, які можна використовувати в тестуванні цієї події.
Надай, будь ласка, один або кілька записів із dev-даних або підтверди, що можна використати запропонований запис.
```

---

## 6. Які дані треба попросити в аналітика

Для `UPDATE`-події:

- `document_id` або безпечний placeholder запису;
- `collection`, зазвичай `source_records`;
- `type`, `sub_type`;
- `record_key`, `document_id`, якщо вони потрібні для пошуку;
- поточне значення поля;
- нове значення для позитивного сценарію;
- приклади значень для негативних сценаріїв, якщо потрібні;
- чи можна змінювати цей запис багаторазово;
- чи треба повертати значення назад після тесту.

Для `APPEND`-події:

- запис або `document_id`, від якого можна наслідувати службові поля;
- приклад нового `currentRecord.item` або бізнес-полів для додавання;
- очікуваний `change.status=added` у `changes`;
- очікуваний event type;
- умови, за яких може створитися інший event type.

Для `DELETE`-події:

- запис, який можна безпечно видалити або реконструювати;
- очікуваний `change.status=deleted` у `changes`;
- чи потрібне відновлення запису після тесту.

---

## 7. Якщо аналітик не надав тестові Mongo-дані

У такому випадку QA-пакет все одно можна створити, але він має бути позначений як шаблонний:

```text
Статус QA-пакета: шаблон, тестові Mongo-дані не погоджені.
```

У REST-прикладах і Mongo-запитах потрібно залишати placeholders:

```text
<DOCUMENT_ID>
<RECORD_KEY>
<DOCUMENT_ID>
<OLD_VALUE>
<NEW_VALUE>
```

Асистент не має вигадувати реальні ідентифікатори або переносити випадкові приклади з попередніх задач.

---

## 8. Як формулювати пропозицію тест-кейсів

Рекомендований формат:

| TC | Сценарій | Вхідні дані | Очікування | Статус |
|---|---|---|---|---|
| TC-01 | Реальна зміна значення | old ≠ new після нормалізації | створюється `<ALIAS>` | запропоновано |
| TC-02 | Значення однакові | old = new | подія не створюється | запропоновано |
| TC-03 | Різниця тільки в пробілах/регістрі | old ≈ new після нормалізації | подія не створюється | запропоновано |
| TC-04 | Відсутнє нове значення | new missing/null | поведінка за контрактом | потребує підтвердження |

Після відповіді аналітика статуси оновлюються.

---

## 9. Правило для Jira і Confluence

Jira-задача і аналітичний шаблон/технічний контракт не повинні приховувати факт, що тест-кейси не погоджені.

Якщо тест-кейси ще не погоджені, у документі потрібно прямо написати:

```text
Тест-кейси є чернеткою і потребують підтвердження аналітика перед передачею в розробку або QA.
```

Якщо погоджені:

```text
Тест-кейси погоджені аналітиком і можуть використовуватися для реалізації та QA-перевірки.
```

## Додаткові правила погодження negative TC і missing values

Під час погодження тест-кейсів асистент має окремо показати аналітику сценарії, де old або new значення відсутнє. Стандартне очікування для користувацьких `values` — символ `—`.

Також асистент має явно позначати negative TC, у яких можлива інша нормальна поведінка модуля:

- зміна іншого поля може створити інший event type;
- інший `type/sub_type` може бути оброблений іншим processor-ом;
- відсутній processor може створити запис у `processing_errors`;
- усе це не є дефектом поточного event type-а, якщо поточний event type не створюється.


## Обов’язкова контрольна точка одразу після погодження TC

Після підтвердження тест-кейсів асистент має окремо повідомити:

```text
Тест-кейси погоджені. Перед формуванням `QA_<ALIAS>.md` потрібно погодити тестові Mongo-дані.
```

Цей checkpoint є обов’язковим. Не можна переходити від погодження TC одразу до “надай архів модуля”, “формую implementation prompt” або “формую фінальний пакет”, якщо ще не зафіксовано статус QA-даних.

Для `UPDATE`-події потрібно попросити або підтвердити: `collection`, `document_id` або placeholder, `record_key`, `document_id`, `type/sub_type`, поточне значення поля, нове значення для позитивного сценарію, значення для negative/normalization сценаріїв, можливість багаторазової зміни запису, rollback.

Якщо дані не надані, QA-пакет має статус: `шаблон, тестові Mongo-дані не погоджені`, а `QA-пакет готовий до виконання на dev: ні`.


---

## Обов’язкове правило: два рівні тест-кейсів

Під час підготовки події зміни запису асистент має розділяти тест-кейси на два набори:

1. `Unit/processor test cases` (`TC-U01`, `TC-U02`, ...) — повний технічний набір для реалізації, unit-тестів, processor-level перевірок і edge cases.
2. `Manual QA test cases` (`TC-01`, `TC-02` або `TC-QA01`, `TC-QA02`, ...) — практичний набір для ручної перевірки тестувальником на dev.

Якщо набори різні, Jira-задача і аналітичний шаблон/технічний контракт мають містити обидва набори та mapping між ними. Окремий `04_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має містити тільки manual QA TC як практичну інструкцію для тестувальника.

Детальні правила, шаблони, checklist і приклад для `RECORD_COMPANY_TYPE_CHANGED` описані в `36_TWO_LEVEL_TEST_CASES_GUIDE.md`.


## Перевірка TC після створення артефактів

Після погодження TC і створення Jira/історичного документа/QA-пакета потрібно перевірити, що:

- unit/processor TC присутні в Jira і історичному документі;
- manual QA TC присутні в Jira і історичному документі;
- QA-пакет містить тільки manual QA TC;
- mapping між наборами TC є в traceability matrix;
- TC для normalization мають приклади, які справді показують normalization behavior;
- TC, які неможливо виконати вручну без окремих даних, не подаються як готові до dev execution.

---

# FILE: 28_ASSISTANT_GUIDED_FLOW_RULES.md

# Правила активного ведення аналітика через процес

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


## 1. Мета

Цей документ фіксує правило, що асистент у цьому процесі є не пасивним виконавцем окремих відповідей, а ведучим повного циклу створення події зміни запису.

Аналітик не має самостійно здогадуватися, який наступний крок потрібен після кожної відповіді. Асистент має підтримувати рух процесу до завершення: пояснювати, який етап виконано, що це означає, які є наступні варіанти, що саме потрібно від аналітика і коли робота вважається завершеною.

## 2. Базове правило

Після кожного змістовного кроку асистент має явно сказати:

1. що саме вже виконано;
2. чи є на цьому етапі відкриті питання;
3. який наступний крок за процесом;
4. що потрібно від аналітика для переходу далі;
5. чи можна переходити далі одразу, чи потрібне підтвердження.

Асистент не має завершувати відповідь у стані, де аналітик має сам здогадатися, що робити далі.

## 3. Формат завершення кожного етапу

Після виконання етапу використовувати короткий службовий блок:

```text
Статус етапу:
<що виконано>

Відкриті питання:
<немає / перелік питань>

Наступний крок:
<конкретний наступний крок>

Що потрібно від тебе:
<підтвердити / надати Mongo-запис / надати zip / вибрати варіант / дозволити перейти далі>
```

Якщо відповідь уже містить добре структурований підсумок, цей блок може бути коротким, але він має бути присутній.

## 4. Коли потрібне підтвердження аналітика

Асистент має зупинитися й попросити підтвердження перед такими переходами:

1. від бізнес-опису до технічного контракту, якщо є неоднозначність;
2. від технічного контракту до паспорта і Jira-задачі;
3. від запропонованих тест-кейсів до фінальних артефактів;
4. від аналітичних артефактів до реалізації в коді;
5. від плану реалізації до зміни коду;
6. від чернеткового QA-пакета до фінального QA-пакета з конкретними Mongo-даними;
7. від review змін до архіву, якщо виявлені суттєві зауваження.

## 5. Коли можна переходити далі без додаткового питання

Асистент може перейти до наступного підетапу без окремого питання, якщо аналітик уже явно підтвердив рішення або написав команду на продовження, наприклад:

```text
так
йдемо далі
давай
погоджую
вносимо
роби
```

Навіть у цьому випадку асистент має коротко назвати, що саме переходить робити далі.

## 6. Як повідомляти про завершення всього процесу

Коли всі кроки завершені, асистент має явно сказати, що робота над подією завершена.

Формат:

```text
Роботу над <ALIAS> завершено.
Підготовлено:
- технічний контракт;
- Jira-задачу;
- аналітичний шаблон/технічний контракт;
- план реалізації;
- QA-пакет;
- фінальний звіт;
- архів або patch-файли, якщо виконувалась реалізація.

Наступних обов'язкових кроків у межах цієї події немає.
```

Якщо лишилися необов'язкові дії, їх потрібно позначити саме як необов'язкові.

## 7. Заборонена поведінка

Асистент не має:

- просто віддавати файл або текст без пояснення наступного кроку;
- чекати, що аналітик сам запитає “що далі?”;
- перескакувати через контрольні точки;
- створювати фінальні артефакти до погодження тест-кейсів;
- переходити до коду без підтвердженого плану реалізації;
- завершувати відповідь тільки словами “готово” без статусу і наступної дії.

## 8. Приклад правильної відповіді після погодження технічного контракту

```text
Технічний контракт погоджено.

Статус етапу:
Зафіксовано event type, processor, поле-тригер, values і нормалізацію.

Відкриті питання:
Потрібно погодити тест-кейси і тестові Mongo-дані.

Наступний крок:
Я покажу запропонований перелік тест-кейсів для підтвердження.

Що потрібно від тебе:
Перевірити TC і сказати, які залишаємо, які прибираємо або які сценарії треба додати.
```

## 9. Приклад правильної відповіді після створення фінальних артефактів

```text
Фінальні аналітичні артефакти підготовлено.

Статус етапу:
Підготовлено технічний контракт, Jira-задачу, аналітичний шаблон/технічний контракт, план реалізації, QA-пакет і delivery report.

Відкриті питання:
Для переходу до коду потрібен актуальний zip модуля.

Наступний крок:
Перехід до реалізації або передача артефактів у Jira/Confluence.

Що потрібно від тебе:
Надати актуальний `internal-record-change-processing-module.zip` або підтвердити, що на цьому етапі завершуємо аналітичну частину.
```


## Правило активного збору покращень процесу

Оскільки асистент є ведучим процесу, він має не тільки вести аналітика до наступного етапу, а й помічати повторювані проблеми процесу.

Якщо аналітик робить зауваження, яке стосується не тільки поточної події, а й загальних промтів, асистент має:

1. коротко підтвердити, що це процесне покращення;
2. внести його в `06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md`;
3. за потреби оновити конкретні артефакти поточної події;
4. у статусі етапу повідомити, що feedback зафіксовано;
5. у фінальному підсумку запропонувати перенести ці зміни в загальний пакет промтів.


## Правило вибору виконавця реалізації

Після погодження аналітичного контракту, тест-кейсів і QA-даних асистент має оцінити обсяг змін у коді. Якщо зміна локальна, вкладається в наявний механізм і потребує лише нового/оновленого rule-класу, реєстрації, тестів і документації, асистент має запропонувати варіант самостійного внесення змін у наданий архів.

Якщо зміна зачіпає загальні класи, routing processor-ів, lifecycle обробки, error handling, модель даних, REST-контракти або може вплинути на кілька існуючих подій, асистент має рекомендувати передати реалізацію розробнику й коротко пояснити причину так, щоб аналітик міг донести її розробнику. Детальні правила описані в `31_IMPLEMENTATION_OWNERSHIP_DECISION.md`.


## Активне ведення після погодження тест-кейсів

Коли TC погоджені, асистент має сам ініціювати наступний checkpoint і не чекати, поки аналітик здогадається надати Mongo/dev-дані. Правильний перехід:

```text
Статус етапу: тест-кейси погоджені.
Наступний крок: погодити тестові Mongo-дані для QA.
Що потрібно від тебе: надати або підтвердити collection, document_id, record_key, document_id, type/sub_type, old/new values, правила rollback.
```

---

## Посилення v0.22: QA-файл як практична інструкція для тестувальника

QA-пакет `04_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має бути написаний як практична покрокова інструкція для тестувальника, а не як технічний опис для розробника.

Критерій готовності: тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, орієнтуватися на розширений приклад. Короткий шаблон є тільки skeleton-ом, не фінальним рівнем якості.

Перед віддачею QA-файла обов’язково застосувати checklist з `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md`. Якщо хоча б один пункт checklist не виконано, QA-файл не віддавати користувачу — спочатку виправити.


---

## Обов’язкове правило: два рівні тест-кейсів

Під час підготовки події зміни запису асистент має розділяти тест-кейси на два набори:

1. `Unit/processor test cases` (`TC-U01`, `TC-U02`, ...) — повний технічний набір для реалізації, unit-тестів, processor-level перевірок і edge cases.
2. `Manual QA test cases` (`TC-01`, `TC-02` або `TC-QA01`, `TC-QA02`, ...) — практичний набір для ручної перевірки тестувальником на dev.

Якщо набори різні, Jira-задача і аналітичний шаблон/технічний контракт мають містити обидва набори та mapping між ними. Окремий `04_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має містити тільки manual QA TC як практичну інструкцію для тестувальника.

Детальні правила, шаблони, checklist і приклад для `RECORD_COMPANY_TYPE_CHANGED` описані в `36_TWO_LEVEL_TEST_CASES_GUIDE.md`.


---

## Посилення v0.24: аналітичний шаблон vs project passport

У межах аналітичного пакета події асистент не створює окремий `03_CONFLUENCE_PASSPORT_<ALIAS>.md` за замовчуванням.

Канонічним результатом заповнення шаблону події є:

```text
01_TECHNICAL_CONTRACT_<ALIAS>.md
```

Цей файл містить погоджений бізнесовий і технічний контракт події: event type, processor, type/sub_type, джерело зміни, field path, правила створення, values, нормалізацію, missing/null/blank поведінку, unit/processor TC, manual QA TC і mapping між ними.

Project passport для репозиторію, наприклад:

```text
docs/record-change-events/source-record-internal/<ALIAS>.md
```

створюється або оновлюється не в аналітичному пакеті, а на етапі реалізації коду через окремий implementation prompt після аналізу актуального архіву модуля. Його не потрібно включати в загальний аналітичний архів до запиту архіву модуля.

Якщо користувач прямо просить окрему сторінку для Confluence, її можна створити як додатковий файл із назвою на кшталт `CONFLUENCE_PAGE_DRAFT_<ALIAS>.md`, але не підміняти ним project passport і не додавати його в мінімальний обов’язковий analysis package.


## Перед переходом до реалізації

Як ведучий процесу, асистент має явно провести користувача через контрольну точку `Consistency review`.

Перед словами “надішли актуальний архів модуля” асистент має повідомити статус:

```text
Перевірка консистентності аналітичного пакета:
- документ події зміни запису: ...
- Jira-задача: ...
- QA-пакет: ...
- traceability matrix: ...
- критичні розбіжності: так/ні
- можна переходити до реалізації: так/ні/так після cleanup
```

Якщо виявлені cleanup-зауваження, асистент має запропонувати виправити їх перед переходом до коду.

---

# FILE: 29_MANUAL_QA_STEP_BY_STEP_GUIDE.md

# Покроковий QA-файл для ручної перевірки події зміни запису

## Обов’язкове правило: відомі REST endpoint-и для ручного QA не перепитувати

Якщо подія зміни запису тестується через зміну існуючого Mongo row, асистент **не має перепитувати endpoint** для UPDATE/patch-сценарію і не має залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`.

За замовчуванням використовувати відносний endpoint:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Для `publish-source-record-patch` завжди використовувати body через `operations`, а не через `patch`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Правила для `operations[].path`:

- шлях завжди відносний до `item`;
- правильно: `companyType.type`, `names.fullName`, `registeredAddress.full`;
- неправильно: `item.companyType.type`, `item.names.fullName`, `currentRecord.item.companyType.type`.

`operation=append` у цьому endpoint-і є параметром currentRecord-import test API для публікації reconstructed product queue payload. Це **не** бізнесовий тип зміни `APPEND` у create-history. Логічний тип зміни create-history перевіряється по фактичному `change.status` у записі `changes`.

Асистент може питати користувача про REST endpoint тільки якщо сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`, потрібен нестандартний endpoint, або користувач явно повідомив, що контракт endpoint-а на поточному стенді відрізняється. У звичайному UPDATE/patch-сценарії питати потрібно не endpoint, а конкретні Mongo/dev-дані, нове значення, rollback і безпечність зміни.


## 1. Призначення

QA-файл для конкретної події зміни запису має бути практичним керівництвом для тестувальника: що саме зробити, який REST виконати, яке тіло запиту передати, у якій колекції MongoDB Compass виконати пошук, який фільтр вставити в рядок пошуку, який результат очікувати і що робити далі.

Такий файл має бути достатньо точним, щоб у майбутньому його можна було використати як основу для автоматизованого тесту: наприклад, Python-скрипта або іншого інструмента, який виконує REST-запити й перевіряє MongoDB.

---

## 2. Обов’язкова структура QA-файла

Для кожної події файл `QA_<ALIAS>.md` має містити:

1. Загальні дані події.
2. Погоджені тестові Mongo-дані.
3. Загальні правила виконання тестів.
4. Окремий покроковий сценарій для кожного TC.
5. Окрему секцію rollback / повернення стану.
6. Секцію “що не є дефектом”.
7. Секцію “що передати розробнику при дефекті”.

Таблиця TC сама по собі недостатня. Після таблиці кожен TC має бути розписаний як інструкція виконання.

---

## 3. Формат Mongo-перевірок

У ручних QA-інструкціях не використовувати shell-команди виду:

```javascript
collection.find(...)
collection.findOne(...)
```

Команда працює з MongoDB Compass. Тому вказувати:

- назву колекції;
- фільтр для рядка пошуку `Filter`;
- за потреби `Sort`;
- за потреби `Limit`;
- якщо потрібна агрегація — окремий pipeline для вкладки `Aggregations`.

### Простий пошук

```text
Колекція: source_records
MongoDB Compass → Filter:
```

```json
{
  "_id": {"$oid": "<DOCUMENT_ID>"}
}
```

### Пошук із сортуванням і лімітом

```text
Колекція: changes
MongoDB Compass → Filter:
```

```json
{
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>",
  "change.status": "modified"
}
```

```text
MongoDB Compass → Sort:
```

```json
{
  "date": -1
}
```

```text
MongoDB Compass → Limit: 5
```

### Агрегація

Якщо перевірка потребує не простого пошуку, а агрегації, давати pipeline для MongoDB Compass → `Aggregations`:

```json
[
  {
    "$match": {
      "currentRecord.record_key": "<RECORD_KEY>"
    }
  },
  {
    "$sort": {
      "date": -1
    }
  },
  {
    "$limit": 5
  }
]
```

---

## Правило використання ідентифікаторів у QA-кроках

У QA-документах потрібно максимально підставляти вже відомі ідентифікатори, щоб тестувальник не працював із абстрактними placeholder-ами без пояснення.

Водночас важливо не змішувати різні типи `_id`:

| Назва в QA-документі | Що це | Коли відомий | Де використовується |
|---|---|---|---|
| `DOCUMENT_ID` або `DOCUMENT_ID` | `_id` вихідного запису в `source_records` або іншій source-колекції | відомий до старту TC, якщо аналітик надав тестовий запис | пошук source row у MongoDB Compass, поле `document_id` у REST-запиті `publish-mongo-*` |
| `CHANGE_ID` | `_id` нового запису в колекції `changes`, створеного після REST-запиту | стає відомий тільки після кроку пошуку в `changes` | пошук `events.change_id` і `processing_errors.change_id` |
| `RECORD_KEY` | бізнесовий ідентифікатор сутності / запису | зазвичай відомий із source row | допоміжний пошук у `changes` / `events`, але не заміна `CHANGE_ID` |

`DOCUMENT_ID` і `CHANGE_ID` — це не один і той самий ідентифікатор. Наприклад, `_id` запису в `source_records` не можна підставляти в `events.change_id` або `processing_errors.change_id`, якщо ці поля посилаються на `_id` запису з `changes`.

Якщо ідентифікатор уже відомий до виконання TC, його потрібно підставляти прямо в JSON-фільтр. Якщо ідентифікатор отримується на попередньому кроці, потрібно писати не просто `<CHANGE_ID_FROM_STEP_3>`, а пояснювати джерело, наприклад:

```text
CHANGE_ID_FROM_STEP_3 — значення `_id` запису з колекції `changes`, знайденого на кроці 3 цього TC.
```

Приклад для `events`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Приклад для `processing_errors`:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Якщо конкретний `CHANGE_ID` уже був отриманий і зафіксований у межах TC, у наступних кроках бажано підставити саме його фактичне значення або явно написати, з якого кроку його взяти.

---

## 4. Формат одного тест-кейса

Кожен TC має бути оформлений так:

```markdown
## TC-XX. <Назва сценарію>

### Мета
<Що саме перевіряє тест-кейс.>

### Передумови
- Який Mongo-запис використовується.
- Яке значення поля має бути перед стартом TC.
- Чи потрібно перед TC повернути baseline.
- Чи може TC створити іншу подію, яка не є дефектом.

### Крок 1. Перевірити початковий запис у `source_records`

Колекція: `source_records`

MongoDB Compass → Filter:

```json
{
  "_id": {"$oid": "<DOCUMENT_ID>"}
}
```

Очікування:
```text
item.<field> = <old value>
type = <type>
sub_type = <sub_type>
record_key = <record_key>
```

### Крок 2. Виконати REST-запит для створення зміни

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Тіло:
```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<path-relative-to-item>",
      "value": "<new value>"
    }
  ]
}
```

### Крок 3. Знайти створений запис у `changes`

Колекція: `changes`

MongoDB Compass → Filter:

```json
{
  "currentRecord.record_key": "<RECORD_KEY>",
  "change.collection": "<TYPE>",
  "change.item_context": "<SUB_TYPE>",
  "change.status": "modified"
}
```

MongoDB Compass → Sort:

```json
{
  "date": -1
}
```

MongoDB Compass → Limit: `5`

Очікування:
```text
Зберегти `_id` знайденого запису як `CHANGE_ID_FROM_STEP_3`. Це `_id` запису з `changes`, а не `_id` source row.
previousRecord.item.<field> = <old value>
currentRecord.item.<field> = <new value>
changeDetails містить <field>, якщо подія залежить від changeDetails.
```

### Крок 4. Запустити обробку create-history

```http
POST /api/record-change-events/process
```

Тіло:
```json
{
  "operation": "start"
}
```

### Крок 5. Перевірити `events`

Колекція: `events`

MongoDB Compass → Filter:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Для позитивного TC очікується конкретний event type і values. Для negative TC очікується відсутність саме поточного event type-а, але інші event type-и можуть бути допустимими.

### Крок 6. Перевірити `processing_errors`

Колекція: `processing_errors`

MongoDB Compass → Filter:

```json
{
  "change_id": {"$oid": "<CHANGE_ID_FROM_STEP_3>"}
}
```

Для позитивного TC записів не має бути. Для TC з іншим `type/sub_type` помилка рівня processor lookup може бути очікуваною і не є дефектом поточного event type-а.

### Крок 7. Rollback / повернення стану
<Конкретний REST-запит або ручний спосіб повернення даних.>
```

---

## 5. Вимоги до REST-кроків

1. Повний фізичний base URL не фіксується. Вказується відносний endpoint, наприклад:
   - `POST /internal/api/test/product-queue/publish-source-record-patch`
   - `POST /internal/api/test/product-queue/publish-source-record-add`
   - `POST /internal/api/test/product-queue/publish-source-record-delete`
   - `POST /api/record-change-events/process`
2. Для кожного TC потрібно показати конкретне тіло REST-запиту.
3. Якщо endpoint або body shape не підтверджено, TC не можна видавати як готовий до ручного виконання. Його потрібно позначити як `потребує підтвердження REST-контракту`.
4. `operation=append` у currentRecord-import test endpoint-ах не є бізнесовим APPEND для create-history. Тип зміни create-history визначає з фактичного `change.status` у `changes`.

---

## 6. Вимоги до Mongo-перевірок

Для кожного TC потрібно вказати перевірки в MongoDB Compass для:

1. `source_records` — перевірити початковий стан або rollback.
2. `changes` — знайти створений `ChangeRecord`.
3. `events` — знайти створену подію зміни запису або підтвердити її відсутність.
4. `processing_errors` — перевірити, чи зміна не пішла в помилку.

Для перевірки результату найкраще використовувати `change_id`, отриманий із `_id` запису `changes`, щоб не сплутати новий результат зі старими подіями того самого `record_key`.

У QA-файлах не писати shell-команди. Писати фільтри для MongoDB Compass у чистому JSON/Extended JSON форматі.

---

## 7. Правила для negative TC

У negative TC не можна писати просто “подія не створюється”, якщо може створитися інша подія.

Потрібно писати так:

```text
Очікується відсутність саме <ALIAS>. Якщо для зміненого поля існує інша подія зміни запису, вона може створитися, і це не є дефектом <ALIAS>.
```

Для іншого `type/sub_type` потрібно писати:

```text
Очікується, що <ALIAS> не створиться цим processor-ом. Якщо спрацював інший processor або запис потрапив у `processing_errors` через відсутній processor для іншого `type/sub_type`, це не є дефектом <ALIAS>.
```

---

## 8. Правила для відсутніх old/new значень

Якщо old або new бізнес-значення відсутнє, у `RecordChangeEvent.values` очікується `—`, якщо для конкретної події не погоджено інше.

Приклад:

```json
{
  "old#value": "—",
  "new#value": "Limited Company"
}
```

---

## 9. Автоматизаційна готовність

QA-файл вважається якісним, якщо з нього можна однозначно винести:

- список REST endpoint-ів;
- список request body;
- список колекцій MongoDB;
- список Compass filter JSON;
- список sort/limit або aggregation pipeline;
- очікувані значення після кожного кроку;
- змінні тестового сценарію: `DOCUMENT_ID`, `RECORD_KEY`, `CHANGE_ID`, `ALIAS`, `OLD_VALUE`, `NEW_VALUE`;
- правила rollback.

Якщо для автоматизації не вистачає даних, це потрібно явно записати в секції “Що потрібно уточнити для автоматизації”.


## Передумова для покрокового QA-гайда

Покроковий QA-гайд може бути готовим до виконання на dev тільки якщо тестові Mongo/dev-дані погоджені. Якщо дані не погоджені, гайду присвоюється статус шаблону, а всі REST body і MongoDB Compass filters використовують placeholders.

Обов’язкові статуси на початку QA-гайда:

```text
Статус тест-кейсів: погоджені / чернетка
Статус Mongo-даних: погоджені / placeholders
QA-пакет готовий до виконання на dev: так / ні
```

---

## Посилення v0.22: QA-файл як практична інструкція для тестувальника

QA-пакет `05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має бути написаний як практична покрокова інструкція для тестувальника, а не як технічний опис для розробника.

Критерій готовності: тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, орієнтуватися на розширений приклад. Короткий шаблон є тільки skeleton-ом, не фінальним рівнем якості.

Перед віддачею QA-файла обов’язково застосувати checklist з `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md`. Якщо хоча б один пункт checklist не виконано, QA-файл не віддавати користувачу — спочатку виправити.

---

# FILE: 30_PROCESS_IMPROVEMENT_FEEDBACK.md

# 30. Зворотний зв’язок для покращення процесу створення подій зміни запису

## Призначення документа

Цей документ описує обов’язковий механізм фіксації зауважень, ідей і покращень, які виникають під час реальної роботи аналітика з асистентом над конкретною історичною подією.

Мета — не втрачати практичні висновки з реальних кейсів і поступово покращувати загальні промти, шаблони, QA-пакети та правила процесу.

## Коли створювати файл з покращеннями

Для кожної події зміни запису в її робочому пакеті потрібно створювати окремий файл:

```text
07_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md
```

Файл створюється, якщо під час роботи над подією з’явилось хоча б одне з таких спостережень:

- аналітик вказав, що поточний процес незручний або неповний;
- тестувальнику потрібен більш детальний формат інструкції;
- у Jira/Confluence/QA-артефактах не вистачає блоку або структури;
- виявлено, що старі шаблони провокують помилки;
- знайшлось правило, яке має повторюватися для інших подій зміни запису;
- виникла ідея, як спростити роботу аналітика, розробника або тестувальника;
- стало зрозуміло, що певний тип даних, REST-крок, Mongo-перевірка або rollback потрібно описувати інакше.

Якщо покращень немає, файл все одно можна створити з коротким записом:

```text
Під час роботи над цією подією окремих покращень процесу не виявлено.
```

## Що не вносити в цей файл

У цей файл не потрібно дублювати:

- сам технічний контракт події;
- Jira-задачу;
- Confluence-паспорт;
- повний QA-пакет;
- implementation prompt;
- production-код або фрагменти тестів.

Файл має містити саме висновки про **покращення процесу**, а не повторення артефактів конкретної події.

## Рекомендована структура файла в пакеті події

```markdown
# Зворотний зв’язок для покращення процесу створення подій зміни запису: <ALIAS>

## 1. Контекст події

- Event type: `<ALIAS>`
- Тип даних: `<type / sub_type>`
- Етап, на якому виникло зауваження: `<аналіз / TC / QA / Jira / Confluence / реалізація / review>`

## 2. Виявлені зауваження до процесу

| № | Зауваження | Де виникло | Чому це важливо |
|---|------------|------------|-----------------|
| 1 | ... | ... | ... |

## 3. Запропоновані покращення загальних промтів

| № | Що змінити | У яких загальних файлах/шаблонах | Очікуваний ефект |
|---|------------|----------------------------------|------------------|
| 1 | ... | ... | ... |

## 4. Що вже враховано в поточному пакеті події

| № | Покращення | Статус |
|---|------------|--------|
| 1 | ... | Враховано / потребує перенесення в загальні промти |

## 5. Що потрібно передати owner-у процесу

Короткий перелік змін, які варто перенести в загальний пакет `history-event-assistant`.
```

## Правило для асистента

Асистент є ведучим процесу, тому він має самостійно відстежувати такі моменти.

Якщо під час діалогу з аналітиком виникло зауваження, яке потенційно корисне для майбутніх подій, асистент не має чекати окремої команди. Він має:

1. зафіксувати зауваження в робочому пакеті поточної події;
2. пояснити, що це не змінює тільки поточну подію, а є кандидатом на покращення загального процесу;
3. у фінальному delivery report вказати, що файл з процесним feedback створено або оновлено;
4. після завершення події запропонувати перенести ці зміни в загальні промти.

## Як використовувати файл після завершення події

Після завершення роботи над подією аналітик або owner процесу може взяти файл `07_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md` і використати його як вхідні дані для оновлення загального пакета промтів.

Це створює цикл покращення:

```text
Реальна робота над подією
→ зауваження аналітика / тестувальника / розробника
→ файл feedback у пакеті події
→ аналіз owner-ом процесу
→ оновлення загальних промтів
→ наступна подія проходить якісніше
```

## Мінімальна вимога до фінального пакета події

У фінальному пакеті кожної події має бути або:

```text
07_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md
```

або явна примітка в delivery report, що процесних покращень для цієї події не виявлено.

Для пілотних і перших реальних прогонів файл зворотного зв’язку бажано створювати завжди, навіть якщо в ньому лише кілька пунктів.


## Правило вибору виконавця реалізації

Після погодження аналітичного контракту, тест-кейсів і QA-даних асистент має оцінити обсяг змін у коді. Якщо зміна локальна, вкладається в наявний механізм і потребує лише нового/оновленого rule-класу, реєстрації, тестів і документації, асистент має запропонувати варіант самостійного внесення змін у наданий архів.

Якщо зміна зачіпає загальні класи, routing processor-ів, lifecycle обробки, error handling, модель даних, REST-контракти або може вплинути на кілька існуючих подій, асистент має рекомендувати передати реалізацію розробнику й коротко пояснити причину так, щоб аналітик міг донести її розробнику. Детальні правила описані в `31_IMPLEMENTATION_OWNERSHIP_DECISION.md`.


## Feedback: checkpoint QA-даних після TC

Якщо в реальному кейсі модель погодила TC, але не запросила Mongo/dev-дані перед QA-пакетом, це потрібно фіксувати як покращення процесу. Очікуване правило: після TC завжди окрема контрольна точка QA-даних; без неї фінальна Jira/Confluence/QA-видача не вважається повною.

---

## Process feedback v0.22: QA-файл має бути практичною інструкцією

З реального кейса `RECORD_COMPANY_TYPE_CHANGED` зафіксовано процесне покращення: QA-файл може формально містити правильні правила про MongoDB Compass, relative endpoint-и, rollback і negative TC, але залишатися незручним для тестувальника, якщо він написаний як технічний опис.

Надалі QA-файл потрібно перевіряти за критерієм: тестувальник може виконати TC зверху вниз без усних пояснень, окрім фізичного base URL і доступів до стенда.

Еталоном стилю є розширений `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`. Якщо короткий шаблон суперечить еталонному прикладу за рівнем практичності, перевага надається еталонному прикладу.


---

## Process feedback: розділення unit/processor TC і manual QA TC

З кейса `RECORD_COMPANY_TYPE_CHANGED` зафіксовано процесне покращення: Jira-задача і Confluence-паспорт мають містити два рівні тест-кейсів, якщо вони відрізняються:

- повний `unit/processor` набір для реалізації та автоматизованих тестів;
- скорочений `manual QA` набір для ручної dev-перевірки.

Окремий QA-файл для тестувальника не має дублювати повний unit/processor-набір як основну частину. Він має містити тільки manual QA TC та посилатися на Jira/паспорт як місце, де описано повний технічний набір.

Це правило винесено в `36_TWO_LEVEL_TEST_CASES_GUIDE.md` і має перевірятися перед віддачею фінального аналітичного архіву.


## Feedback з кейса RECORD_COMPANY_TYPE_CHANGED: consistency review

Реальний кейс показав, що після генерації аналітичних артефактів потрібен окремий consistency review. Модель може створити загалом правильний контракт, але залишити обрізаний `document_id`, випадковий текстовий фрагмент, невдалий TC-приклад або змішати назву аналітичного документа з project passport.

Це загальне правило для всіх наступних подій: після формування analysis package потрібно перевірити консистентність історичного документа, Jira, QA-пакета, traceability matrix і draft implementation plan до запиту архіву модуля.

---

# FILE: 31_IMPLEMENTATION_OWNERSHIP_DECISION.md

# 31. Вибір способу внесення змін у код

Цей документ описує правило, за яким асистент має пропонувати аналітику, хто саме має виконувати реалізацію події зміни запису: сам асистент у наданому архіві, зовнішня модель або розробник.

## Основний принцип

Асистент не повинен автоматично передавати будь-яку реалізацію розробнику, якщо зміни невеликі й добре вкладаються в поточний механізм. Так само асистент не повинен брати на себе зміни, які торкаються загальної архітектури або можуть зламати інші події.

Після погодження аналітичного контракту, тест-кейсів і QA-даних асистент має зробити коротку технічну оцінку обсягу змін і запропонувати один із варіантів.

## Варіант А. Асистент може внести зміни сам

Асистент пропонує самостійно внести зміни, якщо одночасно виконуються умови:

- зміна вкладається в існуючий processor / processor;
- достатньо додати або оновити event rule class;
- достатньо додати або оновити enum / реєстрацію rule, якщо це вже стандартний патерн;
- не потрібно змінювати загальний `DefaultRecordChangeEventProcessor`;
- не потрібно змінювати загальну модель `ChangeRecord`, `RecordChangeEvent`, `RecordChangeValues`, `RecordValueMapping`, `RecordChangeEventRule`, якщо тільки зміна не є вже узгодженим локальним використанням наявної можливості;
- не потрібно змінювати routing між processor-ами або factory;
- не потрібно змінювати загальну схему error handling;
- можна покрити зміни окремим тестовим класом для конкретного event type-а;
- зміни не вимагають міграції даних або зміни контрактів інших сервісів.

У такому випадку асистент має сказати аналітику приблизно так:

```text
Зміна виглядає локальною і вкладається в поточний механізм. Я можу внести її сам у наданий архів: додати/оновити rule-клас, тести, markdown поруч із тестом і паспорт події. Загальні класи не чіпаю, окрім уже існуючих точок реєстрації, якщо вони потрібні.
```

## Варіант Б. Краще передати розробнику

Асистент пропонує передати реалізацію розробнику, якщо є хоча б одна з умов:

- потрібно змінювати загальний processor або factory;
- потрібно змінювати загальний lifecycle обробки `ChangeRecord`;
- потрібно додавати новий processor або новий тип маршрутизації;
- потрібно змінювати модель даних, serialization/deserialization або entity-класи;
- потрібно змінювати error handling, locking, retry або queue-processing;
- потрібно змінювати механіку нормалізації, яка вплине на багато подій;
- потрібно змінювати REST-контракти, інтеграцію з currentRecord-import або зовнішні API;
- є ризик, що зміна вплине на кілька існуючих event type-ів;
- потрібне рішення про сумісність зі старими даними;
- не вистачає прикладів payload-ів або незрозумілий runtime contract.

У такому випадку асистент має не просто сказати “передати розробнику”, а пояснити чому, щоб аналітик міг донести це розробнику:

```text
Я рекомендую передати цю частину розробнику, тому що зміна зачіпає загальний механізм <назва механізму>. Це може вплинути не тільки на <ALIAS>, а й на інші події зміни запису. Для розробника потрібно окремо перевірити <конкретні ризики>.
```

## Формат рішення для аналітика

Після технічної оцінки асистент має явно показати рішення:

```text
Оцінка обсягу змін:
<локальна / середня / широка>

Рекомендований спосіб реалізації:
<асистент сам / зовнішня модель за промтом / розробник>

Причина:
<коротке пояснення>

Наступний крок:
<підтвердити самостійне внесення / передати промт розробнику / надати додаткові дані>
```

## Застосування до стандартних field-change подій

Для стандартної події виду `source record / INTERNAL / UPDATE / одне поле` зазвичай достатньо локальної реалізації:

- rule-клас;
- реєстрація rule, якщо event type новий;
- enum `RecordChangeEventType`, якщо event type новий;
- unit-тест події;
- `.md` поруч із тестовим класом;
- паспорт події;
- QA-пакет.

Якщо всі ці зміни виконуються без зміни загальних механізмів, асистент має пропонувати варіант самостійного внесення.

## Обовʼязкові обмеження

Навіть якщо асистент вносить зміни сам:

- не запускати тести без прямого прохання користувача;
- не включати `application*.yml` / `application*.yaml` у patch-архів;
- не робити повний аудит репозиторію без потреби;
- працювати тільки з файлами, потрібними для конкретної події;
- у підсумку явно вказати, які файли змінені;
- якщо під час роботи виявлено потребу змінювати загальні класи, зупинитися й попросити підтвердження або рекомендувати передачу розробнику.

---

# FILE: 32_QA_DATA_CHECKPOINT_AFTER_TC.md

# Контрольна точка QA-даних після погодження тест-кейсів

## 1. Призначення

Цей документ фіксує обов’язкову контрольну точку, яку асистент має виконати **після погодження тест-кейсів** і **до формування фінальних Jira / Confluence / QA / implementation артефактів**.

Мета — не допустити ситуації, коли тест-кейси вже погоджені, але QA-пакет створюється без конкретних Mongo/dev-даних або без явного статусу, що дані ще не погоджені.

---

## 2. Обов’язкова фраза після погодження TC

Після того як аналітик підтвердив тест-кейси, асистент має окремо зупинити процес і написати:

```text
Тест-кейси погоджені. Перед формуванням `QA_<ALIAS>.md` потрібно погодити тестові Mongo-дані.
```

Після цього асистент не переходить до фрази на кшталт “надай архів модуля”, “переходимо до коду”, “формую фінальний пакет”, поки не зафіксовано статус QA-даних.

---

## 3. Дані, які потрібно запросити для UPDATE-події

Для `UPDATE`-події асистент має попросити або підтвердити такі дані:

| Поле | Що потрібно отримати |
|---|---|
| `collection` | Колекція source row, зазвичай `source_records` |
| `document_id` | `_id` source row або безпечний placeholder `<DOCUMENT_ID>` |
| `record_key` | `record_key` запису / сутності |
| `document_id` | Якщо потрібен для пошуку або контролю |
| `type/sub_type` | Наприклад `source record / INTERNAL` |
| Поточне значення поля | `OLD_VALUE`, яке є у source row до тесту |
| Нове значення для позитивного TC | `NEW_VALUE`, яке буде подано через REST |
| Значення для negative/normalization TC | Наприклад варіанти з пробілами, регістром, `null`, missing |
| Чи можна змінювати запис багаторазово | Так / ні / тільки з rollback |
| Чи потрібен rollback | Так / ні / вручну / окремим REST |

Рекомендований текст:

```text
Для QA-пакета по `<ALIAS>` потрібні конкретні Mongo/dev-дані.
Надай, будь ласка, або підтверди:
- collection;
- document_id або дозвіл залишити `<DOCUMENT_ID>`;
- record_key;
- document_id, якщо потрібен;
- type/sub_type;
- поточне значення `<FIELD_PATH>`;
- нове значення для позитивного сценарію;
- значення для negative/normalization сценаріїв, якщо потрібні;
- чи можна змінювати запис багаторазово;
- чи потрібен rollback.
```

---

## 4. Якщо тестові Mongo-дані не надані

Якщо аналітик не надав або не підтвердив Mongo/dev-запис, QA-пакет можна сформувати лише як шаблонний.

У `QA_<ALIAS>.md` обов’язково написати:

```text
Статус QA-пакета: шаблон, тестові Mongo-дані не погоджені.
QA-пакет готовий до виконання на dev: ні.
```

У REST-прикладах і MongoDB Compass фільтрах залишати placeholders:

```text
<DOCUMENT_ID>
<RECORD_KEY>
<DOCUMENT_ID>
<OLD_VALUE>
<NEW_VALUE>
```

Асистент не має підставляти випадкові записи з попередніх діалогів або прикладів структури.

---

## 5. Якщо тестові Mongo-дані погоджені

Якщо аналітик надав або підтвердив Mongo/dev-запис, у фінальних артефактах треба явно писати:

```text
Статус тест-кейсів: погоджені аналітиком.
Статус Mongo-даних: погоджені.
QA-пакет готовий до виконання на dev: так.
```

У QA-пакеті потрібно підставляти реальні значення там, де вони відомі до старту TC:

- `collection`;
- `document_id`;
- `record_key`;
- `document_id`;
- `type/sub_type`;
- початкове значення поля;
- погоджене нове значення.

Ідентифікатори, які з’являються тільки під час виконання TC, наприклад `_id` запису з `changes`, потрібно позначати як значення з конкретного попереднього кроку:

```text
CHANGE_ID_FROM_STEP_3 — `_id` запису з колекції `changes`, знайденого на кроці 3 цього TC.
```

---

## 6. Заборона переходу до наступного етапу без статусу QA-даних

Після погодження TC асистент може перейти до фінальних Jira / Confluence / QA / implementation артефактів тільки якщо зафіксовано один із двох станів:

| Стан | Що дозволено |
|---|---|
| Mongo-дані погоджені | Формувати повний QA-пакет, готовий до dev-виконання |
| Mongo-дані не погоджені | Формувати лише шаблонний QA-пакет з placeholders і явним статусом |

Не можна одразу після TC писати:

```text
Наступний крок — надай архів модуля.
```

Правильно:

```text
Наступний крок — погодити тестові Mongo-дані для QA-пакета. Після цього я сформую фінальні Jira / Confluence / QA артефакти або позначу QA-пакет як шаблонний.
```

---

## 7. Обов’язкові статуси у фінальній видачі

У фінальній видачі по події асистент має явно вказати:

| Статус | Можливі значення |
|---|---|
| Тест-кейси | `погоджені` / `чернетка` |
| Mongo-дані | `погоджені` / `placeholders` |
| QA-пакет готовий до виконання на dev | `так` / `ні` |

Ці статуси мають бути в:

- `00_FLOW_STATUS_<ALIAS>.md`;
- `02_JIRA_TASK_<ALIAS>.md`;
- `03_CONFLUENCE_PASSPORT_<ALIAS>.md`;
- `05_QA_PACKAGE_<ALIAS>.md`;
- `06_DELIVERY_REPORT_<ALIAS>.md`.

---

# FILE: 33_KNOWN_QA_REST_ENDPOINTS.md

# Відомі REST endpoint-и для ручного QA подій зміни запису

Цей документ фіксує REST-контракти, які вже відомі процесу `history-event-assistant`. Асистент не має перепитувати їх у аналітика для типових сценаріїв і не має вигадувати альтернативний body shape.

## 1. UPDATE / зміна існуючого Mongo row

Для зміни існуючого Mongo row використовується:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

Body:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "<DOCUMENT_ID>",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "<FIELD_PATH_RELATIVE_TO_ITEM>",
      "value": "<NEW_VALUE>"
    }
  ]
}
```

Обов’язкові правила:

- не використовувати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`;
- не питати аналітика підтвердити цей endpoint для стандартного UPDATE/patch-сценарію;
- не використовувати body через поле `patch`;
- `operations[].path` завжди відносний до `item`;
- не додавати `item.` або `currentRecord.item.` у path;
- для реальної публікації використовувати `preview=false`;
- у поточному процесі використовувати `operation=append`;
- після виконання REST перевіряти фактичний `change.status` у `changes`, а не тлумачити `operation=append` як бізнесовий APPEND.

Приклад для `RECORD_COMPANY_TYPE_CHANGED`:

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "69b874b7a194013118b4f8e8",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "companyType.type",
      "value": "Public Company"
    }
  ]
}
```

## 2. Правильні та неправильні field path

Правильно:

```text
companyType.type
names.fullName
registeredAddress.full
```

Неправильно:

```text
item.companyType.type
item.names.fullName
currentRecord.item.companyType.type
```

## 3. Коли endpoint можна уточнювати

Асистент може уточнювати REST endpoint тільки якщо:

1. сценарій не покривається стандартними endpoint-ами `publish-source-record-patch`, `publish-source-record-add`, `publish-source-record-delete`;
2. потрібен нестандартний endpoint;
3. користувач явно сказав, що контракт endpoint-а на поточному стенді відрізняється;
4. потрібно підтвердити не endpoint, а безпечність конкретного Mongo-запису або тестові значення.

## 4. Що питати після погодження TC

Після погодження тест-кейсів для UPDATE-події асистент має питати не endpoint, а:

- `collection`;
- `document_id` або безпечний placeholder;
- `record_key`;
- `document_id`, якщо потрібен;
- `type/sub_type`;
- поточне значення поля;
- нове значення для позитивного сценарію;
- значення для negative/normalization сценаріїв;
- чи можна змінювати запис багаторазово;
- чи потрібен rollback.

---

# FILE: 34_ANALYSIS_PACKAGE_DELIVERY_CHECKPOINT.md

# Контрольна точка: аналітичний пакет віддано користувачу

Цей документ фіксує обов’язкову контрольну точку між аналітичною частиною роботи над історичною подією та переходом до аналізу коду / реалізації.

## 1. Суть правила

Асистент не має просити актуальний архів модуля, доки не підготував і не віддав користувачу окремий архів аналітичних артефактів для поточної події або доки користувач явно не сказав пропустити цей архів.

Назва контрольної точки:

```text
Аналітичний пакет віддано користувачу
```

## 2. Місце в процесі

Контрольна точка виконується після того, як:

1. технічний контракт підтверджено;
2. тест-кейси погоджені або явно позначені як чернетка;
3. тестові Mongo/dev-дані погоджені або явно позначені як placeholders;
4. QA endpoint-и відомі, підтверджені або явно позначені як placeholders;
5. сформовані Jira/Confluence/QA/draft implementation артефакти.

Контрольна точка виконується перед:

1. запитом актуального архіву модуля;
2. аналізом production/test/docs файлів проєкту;
3. формуванням плану реалізації по реальних файлах;
4. будь-якими code changes;
5. створенням patch-архіву.

## 3. Заборонений перехід

Асистент не має писати користувачу:

```text
Надішли актуальний архів модуля.
```

або схожий запит, якщо не виконано одне з двох:

1. архів `<ALIAS>_analysis_package.zip` створено і віддано користувачу;
2. користувач явно сказав: `аналітичний архів не потрібен, переходимо до реалізації`.

## 4. Обов’язковий склад аналітичного архіву

Для події `<ALIAS>` асистент створює архів:

```text
<ALIAS>_analysis_package.zip
```

Структура архіву:

```text
<ALIAS>/
  01_TECHNICAL_CONTRACT_<ALIAS>.md
  02_JIRA_TASK_<ALIAS>.md
  03_IMPLEMENTATION_PLAN_DRAFT_<ALIAS>.md
  04_QA_PACKAGE_<ALIAS>.md
  05_TRACEABILITY_MATRIX_<ALIAS>.md
  06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md
```

### Пояснення щодо файлів

`03_IMPLEMENTATION_PLAN_DRAFT_<ALIAS>.md` на цьому етапі може бути попереднім, без реальних шляхів коду, якщо архів модуля ще не надано.

`04_QA_PACKAGE_<ALIAS>.md` має бути конкретним, якщо Mongo-дані й endpoint-и погоджені. Якщо ні — файл залишається шаблонним із placeholders і з явним статусом:

```text
Статус QA-пакета: шаблон, тестові Mongo-дані не погоджені.
QA-пакет готовий до виконання на dev: ні.
```

`06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md` створюється, якщо під час роботи виявлені процесні помилки або ідеї для покращення інструкцій. Якщо таких ідей немає, файл можна створити з коротким записом:

```text
Під час роботи над подією окремих процесних покращень не зафіксовано.
```

## 5. Самоперевірка перед запитом архіву модуля

Перед тим як просити актуальний архів модуля, асистент має перевірити:

| Пункт | Має бути виконано |
|---|---|
| Технічний контракт | підтверджено або явно позначено як чернетка |
| Тест-кейси | погоджені або явно позначені як чернетка |
| Mongo/dev-дані для QA | погоджені або placeholders |
| QA endpoint-и | відомі або placeholders |
| Jira-задача | створена як файл або copy-paste блок |
| аналітичний шаблон/технічний контракт | створений як файл або copy-paste блок |
| QA-пакет | створений |
| Draft implementation plan | створений |
| Traceability matrix | створена |
| Process feedback | створений або явно не потрібен |
| Аналітичний zip | створений і відданий користувачу |

Якщо останній пункт — `ні`, асистент спочатку створює і віддає `<ALIAS>_analysis_package.zip`.

## 6. Стандартна відповідь після створення аналітичного архіву

Після створення архіву асистент відповідає:

```text
Готово. Підготував аналітичний пакет для <ALIAS>.

Файли в архіві:
- технічний контракт;
- Jira-задача;
- аналітичний шаблон/технічний контракт;
- попередній план реалізації;
- QA-пакет;
- матриця простежуваності;
- process feedback, якщо був.

Посилання:
<ALIAS>_analysis_package.zip

Наступний крок:
надішли актуальний архів модуля internal-record-change-processing-module, і я підготую план реалізації по реальних production/test/docs файлах перед змінами.
```

## 7. Очікувана послідовність у наступних подіях

Асистент має працювати так:

1. зібрати бізнес-опис;
2. сформувати і погодити технічний контракт;
3. сформувати і погодити TC;
4. погодити QA Mongo/dev-дані;
5. сформувати QA-файл;
6. сформувати Jira/Confluence/traceability/draft implementation plan;
7. створити і віддати `<ALIAS>_analysis_package.zip`;
8. лише після цього просити актуальний архів модуля.


---

## Посилення v0.24: аналітичний шаблон vs project passport

У межах аналітичного пакета події асистент не створює окремий `03_CONFLUENCE_PASSPORT_<ALIAS>.md` за замовчуванням.

Канонічним результатом заповнення шаблону події є:

```text
01_TECHNICAL_CONTRACT_<ALIAS>.md
```

Цей файл містить погоджений бізнесовий і технічний контракт події: event type, processor, type/sub_type, джерело зміни, field path, правила створення, values, нормалізацію, missing/null/blank поведінку, unit/processor TC, manual QA TC і mapping між ними.

Project passport для репозиторію, наприклад:

```text
docs/record-change-events/source-record-internal/<ALIAS>.md
```

створюється або оновлюється не в аналітичному пакеті, а на етапі реалізації коду через окремий implementation prompt після аналізу актуального архіву модуля. Його не потрібно включати в загальний аналітичний архів до запиту архіву модуля.

Якщо користувач прямо просить окрему сторінку для Confluence, її можна створити як додатковий файл із назвою на кшталт `CONFLUENCE_PAGE_DRAFT_<ALIAS>.md`, але не підміняти ним project passport і не додавати його в мінімальний обов’язковий analysis package.


## Додаткова умова: analysis package має пройти consistency review

Перед тим як віддати `<ALIAS>_analysis_package.zip` як фінальний пакет і перейти до запиту архіву модуля, перевірити пакет за `38_ANALYSIS_ARTIFACT_CONSISTENCY_REVIEW.md`.

Якщо review знайшов помилки, архів можна віддати лише зі статусом `потребує cleanup`, або спочатку виправити документи і тільки потім віддати фінальну версію.

---

# FILE: 35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md

# QA-пакет як практична інструкція для тестувальника

Цей документ фіксує обов’язковий стандарт для файлів `05_QA_PACKAGE_<ALIAS>.md` або `QA_<ALIAS>.md`.

Головне правило: QA-файл пишеться **для тестувальника**, який відкриває файл і виконує кроки на dev-стенді зверху вниз. Це не технічний опис для розробника і не скорочений перелік ідей для перевірки.

Критерій готовності:

> Тестувальник може виконати TC зверху вниз без усних пояснень від аналітика або розробника, окрім фізичного base URL і доступів до стенда.

## 1. Еталон стилю

Якщо є конфлікт між коротким шаблоном QA-пакета і розширеним прикладом `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, асистент має орієнтуватися на розширений приклад.

Короткий шаблон можна використовувати тільки як мінімальний skeleton. Фінальний QA-файл не має бути коротшим або менш практичним за еталонний приклад.

## 2. Обов’язкова структура QA-файла

Кожен `05_QA_PACKAGE_<ALIAS>.md` або `QA_<ALIAS>.md` має використовувати таку структуру.

```text
# QA-пакет для ручної перевірки `<ALIAS>`

## 1. Статус QA-пакета
- Event type
- Статус тест-кейсів
- Статус Mongo-даних
- Чи можна виконувати на dev без додаткових уточнень
- Рівень перевірки

Коротко пояснити:
- цей файл є покроковою інструкцією для тестувальника;
- він не описує загально “як тестувати”, а задає послідовність дій;
- фізичний base URL не фіксується, використовуються relative endpoint-и.

## 2. Що перевіряємо
- короткий бізнес-сенс;
- погоджений технічний контракт у таблиці;
- processor;
- type/sub_type;
- фактичний статус у `changes`;
- поле;
- нормалізація;
- values;
- правила для missing/null/blank.

## 3. Погоджений Mongo-запис
- collection;
- Mongo `_id`;
- type;
- sub_type;
- source;
- document_id;
- record_key;
- поточні значення ключових полів.

Після таблиці обов’язково додати блок змінних:
- DOCUMENT_ID / DOCUMENT_ID
- RECORD_KEY
- TYPE
- SUB_TYPE
- ALIAS
- BASELINE_...
- CHANGE_ID_FROM_STEP_N

Обов’язково пояснити, що `CHANGE_ID_FROM_STEP_N` — це `_id` запису з `changes`, а не `_id` source row.

## 4. Загальні правила виконання TC
- перед кожним TC повернути baseline, якщо попередній TC змінював дані;
- після REST-запиту знайти запис у `changes`;
- зберегти `_id` з `changes` як `CHANGE_ID_FROM_STEP_N`;
- після `POST /api/record-change-events/process` перевіряти `events` переважно за `change_id = CHANGE_ID_FROM_STEP_N`;
- для negative TC перевіряти відсутність саме поточного event type-а;
- пояснити, що rollback може створити окремий `changes`/event і не враховується як результат TC.

## 4.1. Правило ідентифікаторів
Окрема таблиця:
- `DOCUMENT_ID / DOCUMENT_ID`;
- `CHANGE_ID_FROM_STEP_N`;
- `RECORD_KEY`.

Обов’язково додати заборону: не підставляти `_id` source row у `events.change_id` або `processing_errors.change_id`.

## 5. Допоміжні запити
- перевірити source row у `source_records`;
- запустити `POST /api/record-change-events/process`;
- перевірити `processing_errors`;
- за потреби — допоміжний запит для останніх `events`.

## 6+. Окремі TC
Кожен TC має бути повністю покроковим:
- мета;
- передумови;
- крок 1: перевірити baseline;
- крок 2: виконати REST-запит;
- крок 3: знайти запис у `changes`;
- крок 4: запустити create-history;
- крок 5: перевірити `events`;
- крок 6: перевірити `processing_errors`;
- крок 7: rollback, якщо потрібен.

## Останні секції
- що передати розробнику при дефекті;
- що не є дефектом;
- що потрібно уточнити для майбутньої автоматизації.
```

## 3. Checklist перед віддачею QA-файла

Перед тим як віддати `QA_<ALIAS>.md` або `05_QA_PACKAGE_<ALIAS>.md`, асистент має перевірити:

1. Чи є статус QA-пакета на початку?
2. Чи зрозуміло, що це файл для тестувальника, а не технічний опис?
3. Чи є погоджений Mongo-запис або явно вказано, що дані placeholders?
4. Чи є блок змінних?
5. Чи є окрема секція про різницю між `DOCUMENT_ID / DOCUMENT_ID` і `CHANGE_ID_FROM_STEP_N`?
6. Чи всі Mongo-перевірки оформлені під MongoDB Compass: collection, Filter, Sort, Limit?
7. Чи в усіх REST-запитах використані relative endpoint-и?
8. Чи не вказано фізичний base URL?
9. Чи для `publish-source-record-patch` використано `operations[]`, а не `patch`?
10. Чи `operations[].path` відносний до `item`, без префікса `item.`?
11. Чи кожен TC має мету, передумови, REST-запит, перевірку `changes`, запуск `/api/history`, перевірку `events`, перевірку `processing_errors` і rollback?
12. Чи для negative TC написано, що очікується відсутність саме поточного event type-а?
13. Чи пояснено, що інші event type-и можуть створюватися і це не дефект поточної події?
14. Чи є секція “Що передати розробнику при дефекті”?
15. Чи є секція “Що не є дефектом”?
16. Чи є секція “Що потрібно уточнити для майбутньої автоматизації”?
17. Чи немає сирих placeholder-ів без пояснення, звідки взяти значення?
18. Чи всі `change_id` і `change_id` використовують `CHANGE_ID_FROM_STEP_N`, а не source Mongo `_id`?

Якщо будь-який пункт не виконано, QA-файл не можна віддавати користувачу. Спочатку потрібно виправити файл.

## 4. Назви TC для ручного QA

Для ручного QA не використовувати надто технічні назви типу `TC-QA01`, якщо файл уже є покроковим. Краще:

```text
TC-01. Реальна зміна `companyType.type` створює `RECORD_COMPANY_TYPE_CHANGED`
TC-02. Однакове значення не створює `RECORD_COMPANY_TYPE_CHANGED`
TC-03. Різниця тільки в регістрі не створює подію
```

`TC-QAxx` можна залишати у traceability matrix або аналітичному контракті, але файл для тестувальника має бути читабельним.

## 5. Обсяг ручних TC

Не переносити весь unit-набір у ручний QA-файл як основну частину, якщо частина TC краще покривається unit-тестами.

У ручному QA-файлі потрібно:

- залишати тільки практично виконувані інтеграційні TC;
- для сценаріїв, які потребують інших даних або не підходять для погодженого Mongo-запису, явно писати: “покривається unit-тестом” або “потребує окремих тестових даних”;
- не змушувати тестувальника виконувати технічно дубльовані missing/null/blank варіанти, якщо це вже покрито unit-тестами.

## 6. Дефектність результату

Для кожного negative або edge TC потрібно явно пояснювати, що не є дефектом:

- інший event type створився;
- processor lookup error виник для іншого `type/sub_type`;
- no-op зміна не створила запис у `changes`;
- rollback створив додатковий `changes`;
- `operation=append` у test endpoint не означає бізнесовий APPEND;
- `currentRecord.item.changeType` не керує маршрутизацією create-history.

## 7. Bug report

Кожен QA-пакет має містити секцію “Що передати розробнику при дефекті” з мінімальним набором:

- номер TC;
- REST endpoint і request body;
- `_id` запису в `changes`;
- relevant old/new values;
- результат пошуку в `events`;
- результат пошуку в `processing_errors`;
- очікуваний результат;
- фактичний результат.

## 8. Future automation

Кожен QA-пакет має завершуватися секцією “Що потрібно уточнити для майбутньої автоматизації”:

- фізичні base URL;
- авторизація;
- очищення або ізоляція тестових `events` і `changes`;
- підтримка `value: null`;
- rollback-політика;
- обмеження dev-даних.

## 9. Process feedback

Це правило виникло з реального кейса `RECORD_COMPANY_TYPE_CHANGED`: короткі QA-шаблони можуть формально містити правильні endpoint-и, MongoDB Compass і rollback, але все одно давати файл, незручний для тестувальника. Тому якість QA-файла перевіряється не тільки на наявність технічних блоків, а й на практичну виконуваність зверху вниз.


---

## Обов’язкове правило: два рівні тест-кейсів

Під час підготовки події зміни запису асистент має розділяти тест-кейси на два набори:

1. `Unit/processor test cases` (`TC-U01`, `TC-U02`, ...) — повний технічний набір для реалізації, unit-тестів, processor-level перевірок і edge cases.
2. `Manual QA test cases` (`TC-01`, `TC-02` або `TC-QA01`, `TC-QA02`, ...) — практичний набір для ручної перевірки тестувальником на dev.

Якщо набори різні, Jira-задача і Confluence-паспорт мають містити обидва набори та mapping між ними. Окремий `05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має містити тільки manual QA TC як практичну інструкцію для тестувальника.

Детальні правила, шаблони, checklist і приклад для `RECORD_COMPANY_TYPE_CHANGED` описані в `36_TWO_LEVEL_TEST_CASES_GUIDE.md`.

---

# FILE: 36_TWO_LEVEL_TEST_CASES_GUIDE.md

# 36. Два рівні тест-кейсів: unit/processor і manual QA

Цей документ фіксує обов’язкове правило для всіх подій зміни запису: тест-кейси потрібно розділяти за рівнем виконання. Це правило з’явилося з практичного кейса `RECORD_COMPANY_TYPE_CHANGED`, де повний технічний набір перевірок для реалізації був змішаний із ручними QA-сценаріями для тестувальника.

## 1. Основне правило

Для кожної події зміни запису асистент має розділяти тест-кейси на два рівні:

1. **Unit/processor test cases** — повний технічний набір для реалізації, unit-тестів, processor-level перевірок і edge cases.
2. **Manual QA test cases** — практичний набір для ручної інтеграційної перевірки тестувальником на dev через REST endpoint-и, MongoDB Compass, `POST /api/record-change-events/process`, `events`, `processing_errors` і rollback.

Якщо ці набори повністю збігаються, це потрібно прямо написати. Якщо вони різні, обидва набори мають бути явно присутні в Jira-задачі та Confluence-паспорті, а окремий QA-файл має містити тільки manual QA TC.

## 2. Де мають бути обидва набори

Jira-задача та Confluence-паспорт є джерелами правди для розробника, тестувальника й аналітика. Тому вони мають містити:

- таблицю `Тест-кейси для реалізації та unit/processor-тестів`;
- таблицю `Тест-кейси для ручної QA-перевірки`;
- таблицю `Відповідність між unit/processor TC і manual QA TC`.

Окремий файл `05_QA_PACKAGE_<ALIAS>.md` або `QA_<ALIAS>.md` не має дублювати повний unit/processor-набір як основну частину. Він має бути практичною інструкцією для тестувальника і містити тільки ті manual QA TC, які реально виконуються на dev.

## 3. Шаблон для Jira-задачі

```markdown
## Тест-кейси для реалізації та unit/processor-тестів

Цей набір використовується розробником для покриття логіки в unit/processor tests.

| TC | Сценарій | Вхідні дані | Очікуваний результат | Рівень |
|---|---|---|---|---|
| `TC-U01` | ... | ... | ... | unit/processor |

## Тест-кейси для ручної QA-перевірки

Цей набір використовується тестувальником у файлі `05_QA_PACKAGE_<ALIAS>.md`.

| TC | Сценарій | Тестові дані | Очікуваний результат | Коментар |
|---|---|---|---|---|
| `TC-01` | ... | ... | ... | manual QA |

## Відповідність між unit/processor TC і manual QA TC

| Manual QA TC | Покриває unit/processor TC | Коментар |
|---|---|---|
| `TC-01` | `TC-U01`, частково `TC-U13` | Ручна перевірка основного positive сценарію |
```

## 4. Шаблон для Confluence-паспорта

```markdown
## Тест-кейси для реалізації та unit/processor-тестів

<Повна таблиця TC-U*>

## Тест-кейси для ручної QA-перевірки

<Скорочена таблиця TC-QA* або TC-*>

## Відповідність між unit/processor TC і manual QA TC

<Mapping table>
```

Паспорт є джерелом правди для розробника і тестувальника. Повний unit/processor-набір не потрібно переносити як покрокову ручну інструкцію; manual QA набір має бути достатнім для dev-перевірки ключових інтеграційних сценаріїв.

## 5. Правило для окремого QA-файла

`05_QA_PACKAGE_<ALIAS>.md` / `QA_<ALIAS>.md` має містити тільки manual QA набір.

У QA-файлі потрібно додавати коротку секцію:

```markdown
## Межі цього QA-файла

Цей файл містить тільки ручні інтеграційні TC для тестувальника.
Повний unit/processor-набір описаний у Jira-задачі та паспорті події.
```

Не дублювати `TC-U01`–`TC-Uxx` як таблицю реалізації в QA-файлі, якщо ці сценарії не виконуються вручну.

## 6. Правило для traceability matrix

Матриця простежуваності має показувати зв’язок між вимогами, unit/processor TC і manual QA TC.

```markdown
| Вимога | Unit/processor TC | Manual QA TC | Коментар |
|---|---|---|---|
| Створювати подію при реальній зміні | `TC-U01` | `TC-01` | Покрито автоматично і вручну |
| old missing/null/blank -> `—` | `TC-U02`, `TC-U03`, `TC-U04` | `TC-05` | Manual QA перевіряє representative null-сценарій |
| new missing/null/blank -> `—` | `TC-U05`, `TC-U06`, `TC-U07` | `TC-06` | Manual QA перевіряє representative null-сценарій |
| Різниця тільки у пробілах/регістрі не створює подію | `TC-U09`, `TC-U10` | `TC-03`, `TC-04` | Покрито обома рівнями |
| Нерелевантне поле не створює event type | `TC-U11`, `TC-U12` | `TC-07` | Manual QA може змінити одне representative інше поле |
```

## 7. Правило нумерації

Використовувати різну нумерацію для різних наборів:

- `TC-U01`, `TC-U02`, ... — unit/processor test cases;
- `TC-QA01`, `TC-QA02`, ... або `TC-01`, `TC-02`, ... — manual QA test cases.

Якщо в QA-файлі використовується читабельна нумерація `TC-01`, `TC-02`, у Jira-задачі та паспорті потрібно прямо написати, що це manual QA TC, а не unit/processor TC.

## 8. Checklist перед віддачею Jira/Confluence/QA

Перед створенням фінального аналітичного архіву асистент має перевірити:

1. Чи існує повний unit/processor TC набір?
2. Чи існує manual QA TC набір?
3. Якщо набори різні — чи обидва додані в Jira-задачу?
4. Якщо набори різні — чи обидва додані в Confluence-паспорт?
5. Чи QA-файл містить тільки manual QA TC?
6. Чи є mapping між unit/processor TC і manual QA TC?
7. Чи не змішано нумерацію `TC-U*` і `TC-*` без пояснення?
8. Чи зрозуміло, які TC має реалізувати розробник у unit-тестах?
9. Чи зрозуміло, які TC має виконати тестувальник вручну?
10. Чи не дублює QA-файл повний unit-набір, перевантажуючи тестувальника технічними сценаріями?
11. Чи в QA-файлі є тільки ті сценарії, для яких є REST/Mongo стратегія, або явно написано, що потрібні окремі дані?
12. Чи в traceability matrix показано зв’язок між вимогами, unit/processor TC і manual QA TC?

Якщо будь-який пункт не виконаний, не віддавати фінальний архів. Спочатку виправити Jira, паспорт, QA-пакет і traceability matrix.

## 9. Еталон для `RECORD_COMPANY_TYPE_CHANGED`

### Тест-кейси для реалізації та unit/processor-тестів

| TC | Сценарій | Очікуваний результат | Рівень |
|---|---|---|---|
| `TC-U01` | `Limited Company -> Public Company` | створюється `RECORD_COMPANY_TYPE_CHANGED` | unit/processor |
| `TC-U02` | old missing, new `Limited Company` | створюється, `old#value=—` | unit |
| `TC-U03` | old `null`, new `Limited Company` | створюється, `old#value=—` | unit/QA |
| `TC-U04` | old blank, new `Limited Company` | створюється, `old#value=—` | unit |
| `TC-U05` | old `Limited Company`, new missing | створюється, `new#value=—` | unit |
| `TC-U06` | old `Limited Company`, new `null` | створюється, `new#value=—` | unit/QA |
| `TC-U07` | old `Limited Company`, new blank | створюється, `new#value=—` | unit |
| `TC-U08` | old і new missing/null/blank | не створюється | unit |
| `TC-U09` | різниця тільки у пробілах | не створюється | unit/QA |
| `TC-U10` | різниця тільки у регістрі | не створюється | unit/QA |
| `TC-U11` | `change.fieldPath=names.fullName` | саме `RECORD_COMPANY_TYPE_CHANGED` не створюється | unit/QA |
| `TC-U12` | `change.fieldPath=companyType.subType` | саме `RECORD_COMPANY_TYPE_CHANGED` не створюється | unit/QA |
| `TC-U13` | `change.status=added/deleted` | саме `RECORD_COMPANY_TYPE_CHANGED` не створюється | unit/fixture |
| `TC-U14` | непарсабельний payload | стандартний error сценарій | processor-level / опис |

### Тест-кейси для ручної QA-перевірки

| TC | Сценарій | Тестові дані | Очікуваний результат |
|---|---|---|---|
| `TC-01` | Реальна зміна `companyType.type` | `Limited Company -> Public Company` | створюється `RECORD_COMPANY_TYPE_CHANGED`, `old#value=Limited Company`, `new#value=Public Company` |
| `TC-02` | Однакове значення | `Limited Company -> Limited Company` | `RECORD_COMPANY_TYPE_CHANGED` не створюється або no-op не створює `changes` |
| `TC-03` | Різниця тільки в регістрі | `Limited Company -> limited company` | `RECORD_COMPANY_TYPE_CHANGED` не створюється |
| `TC-04` | Різниця тільки в пробілах | `Limited Company -> Limited   Company` | `RECORD_COMPANY_TYPE_CHANGED` не створюється |
| `TC-05` | Старе значення відсутнє, нове з’явилось | `null -> Limited Company` | створюється, `old#value=—`, `new#value=Limited Company` |
| `TC-06` | Старе значення було, нове зникло | `Limited Company -> null` | створюється, `old#value=Limited Company`, `new#value=—` |
| `TC-07` | Змінилось інше поле | змінити `names.shortName` або `companyType.subType` | саме `RECORD_COMPANY_TYPE_CHANGED` не створюється |
| `TC-08` | Інший `type/sub_type` | окремий погоджений запис або unit/fixture | саме `RECORD_COMPANY_TYPE_CHANGED` не створюється |

### Відповідність між наборами

| Manual QA TC | Покриває unit/processor TC | Коментар |
|---|---|---|
| `TC-01` | `TC-U01` | Основний positive сценарій |
| `TC-02` | частина `TC-U08` / equality behavior | Практичний no-op/equal сценарій |
| `TC-03` | `TC-U10` | Нормалізація регістру |
| `TC-04` | `TC-U09` | Нормалізація пробілів |
| `TC-05` | `TC-U03`, частково `TC-U02`/`TC-U04` | Ручна перевірка null як representative для missing/blank |
| `TC-06` | `TC-U06`, частково `TC-U05`/`TC-U07` | Ручна перевірка null як representative для missing/blank |
| `TC-07` | `TC-U11`, `TC-U12` | Negative scenario для нерелевантного поля |
| `TC-08` | `TC-U13` | Нецільовий сценарій або інший processor |

---

# FILE: 37_ANALYTICAL_TEMPLATE_VS_PROJECT_PASSPORT.md

# Аналітичний шаблон vs project passport

Цей документ фіксує різницю між аналітичним контрактом події, Jira-задачею, QA-пакетом і project passport, який зберігається в репозиторії.

## 1. Канонічний результат заповнення шаблону

Для поточного процесу канонічним результатом заповнення шаблону події є файл:

```text
01_TECHNICAL_CONTRACT_<ALIAS>.md
```

Цей файл є робочим джерелом істини до етапу реалізації. Він має містити:

- event type події;
- processor;
- `type/sub_type`;
- logical change type;
- джерело зміни;
- field path;
- правила створення події;
- values;
- нормалізацію;
- missing/null/blank поведінку;
- unit/processor test cases;
- manual QA test cases;
- mapping між рівнями TC;
- відкриті питання або статус їх відсутності.

## 2. Що таке `03_CONFLUENCE_PASSPORT_<ALIAS>.md`

Файл `03_CONFLUENCE_PASSPORT_<ALIAS>.md` більше не є обов’язковим артефактом analysis package.

У попередніх версіях він змішував дві різні речі:

1. сторінку для Confluence / аналітичного погодження;
2. project passport для репозиторію `docs/record-change-events/source-record-internal/<ALIAS>.md`.

Це створювало плутанину, тому мінімальний analysis package більше не включає цей файл.

## 3. Коли створюється project passport

Project passport для репозиторію створюється або оновлюється на етапі реалізації коду, після того як користувач надав актуальний архів модуля і асистент підготував implementation prompt або самостійно вносить зміни.

Приклад шляху:

```text
docs/record-change-events/source-record-internal/RECORD_COMPANY_TYPE_CHANGED.md
```

Це не є частиною попереднього аналітичного архіву.

## 4. Мінімальний analysis package

Для події `<ALIAS>` мінімальний аналітичний архів має таку структуру:

```text
<ALIAS>_analysis_package.zip
└── <ALIAS>/
    ├── 01_TECHNICAL_CONTRACT_<ALIAS>.md
    ├── 02_JIRA_TASK_<ALIAS>.md
    ├── 03_IMPLEMENTATION_PLAN_DRAFT_<ALIAS>.md
    ├── 04_QA_PACKAGE_<ALIAS>.md
    ├── 05_TRACEABILITY_MATRIX_<ALIAS>.md
    └── 06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md
```

## 5. Якщо користувач просить Confluence-сторінку

Якщо користувач прямо просить окремий copy-paste документ для Confluence, асистент може створити додатковий файл:

```text
CONFLUENCE_PAGE_DRAFT_<ALIAS>.md
```

Але він має бути позначений як опційний додатковий артефакт, а не як project passport і не як обов’язкова частина мінімального analysis package.

## 6. Заборона

Асистент не має:

- додавати project passport у попередній analysis package;
- називати project passport Confluence-паспортом;
- створювати `03_CONFLUENCE_PASSPORT_<ALIAS>.md` за замовчуванням;
- просити архів модуля до того, як віддано analysis package або користувач явно попросив пропустити цей етап.

## 7. Коротке правило для асистента

Якщо виникає питання, який файл є результатом заповнення шаблону, відповідь така:

```text
01_TECHNICAL_CONTRACT_<ALIAS>.md
```

Якщо потрібно створити або оновити project passport у репозиторії, це робиться пізніше на етапі реалізації коду.

---

# FILE: 38_ANALYSIS_ARTIFACT_CONSISTENCY_REVIEW.md

# 38. Перевірка консистентності аналітичних артефактів перед передачею в реалізацію

Цей документ описує обов’язковий review-крок після формування аналітичного пакета події зміни запису і перед тим, як просити актуальний архів модуля або передавати задачу в реалізацію.

## 1. Навіщо потрібен цей крок

Під час роботи над реальною подією модель може правильно зібрати основну логіку, але допустити помилки в узгодженості між артефактами:

- у Jira-задачі може бути неповний або обрізаний `document_id`;
- у Jira або історичному документі можуть залишитися сміттєві фрагменти після генерації або копіювання;
- назва документа може змішувати аналітичний шаблон і project passport;
- TC у Jira, історичному документі, QA-пакеті та traceability matrix можуть відрізнятися без пояснення;
- приклад normalization TC може виглядати як identical-value TC;
- manual QA TC може бути описаний як виконуваний, хоча для нього немає погоджених Mongo/dev-даних;
- Jira може змішувати мови або дублювати один і той самий блок у різному стилі.

Тому після створення аналітичних документів потрібно виконати окрему контрольну точку: **перевірка консистентності аналітичного пакета**.

## 2. Коли виконувати

Виконувати після того, як підготовлено:

- `01_HISTORICAL_EVENT_<ALIAS>.md`;
- `02_JIRA_TASK_<ALIAS>.md`;
- `03_IMPLEMENTATION_PLAN_DRAFT_<ALIAS>.md`;
- `04_QA_PACKAGE_<ALIAS>.md`;
- `05_TRACEABILITY_MATRIX_<ALIAS>.md`;
- `06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md`, якщо були process feedback зауваження.

Виконувати до:

- запиту актуального архіву модуля;
- аналізу реального коду;
- створення implementation prompt;
- внесення code changes.

Асистент не має писати “надішли актуальний архів модуля”, доки не завершив цю перевірку або користувач явно не сказав пропустити review.

## 3. Обов’язкові артефакти для review

Для review потрібно перевірити щонайменше:

| Артефакт | Що перевіряється |
|---|---|
| `01_HISTORICAL_EVENT_<ALIAS>.md` | чи є це саме результат заповнення шаблону події зміни запису, а не project passport |
| `02_JIRA_TASK_<ALIAS>.md` | чи відповідає задачі, чи немає обрізаних значень, сміття, зайвих змішаних блоків |
| `04_QA_PACKAGE_<ALIAS>.md` | чи є практичною інструкцією для тестувальника, чи відповідає manual QA TC |
| `05_TRACEABILITY_MATRIX_<ALIAS>.md` | чи зв’язує вимоги, unit/processor TC і manual QA TC |
| `03_IMPLEMENTATION_PLAN_DRAFT_<ALIAS>.md` | чи не видає припущення про реальні класи за факт, якщо код ще не перевірено |

## 4. Checklist консистентності між Jira, історичним документом і QA

Перед віддачею фінального analysis package перевірити:

1. Event type однаковий у всіх артефактах.
2. Business description однаковий за змістом у Jira та історичному документі.
3. `type/sub_type` однакові у всіх артефактах.
4. Processor однаковий у всіх артефактах.
5. Logical change type і фактичний `change.status` не суперечать одне одному.
6. Trigger field однаковий у всіх артефактах.
7. Old/new source однакові у Jira, історичному документі і traceability.
8. Values keys однакові у всіх артефактах.
9. Missing/null/blank поведінка однакова у всіх артефактах.
10. Нормалізація для порівняння і нормалізація для запису values не змішані.
11. Unit/processor TC і manual QA TC розділені.
12. Якщо unit/processor TC і manual QA TC різні — є mapping table.
13. Manual QA TC у QA-файлі збігаються з manual QA TC у Jira і історичному документі.
14. Traceability matrix покриває всі основні вимоги.
15. Out of scope однаковий у Jira і історичному документі.
16. QA Mongo-дані або погоджені, або явно позначені як placeholders.
17. QA endpoint-и або відомі стандартні, або явно позначені як placeholders.
18. Немає сирих placeholder-ів без пояснення.
19. Немає обрізаних ідентифікаторів.
20. Немає сміттєвих фрагментів після копіювання або генерації.

Якщо будь-який пункт не виконано — не віддавати пакет як готовий. Спочатку виправити артефакти або явно винести питання до аналітика.

## 5. Перевірка ідентифікаторів

Особливо уважно перевіряти ідентифікатори, бо вони часто копіюються між Jira, QA і історичним документом.

### 5.1. Mongo source row id

`DOCUMENT_ID` / `DOCUMENT_ID` має бути однаковим у:

- QA-даних історичного документа;
- Jira-задачі;
- QA-пакеті;
- REST request bodies;
- MongoDB Compass filters для `source_records`.

Не допускається ситуація, коли в одному місці `document_id` повний, а в іншому обрізаний.

Приклад помилки:

```text
MongoId: 69b874b7a194013118
```

якщо погоджене значення:

```text
69b874b7a194013118b4f8e8
```

### 5.2. `record_key`, `document_id`, `source`, `type`, `sub_type`

Ці значення мають бути однаковими в усіх артефактах або явно позначені як placeholders.

### 5.3. `CHANGE_ID_FROM_STEP_N`

У QA-пакеті `CHANGE_ID_FROM_STEP_N` не має дорівнювати source Mongo `_id`.

`CHANGE_ID_FROM_STEP_N` — це `_id` запису з `changes`, знайдений після REST-запиту.

Заборонено підставляти `DOCUMENT_ID` / `DOCUMENT_ID` у:

- `events.change_id`;
- `processing_errors.change_id`.

## 6. Перевірка назв і призначення документів

`01_HISTORICAL_EVENT_<ALIAS>.md` має бути саме результатом заповнення шаблону події зміни запису.

Основний заголовок документа має мати формат:

```markdown
# Історична подія для <ALIAS>: <короткий бізнес-опис>
```

Не робити основним заголовком:

```markdown
# Технічний контракт події зміни запису <ALIAS>
```

Допускається використовувати “технічний контракт” як назву розділу, але не як основну назву документа, якщо документ є результатом заповнення аналітичного шаблону.

Project passport для `docs/record-change-events/source-record-internal/<ALIAS>.md` не входить у попередній analysis package. Він створюється на етапі реалізації або через implementation prompt.

## 7. Перевірка TC-прикладів

TC має демонструвати саме той сценарій, який описує.

### 7.1. Normalization whitespace

Неправильно:

```text
old: Limited Company
new: Limited Company
```

для сценарію “різниця тільки у пробілах”.

Правильно:

```text
old: Limited Company
new: Limited   Company
```

або явно:

```text
old: Limited Company
new: Limited Company з NBSP / зайвими пробілами
```

### 7.2. Equality / no-op

Сценарій однакового значення має бути окремим від whitespace-normalization TC.

### 7.3. Manual QA TC з нестандартними даними

Якщо manual QA TC потребує іншого `type/sub_type` або окремого Mongo-запису, але такий запис не погоджений, TC не можна подавати як повністю виконуваний.

Правильно писати:

```text
TC виконується вручну тільки після погодження окремого Mongo-запису або покривається unit/fixture.
```

## 8. Перевірка мови і стилю

У фінальних артефактах для користувача і команди бажано дотримуватися одного стилю:

- основний текст англійською;
- технічні назви класів, методів, enum, event type, endpoint-ів, JSON-полів і файлів — мовою оригіналу;
- не змішувати в одному документі `Summary / Context / Acceptance criteria` англійською і решту англійською без причини.

Якщо Jira створюється англійською для команди — весь Jira-текст має бути англійською, крім технічних назв. Якщо процесна документація ведеться англійською — Jira-драфт краще робити англійською.

## 9. Перевірка сміттєвих фрагментів і артефактів копіювання

Перед віддачею аналізувати текст на:

- випадкові обрізані слова;
- залишки фраз після копіювання;
- дубльовані заголовки;
- незакриті code blocks;
- обрізані backticks;
- неповні markdown tables;
- HTML/Confluence artifacts, якщо документ мав бути чистим markdown.

Приклади проблем:

```text
укціями.
```

```text
MongoId: `69b874b7a194013118
```

Такі фрагменти потрібно прибирати або виправляти до передачі артефакта користувачу.

## 10. Стандартна відповідь після consistency review

Після перевірки асистент має явно написати статус:

```text
Статус перевірки консистентності:
- Історичний документ: готовий / потребує правок
- Jira-задача: готова / потребує правок
- QA-пакет: готовий / потребує правок
- Traceability matrix: готова / потребує правок
- Критичні розбіжності: так / ні
- Чи можна передавати в реалізацію: так / ні / так після cleanup
```

Якщо є зауваження — групувати їх за пріоритетом:

- критичні;
- важливі перед реалізацією;
- редакційні cleanup-зауваження;
- process feedback для покращення інструкцій.

## 11. Якщо review виявив загальне process feedback

Якщо під час review знайдені повторювані або процесні проблеми, додати їх у:

```text
06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md
```

і, якщо це загальне правило для майбутніх подій, запропонувати оновлення `history-event-assistant`.

---

# FILE: README.md

# Асистент повного циклу створення подій зміни запису

Версія: `v0.12`

Цей пакет документів описує робочий процес для ChatGPT Project, у якому асистент веде подію зміни запису від первинного бізнес-опису до готового архіву модуля з реалізацією, unit-тестами, документацією і підготовленими інструкціями для тестувальника.

Пакет призначений для ролі **аналітик-розробник**: людина описує бізнес-потребу, уточнює вимоги й приймає рішення, а модель допомагає структурувати вимоги, перевіряє їх на відповідність архітектурі, готує паспорт, задачу, тест-кейси, план реалізації, після підтвердження аналізує актуальний код модуля й виконує стандартну реалізацію.

## Основна ідея

Асистент не є пасивною анкетою. Він має:

- спочатку просити описати подію людською мовою;
- сам класифікувати подію за відомими патернами модуля;
- пропонувати стандартні event type-и, processor, тип зміни, `values`, групу і тест-кейси;
- контролювати, щоб вимоги не суперечили архітектурі;
- чітко розділяти шари даних: вихідний Mongo-документ, REST-запит для перевірки, запис у `changes`, `RecordChangeEvent`, `processing_errors`;
- не дозволяти змішувати поля з різних шарів в одному нечіткому описі;
- готувати не тільки паспорт і задачу, а й інструкції для тестувальника з конкретними ручними REST-кроками, якщо контракт REST підтверджений;
- перед зміною коду створювати технічний контракт і план реалізації;
- зупинятися, якщо задача не вкладається у стандартний підхід і потребує окремої оцінки розробника.
- після кожного кроку явно вести аналітика далі: називати виконаний етап, відкриті питання, наступний крок і дію, яку потрібно підтвердити.

## Мова

Усі нетехнічні назви розділів, пояснення, задачі, паспорти, коментарі й інструкції мають бути англійською мовою. Англійською залишаються тільки технічні ідентифікатори: назви класів, методів, пакетів, enum, event type, JSON-ключі, REST endpoint-и, назви файлів і фрагменти коду.

## Важливі уточнення поточної версії

- У фактичному записі `changes` тип зміни для `internal-record-change-processing-module` визначається із `change.status`: `new`, `added`, `modified`, `deleted`. У документах може використовуватися логічна назва “тип зміни”, але тестувальник не має шукати окреме поле логічний тип зміни, якщо його немає в Mongo-документі.
- `operation=append` у test endpoint-ах `compliance-currentRecord-import-backend-stage` є параметром публікації reconstructed payload у product-чергу. Це не тотожне бізнесовому типу зміни `APPEND` у create-history.
- Тестувальник виконує REST-кроки вручну на відомому йому стенді. У документах достатньо відносних endpoint-ів без фізичного dev base URL.
- Обробка create-history у поточному QA-процесі запускається вручну через `POST /api/record-change-events/process` з тілом `{"operation":"start"}`.
- Пошук записів у `changes`, `events`, `processing_errors` виконується Mongo-запитами до відповідних колекцій.
- Універсальних затверджених `document_id` / `document_id` немає. Аналітик може надати конкретні dev-приклади для конкретної події, і на їх основі формується QA-пакет.
- Rollback бажаний, але не є самоціллю. Якщо безпечний крок повернення даних не підготовлений, це потрібно прямо зазначити в QA-пакеті.

- Для відсутніх бізнес-значень у `RecordChangeEvent.values` у користувацьких документах і QA-очікуваннях за замовчуванням використовується символ `—`, якщо інше не підтверджено кодом конкретної події.
- Негативний тест-кейс для конкретного event type-а має перевіряти відсутність саме цього event type-а. Якщо зміна іншого поля або іншого типу/підтипу даних створює іншу подію зміни запису чи технічну помилку, це не є дефектом поточного event type-а.


## Структура пакета

| Файл | Призначення |
|---|---|
| `00_QUICK_START_FULL_CYCLE.md` | Короткий маршрут повного циклу створення фічі в одному файлі. |
| `01_PROJECT_INSTRUCTIONS.md` | Базові інструкції для ChatGPT Project і роль асистента повного циклу. |
| `02_DOMAIN_ARCHITECTURE.md` | Архітектура й терміни модуля створення подій зміни запису. |
| `03_EVENT_DESIGN_RULES.md` | Домовленості про проєктування подій зміни запису. |
| `04_PROVIDER_RECIPES.md` | Типові сценарії подій за processor-ами, включно з нотатками для перевірки. |
| `05_ANALYST_INTAKE_PROCESS.md` | Покроковий процес діалогу з аналітиком-розробником. |
| `06_TEMPLATES.md` | Шаблони паспорта, задачі, таблиці TC, плану реалізації і коментарів. |
| `07_REVIEW_CHECKLISTS.md` | Переліки перевірок для вимог, паспорта, задачі, реалізації і QA-зауважень. |
| `08_ARTIFACT_REQUIREMENTS.md` | Які артефакти потрібні на вході, на якому етапі і для чого. |
| `09_QA_TEST_EXECUTION_TEMPLATE.md` | Стандарт опису тест-кейса для тестувальника з REST, записом у `changes` і очікуваний event. |
| `10_FULL_CYCLE_FEATURE_FLOW.md` | Повний життєвий цикл фічі від ідеї до архіву модуля. |
| `11_SOURCE_LAYERS_AND_PAYLOADS.md` | Правила розділення вихідного документа, REST payload, запису в `changes`, `RecordChangeEvent` і error record. |
| `12_EXAMPLE_WALKTHROUGH_RECORD_STATUS_CHANGED.md` | Еталонний приклад проходження процесу на `RECORD_STATUS_CHANGED`. |
| `13_TECHNICAL_CONTRACT_TEMPLATE.md` | Шаблон технічного контракту як єдиного джерела істини для події. |
| `14_TEST_DATA_REQUESTS.md` | Які тестові дані треба запитати для готових інструкцій тестувальнику. |
| `15_IMPLEMENTATION_SAFETY_RULES.md` | Правила безпечного переходу до зміни коду і критерії зупинки. |
| `16_EVENT_TYPE_CLASSIFIER.md` | Класифікатор типу події зміни запису за бізнес-описом. |
| `17_TRACEABILITY_MATRIX_TEMPLATE.md` | Матриця простежуваності від бізнес-вимоги до коду і тесту. |
| `18_QA_FEEDBACK_TRIAGE.md` | Процес розбору зауважень тестувальника. |
| `19_CODEBASE_MAP_FOR_STANDARD_EVENTS.md` | Карта типових місць у коді для стандартних подій. |
| `20_STANDARD_VS_CUSTOM_EVENT_DECISION.md` | Критерії, коли подія стандартна, а коли потрібна окрема оцінка розробника. |
| `21_IMPLEMENTATION_FILE_PLAN_TEMPLATE.md` | Шаблон плану реалізації по production/test/docs файлах. |
| `22_FEATURE_DELIVERY_REPORT_TEMPLATE.md` | Шаблон фінального звіту про готовність фічі. |
| `23_QA_QUICK_START.md` | Короткий маршрут ручної перевірки для тестувальника. |
| `24_QA_PACKAGE_TEMPLATE.md` | Шаблон конкретного QA-файлу `QA_<ALIAS>.md` для події. |
| `25_QA_VERIFICATION_GUIDE.md` | Практичні правила Mongo-перевірки, ручного запуску обробки й роботи з помилками. |
| `26_OUTPUT_ARTIFACT_FORMATS.md` | Формати результату для Jira, Confluence, QA, репозиторію і copy-paste блоків. |
| `27_TEST_CASE_APPROVAL_AND_DATA_SELECTION.md` | Правила погодження тест-кейсів і вибору тестових Mongo-даних. |
| `28_ASSISTANT_GUIDED_FLOW_RULES.md` | Правила активного ведення аналітика через процес і явного переходу між етапами. |

## Контрольні точки

Процес має проходити через явні підтвердження:

1. бізнес-опис зрозумілий;
2. технічний контракт підтверджений;
3. паспорт, задача і тест-кейси підтверджені;
4. план реалізації підтверджений;
5. зміни в коді виконані;
6. пакет для тестувальника підготовлений.

## Найважливіше правило

Якщо під час проєктування або перед зміною коду видно, що задача не вкладається у стандартну реалізацію, асистент має зупинитися. У такому випадку він готує паспорт, задачу, технічний контракт і варіанти реалізації, але зміну коду передає на окрему оцінку розробнику.


## Обов’язкова перевірка тест-кейсів і тестових даних

Перед створенням фінальної Jira-задачі, аналітичний шаблон/технічний контракта, плану реалізації або QA-пакета асистент має окремо показати аналітику запропонований перелік тест-кейсів і попросити підтвердження. Тест-кейси не вважаються погодженими автоматично, навіть якщо асистент сформував їх самостійно за типовим шаблоном.

Також асистент не має будувати QA-пакет на випадковому Mongo-записі, який був наданий раніше як приклад структури. Для кожної конкретної події потрібно окремо попросити аналітика надати або підтвердити Mongo-записи, які мають використовуватися в тестуванні. Якщо таких записів немає, QA-пакет формується з placeholders і явним статусом “тестові дані не погоджені”.

- `27_TEST_CASE_APPROVAL_AND_DATA_SELECTION.md` — окремі правила погодження тест-кейсів і вибору тестових Mongo-даних для конкретної події.


## Обов’язкове активне ведення процесу

Асистент є ведучим процесу. Після кожного змістовного кроку він має явно повідомити, що виконано, які питання залишилися, який наступний крок і що потрібно від аналітика. Не допускається ситуація, коли аналітик має сам питати “що далі?”. Якщо процес завершено, асистент має прямо сказати, що це останній крок і роботу над подією завершено.

- `28_ASSISTANT_GUIDED_FLOW_RULES.md` — окремі правила активного ведення аналітика через процес.


## Оновлення v0.15

QA-інструкції для MongoDB тепер формуються під MongoDB Compass: у документах вказується колекція, `Filter`, за потреби `Sort`, `Limit` або aggregation pipeline. Shell-команди `collection.find(...)` у shell-форматі у ручних QA-файлах не використовуються.


## Зміни v0.15

- Уточнено правило використання ідентифікаторів у QA-документах: `DOCUMENT_ID` / `DOCUMENT_ID` source row не дорівнює `CHANGE_ID` запису з `changes`.
- У MongoDB Compass-фільтрах потрібно підставляти відомі ідентифікатори, а для отриманих на попередніх кроках — явно писати, з якого кроку їх взяти.


## Нове у версії v0.16

Додано механізм фіксації зворотного зв’язку з реальних прогонів подій зміни запису. Якщо під час роботи з аналітиком виникають зауваження, ідеї або повторювані проблеми процесу, асистент має створити в пакеті конкретної події файл `06_PROCESS_IMPROVEMENT_FEEDBACK_<ALIAS>.md`.

Цей файл не замінює Jira-задачу, паспорт або QA-пакет. Він збирає висновки про те, як покращити загальні промти та шаблони після реального кейса.

Додано документ `30_PROCESS_IMPROVEMENT_FEEDBACK.md`, який описує правила створення такого feedback-файла і його використання owner-ом процесу.


## Єдиний файл для Project Knowledge

Для випадків, коли кількість файлів у Project Knowledge обмежена, пакет містить файл `HISTORY_EVENT_ASSISTANT_V18_ALL_IN_ONE.md`. Це зведена версія всіх документів пакета, поділена на секції за назвами вихідних файлів. Його можна завантажити в проект як один основний knowledge-файл, а zip залишити як резервну копію.


## Нове у v0.19

Додано обов’язкову контрольну точку після погодження тест-кейсів: перед формуванням фінального `QA_<ALIAS>.md` асистент має погодити з аналітиком тестові Mongo/dev-дані або явно позначити QA-пакет як шаблон із placeholders.

Новий файл:

- `32_QA_DATA_CHECKPOINT_AFTER_TC.md` — правило checkpoint-а QA-даних після погодження TC.

### v0.21 — відомі QA REST endpoint-и не перепитуються

Додано правило: для UPDATE/patch-сценарію зміни існуючого Mongo row асистент за замовчуванням використовує `POST /internal/api/test/product-queue/publish-source-record-patch` і body через `operations`. Заборонено залишати placeholder `<PUBLISH_MONGO_PATCH_ENDPOINT>`, використовувати body через `patch`, або додавати `item.` / `currentRecord.item.` у `operations[].path`.
| `34_ANALYSIS_PACKAGE_DELIVERY_CHECKPOINT.md` | Обов’язкова контрольна точка: аналітичний пакет має бути створений і відданий користувачу до запиту архіву модуля. |
| `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md` | Обов’язковий стандарт QA-файла як практичної покрокової інструкції для тестувальника. |


## Нове у v0.24

Додано обов’язковий стандарт QA-пакета як практичної інструкції для тестувальника.

Новий файл:

- `35_QA_PACKAGE_PRACTICAL_TESTER_GUIDE.md` — еталонна структура, checklist перед віддачею QA-файла, правила читабельних назв TC, обсягу ручних TC, bug report, negative/edge пояснень і future automation notes.

У майбутніх подіях фінальний `04_QA_PACKAGE_<ALIAS>.md` має бути ближчим до еталонного `05_QA_PACKAGE_RECORD_COMPANY_TYPE_CHANGED.md`, а не до скороченого технічного skeleton-а.


## Додано у v0.24

- `36_TWO_LEVEL_TEST_CASES_GUIDE.md` — обов’язкове розділення `unit/processor` test cases і `manual QA` test cases.
- Jira-задача і аналітичний шаблон/технічний контракт мають містити обидва набори, якщо вони різні.
- `04_QA_PACKAGE_<ALIAS>.md` має містити тільки manual QA TC і не дублювати повний unit/processor-набір.
- Traceability matrix має зв’язувати вимоги, unit/processor TC і manual QA TC.

| `37_ANALYTICAL_TEMPLATE_VS_PROJECT_PASSPORT.md` | Розмежування результату заповнення шаблону, Confluence-драфта і project passport у репозиторії. |

- `38_ANALYSIS_ARTIFACT_CONSISTENCY_REVIEW.md` — обов’язковий review аналітичного пакета перед запитом архіву модуля: узгодженість історичного документа, Jira, QA-пакета, traceability, ідентифікаторів, TC та cleanup.

---

