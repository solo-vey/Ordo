# Domain-Adapted Analyst Corpus Testing Package

Version: `1.5.0-alpha`

This package is a third benchmark condition:

- not Ordo engine runtime;
- not Ordo prompt-only compilation;
- not a newly authored approximation of accumulated instructions;
- instead, a near-direct domain adaptation of the supplied analyst-created all-in-one corpus.

## Model-visible corpus

`model_input/RECORD_CHANGE_ASSISTANT_DOMAIN_ADAPTED_ANALYST_ALL_IN_ONE.md`

Size: 481,987 bytes
Pseudo-file sections preserved: 40

## Driver

Uses the adaptive semantic analyst Driver from Alpha 1.4 with the same five neutral scenarios.

## Start prompts

- `launch_prompts/START_PROMPT_RUN_01.md`
- `launch_prompts/START_PROMPT_RUN_02.md`
- `launch_prompts/START_PROMPT_RUN_03.md`
- `launch_prompts/START_PROMPT_RUN_04.md`
- `launch_prompts/START_PROMPT_RUN_05.md`

A generic prompt is also available as `START_PROMPT_ALL_RUNS.md`.
