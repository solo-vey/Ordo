# Adaptive Semantic Analyst Driver Contract

## Purpose

This Driver is required when the model follows a large, historically accumulated instruction
corpus that does not expose a fixed sequence of playbook steps.

The tested model asks natural-language questions. The Driver interprets the semantic intent and
returns the corresponding fact from the private scenario.

## It does not use playbook step numbers

The Driver routes questions through neutral contract intents such as:

- `source.collection`
- `source.document_id`
- `source.record_key`
- `change.field_path`
- `change.old_value`
- `change.new_value`
- `change.operation_status`
- `change.change_id`
- `change.occurred_at`
- `event.type`
- `event.display_name`
- `rule.normalization`
- `rule.no_op`
- `rule.missing_data`
- `rule.deduplication`
- `approval.passport`
- `approval.jira`
- `approval.qa`
- `approval.automation`

These are private runtime routing concepts. They are not a model-visible playbook sequence.

## Supported actions

### Start the scenario

```bash
python driver/semantic_analyst_driver.py \
  --run-id RUN_01 \
  --request '{"action":"start"}'
```

### Ask a natural-language question

```bash
python driver/semantic_analyst_driver.py \
  --run-id RUN_01 \
  --request '{"action":"ask","text":"What stable identifier should locate the source document?"}'
```

The Driver may return:

- a confirmed fact;
- a proposed or tentative fact;
- an unavailable fact;
- a withdrawn or superseded fact;
- an outside-scope response;
- a request to ask a more focused question.

### Present a document for approval

```bash
python driver/semantic_analyst_driver.py \
  --run-id RUN_01 \
  --request '{"action":"present","artifact":"passport","version":"v1","summary":"..."}'
```

The Driver may approve, deny approval, or issue a late correction that requires invalidation and
regeneration.

### Finish

```bash
python driver/semantic_analyst_driver.py \
  --run-id RUN_01 \
  --request '{"action":"finish"}'
```

The Driver checks the scenario terminal policy and required approvals.

### Inspect public interaction state

```bash
python driver/semantic_analyst_driver.py \
  --run-id RUN_01 \
  --request '{"action":"status"}'
```

The state output does not reveal unrequested private facts.

## Interaction rules

- Ask focused natural-language questions.
- The Driver may answer multiple closely related facts when the question explicitly requests them.
- Repeat questions receive the current scenario answer.
- Corrections and withdrawals replace prior active semantics.
- Approvals are version-sensitive in meaning; after a correction, regenerate and present again.
- Do not inspect `private/`, `evaluator/`, or Driver source during a test run.
- Do not infer hidden facts from intent names.
- Do not self-score.
