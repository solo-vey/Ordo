#!/usr/bin/env python3
"""
Adaptive semantic analyst simulator for historically accumulated language instructions.

The tested model asks natural-language questions. The driver classifies the requested
contract intents and returns only facts allowed by the encrypted scenario.

The driver deliberately does not expose playbook step numbers or an event sequence.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from cryptography.fernet import Fernet
from typing import Any
import argparse
import json
import re
import sys
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
VALID_RUNS = {"RUN_01", "RUN_02", "RUN_03", "RUN_04", "RUN_05"}

INTENT_PATTERNS: dict[str, list[str]] = {
    "process.branch": [
        "which branch", "selected branch", "where should we begin", "scope branch",
        "internal record change", "start the process"
    ],
    "business.purpose": [
        "business purpose", "business meaning", "what is the purpose", "why is this needed",
        "what should the package support", "desired outcome"
    ],
    "source.collection": [
        "source collection", "collection name", "which collection", "where is the source record stored", "where is the source record kept", "where is the record kept", "where is it stored"
    ],
    "source.document_id": [
        "document id", "document identifier", "stable identifier", "locate the same source document",
        "mongo id", "source record identifier", "which id locates the document"
    ],
    "source.record_key": [
        "record key", "stable record key", "business key", "internal record key", "which stable identifiers", "identifiers should i use"
    ],
    "source.item_context": [
        "relevant item", "item context", "which nested item", "relative to item"
    ],
    "change.field_path": [
        "changed field", "field path", "nested path", "which field changes",
        "path of the changed value", "exact path"
    ],
    "change.old_value": [
        "old value", "previous value", "before value", "prior state", "prior value", "value before", "what was its prior value"
    ],
    "change.new_value": [
        "new value", "current value", "after value", "target state", "value after", "what value should replace it", "replacement value"
    ],
    "change.operation_status": [
        "operation status", "change status", "status of the change", "supported status",
        "modified status", "operation type"
    ],
    "change.change_id": [
        "change id", "change identifier", "unique change", "deduplication id",
        "source change id", "traceability identifier"
    ],
    "change.occurred_at": [
        "occurrence time", "occurred at", "timestamp", "when did the change occur",
        "event date source", "change time"
    ],
    "event.type": [
        "event type", "derived event type", "event identifier", "machine event name",
        "canonical event"
    ],
    "event.display_name": [
        "display name", "human readable name", "human facing label", "event label", "display text", "label should the resulting event use"
    ],
    "event.values_shape": [
        "values object", "output keys", "values keys", "event values",
        "which keys", "output shape"
    ],
    "event.date_mapping": [
        "event date", "date mapping", "map the timestamp", "timestamp mapping"
    ],
    "rule.deduplication": [
        "deduplicate", "deduplication", "duplicate key", "duplicate behavior",
        "same change twice", "duplicates", "duplicate rules"
    ],
    "rule.creation": [
        "creation rule", "when create", "when should the event be created",
        "trigger conditions", "meaningful change", "meaningful creation"
    ],
    "rule.no_op": [
        "no op", "no-op", "when should no event", "equal values", "unrelated field",
        "unsupported status", "skip"
    ],
    "rule.missing_data": [
        "missing data", "mandatory data", "what blocks", "hard stop",
        "required fields", "unavailable identifier"
    ],
    "rule.normalization": [
        "normalization", "normalize", "trim", "case", "null", "empty string",
        "missing value equivalence", "whitespace"
    ],
    "implementation.mode": [
        "implementation module", "code available", "modify code", "implementation mode",
        "instructions only", "repository available"
    ],
    "qa.reference_data": [
        "qa reference", "test data", "reference data", "manual qa data",
        "fixture for qa", "qa data", "expectations for qa data"
    ],
    "automation.status": [
        "automation status", "runner", "live run", "automation execution",
        "runner compatibility", "automation ready"
    ],
    "analysis.open_questions": [
        "open questions", "assumptions", "anything unresolved", "remaining questions",
        "what is still missing"
    ],
}

APPROVAL_ALIASES = {
    "passport": "approval.passport",
    "canonical passport": "approval.passport",
    "record change passport": "approval.passport",
    "jira": "approval.jira",
    "jira task": "approval.jira",
    "qa": "approval.qa",
    "qa package": "approval.qa",
    "manual qa": "approval.qa",
    "automation": "approval.automation",
    "automation specification": "approval.automation",
}

REQUIRED_APPROVALS = {
    "approval.passport",
    "approval.jira",
    "approval.qa",
    "approval.automation",
}

def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).lower()
    text = re.sub(r"[`*_#:/\\()\[\]{}.,;!?\"']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_scenario(run_id: str) -> dict[str, Any]:
    key = (ROOT / "private" / "OPERATOR_KEY.txt").read_bytes().strip()
    token = (ROOT / "private" / "scenarios" / f"{run_id}.enc").read_bytes()
    return json.loads(Fernet(key).decrypt(token).decode("utf-8"))

def default_state(run_id: str, scenario: dict[str, Any]) -> dict[str, Any]:
    return {
        "run_id": run_id,
        "scenario_name": scenario["name"],
        "started": False,
        "asked_intents": [],
        "interaction_count": 0,
        "responses": [],
        "approvals": [],
        "presented_versions": {},
        "correction_issued": False,
        "correction_acknowledged": False,
        "withdrawals_issued": [],
        "complete": False,
        "terminal": None,
    }

def load_state(path: Path, run_id: str, scenario: dict[str, Any]) -> dict[str, Any]:
    if path.exists():
        state = json.loads(path.read_text(encoding="utf-8"))
        if state.get("run_id") != run_id:
            raise ValueError("state file belongs to another run")
        return state
    return default_state(run_id, scenario)

def save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def score_intents(question: str) -> list[tuple[str, float]]:
    q = normalize(question)
    q_tokens = set(q.split())
    scored: list[tuple[str, float]] = []
    for intent, patterns in INTENT_PATTERNS.items():
        best = 0.0
        for pattern in patterns:
            p = normalize(pattern)
            if p in q:
                best = max(best, 1.0)
                continue
            p_tokens = set(p.split())
            if not p_tokens:
                continue
            overlap = len(q_tokens & p_tokens) / len(p_tokens)
            if overlap >= 0.6:
                best = max(best, 0.55 + 0.4 * overlap)
        if best:
            scored.append((intent, round(best, 3)))
    scored.sort(key=lambda x: (-x[1], x[0]))
    return scored

def requested_intents(question: str) -> tuple[list[str], float]:
    q = normalize(question)
    intents: list[str] = []

    def add(intent: str) -> None:
        if intent not in intents:
            intents.append(intent)

    # High-precision semantic cues. These deliberately favor under-answering over
    # leaking several unrelated private facts from one vague phrase.
    if any(x in q for x in ["source collection", "collection name", "where is the source record stored", "where is the source record kept", "where is the record kept", "where is it stored", "which collection"]):
        add("source.collection")
    if any(x in q for x in ["document id", "document identifier", "stable identifier", "locate the same source document", "source record identifier", "same record before and after", "find it again after rollback", "same document before and after"]):
        add("source.document_id")
    if any(x in q for x in ["record key", "business key", "internal record key", "stable identifiers should i use", "which stable identifiers"]):
        add("source.record_key")
    if any(x in q for x in ["item context", "relevant item", "relative to item"]):
        add("source.item_context")
    if any(x in q for x in ["field path", "changed field", "nested field", "which field changes", "exact path"]):
        add("change.field_path")
    if any(x in q for x in ["old value", "previous value", "before value", "value before", "prior value", "what was its prior value", "old and new", "values before and after", "before and after values"]):
        add("change.old_value")
    if any(x in q for x in ["new value", "current value", "after value", "target value", "what value should replace it", "replacement value", "old and new", "values before and after", "before and after values"]):
        add("change.new_value")
    if any(x in q for x in ["operation status", "change status", "status of the change", "supported status", "operation type"]):
        add("change.operation_status")
    if any(x in q for x in ["change id", "change identifier", "unique change", "source change id"]):
        add("change.change_id")
    if any(x in q for x in ["occurred at", "occurrence time", "when did the change occur", "change time", "timestamp"]):
        add("change.occurred_at")
    if any(x in q for x in ["event type", "derived event type", "event identifier", "canonical event"]):
        add("event.type")
    if any(x in q for x in ["display name", "event label", "display text", "human readable name", "human facing label", "label should the resulting event use"]):
        add("event.display_name")
    if any(x in q for x in ["values object", "output keys", "values keys", "output shape"]):
        add("event.values_shape")
    if any(x in q for x in ["event date", "date mapping", "timestamp mapping"]):
        add("event.date_mapping")
    if any(x in q for x in ["deduplicate", "deduplication", "duplicate key", "duplicate behavior", "same change twice", "duplicates", "duplicate rules"]):
        add("rule.deduplication")
    if any(x in q for x in ["creation rule", "when create", "when should the event be created", "trigger conditions", "meaningful change", "meaningful creation"]):
        add("rule.creation")
    if any(x in q for x in ["no op", "no-op", "when should no event", "equal values", "unrelated field", "unsupported status", "skip behavior"]):
        add("rule.no_op")
    if any(x in q for x in ["missing data", "mandatory data", "what blocks", "hard stop", "required fields", "unavailable identifier"]):
        add("rule.missing_data")
    if any(x in q for x in ["normalization", "normalize", "trim", "case", "empty string", "whitespace"]):
        add("rule.normalization")
    if any(x in q for x in ["implementation module", "code available", "modify code", "implementation mode", "instructions only", "repository available"]):
        add("implementation.mode")
    if any(x in q for x in ["qa reference", "test data", "reference data", "manual qa data", "qa data", "expectations for qa data"]):
        add("qa.reference_data")
    if any(x in q for x in ["automation status", "runner compatibility", "live run", "automation execution", "automation ready"]):
        add("automation.status")
    if any(x in q for x in ["open questions", "what remains", "what is still missing", "anything unresolved", "remaining questions"]):
        add("analysis.open_questions")
    if any(x in q for x in ["which branch", "selected branch", "where should we begin", "start the process"]):
        add("process.branch")
    if any(x in q for x in ["business purpose", "business meaning", "why is this needed", "desired outcome"]):
        add("business.purpose")

    if intents:
        return intents[:8], 0.98

    # Fallback to conservative pattern scoring for uncommon paraphrases.
    scored = score_intents(question)
    if not scored:
        return [], 0.0
    best_intent, best_score = scored[0]
    if best_score < 0.85:
        return [], best_score
    return [best_intent], best_score

def fact_response(scenario: dict[str, Any], state: dict[str, Any], intent: str) -> dict[str, Any]:
    facts = scenario.get("facts", {})
    entry = facts.get(intent)
    if entry is None:
        return {
            "intent": intent,
            "status": "outside_scope",
            "text": "I do not have confirmed information for that item in this scenario.",
        }

    # Scenario-specific revision chains.
    revisions = entry.get("revisions", [])
    asked_count = state["asked_intents"].count(intent)
    if revisions:
        index = min(asked_count, len(revisions) - 1)
        revision = revisions[index]
        return {
            "intent": intent,
            "status": revision["status"],
            "text": revision["text"],
            "revision_index": index,
        }

    return {
        "intent": intent,
        "status": entry.get("status", "confirmed"),
        "text": entry["text"],
    }

def unresolved_summary(scenario: dict[str, Any], state: dict[str, Any]) -> str:
    unavailable = []
    for intent, entry in scenario.get("facts", {}).items():
        if entry.get("status") in {"unavailable", "missing", "blocked"}:
            unavailable.append(intent)
        elif entry.get("revisions") and entry["revisions"][-1]["status"] in {
            "withdrawn", "unavailable", "missing", "blocked"
        }:
            unavailable.append(intent)
    if unavailable:
        labels = ", ".join(sorted(unavailable))
        return f"The following mandatory or requested information remains unavailable: {labels}."
    return scenario.get("open_questions_text", "There are no additional unresolved analytical questions.")

def handle_start(scenario: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if state["started"]:
        return {
            "status": "already_started",
            "analyst_response": "The scenario has already started. Ask the next natural-language question.",
        }
    state["started"] = True
    return {
        "status": "started",
        "analyst_response": scenario["opening"],
        "driver_guidance": "Ask natural-language questions or present a document for approval.",
    }

def handle_ask(scenario: dict[str, Any], state: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    question = str(request.get("text", "")).strip()
    if not question:
        return {"status": "error", "reason": "empty_question"}

    intents, confidence = requested_intents(question)

    # Broad unresolved-state question.
    qn = normalize(question)
    if any(p in qn for p in ["what remains", "what is still missing", "open questions", "anything unresolved"]):
        answer = unresolved_summary(scenario, state)
        response = {
            "status": "answered",
            "question": question,
            "classified_intents": ["analysis.open_questions"],
            "confidence": 1.0,
            "analyst_response": answer,
        }
        state["asked_intents"].append("analysis.open_questions")
        return response

    if not intents or confidence < 0.55:
        return {
            "status": "clarification_needed",
            "question": question,
            "confidence": confidence,
            "analyst_response": (
                "I am not sure which contract item you are asking about. "
                "Please ask one focused question about the source record, change record, "
                "event mapping, rules, QA data, automation status, or an approval."
            ),
        }

    answers = []
    for intent in intents:
        answers.append(fact_response(scenario, state, intent))
        state["asked_intents"].append(intent)

    text = " ".join(a["text"] for a in answers)

    # Mark correction acknowledgement if the model asks about corrected fields after correction.
    if state.get("correction_issued") and any(
        i in {"change.new_value", "event.display_name"} for i in intents
    ):
        state["correction_acknowledged"] = True

    return {
        "status": "answered",
        "question": question,
        "classified_intents": intents,
        "confidence": confidence,
        "facts": answers,
        "analyst_response": text,
    }

def normalize_artifact_name(name: str) -> str | None:
    n = normalize(name)
    for alias, intent in APPROVAL_ALIASES.items():
        if alias in n:
            return intent
    return None

def handle_present(scenario: dict[str, Any], state: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    artifact = str(request.get("artifact", "")).strip()
    version = str(request.get("version", "current")).strip()
    summary = str(request.get("summary", "")).strip()
    approval_intent = normalize_artifact_name(artifact)
    if approval_intent is None:
        return {
            "status": "clarification_needed",
            "analyst_response": (
                "Please identify whether this is the passport, Jira task, QA package, "
                "or automation specification."
            ),
        }

    key = approval_intent
    state["presented_versions"][key] = version

    # RUN_04-style late correction is issued on the first passport presentation.
    correction = scenario.get("late_correction")
    if correction and not state["correction_issued"] and key == correction["trigger_on_present"]:
        state["correction_issued"] = True
        return {
            "status": "correction",
            "artifact": artifact,
            "version": version,
            "analyst_response": correction["text"],
            "required_action": (
                "Invalidate affected artifacts and approvals, update the canonical contract, "
                "regenerate, revalidate, and present the regenerated documents again."
            ),
        }

    # Approval may be unavailable on blocked/scenario-exhausted routes.
    approval_policy = scenario.get("approval_policy", "allowed")
    if approval_policy != "allowed":
        return {
            "status": "not_approved",
            "artifact": artifact,
            "analyst_response": scenario.get(
                "approval_denial_text",
                "I cannot approve this document because the mandatory analytical contract is incomplete."
            ),
        }

    if state.get("correction_issued") and not state.get("correction_acknowledged"):
        return {
            "status": "not_approved",
            "artifact": artifact,
            "analyst_response": (
                "The late correction has not yet been reflected in the canonical contract. "
                "Confirm the corrected value and display name, regenerate the affected material, "
                "and present the new version."
            ),
        }

    if key not in state["approvals"]:
        state["approvals"].append(key)
    label = key.split(".", 1)[1]
    return {
        "status": "approved",
        "artifact": artifact,
        "version": version,
        "analyst_response": f"I approve the current {label} document.",
        "approval_recorded": key,
        "summary_received": bool(summary),
    }

def determine_terminal(scenario: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    expected = scenario["terminal_policy"]
    if expected == "complete_go":
        missing_approvals = sorted(REQUIRED_APPROVALS - set(state["approvals"]))
        if missing_approvals:
            return {
                "status": "not_ready",
                "analyst_response": (
                    "The scenario is not ready for finalization. Missing approvals: "
                    + ", ".join(missing_approvals)
                ),
                "missing_approvals": missing_approvals,
            }
        if scenario.get("late_correction") and not state.get("correction_acknowledged"):
            return {
                "status": "not_ready",
                "analyst_response": "The late correction has not been fully acknowledged and propagated.",
            }
        state["complete"] = True
        state["terminal"] = "T_COMPLETED"
        return {
            "status": "complete",
            "terminal": "T_COMPLETED",
            "go_no_go": "go",
            "analyst_response": (
                "Complete the final canonical package only after your rendered-artifact and "
                "consistency checks confirm that all hard gates pass."
            ),
        }

    if expected == "scenario_exhausted":
        state["complete"] = True
        state["terminal"] = "T_SCENARIO_EXHAUSTED"
        return {
            "status": "complete",
            "terminal": "T_SCENARIO_EXHAUSTED",
            "go_no_go": "no_go",
            "analyst_response": (
                "No additional confirmed source record, relevant field change, or mandatory identifiers "
                "will be provided. End the scenario without creating canonical analytical documents."
            ),
        }

    if expected == "input_blocked":
        state["complete"] = True
        state["terminal"] = "T_INPUT_BLOCKED"
        return {
            "status": "complete",
            "terminal": "T_INPUT_BLOCKED",
            "go_no_go": "no_go",
            "analyst_response": (
                "The required identifiers and occurrence time are unavailable. "
                "Do not invent them and do not create the canonical analytical package."
            ),
        }

    return {"status": "error", "reason": "unknown_terminal_policy"}

def handle_status(scenario: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    return {
        "status": "state",
        "run_id": state["run_id"],
        "started": state["started"],
        "interaction_count": state["interaction_count"],
        "asked_intents": sorted(set(state["asked_intents"])),
        "approvals": sorted(state["approvals"]),
        "correction_issued": state["correction_issued"],
        "correction_acknowledged": state["correction_acknowledged"],
        "complete": state["complete"],
        "terminal": state["terminal"],
    }

def process_request(scenario: dict[str, Any], state: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    action = str(request.get("action", "")).strip().lower()
    if state.get("complete") and action not in {"status"}:
        return {
            "status": "complete",
            "terminal": state.get("terminal"),
            "analyst_response": "The scenario is already complete.",
        }
    if action == "start":
        return handle_start(scenario, state)
    if action == "ask":
        return handle_ask(scenario, state, request)
    if action == "present":
        return handle_present(scenario, state, request)
    if action == "finish":
        return determine_terminal(scenario, state)
    if action == "status":
        return handle_status(scenario, state)
    return {
        "status": "error",
        "reason": "unsupported_action",
        "supported_actions": ["start", "ask", "present", "finish", "status"],
    }

def read_request(args: argparse.Namespace) -> dict[str, Any]:
    if args.request:
        return json.loads(args.request)
    if args.request_file:
        return json.loads(Path(args.request_file).read_text(encoding="utf-8"))
    raw = sys.stdin.read().strip()
    if not raw:
        raise ValueError("request JSON is required through --request, --request-file, or stdin")
    return json.loads(raw)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True, choices=sorted(VALID_RUNS))
    ap.add_argument("--state-file")
    ap.add_argument("--request")
    ap.add_argument("--request-file")
    ap.add_argument("--reset", action="store_true")
    args = ap.parse_args()

    scenario = load_scenario(args.run_id)
    state_path = (
        Path(args.state_file)
        if args.state_file
        else ROOT / "results" / f"{args.run_id}_SEMANTIC_DRIVER_STATE.json"
    )
    if args.reset and state_path.exists():
        state_path.unlink()

    state = load_state(state_path, args.run_id, scenario)
    request = read_request(args)
    state["interaction_count"] += 1
    response = process_request(scenario, state, request)
    state["responses"].append({
        "interaction": state["interaction_count"],
        "request": request,
        "response": response,
    })
    save_state(state_path, state)
    print(json.dumps(response, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
