You are running a blind automated test using a domain-adapted, analyst-created all-in-one instruction corpus and an adaptive semantic analyst simulator.

MANDATORY INPUT BOUNDARY
1. Read exactly one model-visible instruction file:
   `model_input/RECORD_CHANGE_ASSISTANT_DOMAIN_ADAPTED_ANALYST_ALL_IN_ONE.md`.
2. Treat the corpus as historically accumulated language instructions, not as an Ordo playbook compilation.
3. Do not create or reconstruct YAML, a state machine, a step table, a transition graph, or hidden numbered process.
4. Do not inspect `private/`, `evaluator/`, `operator_notes/`, or Driver source.
5. Do not use results from earlier benchmark packages.

RUN PARAMETERS
- RUN_ID: RUN_03
- execution mode: test

START THE ANALYST SIMULATOR
`python driver/semantic_analyst_driver.py --run-id RUN_03 --request '{"action":"start"}'`

ASK NATURAL-LANGUAGE QUESTIONS
`python driver/semantic_analyst_driver.py --run-id RUN_03 --request '{"action":"ask","text":"<YOUR NATURAL-LANGUAGE QUESTION>"}'`

PRESENT REQUIRED DOCUMENTS FOR APPROVAL
`python driver/semantic_analyst_driver.py --run-id RUN_03 --request '{"action":"present","artifact":"<passport|jira task|qa package|automation specification>","version":"<VERSION>","summary":"<SHORT FACTUAL SUMMARY>"}'`

FINISH
`python driver/semantic_analyst_driver.py --run-id RUN_03 --request '{"action":"finish"}'`

EXECUTION RULES
- Ask only questions you determine are necessary.
- Keep confirmed, tentative, fixture-only, irrelevant, withdrawn, superseded, corrected and missing facts distinct.
- Do not fill missing data from fixtures.
- Follow correction, invalidation, regeneration and reapproval behavior.
- Inspect the quality and consistency of rendered documents before finalization.
- Generate the canonical eleven-document package only on a successful GO route.
- On blocked or scenario-exhausted routes, do not create canonical analytical documents or archive.
- Do not score or evaluate yourself.

FINAL OUTPUT
Use directory: `RUN_03_DATABASE_CHANGE_ARTIFACT_SET_RESULT`
On a successful GO route also create: `RUN_03_DATABASE_CHANGE_ARTIFACT_SET_RESULT.zip`
