# START PROMPT — Structured Instructions Alpha 1.3.0 — RUN_05

You are executing one blind scenario using the Ordo Database Change Structured Instructions Full-Fidelity Playbook Alpha 1.3.0.

Set `RUN_ID` to exactly `RUN_05`.

From the extracted package root, mandatory pre-flight is:

1. Verify ZIP integrity and every entry in `SHA256SUMS.txt`.
2. Run:
   ```bash
   python validation/validate_semantic_parity.py
   python validation/validate_structured_instruction_representation.py .
   ```
3. Run:
   ```bash
   python validation/validate_structured_runtime_package.py .
   ```
4. Run:
   ```bash
   python validation/validate_selected_run_input_sufficiency.py .
   ```
5. Confirm exactly 126 ordered prose steps and Step 1 = `T001`. Confirm the analyst file contains no copied YAML process-control blocks.
6. Materialize only the selected blind scenario:
   ```bash
   python scripts/materialize_selected_run_input.py --run-id RUN_05 --output runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml
   ```
7. For RUN_01, RUN_02 and RUN_04, confirm:
   - `required_input_sufficiency.all_required_exact_bindings_present: true`;
   - exact source/change fixtures;
   - request schemas;
   - duplicate/fallback policies;
   - runner contract.

These are authoritative package inputs. Do not reclassify them as unavailable merely because live environment values remain placeholders.

On any failure, stop with `NO_CHANGE` and do not create business artifacts or approvals.

On success, execute only route `RUN_05` from `T001`, including all applicable correction, invalidation, regeneration, revalidation, approval and terminal rules.

Runtime placeholders `BASE_URL`, `AUTH_HEADERS` and `DATABASE_NAME` do not block generation of executable specifications.

Return one ZIP containing complete current-run evidence and only route-authorized artifacts. Do not self-score.

The package and this prompt are a version-locked transfer pair. Do not substitute an older prompt.

## Driver validation rule — mandatory

- Do not create or submit validation receipts.
- For each artifact, call the Driver `validation` action with:
  - `artifact`;
  - `artifact_path`;
  - `version`;
  - for Passport, also `case_registry_path`.
- Only the Driver may execute authoritative validators and generate validation receipts.
- Preserve Driver-generated validator logs in the returned evidence ZIP, including:
  - exact commands;
  - stdout;
  - stderr;
  - return codes;
  - validator IDs;
  - artifact hashes.
- A caller-supplied `PASS` receipt is a protocol violation and must be rejected.
