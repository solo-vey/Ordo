# Structured Instructions Compiler Specification v2.0

## Purpose

Compile an immutable YAML playbook into model-readable structured instructions without changing operational semantics. Structural presence alone is insufficient. Release is allowed only after node-level semantic parity validation.

## Normative rules

1. **Source-first compilation.** Compile each position from the complete YAML step object, especially `reference_fidelity_binding`; never infer an action from ordinal position, neighboring titles, or phase expectations.
2. **Canonical-title separation.** Preserve the YAML `title` as provenance metadata. Derive the executable instruction from the binding question, source node, answer type, control actions, gates, evidence, and explicit execution rules. A contradictory YAML title must not override operative binding semantics.
3. **No invented verb.** Do not introduce render, approve, validate, write, execute, archive, or similar operations unless supported by an operative source field.
4. **Atomic instruction contract.** Every compiled position must expose: source step ID, source node ID, source title, operational intent, required inputs, allowed outputs/answer type, state mutations, evidence/gates, success/failure routing, correction owner/route, and terminal effects where present.
5. **Exact control preservation.** Copy answer types, on-answer branches, unmatched-input behavior, predecessors, state updates, system actions, gates, prompt refs, artifact refs, authoritative files, prompt bindings, approval bindings, final-gate controls, terminal preconditions, and execution rules without semantic rewriting.
6. **Correction-loop parity.** Any correctable validation failure must route to the owning generation step, invalidate dependent artifacts/approvals, regenerate, rerun validation, and prohibit successful terminal calculation until resolved.
7. **Title/action coherence gate.** Validate source node + binding question + compiled operational instruction as one semantic unit. The compiled action must be based on the operative binding, not merely repeat a potentially stale YAML title.
8. **Semantic parity matrix.** For all steps compare source and compiled: identity, node, intent source, inputs, outputs, state changes, gates/evidence, success route, failure route, correction route, terminal effects.
9. **Release threshold.** Weighted semantic difference must be <=5%. Any mismatch in routing, state mutation, approval, hard stop, correction loop, or terminal semantics is critical and blocks release regardless of aggregate percentage.
10. **Iteration limit.** Recompile and revalidate until the threshold is met or five cycles are exhausted. Record every cycle.
11. **Independent execution wording.** The model must be able to execute the structured package without consulting YAML. YAML may remain only in `source_lock/` for provenance and validation.
12. **No silent repair of YAML.** Compiler may resolve presentation conflicts by clearly separating canonical YAML title from operative instruction, but may not alter copied source control data. Source defects must be reported in the parity report.

## Operative-intent derivation order

Use the first available source in this order:
1. explicit `execution_rule`;
2. binding `question`;
3. `system_actions` or `gates`;
4. source-node identifier converted into a readable action;
5. YAML title only when coherent with the fields above.

## Critical-field policy

The following must be byte-equivalent after canonical serialization: source-node ID, answer type, on-answer routing, unmatched-input routing, predecessors, state mutations, gates, approvals, correction controls, terminal preconditions, and hard stops.
