# YAML → Structured Instructions Compilation Rules

## Purpose

Structured Instructions preserve the ordered, gated behavior of the YAML playbook without exposing YAML serialization as the analyst's working language.

## Representation boundary

- YAML Playbook is technical in both process and data. It may use nodes, transitions, state mutations, schemas, enums, exact control blocks and machine validators.
- Structured Instructions are structured but process-oriented prose. They preserve ordered steps, decisions, correction routes and hard stops, while avoiding YAML-shaped control blocks. They remain technical for data models, class names, attributes, templates, contracts, validator IDs and exact artifact requirements.
- Mixed Accumulated Instructions imitate a historically accumulated all-in-one analyst corpus built from the YAML process, including controlled repetition and late clarifications.
- Domain Adapted All-in-One is the near-original analyst instruction corpus with domain specificity removed.

## Compilation rules

1. Preserve every executable semantic unit and its order. Use readable numbered steps, not serialized YAML nodes.
2. Convert transitions into prose: explain where the step may be entered from, what happens on success, what happens on failure, and when execution must stop.
3. Do not copy `on_answer`, `allowed_from`, `state_updates`, `gates`, `system_actions`, or similar YAML maps verbatim into the model-visible process file.
4. Preserve exact technical names only where they describe data, artifacts, classes, attributes, templates, contracts, validators, states or external references.
5. Keep correction and invalidation semantics explicit: regeneration invalidates prior receipt and approval; failure returns to the named correction owner.
6. Preserve fail-closed behavior. Missing facts, ambiguous commands and unsupported capabilities may never be silently inferred.
7. Keep one canonical model-visible instruction file. Supporting templates and contracts remain separate technical files.
8. Maintain provenance mapping from each prose step to its YAML source unit. Provenance is audit data, not the runtime process language.
9. Validate both semantic coverage and representation style. A package fails if steps are missing or if the model-visible file contains copied YAML control blocks.
10. Validate the final ZIP with the exact launch prompt in a clean extraction, including Driver-owned validator execution.

## Acceptance criteria

- Exactly 126 ordered step IDs are represented once; the first is T001.
- All source units are covered by provenance.
- No fenced YAML or raw process-control maps appear in the analyst instruction file.
- Data and document requirements remain exact and independently verifiable.
- Driver enforcement, semantic validators, checksums and external-model preflight all pass.
