# History QA Runner Contract Bundle

Цей bundle є нормативним джерелом для генерації `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml`. Він витягнутий із наданого runner source і замінює модельні припущення про schema. Повний runner не дублюється в factory; його source hashes зафіксовані в `RUNNER_CONTRACT_SOURCE.json`.

Порядок використання: перевірити hashes → завантажити contract/capabilities/validation rules → відрендерити canonical schema → виконати structural conformance і, коли runner доступний, dry-run.


## External-model preflight simulation
The validated transfer pair is this ZIP plus `launch_prompts/START_PROMPT_STRUCTURED_INSTRUCTIONS_ANY_RUN_ALPHA_1_3_0_NEUTRAL.md`. Execute its commands literally from a clean extraction.
