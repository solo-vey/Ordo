# Методика перевірки пакетів Playbook та автоматичного тестування

Версія: 1.2 — накопичуваний release-blocking документ

## Головне правило

Перед кожним створенням або оновленням архіву цей файл треба прочитати повністю. Архів дозволено передавати лише після виконання всіх перевірок проти **фінального ZIP, розпакованого у чистий каталог**, і створення green-light evidence. Максимум — п’ять циклів «перевірка → виправлення → повторна збірка».


## Обов’язкова симуляція первинної валідації сторонньою моделлю

Ця перевірка є окремим release-blocking етапом і не замінюється локальними unit/regression checks. Потрібно повністю відтворити те, як стороння модель перевірятиме пакет при першому отриманні:

1. Взяти саме фінальний ZIP, який буде передано моделі, без доступу до build-каталогу.
2. Взяти саме фактичний launch prompt тієї самої версії, який буде передано разом із ZIP.
3. Розпакувати ZIP у новий порожній каталог.
4. Виконати перевірки в тому самому порядку, який визначено launch prompt.
5. Виконати буквально кожну команду з prompt із package root, без alias, підміни шляху або використання «еквівалентного» файла.
6. Перевірити кожен явно згаданий шлях до validator, runtime, input, manifest і output contract.
7. Застосувати ті самі правила fail-closed: будь-який blocker до T001 дає NO_CHANGE; бізнес-артефакти та approvals не створюються.
8. Підтвердити, що успішний pre-flight реально доходить до T001.
9. Зберегти stdout, stderr, exit codes, порядок команд, робочий каталог і результат кожного gate.
10. Green light заборонений, якщо ця симуляція не дала PASS для точної пари «final ZIP + actual launch prompt».


## Обов’язкова перевірка достатності вхідних даних для фактичного маршруту

Pre-flight parity не доводить, що позитивний RUN може бути виконаний. Перед green light треба імітувати перший інформаційний цикл моделі для кожного підтримуваного RUN:

1. Ініціалізувати Driver з чистого стану; у пакеті заборонені pre-started або частково заповнені state-файли.
2. Виконати визначену пакетну команду materialization для вибраного RUN.
3. Для позитивних RUN перевірити наявність точних `rule_id`, duplicate/fallback policy, source fixture, change fixture, request schemas, expected event shape і runner contract.
4. Відрізняти невідомі live environment values від відсутнього бізнес-контракту: `BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` можуть лишатися placeholders і не дозволяють hard stop для генерації executable specifications.
5. Перевірити, що стороння модель однозначно бачить, де отримати ці bindings, і не мусить здогадуватися про питання до Driver.
6. Для terminal RUN перевірити, що materialization явно повертає unavailable/blocked statuses і правильну terminal policy.
7. Запустити `validate_selected_run_input_sufficiency.py` із чисто розпакованого ZIP. Будь-яка відсутність exact binding у позитивному RUN є release blocker.
8. Симуляція повинна довести не лише досягнення `T001`, а й готовність першого позитивного generation gate без вигадування фактів.

## Повний перелік обов’язкових перевірок

1. **ZIP safety та фізична цілісність:** ZIP відкривається; немає duplicate entries, absolute paths, `..`, symlinks або небезпечних шляхів.
2. **Checksum completeness:** кожен запис `SHA256SUMS.txt` існує і збігається; звичайні файли не можуть залишатися поза manifest без явного правила.
3. **Package completeness:** присутні manifest, README, protocol, runtime, driver contract, selected-run input, overlays, templates, contracts, provenance, source lock та обов’язкові validators.
4. **Exact-path addressability:** кожен шлях, згаданий у manifest, README, protocol, scripts, runtime або launch prompt, існує саме за цим шляхом. «Схожий файл» не є еквівалентом.
5. **Launch-prompt/package compatibility:** перевіряти треба конкретну пару «фінальний пакет + фактичний launch prompt». Усі команди з prompt виконуються буквально з package root.
6. **Version coherence:** package ID, version, README, protocol, entrypoint, reports і prompts не містять суперечливих або stale версій.
7. **Entrypoint:** однакова точка входу в manifest, protocol, prompt і runtime; Position 1 має бути `T001`.
8. **Runtime structure:** рівно 126 упорядкованих унікальних позицій, 64 technical і 62 analytical, без пропусків/дублів.
9. **Semantic parity:** intent, title/action, inputs, outputs, state mutation, evidence, gates, transitions, correction owner та terminal semantics зіставлені з immutable YAML source; різниця ≤5%, critical mismatch = 0.
10. **Semantic validator reality:** точна команда `python validation/validate_semantic_parity.py .` існує, запускається з чисто розпакованого ZIP, exit code 0, machine status PASS.
11. **Package validator reality:** точна команда `python validation/validate_structured_runtime_package.py .` існує, запускається з чисто розпакованого ZIP, exit code 0.
12. **Correction-loop reachability:** correctable failure → correction receipt → owning step → dependent invalidation → regeneration → revalidation. Hard stop не підміняє доступний correction loop.
13. **Positive/negative validation:** активні fixtures і validators мають приймати сильні приклади та відхиляти дефектні. Видалені regression suites не можна тихо продовжувати викликати.
14. **Removed-assets audit:** файли, scripts, reports, fixtures і посилання видалених suites мають бути відсутні.
15. **Stale-reference scan:** немає посилань на відсутні validators, старі package names, старі prompts, removed regressions або історичні RUN paths.
16. **Current-artifact binding:** receipts та validators перевіряють саме поточний run/output directory, а не історичний oracle або інший каталог.
17. **Black-box isolation:** жоден validator не використовує файли поза розпакованим ZIP.
18. **Execution smoke rule:** до green pre-flight маршрут не входить у `T001`; при blocker не створюються business artifacts чи approvals.
19. **Returned-package rules:** майбутній run evidence ZIP має містити position ledger, driver states, validators, approvals/corrections, terminal justification та власний checksum manifest.
20. **Green-light evidence:** звіт містить cycle, усі команди, exit codes, check results, ZIP SHA-256 та `GREEN_LIGHT: true|false`.

## Заборонені підстави для PASS

- лише правильна кількість кроків;
- лише наявність checksum-файла;
- запуск у build-каталозі замість final ZIP;
- тест іншого prompt або іншої версії;
- припущення, що зовнішня модель знайде alias;
- receipts для іншого RUN;
- структурна parity без semantic parity;
- заявлений PASS без фактичного виконання зовнішньої команди.

## Відомі false-positive класи

- відсутній validator за шляхом із prompt;
- runtime починається не з `T001`;
- stale version/package/prompt references;
- title/action не відповідає source intent;
- correction loop не виконується;
- validators перевіряють історичний каталог;
- literal, rollback, duplicate-cycle або cross-artifact defects не виявляються;
- видалений regression suite залишається у script/manifest/report.


## Alpha 1.3.0 — Driver-enforced analyst validation

- The Driver MUST execute authoritative validators itself.
- Caller-supplied PASS receipts are forbidden.
- Validation requests provide `artifact_path`, `artifact`, and `version`; Passport also provides `case_registry_path`.
- The Driver captures exact command, stdout, stderr, return code, validator ID, artifact SHA-256, and immutable log path.
- Approval is forbidden unless the receipt was generated by the Driver and contains the exact required validator set.
- A release test MUST prove that a malformed artifact cannot be approved using a fabricated PASS receipt.
