# Structured Instructions Alpha 1.3.0 — Automated Testing Package

The single model-visible process file is `model_input/STRUCTURED_ANALYST_INSTRUCTIONS.md`. It preserves the 126-step process as readable structured prose rather than copied YAML control blocks. Technical definitions for data, artifacts, templates, contracts and validators remain exact in their supporting files.

Run preflight from the package root:

```bash
python validation/validate_semantic_parity.py
python validation/validate_structured_instruction_representation.py
python validation/validate_structured_runtime_package.py
python validation/validate_selected_run_input_sufficiency.py .
python validation/validate_driver_analyst_enforcement.py
```

Use `launch_prompts/START_PROMPT_STRUCTURED_INSTRUCTIONS_ANY_RUN_ALPHA_1_3_0_NEUTRAL.md` for external execution.
