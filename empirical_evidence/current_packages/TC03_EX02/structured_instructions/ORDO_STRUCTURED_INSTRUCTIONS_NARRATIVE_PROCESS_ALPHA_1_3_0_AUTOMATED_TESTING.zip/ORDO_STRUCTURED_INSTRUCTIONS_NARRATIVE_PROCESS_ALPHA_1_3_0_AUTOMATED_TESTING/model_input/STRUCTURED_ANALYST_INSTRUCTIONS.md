# Structured Analyst Instructions — Database Change Artifact Set

## Призначення

Цей файл є єдиним модельно-видимим описом процесу для аналітика. Він походить із YAML Playbook Alpha 1.17.0, але навмисно не повторює YAML-схеми, серіалізовані вузли чи технічні control blocks. Процес викладено як послідовність зрозумілих робочих кроків. Технічна точність збережена для даних, назв класів, атрибутів, шаблонів, контрактів і валідаторів.

## Загальні правила виконання

Починайте з кроку `T001` і рухайтеся далі лише дозволеними переходами. Не вигадуйте факти, значення, approvals, команди, endpoints, колекції або можливості runner. Якщо обов’язкових даних немає, використовуйте передбачений маршрут блокування чи виправлення. Після зміни документа попередня validation receipt та approval втрачають чинність. Driver виконує авторитетні валідатори самостійно; модель не створює PASS receipts від свого імені.

## Результати, які може створити процес

За позитивного маршруту сформуйте README, summary, validation і consistency reports, паспорт зміни, Jira-завдання, implementation prompt, Manual QA package, process-improvement feedback, automation specification і automation README. Перед архівацією поточні версії Passport, Jira, Manual QA та Automation повинні мати чинні validation receipts і approvals.

## Коли потрібно зупинитися

Зупиніться без вигадування бізнес-артефактів, якщо не визначено обов’язковий контракт, proposed дані подаються як confirmed, бракує покриття шаблону, Manual QA не є виконуваним, automation readiness не підтверджена runner evidence, відсутній approval, документ суперечить контракту або package-level go/no-go не дорівнює go.

## Етап: Початок роботи, безпека змін і вибір маршруту

### Крок 1 — `T001`: Load the all-in-one transport artifact into runtime working units

Виявлено repository changes без належної авторизації. Оберіть: переглянути diff, залишити зміни, відкотити або перетворити на proposed patch. Подальша mutation заблокована.

Це **technical** завдання. Очікуваний результат: `single_choice`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `repeat_review_options_and_keep_mutation_blocked`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``UNAUTHORIZED_MUTATION_REVIEW``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 2 — `T002`: Build a documentation index

Створити developer implementation package без зміни repository.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: EXECUTION_ROUTE_SELECTION.
Після виконання перейдіть до `HISTORY_EVENT_PASSPORT_CONFIRMATION`.
Після успішного виконання зафіксуйте стан: `implementation_route_status=developer_package_ready`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PACKAGE_GENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 3 — `T003`: Select only the documents required for the current step

Створити proposed diff/patch для review без застосування до repository.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: EXECUTION_ROUTE_SELECTION.
Після виконання перейдіть до `HISTORY_EVENT_PASSPORT_CONFIRMATION`.
Після успішного виконання зафіксуйте стан: `implementation_route_status=proposed_patch_ready`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PROPOSED_PATCH_GENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 4 — `T004`: Record documentation selection for the current step

Зберегти процес на етапі аналізу без implementation mutation.

Це **technical** завдання. Очікуваний результат: `control_action`.
Переходьте до цього кроку лише після: EXECUTION_ROUTE_SELECTION, IMPLEMENTATION_AUTHORIZATION.
Після виконання перейдіть до `HISTORY_EVENT_PASSPORT_CONFIRMATION`.
Після успішного виконання зафіксуйте стан: `implementation_route_status=analysis_only`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``ANALYSIS_ONLY_HOLD``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 5 — `T005`: Initialize run state

Покажи фінальну версію `01_HISTORY_EVENT_PASSPORT_<ALIAS>.md` окремо. Підтверджуєте цей документ? Відповідь: так, ні або правки.

Це **technical** завдання. Очікуваний результат: `document_confirmation`.
Переходьте до цього кроку лише після: ANALYSIS_ONLY_HOLD, ANALYTICAL_PACKAGE_COMPOSITION_CONFIRMATION, DRAFT_ANALYTICAL_PACKAGE_CONFIRMATION, IMPLEMENTATION_PACKAGE_GENERATION, PROPOSED_PATCH_GENERATION.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``HISTORY_EVENT_PASSPORT_CONFIRMATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 6 — `T006`: Initialize answer registry

Покажи фінальну версію `02_JIRA_TASK_<ALIAS>.md` окремо. Підтверджуєте цей документ? Відповідь: так, ні або правки.

Це **technical** завдання. Очікуваний результат: `document_confirmation`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Jira rendered artifact must be self-contained, preserve exact functional/unit ID sets, atomic deliverables, verifiable acceptance criteria, QA allocation and evidence-based DoD.
Технічний ідентифікатор джерела: ``JIRA_TASK_CONFIRMATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 7 — `T007`: Initialize mandatory-contract evidence matrix

Покажи фінальну версію `04_IMPLEMENTATION_PROMPT_<ALIAS>.md` окремо. Підтверджуєте цей документ? Відповідь: так, ні або правки.

Це **technical** завдання. Очікуваний результат: `document_confirmation`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PROMPT_CONFIRMATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 8 — `T008`: Initialize assumption ledger

Покажи фінальну версію `05_QA_PACKAGE_<ALIAS>.md` окремо. Підтверджуєте цей документ? Відповідь: так, ні або правки.

Це **technical** завдання. Очікуваний результат: `document_confirmation`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MANUAL_QA_PACKAGE_CONFIRMATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 9 — `T009`: Initialize rule-propagation matrix

Покажи фінальну версію `08_QA_AUTOMATION_SPEC_<ALIAS>.yaml` окремо. Підтверджуєте цей документ? Відповідь: так, ні або правки.

Це **technical** завдання. Очікуваний результат: `document_confirmation`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``QA_AUTOMATION_SPEC_CONFIRMATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 10 — `T010`: Initialize approval ledger

Jira must repeat atomic test requirements, technical deliverables, stable QA reference data, and expected results. References alone are insufficient.

Це **technical** завдання. Очікуваний результат: `package_composition_confirmation`.
Переходьте до цього кроку лише після: FINAL_ANALYTICAL_PACKAGE_COMPOSITION_GENERATION.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Правило виконання: Jira must repeat atomic test requirements, technical deliverables, stable QA reference data, and expected results. References alone are insufficient.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``ANALYTICAL_PACKAGE_COMPOSITION_CONFIRMATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 11 — `T011`: Initialize artifact-state registry

Після всіх document confirmations і consistency pass одним локальним кроком перегенерувати README.md, SUMMARY.json, VALIDATION_REPORT.json і CONSISTENCY_CHECK_REPORT.json.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: PACKAGE_METADATA_AND_VALIDATION_REPORTS_GATE.
Після виконання перейдіть до `PACKAGE_METADATA_AND_VALIDATION_REPORTS_GATE`.
Після успішного виконання зафіксуйте стан: `metadata_bundle_status=regenerated_after_final_confirmations`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``FINAL_METADATA_BUNDLE_REGENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 12 — `T012`: Initialize validation-results registry

Зібрати draft аналітичного пакета лише з чотирьох підтверджених core artifacts.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: QA_AUTOMATION_SPEC_CONFIRMATION.
Після виконання перейдіть до `DRAFT_ANALYTICAL_PACKAGE_CONFIRMATION`.
Після успішного виконання зафіксуйте стан: `draft_package_status=generated`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``DRAFT_ANALYTICAL_PACKAGE_GENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Завантаження джерел, визначення обсягу й перевірка вхідних фактів

### Крок 13 — `T013`: Create canonical identifiers

Підтверджуєте draft аналітичного пакета з чотирьох core artifacts?

Це **technical** завдання. Очікуваний результат: `package_composition_confirmation`.
Переходьте до цього кроку лише після: DRAFT_ANALYTICAL_PACKAGE_GENERATION.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``DRAFT_ANALYTICAL_PACKAGE_CONFIRMATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 14 — `T014`: Normalize identifiers across runtime state

Виконати read-only перевірку структури наданого модуля.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N7.
Після виконання перейдіть до `MODULE_ANALOGS_INSPECTION`.
Після успішного виконання зафіксуйте стан: `module_structure_inspection_status=completed`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MODULE_STRUCTURE_INSPECTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 15 — `T015`: Validate required input envelope

Знайти аналогічні реалізації в наданому коді.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: MODULE_STRUCTURE_INSPECTION.
Після виконання перейдіть до `MODULE_CONTRACTS_INSPECTION`.
Після успішного виконання зафіксуйте стан: `module_analogs_inspection_status=completed`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MODULE_ANALOGS_INSPECTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 16 — `T016`: Validate source-record structure

Every manual QA case must contain case-local executable fenced command blocks for setup, mutation, trigger, verification, rollback, and post-rollback verification.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: MODULE_ANALOGS_INSPECTION.
Після виконання перейдіть до `MODULE_TESTS_INSPECTION`.
Після успішного виконання зафіксуйте стан: `module_contracts_inspection_status=completed`.
Правило виконання: Every manual QA case must contain case-local executable fenced command blocks for setup, mutation, trigger, verification, rollback, and post-rollback verification.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MODULE_CONTRACTS_INSPECTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 17 — `T017`: Validate change-record structure

Reject abstract verbs such as upsert, submit, invoke processor, query store, restore baseline unless accompanied in the same case by a complete command.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: MODULE_CONTRACTS_INSPECTION.
Після виконання перейдіть до `MODULE_DEPENDENCY_INSPECTION`.
Після успішного виконання зафіксуйте стан: `module_tests_inspection_status=completed`.
Правило виконання: Reject abstract verbs such as upsert, submit, invoke processor, query store, restore baseline unless accompanied in the same case by a complete command.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MODULE_TESTS_INSPECTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 18 — `T018`: Validate field-path syntax

Перевірити залежності та потенційно зачеплені компоненти.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: MODULE_TESTS_INSPECTION.
Після виконання перейдіть до `IMPLEMENTATION_IMPACT_ANALYSIS_NODE`.
Після успішного виконання зафіксуйте стан: `module_dependency_inspection_status=completed`, `repository_inspection_status=completed`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MODULE_DEPENDENCY_INSPECTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 19 — `T019`: Validate operation-status vocabulary

Визначити точний implementation impact на основі read-only inspection.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: MODULE_DEPENDENCY_INSPECTION.
Після виконання перейдіть до `IMPLEMENTATION_PLAN_GENERATION_NODE`.
Після успішного виконання зафіксуйте стан: `implementation_impact_status=completed`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_IMPACT_ANALYSIS_NODE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 20 — `T020`: Validate timestamp format

Сформувати implementation plan для підтвердженого scope.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: IMPLEMENTATION_IMPACT_ANALYSIS_NODE.
Після виконання перейдіть до `CHANGE_COMPLEXITY_ASSESSMENT`.
Після успішного виконання зафіксуйте стан: `implementation_plan_status=generated`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PLAN_GENERATION_NODE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 21 — `T021`: Validate change-id presence

Сформувати repository-unverified developer handoff без тверджень про перевірену архітектуру або complexity.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: B1_N8_PROMPT_ONLY.
Після виконання перейдіть до `IMPLEMENTATION_RESULT_CAPTURE`.
Після успішного виконання зафіксуйте стан: `implementation_executor=developer`, `implementation_result_artifact=prompt_only_handoff`, `implementation_execution_status=formal_handoff`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PROMPT_ONLY_HANDOFF_GENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 22 — `T022`: Resolve contract evidence using the mandatory source order

Застосувати підтверджений implementation prompt до копії наданого архіву.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Після виконання перейдіть до `IMPLEMENTATION_CODE_REVIEW`.
Після успішного виконання зафіксуйте стан: `implementation_execution_status=code_changed`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MODEL_CODE_MUTATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 23 — `T023`: Block promotion of examples into contracts

Every automation case must provide runner binding, exact fixture construction, exact invocation, machine assertions, cleanup, and post-cleanup assertions.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: MODEL_CODE_MUTATION.
Після виконання перейдіть до `CODE_REVIEW_COMPLETION_GATE`.
Після успішного виконання зафіксуйте стан: `implementation_code_review_status=completed`.
Правило виконання: Every automation case must provide runner binding, exact fixture construction, exact invocation, machine assertions, cleanup, and post-cleanup assertions.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_CODE_REVIEW``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 24 — `T024`: Block promotion of proposed values into confirmed values

Runner adapter is a declared executable interface, not prose. Each action must use command/HTTP/database syntax or a named callable with full arguments.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Після виконання перейдіть до `IMPLEMENTATION_RESULT_CAPTURE`.
Після успішного виконання зафіксуйте стан: `implementation_execution_status=formal_handoff`.
Правило виконання: Runner adapter is a declared executable interface, not prose. Each action must use command/HTTP/database syntax or a named callable with full arguments.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``DEVELOPER_HANDOFF_GENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Паспорт зміни та його підтвердження

### Крок 25 — `T025`: Run the mandatory contract micro-check before each gate

Запустити доступні implementation tests і зберегти фактичний результат.

Це **technical** завдання. Очікуваний результат: `ack`.
Після виконання перейдіть до `IMPLEMENTATION_ROLLBACK_VERIFICATION`.
Після успішного виконання зафіксуйте стан: `implementation_test_status=completed`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_TEST_EXECUTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 26 — `T026`: Run one-question-per-hard-contract control

Перевірити rollback для виконаних code mutations.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: IMPLEMENTATION_TEST_EXECUTION.
Після виконання перейдіть до `IMPLEMENTATION_RELEASE_EVIDENCE_GENERATION`.
Після успішного виконання зафіксуйте стан: `implementation_rollback_status=verified`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_ROLLBACK_VERIFICATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 27 — `T027`: Run tree-to-template coverage

Сформувати release evidence з changed files, executed commands, results, blockers і residual risks.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: IMPLEMENTATION_ROLLBACK_VERIFICATION.
Після виконання перейдіть до `IMPLEMENTATION_RELEASE_EVIDENCE_COMPLETENESS_GATE`.
Після успішного виконання зафіксуйте стан: `implementation_release_evidence_status=generated`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_RELEASE_EVIDENCE_GENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 28 — `T028`: Map each required template section to an answer or source

Зафіксувати короткий implementation result або formal handoff result.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: DEVELOPER_HANDOFF_GENERATION, PROMPT_ONLY_HANDOFF_GENERATION.
Після виконання перейдіть до `B1_G12P`.
Після успішного виконання зафіксуйте стан: `implementation_result_status=captured`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_RESULT_CAPTURE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 29 — `T029`: Block generation when required coverage is missing

Чи змінила фактична реалізація або handoff assumptions у підтверджених core artifacts?

Це **technical** завдання. Очікуваний результат: `single_choice`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``AFFECTED_ARTIFACTS_GATE_NODE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 30 — `T030`: Render README from template

Визначити перелік підтверджених артефактів, які потребують регенерації.

Це **technical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: AFFECTED_ARTIFACTS_GATE_NODE.
Після виконання перейдіть до `PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE`.
Після успішного виконання зафіксуйте стан: `affected_artifacts_selection_status=completed`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``AFFECTED_ARTIFACTS_SELECTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 31 — `T031`: Render SUMMARY from template

Сформувати фінальний склад аналітичного пакета після implementation block.

Це **technical** завдання. Очікуваний результат: `artifact_generation`.
Переходьте до цього кроку лише після: AFFECTED_ARTIFACTS_GATE_NODE.
Після виконання перейдіть до `ANALYTICAL_PACKAGE_COMPOSITION_CONFIRMATION`.
Після успішного виконання зафіксуйте стан: `aggregate_package_composition_status=generated`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``FINAL_ANALYTICAL_PACKAGE_COMPOSITION_GENERATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 32 — `T032`: Render VALIDATION_REPORT from template

Перевір, що робочий playbook виконується у PROCESS_EXECUTOR_ONLY / EXECUTION_MODE.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: ROOT_N0.
Якщо перевірка успішна, продовжуйте з `AUTHORITATIVE_CONTEXT_RELOAD_GATE`.
Якщо перевірка неуспішна, поверніться до `BLOCKED_MISSING_INSTRUCTION` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PROCESS_EXECUTION_MODE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 33 — `T033`: Render CONSISTENCY_CHECK_REPORT from template

Процес заблоковано: active contract не визначає дію однозначно. Запроси точне рішення користувача.

Це **technical** завдання. Очікуваний результат: `terminal`.
Переходьте до цього кроку лише після: AFFECTED_ARTIFACTS_GATE_NODE, ANALYTICAL_PACKAGE_COMPOSITION_CONFIRMATION, AUTHORITATIVE_CONTEXT_RELOAD_GATE, AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, AUTOMATION_ARTIFACT_PROVENANCE_GATE, AUTOMATION_CONFIRMED_STATE_COVERAGE_GATE, AUTOMATION_DOCUMENT_COMPLETENESS_VALIDATION, AUTOMATION_NO_EDITORIAL_TRANSFORMATION_GATE, DRAFT_ANALYTICAL_PACKAGE_CONFIRMATION, HISTORY_EVENT_PASSPORT_CONFIRMATION, IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, IMPLEMENTATION_PROMPT_ARTIFACT_PROVENANCE_GATE, IMPLEMENTATION_PROMPT_CONFIRMATION, IMPLEMENTATION_PROMPT_CONFIRMED_STATE_COVERAGE_GATE, IMPLEMENTATION_PROMPT_DOCUMENT_COMPLETENESS_VALIDATION, IMPLEMENTATION_PROMPT_NO_EDITORIAL_TRANSFORMATION_GATE, JIRA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, JIRA_ARTIFACT_PROVENANCE_GATE, JIRA_CONFIRMED_STATE_COVERAGE_GATE, JIRA_DOCUMENT_COMPLETENESS_VALIDATION, JIRA_NO_EDITORIAL_TRANSFORMATION_GATE, JIRA_TASK_CONFIRMATION, MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, MANUAL_QA_ARTIFACT_PROVENANCE_GATE, MANUAL_QA_CONFIRMED_STATE_COVERAGE_GATE, MANUAL_QA_DOCUMENT_COMPLETENESS_VALIDATION, MANUAL_QA_ISOLATED_TC_VALIDATION_GATE, MANUAL_QA_PACKAGE_CONFIRMATION, NO_EDITORIAL_TRANSFORMATION_GATE, PACKAGE_METADATA_AND_VALIDATION_REPORTS_GATE, PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, PASSPORT_ARTIFACT_PROVENANCE_GATE, PASSPORT_CONFIRMED_STATE_COVERAGE_GATE, PASSPORT_DOCUMENT_COMPLETENESS_VALIDATION, PASSPORT_NO_EDITORIAL_TRANSFORMATION_GATE, PROCESS_EXECUTION_MODE_GATE, QA_AUTOMATION_SPEC_CONFIRMATION.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``BLOCKED_MISSING_INSTRUCTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 34 — `T034`: Render canonical passport from template

Повторно resolve і прочитай exact authoritative inputs active node безпосередньо перед дією.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: PROCESS_EXECUTION_MODE_GATE.
Якщо перевірка успішна, продовжуйте з `ROOT_N1`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `contracts/PASSPORT_CROSS_ARTIFACT_TRACEABILITY_CONTRACT.yaml`, `runtime/CASE_STATUS_REGISTRY.yaml`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``AUTHORITATIVE_CONTEXT_RELOAD_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 35 — `T035`: Validate canonical passport

Passport approval requires UNIT specificity PASS and traceability PASS; full Manual QA steps are not required in Passport. Passport approval requires behavior-specific mapping rationale for runnable rows and exact missing-authority plus closure evidence for blocked rows.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: MANUAL_QA_DOCUMENT_COMPLETENESS_VALIDATION.
Якщо перевірка успішна, продовжуйте з `MANUAL_QA_ISOLATED_TC_VALIDATION_GATE`.
Якщо перевірка неуспішна, поверніться до `MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `validation/validate_unit_provider_semantics.py`, `contracts/UNIT_PROVIDER_ATOMIC_SPECIFICATION_CONTRACT.yaml`, `contracts/FUNCTIONAL_UNIT_SEMANTIC_COVERAGE_CONTRACT.yaml`, `validation/validate_passport_cross_artifact_traceability.py`, `contracts/PASSPORT_CROSS_ARTIFACT_TRACEABILITY_CONTRACT.yaml`, `contracts/PASSPORT_MAPPING_RATIONALE_AND_CLOSURE_EVIDENCE_CONTRACT.yaml`.
Правило виконання: Passport approval requires UNIT specificity PASS and traceability PASS; full Manual QA steps are not required in Passport. Passport approval requires behavior-specific mapping rationale for runnable rows and exact missing-authority plus closure evidence for blocked rows.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``NO_EDITORIAL_TRANSFORMATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 36 — `T036`: Present canonical passport for approval

Перевір кожен Manual QA test case окремо після видалення shared sections та інших test cases.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: NO_EDITORIAL_TRANSFORMATION_GATE.
Якщо перевірка успішна, продовжуйте з `MANUAL_QA_ARTIFACT_QUALITY_GATE`.
Якщо перевірка неуспішна, поверніться до `MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MANUAL_QA_ISOLATED_TC_VALIDATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 37 — `T037`: Record canonical passport approval

Validate the regenerated README.md, SUMMARY.json, VALIDATION_REPORT.json, and CONSISTENCY_CHECK_REPORT.json as one metadata bundle.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: FINAL_METADATA_BUNDLE_REGENERATION.
Якщо перевірка успішна, продовжуйте з `B1_G13A`.
Якщо перевірка неуспішна, поверніться до `FINAL_METADATA_BUNDLE_REGENERATION` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PACKAGE_METADATA_AND_VALIDATION_REPORTS_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Jira-завдання і контракт реалізації

### Крок 38 — `T038`: Render Jira task from template

Render Jira without duplicating unit-test specifications. Use specific Passport references. Materialize atomic delivery rows, behavior-specific acceptance criteria, functional coverage, dependencies with closure criteria, and evidence-based Definition of Done. Use the canonical positive and forbidden DEL examples and complete a line-by-line DEL/AC self-review before rendering.

Це **technical** завдання. Очікуваний результат: `successor_resolution_result`.
Переходьте до цього кроку лише після: B1_P14, NEXT_MANDATORY_NODE_SELECTION_GATE, TERMINAL_ELIGIBILITY_GATE.
Після виконання перейдіть до `NEXT_MANDATORY_NODE_SELECTION_GATE`.
Після успішного виконання зафіксуйте стан: `overall_process_status=in_progress`.
Для цього кроку використовуйте авторитетні матеріали: `templates/TEMPLATE_JIRA_TASK_V3.md`, `prompts/hp.artifact.jira.generate_and_review.v3.md`, `contracts/JIRA_DELIVERY_FOCUSED_CONTRACT_V2.yaml`, `runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml`, `validation/validate_jira_delivery_content.py`.
Правило виконання: Render Jira without duplicating unit-test specifications. Use specific Passport references. Materialize atomic delivery rows, behavior-specific acceptance criteria, functional coverage, dependencies with closure criteria, and evidence-based Definition of Done. Use the canonical positive and forbidden DEL examples and complete a line-by-line DEL/AC self-review before rendering.
Критерій якості: Jira is a delivery-focused derivative of Passport. Unit-test specifications are not duplicated; specific Passport references are allowed; section order is irrelevant. Require atomic delivery requirements, behavior-specific verifiable acceptance criteria, functional coverage, blocker closure criteria, and evidence-based Definition of Done.
Технічний ідентифікатор джерела: ``POST_PACKAGE_SUCCESSOR_RESOLUTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 39 — `T039`: Validate Jira task

Parse every rendered Jira DEL/AC structurally, require parser coverage equality, validate target→action→output/side-effect→measurable-result semantics, and reject heading-only DoD evidence.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: POST_PACKAGE_SUCCESSOR_RESOLUTION.
Для цього кроку використовуйте авторитетні матеріали: `contracts/JIRA_DELIVERY_FOCUSED_CONTRACT_V2.yaml`, `validation/validate_jira_delivery_content.py`, `runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml`, `validation/validate_jira_implementation_output.py`.
Правило виконання: Parse every rendered Jira DEL/AC structurally, require parser coverage equality, validate target→action→output/side-effect→measurable-result semantics, and reject heading-only DoD evidence.
Критерій якості: Jira is a delivery-focused derivative of Passport. Unit-test specifications are not duplicated; specific Passport references are allowed; section order is irrelevant. Require atomic delivery requirements, behavior-specific verifiable acceptance criteria, functional coverage, blocker closure criteria, and evidence-based Definition of Done.
Технічний ідентифікатор джерела: ``NEXT_MANDATORY_NODE_SELECTION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 40 — `T040`: Present Jira task for approval

Jira approval requires every DEL to state a concrete implementation output independently; cross-document references are supplementary only. Presentation additionally requires a valid artifact validation receipt bound to the current Jira artifact hash and version.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: NEXT_MANDATORY_NODE_SELECTION_GATE.
Якщо перевірка успішна, продовжуйте з `FINAL_COMPLETION_SCOPE_GATE`.
Якщо перевірка неуспішна, поверніться до `POST_PACKAGE_SUCCESSOR_RESOLUTION` і не просувайте артефакт далі.
Для цього кроку використовуйте авторитетні матеріали: `contracts/JIRA_IMPLEMENTATION_OUTPUT_SPECIFICITY_CONTRACT.yaml`, `contracts/ARTIFACT_APPROVAL_VALIDATION_RECEIPT_CONTRACT.yaml`, `validation/validate_artifact_approval_receipt.py`.
Правило виконання:  Jira approval requires every DEL to state a concrete implementation output independently; cross-document references are supplementary only. Presentation additionally requires a valid artifact validation receipt bound to the current Jira artifact hash and version.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``TERMINAL_ELIGIBILITY_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 41 — `T041`: Record Jira task approval

Перевір rendered passport artifact на заборонені редакторські трансформації.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: PASSPORT_DOCUMENT_COMPLETENESS_VALIDATION.
Якщо перевірка успішна, продовжуйте з `PASSPORT_ARTIFACT_QUALITY_GATE`.
Якщо перевірка неуспішна, поверніться до `PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PASSPORT_NO_EDITORIAL_TRANSFORMATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 42 — `T042`: Render implementation prompt from template

Перевір rendered Jira artifact на заборонені редакторські трансформації.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: JIRA_DOCUMENT_COMPLETENESS_VALIDATION.
Якщо перевірка успішна, продовжуйте з `JIRA_ARTIFACT_QUALITY_GATE`.
Якщо перевірка неуспішна, поверніться до `JIRA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Jira rendered artifact must be self-contained, preserve exact functional/unit ID sets, atomic deliverables, verifiable acceptance criteria, QA allocation and evidence-based DoD.
Технічний ідентифікатор джерела: ``JIRA_NO_EDITORIAL_TRANSFORMATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 43 — `T043`: Validate implementation prompt

Перевір rendered automation artifact на заборонені редакторські трансформації.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: AUTOMATION_DOCUMENT_COMPLETENESS_VALIDATION.
Якщо перевірка успішна, продовжуйте з `AUTOMATION_ARTIFACT_QUALITY_GATE`.
Якщо перевірка неуспішна, поверніться до `AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``AUTOMATION_NO_EDITORIAL_TRANSFORMATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Ручне QA та доказовість перевірок

### Крок 44 — `T044`: Load and render Manual QA from authoritative operational contracts

Render each Manual QA case from authoritative status and lifecycle. Every count=1 change/event/error assertion must be case-local executable code that queries/projects and compares all authoritative literal fields; narrative assertion text and cardinality-only commands are invalid. Preserve rollback/no-record/blocked semantics. Use the canonical forbidden and required fail-closed examples and perform line-by-line self-review of Steps 5, 7, 8 and 9.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: IMPLEMENTATION_PROMPT_DOCUMENT_COMPLETENESS_VALIDATION.
Якщо перевірка успішна, продовжуйте з `IMPLEMENTATION_PROMPT_ARTIFACT_QUALITY_GATE`.
Якщо перевірка неуспішна, поверніться до `IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `runtime/CASE_STATUS_REGISTRY.yaml`, `contracts/CASE_STATUS_REGISTRY_CONTRACT.yaml`, `contracts/MANUAL_QA_DUPLICATE_CYCLE_CONTRACT.yaml`, `contracts/MANUAL_QA_EXECUTABLE_EXACT_ASSERTION_CONTRACT.yaml`.
Правило виконання: Render each Manual QA case from authoritative status and lifecycle. Every count=1 change/event/error assertion must be case-local executable code that queries/projects and compares all authoritative literal fields; narrative assertion text and cardinality-only commands are invalid. Preserve rollback/no-record/blocked semantics. Use the canonical forbidden and required fail-closed examples and perform line-by-line self-review of Steps 5, 7, 8 and 9.
Критерій якості: Each Manual QA case must be independently executable or explicitly blocked with one deterministic blocker.
Технічний ідентифікатор джерела: ``MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 45 — `T045`: Validate every Manual QA case semantically in isolation

Manual QA approval requires lifecycle PASS plus executable exact-payload PASS. Reject prose-only exact assertions and count-only evidence for created records. Duplicate manual cases still require two complete executable cycles. Manual QA approval requires all zero-count and rollback checks to be fail-closed executable assertions with nonzero exit on mismatch and exact restored values. Strip comments before validation; validate each step independently and require executable query→comparison→nonzero-failure relations.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: AFFECTED_ARTIFACTS_SELECTION, B1_N5F, HISTORY_EVENT_PASSPORT_CONFIRMATION, PASSPORT_ARTIFACT_PROVENANCE_GATE, PASSPORT_CONFIRMED_STATE_COVERAGE_GATE, PASSPORT_DOCUMENT_COMPLETENESS_VALIDATION, PASSPORT_NO_EDITORIAL_TRANSFORMATION_GATE.
Якщо перевірка успішна, продовжуйте з `B1_P5A`.
Якщо перевірка неуспішна, поверніться до `BLOCKED_RETURN_TO_MISSING_ARTIFACT_OR_TEMPLATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `validation/validate_manual_qa_rendered.py`, `contracts/MANUAL_QA_CASE_LOCAL_SEMANTIC_CONTRACT.yaml`, `contracts/CASE_STATUS_REGISTRY_CONTRACT.yaml`, `runtime/CASE_STATUS_REGISTRY.yaml`, `contracts/MANUAL_QA_DUPLICATE_CYCLE_CONTRACT.yaml`, `contracts/MANUAL_QA_EXECUTABLE_EXACT_ASSERTION_CONTRACT.yaml`, `contracts/MANUAL_QA_ZERO_AND_ROLLBACK_FAIL_CLOSED_CONTRACT.yaml`.
Правило виконання: Manual QA approval requires lifecycle PASS plus executable exact-payload PASS. Reject prose-only exact assertions and count-only evidence for created records. Duplicate manual cases still require two complete executable cycles. Manual QA approval requires all zero-count and rollback checks to be fail-closed executable assertions with nonzero exit on mismatch and exact restored values. Strip comments before validation; validate each step independently and require executable query→comparison→nonzero-failure relations.
Критерій якості: Validate local IDs, commands, schema compatibility, exact assertions, deterministic branching and rollback symmetry.
Технічний ідентифікатор джерела: ``MANUAL_QA_ISOLATED_TC_VALIDATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 46 — `T046`: Check that global QA flow does not replace per-test steps

Validate exact generation provenance for 01_HISTORY_EVENT_PASSPORT_<ALIAS>.md.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: B1_P5A.
Якщо перевірка успішна, продовжуйте з `PASSPORT_CONFIRMED_STATE_COVERAGE_GATE`.
Якщо перевірка неуспішна, поверніться до `PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PASSPORT_ARTIFACT_PROVENANCE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 47 — `T047`: Present manual QA package for approval

Present Manual QA only with a valid validation receipt bound to the current artifact hash/version and created after the latest regeneration.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: PASSPORT_ARTIFACT_PROVENANCE_GATE.
Якщо перевірка успішна, продовжуйте з `PASSPORT_DOCUMENT_COMPLETENESS_VALIDATION`.
Якщо перевірка неуспішна, поверніться до `PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `contracts/ARTIFACT_APPROVAL_VALIDATION_RECEIPT_CONTRACT.yaml`, `validation/validate_artifact_approval_receipt.py`.
Правило виконання: Present Manual QA only with a valid validation receipt bound to the current artifact hash/version and created after the latest regeneration.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PASSPORT_CONFIRMED_STATE_COVERAGE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 48 — `T048`: Record manual QA package approval

Record approval only after the current Manual QA validation receipt passes; any regeneration or invalidation voids the receipt and approval.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: PASSPORT_CONFIRMED_STATE_COVERAGE_GATE.
Якщо перевірка успішна, продовжуйте з `PASSPORT_NO_EDITORIAL_TRANSFORMATION_GATE`.
Якщо перевірка неуспішна, поверніться до `PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Правило виконання: Record approval only after the current Manual QA validation receipt passes; any regeneration or invalidation voids the receipt and approval.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``PASSPORT_DOCUMENT_COMPLETENESS_VALIDATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 49 — `T049`: Render process-improvement feedback

Load exact authoritative prompt and canonical template for 02_JIRA_TASK_<ALIAS>.md before generation.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: HISTORY_EVENT_PASSPORT_CONFIRMATION, JIRA_ARTIFACT_PROVENANCE_GATE, JIRA_CONFIRMED_STATE_COVERAGE_GATE, JIRA_DOCUMENT_COMPLETENESS_VALIDATION, JIRA_NO_EDITORIAL_TRANSFORMATION_GATE, JIRA_TASK_CONFIRMATION.
Якщо перевірка успішна, продовжуйте з `B1_P5B`.
Якщо перевірка неуспішна, поверніться до `BLOCKED_RETURN_TO_MISSING_ARTIFACT_OR_TEMPLATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Jira rendered artifact must be self-contained, preserve exact functional/unit ID sets, atomic deliverables, verifiable acceptance criteria, QA allocation and evidence-based DoD.
Технічний ідентифікатор джерела: ``JIRA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 50 — `T050`: Validate process-improvement feedback

Validate exact generation provenance for 02_JIRA_TASK_<ALIAS>.md.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: B1_P5B.
Якщо перевірка успішна, продовжуйте з `JIRA_CONFIRMED_STATE_COVERAGE_GATE`.
Якщо перевірка неуспішна, поверніться до `JIRA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Jira rendered artifact must be self-contained, preserve exact functional/unit ID sets, atomic deliverables, verifiable acceptance criteria, QA allocation and evidence-based DoD.
Технічний ідентифікатор джерела: ``JIRA_ARTIFACT_PROVENANCE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Автоматизація QA і прив’язка до runner contract

### Крок 51 — `T051`: Render Automation Spec from authoritative runner contracts

Generate each runnable Automation case from authoritative Driver/registry facts with a stable authoritative_fixture_ref. Require complete literal publish and process payloads. For duplicate/idempotency, require two complete causal cycles using the same authoritative business payload and dedup identity, followed by final cardinality and explicit no-second-side-effect assertions.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: JIRA_ARTIFACT_PROVENANCE_GATE.
Якщо перевірка успішна, продовжуйте з `JIRA_DOCUMENT_COMPLETENESS_VALIDATION`.
Якщо перевірка неуспішна, поверніться до `JIRA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `runtime/CASE_STATUS_REGISTRY.yaml`, `contracts/CASE_STATUS_REGISTRY_CONTRACT.yaml`, `contracts/AUTOMATION_DUPLICATE_CAUSAL_CYCLE_CONTRACT.yaml`, `contracts/AUTOMATION_FULL_SEMANTIC_VALIDATION_CONTRACT.yaml`.
Правило виконання: Generate each runnable Automation case from authoritative Driver/registry facts with a stable authoritative_fixture_ref. Require complete literal publish and process payloads. For duplicate/idempotency, require two complete causal cycles using the same authoritative business payload and dedup identity, followed by final cardinality and explicit no-second-side-effect assertions.
Критерій якості: Every runnable automation case must have complete lifecycle stimuli and exact field-level assertions; blocked cases must name the missing authoritative binding.
Технічний ідентифікатор джерела: ``QA_AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 52 — `T052`: Validate Automation Spec semantic completeness

Automation approval requires full external-rubric semantic PASS: authoritative fixture binding, complete payloads, behavior-fixture relations, lifecycle/rollback, cross-action identity, duplicate causal order, duplicate payload equivalence, dedup identity equality, and post-second-cycle exact negative assertions.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: JIRA_CONFIRMED_STATE_COVERAGE_GATE.
Якщо перевірка успішна, продовжуйте з `JIRA_NO_EDITORIAL_TRANSFORMATION_GATE`.
Якщо перевірка неуспішна, поверніться до `JIRA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `validation/validate_automation_rendered.py`, `contracts/CASE_STATUS_REGISTRY_CONTRACT.yaml`, `runtime/CASE_STATUS_REGISTRY.yaml`, `contracts/AUTOMATION_BEHAVIOR_FIXTURE_RELATION_CONTRACT.yaml`, `contracts/AUTOMATION_DUPLICATE_CAUSAL_CYCLE_CONTRACT.yaml`, `contracts/AUTOMATION_FULL_SEMANTIC_VALIDATION_CONTRACT.yaml`.
Правило виконання: Automation approval requires full external-rubric semantic PASS: authoritative fixture binding, complete payloads, behavior-fixture relations, lifecycle/rollback, cross-action identity, duplicate causal order, duplicate payload equivalence, dedup identity equality, and post-second-cycle exact negative assertions.
Критерій якості: Validate assertions, lifecycle stimuli, manual mapping, blocked-case evidence and runner schema.
Технічний ідентифікатор джерела: ``QA_AUTOMATION_SEMANTIC_VALIDATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 53 — `T053`: Validate runner-discovery compatibility

Do not load Manual QA sources at this node. Unsupported actions become exact blocked cases, not plausible commands.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: JIRA_TASK_CONFIRMATION, MANUAL_QA_ARTIFACT_PROVENANCE_GATE, MANUAL_QA_CONFIRMED_STATE_COVERAGE_GATE, MANUAL_QA_DOCUMENT_COMPLETENESS_VALIDATION, MANUAL_QA_ISOLATED_TC_VALIDATION_GATE, MANUAL_QA_PACKAGE_CONFIRMATION, NO_EDITORIAL_TRANSFORMATION_GATE.
Якщо перевірка успішна, продовжуйте з `B1_P5C`.
Якщо перевірка неуспішна, поверніться до `BLOCKED_RETURN_TO_MISSING_ARTIFACT_OR_TEMPLATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Правило виконання: Do not load Manual QA sources at this node. Unsupported actions become exact blocked cases, not plausible commands.
Критерій якості: Validate that every runnable action and assertion is supported by the authoritative runner contract.
Технічний ідентифікатор джерела: ``QA_AUTOMATION_RUNNER_DISCOVERY_COMPATIBILITY_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 54 — `T054`: Separate structure validation from live-run status

Validate exact generation provenance for 05_QA_PACKAGE_<ALIAS>.md.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Якщо перевірка успішна, продовжуйте з `MANUAL_QA_CONFIRMED_STATE_COVERAGE_GATE`.
Якщо перевірка неуспішна, поверніться до `MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MANUAL_QA_ARTIFACT_PROVENANCE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 55 — `T055`: Present automation specification for approval

Validate confirmed-state coverage in 05_QA_PACKAGE_<ALIAS>.md.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: B1_P5C, MANUAL_QA_ARTIFACT_PROVENANCE_GATE.
Якщо перевірка успішна, продовжуйте з `MANUAL_QA_DOCUMENT_COMPLETENESS_VALIDATION`.
Якщо перевірка неуспішна, поверніться до `MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MANUAL_QA_CONFIRMED_STATE_COVERAGE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 56 — `T056`: Record automation specification approval

Validate canonical completeness of 05_QA_PACKAGE_<ALIAS>.md before confirmation.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: MANUAL_QA_CONFIRMED_STATE_COVERAGE_GATE.
Якщо перевірка успішна, продовжуйте з `NO_EDITORIAL_TRANSFORMATION_GATE`.
Якщо перевірка неуспішна, поверніться до `MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``MANUAL_QA_DOCUMENT_COMPLETENESS_VALIDATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 57 — `T057`: Render automation README

Load exact authoritative prompt and canonical template for 08_QA_AUTOMATION_SPEC_<ALIAS>.yaml before generation.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: AUTOMATION_ARTIFACT_PROVENANCE_GATE, AUTOMATION_CONFIRMED_STATE_COVERAGE_GATE, AUTOMATION_DOCUMENT_COMPLETENESS_VALIDATION, AUTOMATION_NO_EDITORIAL_TRANSFORMATION_GATE, MANUAL_QA_PACKAGE_CONFIRMATION, QA_AUTOMATION_SPEC_CONFIRMATION.
Якщо перевірка успішна, продовжуйте з `B1_P5D`.
Якщо перевірка неуспішна, поверніться до `BLOCKED_RETURN_TO_MISSING_ARTIFACT_OR_TEMPLATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Узгодження артефактів, виправлення та повторні перевірки

### Крок 58 — `T058`: Validate automation README

Validate exact generation provenance for 08_QA_AUTOMATION_SPEC_<ALIAS>.yaml.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: B1_P5D.
Якщо перевірка успішна, продовжуйте з `AUTOMATION_CONFIRMED_STATE_COVERAGE_GATE`.
Якщо перевірка неуспішна, поверніться до `AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``AUTOMATION_ARTIFACT_PROVENANCE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 59 — `T059`: Run cross-artifact value-consistency checks

Cross-artifact approval compares normalized behavior facts, not only IDs and statuses.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: AUTOMATION_ARTIFACT_PROVENANCE_GATE.
Якщо перевірка успішна, продовжуйте з `AUTOMATION_DOCUMENT_COMPLETENESS_VALIDATION`.
Якщо перевірка неуспішна, поверніться до `AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `validation/validate_cross_artifact_semantics.py`, `contracts/CASE_STATUS_REGISTRY_CONTRACT.yaml`, `runtime/CASE_STATUS_REGISTRY.yaml`, `validation/validate_cross_artifact_behavior_semantics.py`, `contracts/CROSS_ARTIFACT_BEHAVIOR_SEMANTIC_CONSISTENCY_CONTRACT.yaml`.
Правило виконання: Cross-artifact approval compares normalized behavior facts, not only IDs and statuses.
Критерій якості: Validate a complete semantic matrix: Functional ID → Passport UNIT/provider → Jira DEL/AC → MQA → AUTO → authoritative status/blocker/cardinalities.
Технічний ідентифікатор джерела: ``AUTOMATION_CONFIRMED_STATE_COVERAGE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 60 — `T060`: Run negative assertions

Validate canonical completeness of 08_QA_AUTOMATION_SPEC_<ALIAS>.yaml before confirmation.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: AUTOMATION_CONFIRMED_STATE_COVERAGE_GATE.
Якщо перевірка успішна, продовжуйте з `AUTOMATION_NO_EDITORIAL_TRANSFORMATION_GATE`.
Якщо перевірка неуспішна, поверніться до `AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``AUTOMATION_DOCUMENT_COMPLETENESS_VALIDATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 61 — `T061`: Run stale-reference and forbidden-form checks

Load exact authoritative prompt and canonical template for 04_IMPLEMENTATION_PROMPT_<ALIAS>.md before generation.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: CHANGE_COMPLEXITY_ASSESSMENT, IMPLEMENTATION_PROMPT_ARTIFACT_PROVENANCE_GATE, IMPLEMENTATION_PROMPT_CONFIRMATION, IMPLEMENTATION_PROMPT_CONFIRMED_STATE_COVERAGE_GATE, IMPLEMENTATION_PROMPT_DOCUMENT_COMPLETENESS_VALIDATION, IMPLEMENTATION_PROMPT_NO_EDITORIAL_TRANSFORMATION_GATE.
Якщо перевірка успішна, продовжуйте з `B1_P5E`.
Якщо перевірка неуспішна, поверніться до `BLOCKED_RETURN_TO_MISSING_ARTIFACT_OR_TEMPLATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 62 — `T062`: Run rendered-artifact validation

Validate exact generation provenance for 04_IMPLEMENTATION_PROMPT_<ALIAS>.md.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: B1_P5E.
Якщо перевірка успішна, продовжуйте з `IMPLEMENTATION_PROMPT_CONFIRMED_STATE_COVERAGE_GATE`.
Якщо перевірка неуспішна, поверніться до `IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PROMPT_ARTIFACT_PROVENANCE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 63 — `T063`: Run package-level validation

Validate confirmed-state coverage in 04_IMPLEMENTATION_PROMPT_<ALIAS>.md.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: IMPLEMENTATION_PROMPT_ARTIFACT_PROVENANCE_GATE.
Якщо перевірка успішна, продовжуйте з `IMPLEMENTATION_PROMPT_DOCUMENT_COMPLETENESS_VALIDATION`.
Якщо перевірка неуспішна, поверніться до `IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PROMPT_CONFIRMED_STATE_COVERAGE_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 64 — `T064`: Write final go/no-go status and assemble the archive

This is the only final terminal calculation point. Any later invalidation or hash change supersedes T_COMPLETED, resets terminal to not_ready/no_go, and requires recomputation. T064 is prohibited while any correctable validator failure lacks a regeneration attempt.

Це **technical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: IMPLEMENTATION_PROMPT_CONFIRMED_STATE_COVERAGE_GATE.
Якщо перевірка успішна, продовжуйте з `IMPLEMENTATION_PROMPT_NO_EDITORIAL_TRANSFORMATION_GATE`.
Якщо перевірка неуспішна, поверніться до `IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE` і не просувайте артефакт далі.
Якщо відповідь або дані не відповідають очікуванню, виконайте `route_to_blocked_missing_instruction` та перейдіть до `BLOCKED_MISSING_INSTRUCTION`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Правило виконання: This is the only final terminal calculation point. Any later invalidation or hash change supersedes T_COMPLETED, resets terminal to not_ready/no_go, and requires recomputation. T064 is prohibited while any correctable validator failure lacks a regeneration attempt.
Критерій якості: Validate rendered document depth, not only field presence.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PROMPT_DOCUMENT_COMPLETENESS_VALIDATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 65 — `A001`: Establish focused scope for the current run

Підтверджуєш sync, deduplication, no-op і error behavior для зовнішнього історичного факту?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B4_N3.
Після виконання перейдіть до `COMMON_N4A`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B4_N4``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 66 — `A002`: Confirm the selected benchmark branch is the fixed internal-record-change branch

Можеш надати опис або приклад зовнішнього data block? Якщо прикладу немає або є лише неповний опис, скажи це прямо.

Це **analytical** завдання. Очікуваний результат: `artifact_presence`.
Переходьте до цього кроку лише після: ROOT_N1.
Якщо відповідь або дані не відповідають очікуванню, виконайте `classify_as_provided_partial_or_missing_then_route`.
Технічний ідентифікатор джерела: ``B5_N1``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 67 — `A003`: Identify the business purpose of the requested artifact set

Запропонуй candidate data block contract і snapshot assumptions. Явно покажи невідомі поля, matching context та open gaps.

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B5_N1.
Після виконання перейдіть до `B5_N1_RECONSTRUCT_CONFIRM`.
Після успішного виконання зафіксуйте стан: `external_data_block_reconstruction_status=draft_ready`.
Технічний ідентифікатор джерела: ``B5_N1_RECONSTRUCT``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 68 — `A004`: Identify the source record collection

Підтверджуєш реконструйований data block contract як основу для snapshot model?

Це **analytical** завдання. Очікуваний результат: `free_response`.
Переходьте до цього кроку лише після: B5_N1_RECONSTRUCT.
Після виконання перейдіть до `B5_N2`.
Після успішного виконання зафіксуйте стан: `external_data_block_contract_status=confirmed`.
Технічний ідентифікатор джерела: ``B5_N1_RECONSTRUCT_CONFIRM``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 69 — `A005`: Confirm the stable document identifier

Підтверджуєш модель previous/current snapshot для цього data block: де береться previous snapshot, що є current state, як визначається first baseline і який context ідентифікує snapshot?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B5_N1, B5_N1_RECONSTRUCT_CONFIRM.
Після виконання перейдіть до `B5_N3`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B5_N2``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 70 — `A006`: Confirm the stable record key

Підтверджуєш правило порівняння previous snapshot і current state для цього data block: matching key, compared fields, ignored fields, normalization і meaningful differences?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B5_N2.
Після виконання перейдіть до `B5_N4`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B5_N3``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 71 — `A007`: Confirm the relevant nested item

Яку granularність HistoryEvent обираємо для differences у цьому data block: одна подія на зміну всього блоку, окремі події по item/field changes, чи змішана модель?

Це **analytical** завдання. Очікуваний результат: `single_choice`.
Переходьте до цього кроку лише після: B5_N3.
Технічний ідентифікатор джерела: ``B5_N4``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 72 — `A008`: Confirm the changed field path

Запропонуй рекомендовану granularність, коротко порівняй альтернативи та поясни вплив на cardinality, dedup і читабельність HistoryEvent.

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B5_N4.
Після виконання перейдіть до `B5_N4_PROPOSE_CONFIRM`.
Після успішного виконання зафіксуйте стан: `event_granularity_proposal_status=draft_ready`.
Технічний ідентифікатор джерела: ``B5_N4_PROPOSE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Пакування, provenance, approvals і готовність до передачі

### Крок 73 — `A009`: Confirm the old field value

Підтверджуєш запропоновану granularність HistoryEvent?

Це **analytical** завдання. Очікуваний результат: `free_response`.
Переходьте до цього кроку лише після: B5_N4_PROPOSE.
Після виконання перейдіть до `B5_N5`.
Після успішного виконання зафіксуйте стан: `event_granularity_proposal_status=confirmed`.
Технічний ідентифікатор джерела: ``B5_N4_PROPOSE_CONFIRM``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 74 — `A010`: Confirm the new field value

Підтверджуєш mapping detected difference у HistoryEvent: alias, group, source, type/sub_type, event date, item.values, evidence і reference на compared snapshots?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B5_N4, B5_N4_PROPOSE_CONFIRM.
Після виконання перейдіть до `B5_N6`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B5_N5``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 75 — `A011`: Confirm the operation status

Підтверджуєш snapshot, no-op і error behavior для comparison-based data block: first baseline, no meaningful diff, created events, snapshot update, external error і malformed block behavior?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B5_N5.
Після виконання перейдіть до `B5_P7`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B5_N6``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 76 — `A012`: Confirm the change occurrence time

comparison algorithm artifact assembly

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B5_N6.
Після виконання перейдіть до `COMMON_N4A`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B5_P7``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 77 — `A013`: Confirm the unique change identifier

Ця історична подія нова, вже існує, частково існує або не впевнені?

Це **analytical** завдання. Очікуваний результат: `single_choice`.
Переходьте до цього кроку лише після: ROOT_N1.
Технічний ідентифікатор джерела: ``B1_N1``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 78 — `A014`: Check whether the changed field is in scope

Можеш надати original source row / Mongo-запис або його релевантний фрагмент? Якщо запису немає, скажи це прямо. Якщо є лише шлях поля або неповний фрагмент, теж познач це явно.

Це **analytical** завдання. Очікуваний результат: `artifact_presence`.
Переходьте до цього кроку лише після: B1_N1.
Якщо відповідь або дані не відповідають очікуванню, виконайте `classify_as_provided_partial_or_missing_then_route`.
Технічний ідентифікатор джерела: ``B1_N2A``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 79 — `A015`: Check whether old and new values are meaningfully different

Покажи визначений source row path, межі наданого фрагмента та open gaps. Підтверджуєш, що цього достатньо для design-time визначення поля, без runtime-залежності від source row?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N2A, B1_N2A_MISSING.
Після виконання перейдіть до `B1_N2B`.
Після успішного виконання зафіксуйте стан: `source_row_contract_status=confirmed`.
Технічний ідентифікатор джерела: ``B1_N2A_CONFIRM``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 80 — `A016`: Confirm the event type name

Source row відсутній. Надай хоча б точний source row path виду item.<path> або підтвердь, що визначення поля треба заблокувати до отримання джерела.

Це **analytical** завдання. Очікуваний результат: `single_choice`.
Переходьте до цього кроку лише після: B1_N2A.
Технічний ідентифікатор джерела: ``B1_N2A_MISSING``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 81 — `A017`: Confirm the event display names used in documents

Можеш надати ChangeRecord / RowDataChange для цієї події? Якщо запису немає, скажи це прямо. Також обери allowed ChangeRecord.data.status: modified, new, deleted.

Це **analytical** завдання. Очікуваний результат: `artifact_presence`.
Переходьте до цього кроку лише після: B1_N2A_CONFIRM, ROOT_N1.
Якщо відповідь або дані не відповідають очікуванню, виконайте `classify_as_provided_or_missing_then_route`.
Технічний ідентифікатор джерела: ``B1_N2B``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 82 — `A018`: Confirm the source-record contract

Покажи перевірений ChangeRecord contract: status pre-filter, delta.field, delta.old, delta.new, ChangeRecord.date, source_change_id та open gaps. Підтверджуєш цей контракт?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N2B.
Після виконання перейдіть до `B1_N2C`.
Після успішного виконання зафіксуйте стан: `change_record_contract_status=confirmed`.
Технічний ідентифікатор джерела: ``B1_N2B_PROVIDED_CONFIRM``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 83 — `A019`: Confirm the source-field-path contract

Реконструюй мінімальний ChangeRecord contract лише з delta.field, delta.old, delta.new, allowed ChangeRecord.data.status та ChangeRecord.date. Не використовуй changed_at, date_change або date_create як fallback; невідомі значення залиш open gaps.

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N2B.
Після виконання перейдіть до `B1_N2B_RECONSTRUCT_CONFIRM`.
Після успішного виконання зафіксуйте стан: `change_record_reconstruction_status=draft_ready`.
Технічний ідентифікатор джерела: ``B1_N2B_RECONSTRUCT``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 84 — `A020`: Confirm the change-record contract

Підтверджуєш реконструйований ChangeRecord contract разом з усіма assumptions і open gaps?

Це **analytical** завдання. Очікуваний результат: `free_response`.
Переходьте до цього кроку лише після: B1_N2B_RECONSTRUCT.
Після виконання перейдіть до `B1_N2C`.
Після успішного виконання зафіксуйте стан: `change_record_contract_status=confirmed`.
Технічний ідентифікатор джерела: ``B1_N2B_RECONSTRUCT_CONFIRM``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 85 — `A021`: Confirm that the change field path is relative to the item context

Можеш надати приклад HistoryEvent для цієї події? Якщо готового прикладу немає, скажи це прямо.

Це **analytical** завдання. Очікуваний результат: `artifact_presence`.
Переходьте до цього кроку лише після: B1_N2B_PROVIDED_CONFIRM, B1_N2B_RECONSTRUCT_CONFIRM.
Якщо відповідь або дані не відповідають очікуванню, виконайте `classify_as_provided_or_missing_then_route`.
Технічний ідентифікатор джерела: ``B1_N2C``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 86 — `A022`: Confirm the derived-event contract

Покажи перевірений HistoryEvent field source/status contract, values/date mapping, excluded fields та open gaps. Підтверджуєш цей контракт?

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N2C.
Після виконання перейдіть до `B1_P1`.
Після успішного виконання зафіксуйте стан: `history_event_contract_status=confirmed`.
Технічний ідентифікатор джерела: ``B1_N2C_PROVIDED_CONFIRM``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 87 — `A023`: Confirm the exact values shape

Реконструюй повний candidate HistoryEvent output contract. Явно розділи auto-default, reconstructed, proposed і open fields; не приховуй assumptions.

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N2C.
Після виконання перейдіть до `B1_N2C_RECONSTRUCT_CONFIRM`.
Після успішного виконання зафіксуйте стан: `history_event_reconstruction_status=draft_ready`.
Технічний ідентифікатор джерела: ``B1_N2C_RECONSTRUCT``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 88 — `A024`: Confirm the exact values keys

Підтверджуєш реконструйований candidate HistoryEvent contract разом з усіма assumptions і open gaps?

Це **analytical** завдання. Очікуваний результат: `free_response`.
Переходьте до цього кроку лише після: B1_N2C_RECONSTRUCT.
Після виконання перейдіть до `B1_P1`.
Після успішного виконання зафіксуйте стан: `history_event_contract_status=confirmed`.
Технічний ідентифікатор джерела: ``B1_N2C_RECONSTRUCT_CONFIRM``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 89 — `A025`: Confirm the event date mapping

Зібрати структурований candidate contract із source row + ChangeRecord.data.status pre-filter + delta/date + HistoryEvent fields + bilingual display candidates + values/date mapping + open fields. Показати summary, порядок перевірок і попросити підтвердження як основу для подальшого пакета.

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N2C_PROVIDED_CONFIRM, B1_N2C_RECONSTRUCT_CONFIRM.
Після виконання перейдіть до `B1_N3`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_P1``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 90 — `A026`: Confirm the source identifier mapping

Підтверджуєш candidate contract для цієї події?

Це **analytical** завдання. Очікуваний результат: `free_response`.
Переходьте до цього кроку лише після: B1_P1.
Після виконання перейдіть до `COMMON_N4A`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N3``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Аналітичні уточнення, класифікація і контроль повноти

### Крок 91 — `A027`: Confirm the target identifier mapping

Підтверджуєш normalization для delta old/new values, event condition і stored item.values fallback: для порівняння empty -> empty string, а під час запису в item.values порожні old/new значення стають "-"?

Це **analytical** завдання. Очікуваний результат: `per_field_or_value_confirmation`.
Переходьте до цього кроку лише після: B1_N3, B4_N4, B5_P7.
Після виконання перейдіть до `B1_N4B`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``COMMON_N4A``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 92 — `A028`: Confirm the deduplication key

Підтверджуєш bilingual human/UI texts для події: display_name.uk/en, text_template.uk/en, placeholders, і правило що порожні placeholder values уже записані в item.values як "-", а не обробляються template/render layer?

Це **analytical** завдання. Очікуваний результат: `structured_text_confirmation`.
Переходьте до цього кроку лише після: COMMON_N4A.
Після виконання перейдіть до `B1_N4`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N4B``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 93 — `A029`: Confirm the positive trigger condition

Підтверджуєш, коли HistoryEvent створюється, коли не створюється, що є duplicate/no-op і як поводитися з неповними даними або помилками джерела?

Це **analytical** завдання. Очікуваний результат: `structured_rules_confirmation`.
Переходьте до цього кроку лише після: B1_N4B.
Після виконання перейдіть до `B1_N5`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N4``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 94 — `A030`: Confirm the same-value no-op condition

Підтверджуєш повний QA/test package: unit tests, functional tests, integration tests, automation explanation і reviewer/manual notes для confirmed contract?

Це **analytical** завдання. Очікуваний результат: `compact_table_confirmation`.
Переходьте до цього кроку лише після: B1_N4.
Після виконання перейдіть до `B1_P5_QA_DATA_PROPOSAL`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N5``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 95 — `A031`: Confirm the unrelated-field no-op condition

Build a canonical test catalog with exact inputs, exact expected outputs, and stable IDs. No generic scenario labels.

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N5.
Після виконання перейдіть до `OPERATIONAL_QA_DATA_MATERIALIZATION_GATE`.
Після успішного виконання зафіксуйте стан: `operational_qa_dev_contract_generation_status=completed`, `operational_qa_dev_contract_validation_status=pending`, `operational_qa_dev_contract_approval_status=pending`.
Правило виконання: Build a canonical test catalog with exact inputs, exact expected outputs, and stable IDs. No generic scenario labels.
Технічний ідентифікатор джерела: ``B1_P5_QA_DATA_PROPOSAL``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 96 — `A032`: Confirm the unsupported-operation no-op condition

Execute the operation represented by source node `OPERATIONAL_QA_DATA_MATERIALIZATION_GATE` (operational qa data materialization gate), using the copied control contract below.

Це **analytical** завдання. Очікуваний результат: `None`.
Переходьте до цього кроку лише після: B1_P5_QA_DATA_PROPOSAL.
Технічний ідентифікатор джерела: ``OPERATIONAL_QA_DATA_MATERIALIZATION_GATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 97 — `A033`: Confirm the missing-data hard-stop condition

Показано окремо сформований operational QA/dev contract у блоках AUTO-FILLED і OPEN GAPS. Підтверджуєш його без змін, хочеш змінити окремі значення чи повернути на доопрацювання?

Це **analytical** завдання. Очікуваний результат: `structured_confirmation`.
Після виконання перейдіть до `B1_N5C`.
Після успішного виконання зафіксуйте стан: `operational_qa_dev_contract_approval_status=confirmed`, `operational_qa_dev_contract_validation_status=passed`.
Технічний ідентифікатор джерела: ``B1_N5A``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 98 — `A034`: Confirm duplicate-input behavior

Підтверджуєш розподіл functional tests між Manual QA та Automation?

Це **analytical** завдання. Очікуваний результат: `compact_matrix_confirmation`.
Переходьте до цього кроку лише після: B1_N5A.
Після виконання перейдіть до `B1_N5D`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N5C``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 99 — `A035`: Confirm null-value normalization

Підтверджуєш execution design автоматичних тестів для всіх FUNC-TC, де Automated = Так?

Це **analytical** завдання. Очікуваний результат: `automation_execution_matrix_confirmation`.
Переходьте до цього кроку лише після: B1_N5C.
Після виконання перейдіть до `B1_N5E`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N5D``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 100 — `A036`: Confirm missing-value normalization

Який режим автоматизації підтверджуєш: draft, automation-ready чи execute?

Це **analytical** завдання. Очікуваний результат: `automation_execution_mode_confirmation`.
Переходьте до цього кроку лише після: B1_N5D.
Після виконання перейдіть до `B1_N5B`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N5E``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 101 — `A037`: Confirm empty-string normalization

Підтверджуєш manual QA runbook plan? Після цього я матеріалізую окремий executable execution spec для кожного MANUAL-TC.

Це **analytical** завдання. Очікуваний результат: `runbook_plan_confirmation`.
Переходьте до цього кроку лише після: B1_N5E.
Після виконання перейдіть до `B1_N5F`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N5B``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 102 — `A038`: Confirm whether trimming or case normalization is allowed

Підтверджуєш повний MANUAL_QA_EXECUTION_SPEC: кожен MANUAL-TC має конкретні Mongo/REST кроки, exact assertions, error check і rollback?

Це **analytical** завдання. Очікуваний результат: `manual_execution_spec_confirmation`.
Переходьте до цього кроку лише після: B1_N5B.
Після виконання перейдіть до `PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE`.
Після успішного виконання зафіксуйте стан: `manual_qa_execution_spec_confirmed=True`.
Технічний ідентифікатор джерела: ``B1_N5F``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 103 — `A039`: Confirm the implementation module availability

Надай Confluence URL для паспорта або познач як skipped/deferred/not provided; URL не можна вигадувати.

Це **analytical** завдання. Очікуваний результат: `url_or_skip`.
Переходьте до цього кроку лише після: DRAFT_ANALYTICAL_PACKAGE_CONFIRMATION.
Після виконання перейдіть до `B1_P6B`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N6A``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 104 — `A040`: Confirm the implementation output mode

update Jira task draft with Confluence link if provided

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N6A.
Після виконання перейдіть до `B1_N6C`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_P6B``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 105 — `A041`: Define the canonical contract source

Надай Jira issue URL або познач як skipped/deferred/not provided; URL не можна вигадувати.

Це **analytical** завдання. Очікуваний результат: `url_or_skip`.
Переходьте до цього кроку лише після: B1_P6B.
Після виконання перейдіть до `B1_P6D`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_N6C``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 106 — `A042`: Define scope

propagate external links to implementation context

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_N6C.
Після виконання перейдіть до `B1_N7`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``B1_P6D``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 107 — `A043`: Define out of scope

Чи надано актуальний архів проєкту або цільового модуля чи read-only доступ до repository з визначеною branch/revision?

Це **analytical** завдання. Очікуваний результат: `single_choice`.
Переходьте до цього кроку лише після: B1_P6D.
Якщо відповідь або дані не відповідають очікуванню, виконайте `repeat_question_and_require_explicit_archive_or_repository_available_or_missing`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Технічний ідентифікатор джерела: ``B1_N7``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 108 — `A044`: Define business rules

Source evidence відсутнє. Не оцінюй complexity або criticality і не переходь до execution route. Збережи confirmed scope, познач стан blocked_missing_repository_evidence та запроси актуальний архів проєкту/модуля або read-only repository access.

Це **analytical** завдання. Очікуваний результат: `repository_evidence_block`.
Переходьте до цього кроку лише після: B1_N7.
Після виконання перейдіть до `PROMPT_ONLY_HANDOFF_GENERATION`.
Після успішного виконання зафіксуйте стан: `repository_availability_status=missing`, `repository_inspection_status=blocked`, `complexity_assessment_status=blocked_missing_repository_evidence`, `implementation_prompt_status=blocked`, `implementation_result_artifact=none`.
Технічний ідентифікатор джерела: ``B1_N8_PROMPT_ONLY``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Етап: Фінальні гейти, завершення або коректна зупинка

### Крок 109 — `A045`: Define event creation logic

Хто має внести підготовлені зміни: модель у цьому чаті чи розробник за перевіреним prompt?

Це **analytical** завдання. Очікуваний результат: `single_choice`.
Переходьте до цього кроку лише після: IMPLEMENTATION_PROMPT_CONFIRMATION.
Якщо відповідь або дані не відповідають очікуванню, виконайте `repeat_question_and_require_explicit_model_or_developer`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Технічний ідентифікатор джерела: ``B1_N10``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 110 — `A046`: Define data mapping

final analytical package composition gate; verify the canonical compact flat structure and confirm that code, repository files and patches remain separate

Це **analytical** завдання. Очікуваний результат: `gate_result`.
Переходьте до цього кроку лише після: PACKAGE_METADATA_AND_VALIDATION_REPORTS_GATE.
Якщо перевірка успішна, продовжуйте з `B1_P14`.
Якщо перевірка неуспішна, поверніться до `BLOCKED_RETURN_TO_MISSING_ARTIFACT_OR_TEMPLATE` і не просувайте артефакт далі.
Технічний ідентифікатор джерела: ``B1_G13A``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 111 — `A047`: Define validation rules

final compact analytical package assembly using the canonical single-root flat structure

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: B1_G13A.
Після виконання перейдіть до `POST_PACKAGE_SUCCESSOR_RESOLUTION`.
Після успішного виконання зафіксуйте стан: `final_analytical_package_status=assembled_after_all_confirmations`.
Технічний ідентифікатор джерела: ``B1_P14``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 112 — `A048`: Define error and blocking behavior

return to missing artifact/template resolution

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: AUTHORITATIVE_CONTEXT_RELOAD_GATE, AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, B1_G13A, IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, JIRA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE, PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE.
Технічний ідентифікатор джерела: ``BLOCKED_RETURN_TO_MISSING_ARTIFACT_OR_TEMPLATE``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 113 — `A049`: Define unit/provider test cases

Define atomic unit/provider test cases from confirmed rule behavior

Це **analytical** завдання. Очікуваний результат: `structured_catalog`.
Переходьте до цього кроку лише після: A048.
Після виконання перейдіть до `A050`.
Після успішного виконання зафіксуйте стан: `unit_provider_catalog_status=defined`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Технічний ідентифікатор джерела: ``DATABASE_CHANGE_A049_UNIT_PROVIDER_ATOMIC_DEFINITION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 114 — `A050`: Define functional/manual test cases

Generate passport artifact from canonical template

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: PASSPORT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE.
Після виконання перейдіть до `PASSPORT_ARTIFACT_PROVENANCE_GATE`.
Після успішного виконання зафіксуйте стан: `active_artifact_kind=passport`.
Для цього кроку використовуйте авторитетні матеріали: `contracts/PASSPORT_CROSS_ARTIFACT_TRACEABILITY_CONTRACT.yaml`, `runtime/CASE_STATUS_REGISTRY.yaml`.
Технічний ідентифікатор джерела: ``B1_P5A``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 115 — `A051`: Define mapping between unit and functional tests

Build semantic mapping between functional and unit/provider tests

Це **analytical** завдання. Очікуваний результат: `coverage_matrix`.
Переходьте до цього кроку лише після: A050.
Після виконання перейдіть до `A052`.
Після успішного виконання зафіксуйте стан: `functional_unit_coverage_status=complete`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Для цього кроку використовуйте авторитетні матеріали: `contracts/PASSPORT_CROSS_ARTIFACT_TRACEABILITY_CONTRACT.yaml`, `runtime/CASE_STATUS_REGISTRY.yaml`.
Технічний ідентифікатор джерела: ``DATABASE_CHANGE_A051_FUNCTIONAL_UNIT_SEMANTIC_MAPPING``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 116 — `A052`: Define QA reference data

Materialize executable manual QA runbook

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: MANUAL_QA_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE.
Після виконання перейдіть до `MANUAL_QA_CONFIRMED_STATE_COVERAGE_GATE`.
Після успішного виконання зафіксуйте стан: `active_artifact_kind=manual_qa`.
Технічний ідентифікатор джерела: ``B1_P5C``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 117 — `A053`: Define manual QA execution sequence

Generate executable automation runner spec

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: AUTOMATION_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE.
Після виконання перейдіть до `AUTOMATION_ARTIFACT_PROVENANCE_GATE`.
Після успішного виконання зафіксуйте стан: `active_artifact_kind=automation`.
Технічний ідентифікатор джерела: ``B1_P5D``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 118 — `A054`: Define positive-path expected results

Generate implementation prompt artifact

Це **analytical** завдання. Очікуваний результат: `ack`.
Переходьте до цього кроку лише після: IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE.
Після виконання перейдіть до `IMPLEMENTATION_PROMPT_ARTIFACT_PROVENANCE_GATE`.
Після успішного виконання зафіксуйте стан: `active_artifact_kind=implementation_prompt`.
Технічний ідентифікатор джерела: ``B1_P5E``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 119 — `A055`: Define no-op expected absence

Перевірити, чи доступний production repository або архів цільового модуля для repository discovery.

Це **analytical** завдання. Очікуваний результат: `repository_availability_result`.
Після виконання перейдіть до `REPOSITORY_AVAILABILITY_GATE`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``REPOSITORY_AVAILABILITY_CHECK``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 120 — `A056`: Define duplicate expected behavior

Створити REPOSITORY_DISCOVERY_<ALIAS>.md на основі фактичного repository evidence.

Це **analytical** завдання. Очікуваний результат: `artifact_generation`.
Після виконання перейдіть до `REPOSITORY_DISCOVERY_COMPLETION_GATE`.
Після успішного виконання зафіксуйте стан: .
Для цього кроку використовуйте авторитетні матеріали: `contracts/MANUAL_QA_DUPLICATE_CYCLE_CONTRACT.yaml`.
Технічний ідентифікатор джерела: ``REPOSITORY_DISCOVERY``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 121 — `A057`: Define missing-data expected behavior

Створити MODULE_ANALYSIS_<ALIAS>.md з фактичними module paths, runtime flow, extension points і test commands.

Це **analytical** завдання. Очікуваний результат: `artifact_generation`.
Після виконання перейдіть до `MODULE_ANALYSIS_COMPLETION_GATE`.
Після успішного виконання зафіксуйте стан: .
Для цього кроку використовуйте авторитетні матеріали: `contracts/CASE_STATUS_REGISTRY_CONTRACT.yaml`, `templates/TEMPLATE_CASE_STATUS_REGISTRY.yaml`, `runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml`, `contracts/DATABASE_CHANGE_AUTOMATION_RUNNER_CONTRACT.yaml`.
Критерій якості: Resolve one authoritative behavior status in runtime/CASE_STATUS_REGISTRY.yaml. If omission/missing-field binding is unavailable, both Manual QA and Automation are blocked_missing_binding.
Технічний ідентифікатор джерела: ``MODULE_ANALYSIS``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 122 — `A058`: Define rollback and post-rollback expectations

Створити IMPACT_ANALYSIS_<ALIAS>.md з changed files, protected core, dependencies і regression surface.

Це **analytical** завдання. Очікуваний результат: `artifact_generation`.
Після виконання перейдіть до `IMPACT_ANALYSIS_COMPLETION_GATE`.
Після успішного виконання зафіксуйте стан: .
Для цього кроку використовуйте авторитетні матеріали: `contracts/MANUAL_QA_CASE_LOCAL_SEMANTIC_CONTRACT.yaml`, `contracts/QA_AUTOMATION_TEST_LIFECYCLE_PROFILE_CONTRACT.yaml`, `runtime/CASE_STATUS_REGISTRY.yaml`.
Критерій якості: Define lifecycle-specific rollback from mutation provenance. No mutation means rollback not required; rollback must restore the same field and captured representation.
Технічний ідентифікатор джерела: ``IMPACT_ANALYSIS``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 123 — `A059`: Define automation scope

Створити IMPLEMENTATION_PLAN_<ALIAS>.md на основі підтверджених repository/module/impact artifacts.

Це **analytical** завдання. Очікуваний результат: `artifact_generation`.
Після виконання перейдіть до `IMPLEMENTATION_PLAN_COMPLETION_GATE`.
Після успішного виконання зафіксуйте стан: .
Технічний ідентифікатор джерела: ``IMPLEMENTATION_PLAN``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 124 — `A060`: Define runner compatibility status

Оцінити складність підтверджених змін, пояснити масштаб, ризики, affected areas і потребу в міграції. На цьому вузлі repository не змінюється.

Це **analytical** завдання. Очікуваний результат: `complexity_assessment`.
Переходьте до цього кроку лише після: IMPLEMENTATION_PLAN_GENERATION_NODE.
Після виконання перейдіть до `IMPLEMENTATION_PROMPT_ACTIVE_DOCUMENT_SOURCE_LOADING_GATE`.
Після успішного виконання зафіксуйте стан: `complexity_assessment_status=assessed`, `change_complexity_status=assessed`.
Технічний ідентифікатор джерела: ``CHANGE_COMPLEXITY_ASSESSMENT``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 125 — `A061`: Define open questions and assumptions

Оберіть спосіб продовження: 1 — реалізувати тут; 2 — підготувати пакет для розробника; 3 — підготувати лише proposed patch без застосування; 4 — залишитися на етапі аналізу.

Це **analytical** завдання. Очікуваний результат: `single_choice`.
Якщо відповідь або дані не відповідають очікуванню, виконайте `repeat_options_without_state_change`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Технічний ідентифікатор джерела: ``EXECUTION_ROUTE_SELECTION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

### Крок 126 — `A062`: Make the final analytical go/no-go decision

Passport must embed concrete manual QA cases and concrete unit/processor test specifications with IDs, inputs, invocation boundary, assertions, and expected outcomes.

Це **analytical** завдання. Очікуваний результат: `single_choice`.
Переходьте до цього кроку лише після: B1_N10, EXECUTION_ROUTE_SELECTION.
Якщо відповідь або дані не відповідають очікуванню, виконайте `repeat_authorization_question_without_mutation`.
Не приймайте довільну або неоднозначну відповідь як успішне завершення кроку.
Правило виконання: Passport must embed concrete manual QA cases and concrete unit/processor test specifications with IDs, inputs, invocation boundary, assertions, and expected outcomes.
Технічний ідентифікатор джерела: ``IMPLEMENTATION_AUTHORIZATION``. Він використовується для трасування, але не змінює текстовий порядок роботи.

---

## Постійні вимоги до даних і документів

- Назви класів, полів, атрибутів, статусів, contract IDs, validator IDs і шаблонів використовуйте точно так, як вони визначені у відповідних файлах пакета.
- Passport має містити поведінково конкретні unit/provider specifications і трасування до Jira, Manual QA та Automation.
- Jira має бути самодостатнім delivery contract із `DEL-*`, `AC-*`, залежностями, вимірюваними результатами та Definition of Done.
- Кожен Manual QA case має містити точні payloads, executable queries, case-local assertions, rollback/cleanup і post-checks.
- Кожен Automation case має бути прив’язаний до runner contract, містити literal fixtures, точний виклик, machine assertions, cleanup і post-cleanup verification.
- Driver має запускати валідатори, зберігати validator ID, command, stdout, stderr, return code та artifact hash. PASS без такого доказу недійсний.

## Джерела поточного запуску

Для фактів конкретного сценарію використовуйте `runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml`, `contracts/DATABASE_CHANGE_OPERATIONAL_QA_CONTRACT.yaml` і `contracts/DATABASE_CHANGE_AUTOMATION_RUNNER_CONTRACT.yaml`. Значення, позначені як confirmed, не потрібно повторно підтверджувати. Підтвердження артефакту означає підтвердження його повноти, а не імітацію діалогу з користувачем.
