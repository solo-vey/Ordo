# Runtime entrypoint contract

- Package: Structured Instructions Alpha 1.3.0 automated testing bundle.
- Mandatory pre-flight command from package root:

```bash
python validation/validate_structured_runtime_package.py .
```

- Continue only when the validator exits with code `0` and prints `"result": "PASS"`.
- Canonical first runtime position: `T001`.
- Continue in the exact printed order of `model_input/STRUCTURED_ANALYST_INSTRUCTIONS.md`.
- A missing validator, a non-zero exit, a first position other than `T001`, missing required model-visible files, checksum failure, stale package version, or unresolved reference is a pre-flight blocker.
- Pre-flight failure creates no business artifacts and no approvals.
