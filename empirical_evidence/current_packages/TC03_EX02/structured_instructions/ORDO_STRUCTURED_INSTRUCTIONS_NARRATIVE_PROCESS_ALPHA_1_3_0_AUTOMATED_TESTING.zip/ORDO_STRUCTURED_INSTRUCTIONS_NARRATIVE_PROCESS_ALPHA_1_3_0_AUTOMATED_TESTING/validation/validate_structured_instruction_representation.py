#!/usr/bin/env python3
from pathlib import Path
import re, json, sys
root=Path(__file__).resolve().parents[1]
t=(root/'model_input/STRUCTURED_ANALYST_INSTRUCTIONS.md').read_text(encoding='utf-8')
errors=[]
for pat,label in [(r'```ya?ml','fenced YAML'),(r'^\s*(on_answer|allowed_from|state_updates|system_actions|gates|artifact_refs|prompt_refs):','raw YAML process key'),(r'^### Position ','legacy Position heading')]:
    if re.search(pat,t,re.M|re.I): errors.append(label)
steps=re.findall(r'^### Крок \d+ — `([TA]\d{3})`:',t,re.M)
if len(steps)!=126: errors.append(f'expected 126 prose steps, got {len(steps)}')
required=['Manual QA','Automation','Jira','Passport','Driver','validation receipt','rollback','runner contract']
for x in required:
    if x.lower() not in t.lower(): errors.append('missing technical data/document requirement: '+x)
print(json.dumps({'status':'PASS' if not errors else 'FAIL','errors':errors,'step_count':len(steps)},indent=2,ensure_ascii=False))
sys.exit(1 if errors else 0)
