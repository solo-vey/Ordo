#!/usr/bin/env python3
from pathlib import Path
import re, json, sys
root=Path(__file__).resolve().parents[1]
p=root/'model_input/STRUCTURED_ANALYST_INSTRUCTIONS.md'
t=p.read_text(encoding='utf-8')
steps=re.findall(r'^### Крок (\d+) — `([TA]\d{3})`:',t,re.M)
ids=[x[1] for x in steps]
errors=[]
if len(steps)!=126: errors.append(f'expected 126 steps, got {len(steps)}')
if not steps or steps[0] != ('1','T001'): errors.append('Step 1 must be T001')
if len(ids)!=len(set(ids)): errors.append('duplicate step IDs')
prov=json.loads((root/'provenance/STEP_PROVENANCE_MAP.json').read_text())
# accept list or dict structures
if isinstance(prov,dict):
    entries=prov.get('steps') or prov.get('mappings') or prov.get('entries') or []
else: entries=prov
if len(entries)!=126: errors.append(f'provenance expected 126 entries, got {len(entries)}')
print(json.dumps({'status':'PASS' if not errors else 'FAIL','step_count':len(steps),'first_step':ids[0] if ids else None,'errors':errors},indent=2))
sys.exit(1 if errors else 0)
