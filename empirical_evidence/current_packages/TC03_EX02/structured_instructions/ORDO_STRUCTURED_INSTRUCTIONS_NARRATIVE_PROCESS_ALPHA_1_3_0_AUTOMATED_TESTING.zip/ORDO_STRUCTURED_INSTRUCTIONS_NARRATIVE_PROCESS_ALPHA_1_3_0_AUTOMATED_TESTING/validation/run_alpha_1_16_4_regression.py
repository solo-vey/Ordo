#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parents[1]
tests=[
 ('passport_bad','validate_passport_mapping_rationale.py','PASSPORT_BAD.md',True),
 ('passport_good','validate_passport_mapping_rationale.py','PASSPORT_GOOD.md',False),
 ('jira_bad','validate_jira_implementation_output.py','JIRA_BAD.md',True),
 ('jira_good','validate_jira_implementation_output.py','JIRA_GOOD.md',False),
 ('manual_bad','validate_manual_qa_fail_closed.py','MANUAL_BAD.md',True),
 ('manual_good','validate_manual_qa_fail_closed.py','MANUAL_GOOD.md',False),
]
results=[]; failed=[]
for name,val,fix,expect_reject in tests:
 p=subprocess.run([sys.executable,str(root/'validation'/val),str(root/'validation/regression_1164'/fix)],capture_output=True,text=True,timeout=20)
 rejected=p.returncode!=0
 ok=rejected==expect_reject
 results.append({'name':name,'expected_reject':expect_reject,'actual_reject':rejected,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'result':'PASS' if ok else 'FAIL'})
 if not ok: failed.append(name)
print(json.dumps({'suite':'alpha_1_16_4_remaining_document_alignment','results':results,'failed':failed,'result':'PASS' if not failed else 'FAIL'},ensure_ascii=False,indent=2))
sys.exit(0 if not failed else 1)
