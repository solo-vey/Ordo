#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parents[1]
p=root/'model_input/STRUCTURED_ANALYST_INSTRUCTIONS.md'
prov=root/'provenance/STEP_PROVENANCE_MAP.json'
par=root/'validation/COMPILATION_PARITY_REPORT.json'
errors=[]
text=p.read_text() if p.exists() else ''
ids=re.findall(r'^###\s+Position\s+\d+:\s+`([AT]\d{3})`',text,re.M)
if len(ids)!=126: errors.append(f'position_count={len(ids)}')
if ids and ids[0] != 'T001': errors.append('entrypoint_not_T001')
if len(set(ids))!=126: errors.append('duplicate_position_ids')
if sum(i.startswith('A') for i in ids)!=62: errors.append('analytical_count')
if sum(i.startswith('T') for i in ids)!=64: errors.append('technical_count')
try:
 d=json.loads(prov.read_text()); entries=d.get('steps',d.get('steps',d.get('mappings',[])))
 if isinstance(entries,dict): entries=list(entries.values())
 if len(entries)!=126: errors.append(f'provenance_count={len(entries)}')
except Exception as e: errors.append('provenance_invalid:'+str(e))
try:
 d=json.loads(par.read_text()); status=str(d.get('status',d.get('result',''))).upper()
 if status!='PASS': errors.append('parity_not_pass:'+status)
except Exception as e: errors.append('parity_invalid:'+str(e))
print(json.dumps({'status':'passed' if not errors else 'failed','errors':errors,'counts':{'total':len(ids),'analytical':sum(i.startswith('A') for i in ids),'technical':sum(i.startswith('T') for i in ids)}},indent=2))
sys.exit(1 if errors else 0)
