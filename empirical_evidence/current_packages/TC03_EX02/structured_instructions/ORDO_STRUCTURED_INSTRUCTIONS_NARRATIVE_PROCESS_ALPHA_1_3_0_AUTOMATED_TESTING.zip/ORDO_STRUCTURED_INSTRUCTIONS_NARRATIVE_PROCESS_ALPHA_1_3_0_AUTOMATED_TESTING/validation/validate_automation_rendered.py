#!/usr/bin/env python3
from pathlib import Path
import yaml, re, sys, json

d = yaml.safe_load(Path(sys.argv[1]).read_text(encoding="utf-8"))
errs = []

def dump(x):
    return yaml.safe_dump(x, sort_keys=False) if x is not None else ""

def val(case, key):
    txt = dump(case)
    m = re.search(rf"{key}:\s*[\"']?([^\n\"']+)", txt, re.I)
    return m.group(1).strip() if m else None

def action_body(node):
    if not isinstance(node, dict):
        return {}
    action = node.get("action")
    if isinstance(action, dict):
        return action.get("body") or {}
    return {}

def assertion_fields(node):
    if not isinstance(node, dict):
        return set()
    assertions = node.get("assertions") or {}
    return {k for k in assertions if k != "assert_document_count"}

def has_source_mutation_provenance(case):
    provenance = case.get("source_mutation_provenance")
    if isinstance(provenance, dict):
        return bool(
            provenance.get("proven")
            or provenance.get("authoritative_evidence")
            or provenance.get("evidence_ref")
        )
    if provenance is True:
        return True
    return bool(case.get("source_mutation_proven") or case.get("source_mutation_evidence"))


PUBLISH_REQUIRED = ["changeId","documentId","recordKey","operationStatus","fieldPath","oldValue","newValue"]
PROCESS_REQUIRED = ["changeId","ruleId"]

def get_path_action(node, expected_path):
    if not isinstance(node, dict):
        return None
    if node.get("path") == expected_path:
        return node
    action = node.get("action")
    if isinstance(action, dict) and action.get("path") == expected_path:
        return action
    for value in node.values():
        if isinstance(value, dict):
            found = get_path_action(value, expected_path)
            if found:
                return found
        elif isinstance(value, list):
            for item in value:
                found = get_path_action(item, expected_path)
                if found:
                    return found
    return None

def complete_body(action, required):
    if not isinstance(action, dict):
        return False
    body = action.get("body")
    return isinstance(body, dict) and all(k in body and (body[k] not in (None, "") or (k in {"oldValue","newValue"} and body[k] is None)) for k in required)

def case_authoritative_reference(case):
    return any(case.get(k) for k in [
        "authoritative_fixture_ref", "driver_fact_ref",
        "case_status_registry_ref", "behavior_catalog_ref"
    ])

def extract_cycle_facts(cycle):
    pub = get_path_action(cycle, "/api/test/database-change/publish")
    proc = get_path_action(cycle, "/api/database-change/process")
    pb = pub.get("body", {}) if isinstance(pub, dict) else {}
    rb = proc.get("body", {}) if isinstance(proc, dict) else {}
    return {
        "publish_action": pub,
        "process_action": proc,
        "changeId": pb.get("changeId"),
        "documentId": pb.get("documentId"),
        "recordKey": pb.get("recordKey"),
        "operationStatus": pb.get("operationStatus"),
        "fieldPath": pb.get("fieldPath"),
        "oldValue": pb.get("oldValue"),
        "newValue": pb.get("newValue"),
        "ruleId": rb.get("ruleId"),
        "processChangeId": rb.get("changeId"),
    }

def duplicate_final_assertions(cycle):
    if not isinstance(cycle, dict):
        return False, False
    node = cycle.get("post_process_assertions") or cycle.get("assertions") or {}
    txt = dump(node).lower()
    final_cardinality = (
        "expected_change_count" in txt or "expected_event_count" in txt
        or "assert_document_count" in txt or "final" in txt
    )
    no_second = any(token in txt for token in [
        "no_second_event", "no_second_record", "no_duplicate_event",
        "no_duplicate_record", "expected_event_count: 1",
        "expected_change_count: 1"
    ])
    return final_cardinality, no_second

for c in d.get("test_cases", []):
    cid = c.get("id", "UNKNOWN")
    title = str(c.get("title", "")).lower()
    txt = dump(c)

    old = val(c, "old_value") or val(c, "oldValue")
    new = val(c, "new_value") or val(c, "newValue")
    field = val(c, "field_path") or val(c, "fieldPath")
    status = val(c, "operation_status") or val(c, "operationStatus")

    evnums = [int(x) for x in re.findall(
        r"(?:expected_event_count|assert_document_count):\s*(\d+)", txt, re.I
    )]

    # Alpha 1.16 behavior/fixture relation gates.
    if "equal-value" in title or "equal value" in title:
        if old is not None and new is not None and old != new:
            errs.append(cid + ":AUTO_EQUAL_VALUE_RELATION_VIOLATION")
        if evnums and 0 not in evnums:
            errs.append(cid + ":AUTO_BEHAVIOR_LIFECYCLE_PROFILE_MISMATCH")

    if "meaningful" in title or "creates event" in title or "target-field change" in title:
        if old is not None and new is not None and old == new:
            errs.append(cid + ":AUTO_MEANINGFUL_CHANGE_RELATION_VIOLATION")

    if "unrelated" in title and field and field == "item.processingState":
        errs.append(cid + ":AUTO_UNRELATED_FIELD_RELATION_VIOLATION")

    if "unsupported" in title and status in {"modified", "updated"}:
        errs.append(cid + ":AUTO_UNSUPPORTED_STATUS_RELATION_VIOLATION")

    if "duplicate" in title or "idempot" in title:
        cycles = c.get("cycles")
        if isinstance(cycles, list):
            if len(cycles) < 2:
                errs.append(cid + ":AUTO_DUPLICATE_SECOND_CYCLE_MISSING")
            else:
                for idx, cycle in enumerate(cycles[:2], start=1):
                    cycle_txt = dump(cycle)
                    has_publish = "/api/test/database-change/publish" in cycle_txt
                    has_process = "/api/database-change/process" in cycle_txt
                    has_assertions = bool(
                        cycle.get("post_process_assertions")
                        or cycle.get("assertions")
                        or cycle.get("expected_events")
                        or cycle.get("expected_change")
                    )
                    if not (has_publish and has_process):
                        errs.append(cid + f":AUTO_DUPLICATE_CYCLE_{idx}_INCOMPLETE")
                    if not has_assertions:
                        errs.append(cid + f":AUTO_DUPLICATE_CYCLE_{idx}_ASSERTIONS_MISSING")
        else:
            # Legacy representation is accepted only through one explicitly ordered execution_steps list.
            steps = c.get("execution_steps")
            if not isinstance(steps, list):
                errs.append(cid + ":AUTO_DUPLICATE_CAUSAL_ORDER_INVALID")
            else:
                paths = []
                assertion_steps = []
                for i, step in enumerate(steps):
                    st = dump(step)
                    if "/api/test/database-change/publish" in st:
                        paths.append(("publish", i))
                    if "/api/database-change/process" in st:
                        paths.append(("process", i))
                    if any(k in step for k in ["assertions", "expected_events", "expected_change", "post_process_assertions"]):
                        assertion_steps.append(i)
                pubs = [i for kind, i in paths if kind == "publish"]
                procs = [i for kind, i in paths if kind == "process"]
                if len(pubs) < 2 or len(procs) < 2:
                    errs.append(cid + ":AUTO_DUPLICATE_SECOND_CYCLE_MISSING")
                elif not (pubs[0] < procs[0] < pubs[1] < procs[1]):
                    errs.append(cid + ":AUTO_DUPLICATE_CAUSAL_ORDER_INVALID")
                else:
                    if not any(procs[0] < a < pubs[1] for a in assertion_steps):
                        errs.append(cid + ":AUTO_DUPLICATE_CYCLE_1_ASSERTIONS_MISSING")
                    if not any(a > procs[1] for a in assertion_steps):
                        errs.append(cid + ":AUTO_DUPLICATE_CYCLE_2_ASSERTIONS_MISSING")


    # Alpha 1.16.3 full Automation external-rubric alignment.
    runnable = str(c.get("status", "runnable")).lower() not in {"blocked", "blocked_missing_binding"}
    if runnable and not case_authoritative_reference(c):
        errs.append(cid + ":AUTO_AUTHORITATIVE_FIXTURE_REFERENCE_MISSING")

    cycles = c.get("cycles")
    if runnable and isinstance(cycles, list):
        for idx, cycle in enumerate(cycles, start=1):
            facts = extract_cycle_facts(cycle)
            if facts["publish_action"] and not complete_body(facts["publish_action"], PUBLISH_REQUIRED):
                errs.append(cid + f":AUTO_CYCLE_{idx}_PUBLISH_PAYLOAD_INCOMPLETE")
            if facts["process_action"] and not complete_body(facts["process_action"], PROCESS_REQUIRED):
                errs.append(cid + f":AUTO_CYCLE_{idx}_PROCESS_PAYLOAD_INCOMPLETE")
            if facts["changeId"] and facts["processChangeId"] and facts["changeId"] != facts["processChangeId"]:
                errs.append(cid + f":AUTO_CYCLE_{idx}_CASE_IDENTITY_MISMATCH")

    if runnable and ("duplicate" in title or "idempot" in title) and isinstance(cycles, list) and len(cycles) >= 2:
        f1, f2 = extract_cycle_facts(cycles[0]), extract_cycle_facts(cycles[1])
        business_fields = ["documentId","recordKey","operationStatus","fieldPath","oldValue","newValue","ruleId"]
        for field_name in business_fields:
            if f1.get(field_name) != f2.get(field_name):
                errs.append(cid + ":AUTO_DUPLICATE_BUSINESS_PAYLOAD_MISMATCH")
                break
        if f1.get("changeId") != f2.get("changeId"):
            errs.append(cid + ":AUTO_DUPLICATE_DEDUP_IDENTITY_MISMATCH")
        for idx, facts in enumerate([f1, f2], start=1):
            if not complete_body(facts["publish_action"], PUBLISH_REQUIRED):
                errs.append(cid + f":AUTO_CYCLE_{idx}_PUBLISH_PAYLOAD_INCOMPLETE")
            if not complete_body(facts["process_action"], PROCESS_REQUIRED):
                errs.append(cid + f":AUTO_CYCLE_{idx}_PROCESS_PAYLOAD_INCOMPLETE")
        final_cardinality, no_second = duplicate_final_assertions(cycles[1])
        if not final_cardinality:
            errs.append(cid + ":AUTO_DUPLICATE_FINAL_ASSERTION_MISSING")
        if not no_second:
            errs.append(cid + ":AUTO_DUPLICATE_NO_SECOND_SIDE_EFFECT_ASSERTION_MISSING")

    # Restored Alpha 1.14 lifecycle/rollback gates.
    rollback = c.get("rollback") or {}
    rollback_body = action_body(rollback)
    rollback_field = rollback_body.get("fieldPath") or rollback_body.get("field_path")

    post = rollback.get("post_rollback_verification") or {}
    verified_fields = assertion_fields(post)

    if rollback_field and verified_fields:
        normalized_verified = {str(x) for x in verified_fields}
        if rollback_field not in normalized_verified:
            errs.append(cid + ":post_rollback_verification_observes_different_field")

    lifecycle_profile = str(c.get("lifecycle_profile", "")).strip().lower()
    rollback_required = bool(rollback.get("required"))
    rollback_action = rollback.get("action")
    executable_reverse_publish = (
        rollback_required
        and isinstance(rollback_action, dict)
        and rollback_action.get("action") == "http_post"
        and rollback_action.get("path") == "/api/test/database-change/publish"
    )

    if (
        lifecycle_profile == "change_absent"
        and executable_reverse_publish
        and not has_source_mutation_provenance(c)
    ):
        errs.append(cid + ":change_absent_rollback_without_source_mutation_provenance")

print(json.dumps({
    "validator": "automation_full_external_rubric_semantics_v6",
    "errors": errs,
    "result": "PASS" if not errs else "FAIL"
}, ensure_ascii=False, indent=2))

sys.exit(0 if not errs else 1)
