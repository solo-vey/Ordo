#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,zipfile,tempfile,re

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def verify(root):
 e=[]; sums=root/'SHA256SUMS.txt'
 if not sums.exists(): return ['SHA256SUMS_MISSING']
 for line in sums.read_text().splitlines():
  if not line.strip(): continue
  exp,rel=line.split('  ',1); p=root/rel
  if not p.exists(): e.append('MISSING:'+rel)
  elif sha(p)!=exp:e.append('HASH_MISMATCH:'+rel)
 p=root/'model_input/STRUCTURED_ANALYST_INSTRUCTIONS.md'
 ids=re.findall(r'^###\s+Position\s+\d+:\s+`([AT]\d{3})`',p.read_text(),re.M)
 if len(ids)!=126:e.append('POSITION_COUNT:'+str(len(ids)))
 req=['driver/semantic_analyst_driver.py','driver/STRUCTURED_INSTRUCTIONS_MULTI_SCENARIO_USAGE.md','validation/self_check.py','validation/COMPILATION_PARITY_REPORT.json','provenance/STEP_PROVENANCE_MAP.json','MODEL_VISIBLE_FILE_POLICY.json','scripts/run_structured_full_release_validation.sh']
 for rel in req:
  if not (root/rel).exists():e.append('REQUIRED_MISSING:'+rel)
 return e
def main():
 ap=argparse.ArgumentParser();ap.add_argument('package');a=ap.parse_args();z=Path(a.package);e=[]
 if not zipfile.is_zipfile(z):e.append('ZIP_INVALID')
 else:
  with tempfile.TemporaryDirectory() as td:
   with zipfile.ZipFile(z) as f:f.extractall(td)
   roots=[p for p in Path(td).iterdir() if p.is_dir()]
   if len(roots)!=1:e.append('ZIP_ROOT_COUNT')
   else:e+=verify(roots[0])
 print(json.dumps({'validator':'structured_release_package_self_validation_v1','package':str(z),'sha256':sha(z) if z.exists() else None,'errors':e,'result':'PASS' if not e else 'FAIL'},indent=2));return 0 if not e else 1
if __name__=='__main__':raise SystemExit(main())
