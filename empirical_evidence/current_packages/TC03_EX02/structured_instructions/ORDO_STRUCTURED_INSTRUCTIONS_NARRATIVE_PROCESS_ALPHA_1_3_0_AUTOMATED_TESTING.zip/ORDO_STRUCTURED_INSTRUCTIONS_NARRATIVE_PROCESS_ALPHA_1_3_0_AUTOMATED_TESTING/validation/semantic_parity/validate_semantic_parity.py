#!/usr/bin/env python3
import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
r=json.loads((root/'validation/SEMANTIC_PARITY_REPORT.json').read_text())
m=json.loads((root/'validation/SEMANTIC_PARITY_MATRIX.json').read_text())
assert r['step_count']==126
assert r['final_status']=='PASS'
assert r['final_difference_percent']<=5
assert all(x['status']=='PASS' for x in m)
print('PASS: 126 steps; semantic difference',r['final_difference_percent'],'%')
