#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parents[1]
required=['model_input/STRUCTURED_ANALYST_INSTRUCTIONS.md','compiler/STRUCTURED_INSTRUCTIONS_COMPILATION_RULES.md','driver/SEMANTIC_DRIVER_CONTRACT.md','runtime/SELECTED_RUN_FULL_FIDELITY_INPUT.yaml','validation/validate_semantic_parity.py','validation/validate_structured_instruction_representation.py','validation/validate_driver_analyst_enforcement.py']
errors=[x for x in required if not (root/x).exists()]
checks=[]
for script in ['validation/validate_semantic_parity.py','validation/validate_structured_instruction_representation.py']:
 r=subprocess.run([sys.executable,str(root/script)],cwd=root,capture_output=True,text=True); checks.append({'script':script,'returncode':r.returncode,'stdout':r.stdout[-2000:],'stderr':r.stderr[-1000:]});
 if r.returncode: errors.append(script+' failed')
print(json.dumps({'status':'PASS' if not errors else 'FAIL','required_paths':len(required),'checks':checks,'errors':errors},indent=2))
sys.exit(1 if errors else 0)
