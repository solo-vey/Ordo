# External Model Initial Validation Simulation

Release blocking. Validate the exact final ZIP plus the exact version-matched launch prompt from a clean extraction. Execute all prompt commands literally in prompt order from package root. Do not substitute aliases. On any pre-T001 failure, stop NO_CHANGE and create no business artifacts or approvals. Green light requires successful arrival at T001 and saved stdout/stderr/exit codes.
