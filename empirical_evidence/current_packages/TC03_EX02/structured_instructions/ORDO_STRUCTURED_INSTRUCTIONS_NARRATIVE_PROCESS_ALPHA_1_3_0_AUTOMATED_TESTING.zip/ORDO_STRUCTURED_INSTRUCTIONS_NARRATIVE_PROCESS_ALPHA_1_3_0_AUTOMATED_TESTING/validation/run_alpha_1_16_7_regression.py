#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json, tempfile
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('drv', ROOT/'driver/semantic_analyst_driver.py')
drv=importlib.util.module_from_spec(spec); spec.loader.exec_module(drv)
scenario={'name':'test','terminal_policy':'complete_go','approval_policy':'allowed'}
state=drv.default_state('RUN_02',scenario)
with tempfile.TemporaryDirectory() as td:
 td=Path(td); state_file=td/'state.json'
 # approval without Driver receipt rejected
 r=drv.handle_present(scenario,state,{'artifact':'passport','version':'v1'}); assert r['status']=='not_approved'
 # caller-created receipt is forbidden
 fake={'artifact':'approval.jira','artifact_version':'v1','artifact_sha256':'x','required_validator_ids':[],'validator_results':[],'validated_at':'2026-07-16T12:00:00Z','generated_by_driver':False}
 r=drv.handle_validation(state,{'artifact':'jira','validation_receipt':fake},state_file); assert r['reason']=='caller_supplied_validation_receipts_forbidden'
 # malformed Jira is actually validated and rejected
 art=td/'jira.md'; art.write_text('# weak jira\n- prose only\n')
 r=drv.handle_validation(state,{'artifact':'jira','artifact_path':str(art),'version':'v1'},state_file); assert r['status']=='validation_failed'
 assert 'approval.jira' in state['regeneration_required']
 # correction blocks approval and terminal
 r=drv.handle_present(scenario,state,{'artifact':'jira','version':'v1'}); assert r['status']=='not_approved'
 r=drv.determine_terminal(scenario,state); assert r['status']=='not_ready'
 # logs were captured for executed validators
 logs=list((td/'validator_logs').glob('*.json')); assert len(logs)>=2
print(json.dumps({'result':'PASS','tests':6,'version':'1.16.7-adapted-to-driver-enforced-validation'}))
