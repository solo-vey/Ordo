# Run scripts

- `./scripts/run_preflight_and_regressions.sh` — preflight and all inherited/new regression suites.
- `./scripts/driver_request.sh RUN_02 request.json [state.json]` — send one Driver request.

New Driver actions: `validation`, `present`, `invalidate`, `gate`, `finish`. Present requires a current PASS validation receipt. Before finish, record `cross_artifact` and `package` gates as PASS.


## External-model preflight simulation
The validated transfer pair is this ZIP plus `launch_prompts/START_PROMPT_STRUCTURED_INSTRUCTIONS_ANY_RUN_ALPHA_1_3_0_NEUTRAL.md`. Execute its commands literally from a clean extraction.
