#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python validation/validate_semantic_parity.py
python validation/validate_structured_instruction_representation.py
python validation/validate_structured_runtime_package.py
python validation/validate_selected_run_input_sufficiency.py .
python validation/validate_driver_analyst_enforcement.py
echo PASS
