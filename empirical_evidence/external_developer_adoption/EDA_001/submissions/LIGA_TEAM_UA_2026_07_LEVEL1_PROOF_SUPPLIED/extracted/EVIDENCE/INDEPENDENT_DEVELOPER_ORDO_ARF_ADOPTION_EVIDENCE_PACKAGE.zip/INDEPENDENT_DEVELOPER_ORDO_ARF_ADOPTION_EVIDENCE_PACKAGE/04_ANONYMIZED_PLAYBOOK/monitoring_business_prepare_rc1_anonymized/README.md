# Monitoring BusinessPrepare — Release Candidate 1

Independent Ordo playbook for preparing one monitoring event as an approved business contract and downstream handoff. The package is authored from scratch; the user-provided process description was design input only and is not included.

## Operating model

The analyst executes the playbook manually. The playbook generates documents but never writes to Jira or Confluence.

1. Generate the complete draft package.
2. The analyst downloads, reviews, and explicitly approves the draft.
3. The analyst manually creates the Confluence Business Passport and returns its URL.
4. The playbook inserts the Confluence URL into the Business Jira document.
5. The analyst manually creates the BusinessPrepare Jira entity and returns its URL.
6. The playbook writes the BusinessPrepare Jira URL into this README, increments the package revision, and validates the linked package.
7. No second approval is required after link synchronization when business content is unchanged.

## External lifecycle links

- BusinessPrepare Jira URL: `{{business_jira_url}}`

The Confluence Business Passport URL is intentionally stored in the generated Business Jira document, not duplicated here or across other business artifacts.

Only the Confluence Business Passport URL and BusinessPrepare Jira URL are mandatory lifecycle links. URL host allowlists and remote accessibility are not checked.

Release status: **release candidate**, not canonical.
