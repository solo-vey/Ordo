# Quick Start

1. Run the playbook manually for one monitoring event.
2. Complete discovery, data-mode, identity, user-plane, template, placeholder, and scenario gates.
3. Download and review the generated draft package.
4. Explicitly answer that you approve the draft, or request corrections.
5. After approval, create the Confluence Business Passport manually and return its URL.
6. Create the BusinessPrepare Jira entity from the generated document, which already contains the Confluence URL, and return the Jira URL.
7. The playbook keeps the Confluence URL in the Jira document, writes the Jira URL into README.md, regenerates the package revision, and performs final validation. No second approval is required.

The playbook does not create or update external records directly and does not enforce URL host allowlists.
