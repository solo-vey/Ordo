# Changelog

## 0.1.0-alpha.1 — 2026-07-15

- Initial independently authored alpha playbook package.


## 0.1.0-alpha.2
- Added draft review before external publication.
- Added manual Confluence then Jira publication steps.
- Added returned-URL capture and bidirectional link synchronization.
- Clarified that package revision changes do not bump playbook SemVer.
- Set manual analyst execution and non-resumable cancellation.

## 0.1.0-alpha.3 — 2026-07-15
- Made BusinessPrepare Jira URL the only mandatory Jira lifecycle link.
- Added explicit analyst draft confirmation gate.
- Removed second approval after URL synchronization.
- Removed host/domain and remote URL validation requirements.
- Limited stored external metadata to Confluence and Business Jira URLs.
- Added completion-based cleanup of temporary runtime evidence.
- Added model-proposed, Product/PO-confirmed human approver policy.

## 0.1.0-rc.1 — 2026-07-15
- Promoted the package to release candidate.
- Completed BL-MBP-002 lifecycle flow validation.
- Completed BL-MBP-003 exact external-link placement.
- Confluence URL is stored in the Business Jira document.
- BusinessPrepare Jira URL is stored in README.md.
- Removed unnecessary local over-engineering backlog items.
- Deferred BL-MBP-007 until a future Ordo/ARF release.
