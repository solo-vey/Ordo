# Business Jira Entity: {{event_alias}}

## Goal
{{business_need}}

## Data mode
{{data_mode}}

## Blockers and dependencies
{{dependencies}}

## Lifecycle checklist
{{checklist}}

## Confluence Business Passport
{{confluence_business_passport_url}}
