| Name / Назва | Group / Група |
|---|---|
| [{{event_name}}]({{confluence_business_passport_url}}) | {{group_name}} |
