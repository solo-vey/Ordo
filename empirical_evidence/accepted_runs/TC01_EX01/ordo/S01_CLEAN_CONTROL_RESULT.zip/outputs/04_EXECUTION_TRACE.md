# Execution Trace

| # | Node | Transition status |
|---:|---|---|
| 1 | N01_BUSINESS_INITIATION | accepted |
| 2 | N02_GEOGRAPHY_AND_TARGET_DATE | accepted |
| 3 | N03_INITIAL_BUDGET | accepted |
| 4 | N04_HEADCOUNT_PLANNING | accepted |
| 5 | N05_WORK_MODEL_AND_SPACE | accepted |
| 6 | N06_LOCATION_SEARCH_CRITERIA | accepted |
| 7 | N07_LEGAL_AND_REGULATORY_MODEL | accepted |
| 8 | N07B_LEGAL_ENTITY_REGISTRATION | accepted |
| 9 | N08_CANDIDATE_LOCATION_SEARCH | accepted |
| 10 | N09_PRELIMINARY_LOCATION_SCREENING | accepted |
| 11 | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION | accepted |
| 12 | N11_LEASE_NEGOTIATION | accepted |
| 13 | N11D_GENERATE_DOCUMENT_1 | accepted |
| 14 | N12_RENOVATION_AND_FIT_OUT_DESIGN | accepted |
| 15 | N13_IT_AND_PHYSICAL_SECURITY_DESIGN | accepted |
| 16 | N14_WORKPLACE_STANDARD | accepted |
| 17 | N15_CONTRACTORS_AND_SUPPLIERS | accepted |
| 18 | N16_PEOPLE_PLAN | accepted |
| 19 | N17_OPERATIONAL_OWNERS | accepted |
| 20 | N17D_GENERATE_DOCUMENT_2 | accepted |
| 21 | N18_READINESS_TEST | accepted |
| 22 | N19_PILOT_DAY | accepted |
| 23 | N20_FINAL_DECISION_AND_PACKAGE | accepted |
| 24 | N20D_GENERATE_DOCUMENT_3 | accepted |
| 25 | N20V_VALIDATE_FINAL_PACKAGE | accepted |
| 26 | T_COMPLETED | accepted |
