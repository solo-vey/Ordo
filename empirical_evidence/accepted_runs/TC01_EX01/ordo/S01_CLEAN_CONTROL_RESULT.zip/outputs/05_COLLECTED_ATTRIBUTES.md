# Collected Attributes

| ID | Attribute | Value | Source node |
|---|---|---|---|
| P01 | company_legal_name | Northstar Analytics GmbH | N01_BUSINESS_INITIATION |
| P02 | company_brand_name | Northstar | N01_BUSINESS_INITIATION |
| P03 | company_industry | B2B SaaS / аналітика ланцюгів постачання | N01_BUSINESS_INITIATION |
| P04 | company_headquarters_country | Німеччина | N01_BUSINESS_INITIATION |
| P05 | company_size_employees | 420 | N01_BUSINESS_INITIATION |
| P06 | office_business_goal | Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі | N01_BUSINESS_INITIATION |
| P07 | target_country | Польща | N02_GEOGRAPHY_AND_TARGET_DATE |
| P08 | target_city | Краків | N02_GEOGRAPHY_AND_TARGET_DATE |
| P09 | target_opening_date | 2027-03-15 | N02_GEOGRAPHY_AND_TARGET_DATE |
| P10 | initial_budget | 2 400 000 EUR | N03_INITIAL_BUDGET |
| P11 | planned_headcount_year1 | 85 | N04_HEADCOUNT_PLANNING |
| P12 | planned_headcount_year3 | 180 | N04_HEADCOUNT_PLANNING |
| P13 | work_model | hybrid | N05_WORK_MODEL_AND_SPACE |
| P14 | required_workspace_count | 110 | N05_WORK_MODEL_AND_SPACE |
| P15 | required_meeting_rooms | 8 | N05_WORK_MODEL_AND_SPACE |
| P16 | special_space_requirements | Серверна кімната, дві phone-booth зони, training room на 30 осіб | N05_WORK_MODEL_AND_SPACE |
| P17 | location_priority | Транспортна доступність і близькість до talent hub | N06_LOCATION_SEARCH_CRITERIA |
| P18 | maximum_commute_target | 45 хвилин для 80% працівників | N06_LOCATION_SEARCH_CRITERIA |
| P19 | candidate_location_count | 5 | N06_LOCATION_SEARCH_CRITERIA |
| P20 | preferred_lease_term_months | 60 | N06_LOCATION_SEARCH_CRITERIA |
| P21 | maximum_monthly_rent | 58 000 EUR без комунальних витрат | N06_LOCATION_SEARCH_CRITERIA |
| P22 | legal_entity_required | true | N07_LEGAL_AND_REGULATORY_MODEL |
| P23 | regulatory_constraints | Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці | N07_LEGAL_AND_REGULATORY_MODEL |
| P24 | tax_model | Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією | N07_LEGAL_AND_REGULATORY_MODEL |
| P25 | employment_model | Пряме локальне працевлаштування через польську юридичну особу | N07_LEGAL_AND_REGULATORY_MODEL |
| P26 | visa_support_required | true | N07_LEGAL_AND_REGULATORY_MODEL |
| P27 | data_residency_requirement | Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі | N07_LEGAL_AND_REGULATORY_MODEL |
| P28 | accessibility_standard | Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця | N07_LEGAL_AND_REGULATORY_MODEL |
| P29 | selected_location_address | Mogilska 35, 31-545 Kraków, Poland | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P30 | backup_location_address | Pawia 23, 31-154 Kraków, Poland | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P31 | usable_area_sqm | 1 850 м² | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P32 | technical_readiness_score | 82 зі 100 | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P33 | renovation_scope | Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні | N12_RENOVATION_AND_FIT_OUT_DESIGN |
| P34 | renovation_budget | 740 000 EUR | N12_RENOVATION_AND_FIT_OUT_DESIGN |
| P35 | fitout_deadline | 2027-02-12 | N12_RENOVATION_AND_FIT_OUT_DESIGN |
| P36 | network_capacity_requirement | Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P37 | server_room_required | true | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P38 | physical_security_level | Підвищений | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P39 | access_control_model | Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P40 | furniture_standard | Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце | N14_WORKPLACE_STANDARD |
| P41 | primary_general_contractor | BuildCore Polska Sp. z o.o. | N15_CONTRACTORS_AND_SUPPLIERS |
| P42 | critical_supplier_count | 6 | N15_CONTRACTORS_AND_SUPPLIERS |
| P43 | local_hiring_target | 65 нових працівників у перший рік | N16_PEOPLE_PLAN |
| P44 | relocation_target | 20 працівників із Німеччини, Чехії та України | N16_PEOPLE_PLAN |
| P45 | local_hr_owner | Anna Kowalska, Head of People Poland | N16_PEOPLE_PLAN |
| P46 | local_it_owner | Marek Zieliński, Regional IT Manager | N17_OPERATIONAL_OWNERS |
| P47 | local_facilities_owner | Katarzyna Nowak, Workplace Operations Lead | N17_OPERATIONAL_OWNERS |
| P48 | readiness_test_date | 2027-02-22 | N18_READINESS_TEST |
| P49 | pilot_day_participants | 24 | N19_PILOT_DAY |
| P50 | final_opening_decision | conditional open | N20_FINAL_DECISION_AND_PACKAGE |
