# Office Opening Business & Location Brief

**Company:** Northstar Analytics GmbH  
**Brand:** Northstar  
**Industry:** B2B SaaS / аналітика ланцюгів постачання  
**Headquarters:** Німеччина  
**Target office:** Краків, Польща  
**Target opening date:** 2027-03-15

## 1. Business context and objective

Northstar Analytics GmbH is a company operating under the **Northstar** brand in the **B2B SaaS / аналітика ланцюгів постачання** industry. The company is headquartered in **Німеччина** and currently employs approximately **420 people**.

The purpose of the new office is to **Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі**. The programme has an initial budget envelope of **2 400 000 EUR**.

The company plans to employ **85 people during the first year** and scale to approximately **180 employees by year three**.

## 2. Workplace requirements

The office will operate under a **hybrid work model**. The planned workplace capacity is **110 workstations** with **8 meeting rooms**.

Additional space requirements include:

Серверна кімната, дві phone-booth зони, training room на 30 осіб

The location strategy prioritises **Транспортна доступність і близькість до talent hub**. The target maximum commute is **45 хвилин для 80% працівників**.

## 3. Location search criteria

The search programme evaluates **5 candidate locations** in Краків.

The preferred lease term is **60 months**, and the maximum acceptable monthly rent is **58 000 EUR без комунальних витрат**.

The location assessment must consider business suitability, transport accessibility, talent-market proximity, usable area, technical readiness, regulatory constraints and accessibility requirements.

## 4. Legal and operating model

A local legal entity is required.


The local operating and tax structure is **Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією**.


Employees will be engaged under the following model:

**Пряме локальне працевлаштування через польську юридичну особу**

The office programme must comply with:

**Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці**

Visa support is required for the relocation population.


A dedicated immigration and relocation workstream must cover document collection, visa case tracking and coordination of employee arrival dates.


## 5. Data residency and compliance

The applicable data-residency requirement is:

**Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі**


This requirement must be treated as a dedicated compliance constraint for the office technology design.


## 6. Accessibility requirements

The selected office must meet the following accessibility standard:

**Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця**

Accessibility is a mandatory location criterion rather than an optional fit-out improvement.

## 7. Selected location

The selected primary location is:

**Mogilska 35, 31-545 Kraków, Poland**

The retained backup location is:

**Pawia 23, 31-154 Kraków, Poland**

The selected office provides approximately **1 850 м²** of usable area and received a **technical readiness score of 82 зі 100**.

The primary location was selected because it provides the best combined fit against the defined business, transport, workforce, capacity and technical criteria.

## 8. Business and location conclusion

The proposed office is aligned with the business objective: **Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі**.

The selected location must support the planned headcount, work model and specialist-space requirements. The legal, employment, visa, data-residency and accessibility requirements recorded in this document are binding delivery constraints.

The programme may proceed with **Mogilska 35, 31-545 Kraków, Poland**, subject to successful execution of the build, technology, security and operational-readiness plan.


