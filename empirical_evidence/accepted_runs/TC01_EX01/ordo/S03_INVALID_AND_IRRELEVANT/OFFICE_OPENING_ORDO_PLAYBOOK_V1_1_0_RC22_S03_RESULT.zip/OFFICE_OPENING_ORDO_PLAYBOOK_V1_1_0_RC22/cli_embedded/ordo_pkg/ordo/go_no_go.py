from __future__ import annotations

from pathlib import Path
import json
from typing import Any

from .artifact_validator import validate_artifacts
from .compiler import compile_source
from .consistency import consistency as build_consistency_report
from .coverage import build_coverage
from .contract_coverage import validate_contract_artifact_references
from .helpers import validate_state
from .intake import guided_intake
from .linter import lint_source
from .loader import load_package
from .output_generator import generate_output
from .registry_checks import find_repo_root, validate_ir_opcodes, validate_capability_registry
from .reporter import write_json
from .session_chain import verify_session


_NO_GO_BY_STEP = {
    "lint": "no_go_requires_source_fix",
    "compile": "no_go_requires_runner_contract",
    "coverage": "no_go_requires_template_fix",
    "validate-state": "no_go_requires_confirmation",
    "intake": "no_go_requires_confirmation",
    "generate-output": "no_go_requires_artifact_fix",
    "validate-artifacts": "no_go_requires_artifact_fix",
    "consistency": "no_go_requires_artifact_fix",
    "verify-session": "no_go_requires_session_fix",
}


def _step(name: str, status: str, *, report_path: str | None = None, summary: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "step": name,
        "status": status,
        "report": report_path,
        "summary": summary or {},
    }


def _issue(step: str, message: str, *, report_path: str | None = None, code: str = "ORDO-GNG-001") -> dict[str, Any]:
    return {
        "severity": "error",
        "code": code,
        "step": step,
        "message": message,
        "report": report_path,
    }


def _rel(root: Path, path: Path | None) -> str | None:
    if path is None:
        return None
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path)


def _compile_step(root: Path, manifest: dict[str, Any], source: dict[str, Any], tests: dict[str, Any], lint_report: dict[str, Any], *, force: bool = False) -> tuple[dict[str, Any], dict[str, Any] | None]:
    out = root / manifest.get("compiled", "compiled/program.ir.json")
    contract_artifact_report = validate_contract_artifact_references(source)
    opcode_registry_report: dict[str, Any] = {"status": "skipped", "reason": "compile skipped"}
    capability_registry_report: dict[str, Any] = {"status": "skipped", "reason": "compile skipped"}
    ir: dict[str, Any] | None = None

    if lint_report.get("status") != "passed" and not force:
        compile_status = "failed_lint"
    else:
        ir = compile_source(source)
        write_json(out, ir)
        repo_root = find_repo_root(root)
        opcode_registry_report = validate_ir_opcodes(ir, repo_root)
        capability_registry_report = validate_capability_registry(repo_root)
        compile_status = "passed" if lint_report.get("status") == "passed" else "passed_with_lint_errors_forced"

    if contract_artifact_report.get("status") == "failed":
        compile_status = "failed_contract_artifact_references"
    if opcode_registry_report.get("status") == "failed":
        compile_status = "failed_opcode_registry_mismatch"
    if capability_registry_report.get("status") == "failed":
        compile_status = "failed_capability_registry_mismatch"

    report = {
        "status": compile_status,
        "source": manifest.get("source", "source/program.ordo.yaml"),
        "output": _rel(root, out),
        "ops_count": len((ir or {}).get("ops", [])),
        "lint_status": lint_report.get("status"),
        "contract_artifact_reference_check": contract_artifact_report,
        "opcode_registry_check": opcode_registry_report,
        "capability_registry_check": capability_registry_report,
    }
    write_json(root / "reports" / "compile_report.json", report)
    return report, ir


def _blocking_status(steps: list[dict[str, Any]]) -> str:
    for item in steps:
        status = item.get("status")
        name = item.get("step")
        if status in {"passed", "generated", "go"}:
            continue
        if status == "passed_with_warnings":
            continue
        return _NO_GO_BY_STEP.get(str(name), "no_go")
    return "go"


def go_no_go(
    package_path: str | Path,
    *,
    answers_path: str | Path | None = None,
    state_path: str | Path | None = None,
    artifacts: str | Path | None = None,
    run_intake: bool = False,
    generate_outputs: bool = False,
    allow_blocked_output: bool = False,
    force_compile: bool = False,
    out: str | Path | None = None,
) -> dict[str, Any]:
    """Run the final non-mutating runtime validation pipeline.

    RC12 invariant: this command never compiles, rewrites compiled IR, runs intake,
    or generates outputs. Authoring checks belong before the first intake.
    """
    from .output_validator import validate_output
    from .targets import verify_targets

    root, manifest, source, tests = load_package(package_path)
    reports_dir = root / manifest.get("reports", "reports")
    reports_dir.mkdir(parents=True, exist_ok=True)
    canonical_state = Path(state_path).resolve() if state_path else root / "runtime" / "run_state.json"
    artifact_dir = Path(artifacts).resolve() if artifacts else root / "outputs"

    steps: list[dict[str, Any]] = []
    blocking_issues: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    # RC12 terminal-proof contract: GO is impossible without canonical, non-fixture,
    # version-matched state and a real N20V -> T_COMPLETED session event.
    canonical_doc: dict[str, Any] = {}
    canonical_state_doc: dict[str, Any] = {}
    try:
        canonical_doc = json.loads(canonical_state.read_text(encoding="utf-8"))
        canonical_state_doc = canonical_doc.get("state") if isinstance(canonical_doc.get("state"), dict) else canonical_doc
    except Exception as exc:
        blocking_issues.append(_issue("terminal-proof", f"canonical runtime state cannot be read: {exc}", code="ORDO-GNG-TERMINAL-001"))
    if canonical_state_doc:
        package_version = str(canonical_state_doc.get("package_version") or canonical_doc.get("package_version") or "")
        if package_version != str(manifest.get("version") or ""):
            blocking_issues.append(_issue("terminal-proof", "canonical state package version does not match package manifest", code="ORDO-GNG-VERSION-001"))
        serialized = json.dumps(canonical_state_doc, ensure_ascii=False).lower()
        if "validation fixture" in serialized or '"fixture"' in serialized or "fixture completed" in serialized:
            blocking_issues.append(_issue("terminal-proof", "fixture/test data detected in canonical runtime state", code="ORDO-GNG-FIXTURE-001"))
        completed = canonical_state_doc.get("completed_steps") or []
        transition = canonical_state_doc.get("terminal_transition") or canonical_doc.get("terminal_proof") or {}
        terminal_ok = (
            "N20V_VALIDATE_FINAL_PACKAGE" in completed
            and canonical_state_doc.get("last_closed_node") == "N20V_VALIDATE_FINAL_PACKAGE"
            and canonical_state_doc.get("current_node") == "T_COMPLETED"
            and canonical_state_doc.get("runtime_status") == "completed"
            and canonical_state_doc.get("package_validation_completed") is True
            and canonical_state_doc.get("final_package_ready") is True
            and isinstance(transition, dict)
            and transition.get("from_node") == "N20V_VALIDATE_FINAL_PACKAGE"
            and transition.get("to_node") == "T_COMPLETED"
        )
        if not terminal_ok:
            blocking_issues.append(_issue("terminal-proof", "canonical runtime state lacks complete N20V -> T_COMPLETED proof", code="ORDO-GNG-TERMINAL-002"))

    if run_intake or generate_outputs or force_compile:
        blocking_issues.append(_issue("go-no-go", "mutating options are forbidden in runtime finalization", code="ORDO-GNG-IMMUTABLE-001"))

    target_report = verify_targets(root, out=reports_dir / "target_verification_report.json")
    target_path = reports_dir / "target_verification_report.json"
    steps.append(_step("verify-targets", target_report.get("status", "failed"), report_path=_rel(root, target_path), summary=target_report.get("summary", {})))
    if target_report.get("status") != "passed":
        blocking_issues.append(_issue("verify-targets", "target-set verification failed", report_path=_rel(root, target_path)))

    session_report = verify_session(root, out=reports_dir / "session_verification_report.json")
    session_path = reports_dir / "session_verification_report.json"
    steps.append(_step("verify-session", session_report.get("status", "failed"), report_path=_rel(root, session_path), summary=session_report.get("summary", {})))
    if session_report.get("status") != "passed":
        blocking_issues.append(_issue("verify-session", "session-chain verification failed", report_path=_rel(root, session_path)))
    if int(session_report.get("session_trace_steps_checked") or 0) < 25:
        blocking_issues.append(_issue("terminal-proof", "session trace contains fewer than 25 accepted runtime steps", code="ORDO-GNG-TRACE-001"))
    if int(session_report.get("snapshots_checked") or 0) < 26:
        blocking_issues.append(_issue("terminal-proof", "session chain contains fewer than initial + 25 accepted snapshots", code="ORDO-GNG-SNAPSHOT-001"))
    try:
        from .session_trace import parse_session_trace
        trace_doc = parse_session_trace(root)
        trace_steps = trace_doc.get("steps") or []
        last_step = trace_steps[-1] if trace_steps else {}
        # parse_session_trace stores trace attributes under `fields`; older
        # validators incorrectly read them as top-level keys.
        last_fields = last_step.get("fields") if isinstance(last_step.get("fields"), dict) else last_step
        if last_fields.get("node") != "N20V_VALIDATE_FINAL_PACKAGE" or last_fields.get("next") != "T_COMPLETED" or last_fields.get("status") != "passed":
            blocking_issues.append(_issue("terminal-proof", "last session trace step is not accepted N20V -> T_COMPLETED", code="ORDO-GNG-TRACE-002"))
    except Exception as exc:
        blocking_issues.append(_issue("terminal-proof", f"terminal trace proof cannot be parsed: {exc}", code="ORDO-GNG-TRACE-003"))

    state_report = validate_state(root, state_path=canonical_state, answers_path=None, out=reports_dir / "state_validation_report.json")
    state_path_report = reports_dir / "state_validation_report.json"
    steps.append(_step("validate-state", state_report.get("status", "blocked"), report_path=_rel(root, state_path_report), summary=state_report.get("summary", {})))
    if state_report.get("status") != "passed":
        blocking_issues.append(_issue("validate-state", "canonical runtime state validation failed", report_path=_rel(root, state_path_report)))

    output_report = validate_output(root)
    output_path = reports_dir / "output_validation_report.json"
    steps.append(_step("validate-output", output_report.get("status", "failed"), report_path=_rel(root, output_path), summary=output_report.get("summary", {})))
    if output_report.get("status") != "passed":
        blocking_issues.append(_issue("validate-output", "output validation failed", report_path=_rel(root, output_path)))

    artifact_report = validate_artifacts(root, artifacts=artifact_dir, state_path=canonical_state, out=reports_dir / "artifact_validation_report.json")
    artifact_path = reports_dir / "artifact_validation_report.json"
    steps.append(_step("validate-artifacts", artifact_report.get("status", "failed"), report_path=_rel(root, artifact_path), summary=artifact_report.get("summary", {})))
    if artifact_report.get("status") != "passed":
        blocking_issues.append(_issue("validate-artifacts", "rendered artifact validation failed", report_path=_rel(root, artifact_path)))
        blocking_issues.extend(artifact_report.get("issues", []) or [])
    warnings.extend(artifact_report.get("warnings", []) or [])

    consistency_report = build_consistency_report(root, artifacts=artifact_dir, state_path=canonical_state, out=reports_dir / "CONSISTENCY_CHECK_REPORT.json")
    consistency_path = reports_dir / "CONSISTENCY_CHECK_REPORT.json"
    steps.append(_step("consistency", consistency_report.get("status", "failed"), report_path=_rel(root, consistency_path), summary=consistency_report.get("summary", {})))
    if consistency_report.get("status") not in {"passed", "passed_with_warnings"}:
        blocking_issues.append(_issue("consistency", "cross-artifact consistency failed", report_path=_rel(root, consistency_path)))
        blocking_issues.extend(consistency_report.get("blocking_issues", []) or [])
    warnings.extend(consistency_report.get("warnings", []) or [])

    status = "go" if not blocking_issues and all(s.get("status") in {"passed", "passed_with_warnings"} for s in steps) else "no_go"
    report = {
        "status": status,
        "kind": "go_no_go",
        "mode": "non_mutating_runtime_finalization",
        "compiled_ir_mutated": False,
        "canonical_state": _rel(root, canonical_state),
        "package": {"name": manifest.get("name"), "version": manifest.get("version")},
        "pipeline": [step["step"] for step in steps],
        "steps": steps,
        "blocking_issues": blocking_issues,
        "warnings": warnings,
        "summary": {"steps_total": len(steps), "blocking_issues": len(blocking_issues), "warnings": len(warnings), "artifacts_dir": str(artifact_dir)},
    }
    output = Path(out).resolve() if out else reports_dir / "GO_NO_GO_REPORT.json"
    write_json(output, report)
    return report
