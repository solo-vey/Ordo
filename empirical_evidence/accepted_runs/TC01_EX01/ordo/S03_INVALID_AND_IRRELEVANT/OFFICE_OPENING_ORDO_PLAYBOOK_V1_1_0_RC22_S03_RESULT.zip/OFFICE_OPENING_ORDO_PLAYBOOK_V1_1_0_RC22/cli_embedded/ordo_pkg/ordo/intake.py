from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import copy
import json
import re
import sys

from .loader import load_package, load_yaml
from .runtime import load_runtime_source
from .checkpoints import build_checkpoint_report, enrich_state_with_checkpoint
from .runtime_evidence import write_node_evidence, attach_report_digest, canonical_sha256
from .session_chain import has_chain_snapshots, write_session_snapshot
from .session_trace import append_session_trace_step
from .targets import verify_targets
from .session_chain import verify_session
from .reporter import write_json
from .runner import (
    initial_state,
    state_diff,
    set_path,
    evaluate_gates,
    evaluate_assertions,
    allowed_outputs,
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()




def _artifact_file_valid(path: Path) -> bool:
    if not path.exists() or not path.is_file() or path.stat().st_size < 40:
        return False
    text = path.read_text(encoding="utf-8", errors="replace")
    forbidden = ("{{", "}}", "Validation fixture", "Runtime runs must replace")
    return not any(token in text for token in forbidden)

def _report_passed(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return False
    return str(doc.get("status", "")).lower() in {"passed", "go", "ready"}

def _validate_system_action(root: Path, node_id: str) -> tuple[bool, list[str]]:
    requirements = {
        "N11D_GENERATE_DOCUMENT_1": ["outputs/01_OFFICE_OPENING_BUSINESS_AND_LOCATION_BRIEF.md"],
        "N17D_GENERATE_DOCUMENT_2": ["outputs/02_OFFICE_BUILD_TECHNOLOGY_AND_OPERATIONS_PLAN.md"],
        "N20D_GENERATE_DOCUMENT_3": [
            "outputs/03_OFFICE_READINESS_AND_OPENING_DECISION_REPORT.md",
            "outputs/04_EXECUTION_TRACE.md",
            "outputs/05_COLLECTED_ATTRIBUTES.md",
        ],
    }
    if node_id in requirements:
        missing = [rel for rel in requirements[node_id] if not _artifact_file_valid(root / rel)]
        return (not missing, missing)
    if node_id == "N20V_VALIDATE_FINAL_PACKAGE":
        files = [
            "outputs/01_OFFICE_OPENING_BUSINESS_AND_LOCATION_BRIEF.md",
            "outputs/02_OFFICE_BUILD_TECHNOLOGY_AND_OPERATIONS_PLAN.md",
            "outputs/03_OFFICE_READINESS_AND_OPENING_DECISION_REPORT.md",
            "outputs/04_EXECUTION_TRACE.md",
            "outputs/05_COLLECTED_ATTRIBUTES.md",
        ]
        missing = [rel for rel in files if not _artifact_file_valid(root / rel)]
        reports = ["reports/output_validation_report.json", "reports/artifact_validation_report.json", "reports/consistency_check_report.json"]
        failed_reports = [rel for rel in reports if not _report_passed(root / rel)]
        gaps = missing + failed_reports
        return (not gaps, gaps)
    return True, []

def _sync_derived_control_state(source: dict[str, Any], state: dict[str, Any], next_target: str | None) -> None:
    answered = []
    for item in (state.get("answered_questions") or []):
        if isinstance(item, str): answered.append(item)
        elif isinstance(item, dict):
            node_key = item.get("node") or item.get("node_id") or item.get("id")
            if node_key: answered.append(str(node_key))
    state["completed_steps"] = answered
    state["current_node"] = next_target or ""
    by_id = {str(n.get("id")): n for n in source.get("nodes", []) or []}
    next_node = by_id.get(str(next_target or ""), {})
    step_no = ((next_node.get("step_contract") or {}).get("step_number"))
    if step_no is None and next_target:
        match = re.match(r"N(\d{2})", str(next_target))
        if match: step_no = int(match.group(1))
    if step_no is None and answered:
        step_no = ((by_id.get(answered[-1], {}).get("step_contract") or {}).get("step_number"))
        if step_no is None:
            match = re.match(r"N(\d{2})", str(answered[-1]))
            if match: step_no = int(match.group(1))
    state["current_step"] = step_no or 20


def _parse_answer(raw: Any, answer_type: str | None) -> Any:
    if answer_type == "list" and isinstance(raw, str):
        return [part.strip() for part in raw.split(",") if part.strip()]
    return raw


def _answer_from_map(answers: dict[str, Any], node_id: str, attempt: int) -> tuple[bool, Any]:
    if node_id not in answers:
        return False, None
    value = answers[node_id]
    if isinstance(value, list) and value and not all(isinstance(x, str) for x in value):
        # Treat list of non-string objects as attempts only if explicitly nested.
        pass
    if isinstance(value, dict) and "attempts" in value:
        attempts = value.get("attempts") or []
        if attempt < len(attempts):
            return True, attempts[attempt]
        return False, None
    return True, value


def _prompt_for_answer(node: dict[str, Any], attempt: int) -> Any:
    print()
    print(f"[{node.get('id')}] {node.get('question')}")
    allowed = node.get("allowed_answers")
    if allowed:
        print("Allowed:", ", ".join(str(x) for x in allowed))
    if attempt > 0:
        clarify = node.get("on_unmatched_input") or {}
        strategy = clarify.get("strategy", "rephrase_and_narrow")
        print(f"Clarify ({strategy}): please answer in the expected format.")
    return input("> ")


def _resolve_answer_ref(value: Any, parsed_answer: Any) -> Any:
    if value == "$answer":
        return parsed_answer
    if isinstance(value, str) and value.startswith("$answer."):
        key = value[len("$answer."):]
        if isinstance(parsed_answer, dict):
            return parsed_answer.get(key)
    return value


def _branch_matches(rule: dict[str, Any], parsed_answer: Any, state: dict[str, Any]) -> bool:
    cond = str(rule.get("when") or "").strip()
    m = re.fullmatch(r"answer\.([A-Za-z0-9_]+)\s+is\s+(true|false)", cond, re.I)
    if m and isinstance(parsed_answer, dict):
        return bool(parsed_answer.get(m.group(1))) is (m.group(2).lower() == "true")
    m = re.fullmatch(r"state\.([A-Za-z0-9_.]+)\s+is\s+(true|false)", cond, re.I)
    if m:
        cur: Any = state
        for part in m.group(1).split('.'):
            cur = cur.get(part) if isinstance(cur, dict) else None
        return bool(cur) is (m.group(2).lower() == "true")
    m = re.fullmatch(r"answer\.([A-Za-z0-9_]+)\s+is\s+(.+)", cond, re.I)
    if m and isinstance(parsed_answer, dict):
        return str(parsed_answer.get(m.group(1), "")).strip().lower() == m.group(2).strip().lower()
    return False


def _apply_node_answer(node: dict[str, Any], answer: Any, state: dict[str, Any]) -> tuple[str | None, dict[str, Any]]:
    before = copy.deepcopy(state)
    on_answer = node.get("on_answer") or {}
    next_target: str | None = None
    update: dict[str, Any] = {}

    if isinstance(on_answer, dict) and "update_state" in on_answer:
        update = on_answer.get("update_state") or {}
        next_target = on_answer.get("next")
    elif isinstance(on_answer, dict):
        matched_key = None
        for key in on_answer.keys():
            if str(key).lower() == str(answer).lower():
                matched_key = key
                break
        if matched_key is not None:
            branch = on_answer.get(matched_key) or {}
            update = branch.get("update_state") or {}
            next_target = branch.get("next")

    parsed_answer = _parse_answer(answer, node.get("answer_type"))
    for key, value in update.items():
        if value == "$append_answer":
            existing = state.get(key)
            if not isinstance(existing, list): existing = []
            existing.append(parsed_answer)
            state[key] = existing
        else:
            set_path(state, key, _resolve_answer_ref(value, parsed_answer))

    # Close previously selected branches when execution reaches their canonical rejoin node.
    for branch in state.get("branch_history", []) or []:
        if isinstance(branch, dict) and branch.get("rejoin_node") == node.get("id") and not branch.get("rejoin_confirmed"):
            branch["rejoin_confirmed"] = True
            branch["rejoined_at_node"] = node.get("id")
            branch["rejoin_evidence"] = "accepted_node_execution"

    branch_recorded = False
    for rule in node.get("branch_rules") or []:
        if isinstance(rule, dict) and _branch_matches(rule, parsed_answer, state):
            next_target = rule.get("next") or next_target
            state.setdefault("branch_history", []).append({
                "decision_node": node.get("id"),
                "condition": rule.get("when"),
                "selected_branch": next_target,
                "rejoin_node": rule.get("return_to") or "",
                "recorded_from": "accepted_transition"
            })
            branch_recorded = True
            break
    # Preserve a structured branch decision even when a legacy condition parser
    # cannot match but the selected target is unambiguous.
    if node.get("branch_rules") and not branch_recorded and next_target:
        candidates = [r for r in node.get("branch_rules") or [] if isinstance(r, dict) and r.get("next") == next_target]
        if len(candidates) == 1:
            rule = candidates[0]
            state.setdefault("branch_history", []).append({
                "decision_node": node.get("id"),
                "condition": rule.get("when"),
                "selected_branch": next_target,
                "rejoin_node": rule.get("return_to") or "",
                "recorded_from": "accepted_transition",
                "inferred_from_selected_target": True
            })
    return next_target, state_diff(before, state)


def _is_answer_matched(node: dict[str, Any], answer: Any) -> bool:
    answer_type = node.get("answer_type")
    parsed = _parse_answer(answer, answer_type)
    expected = node.get("expected_fields") or []

    # Enforce the declared input shape before evaluating field-level content.
    # Previously any non-empty prose was accepted for structured_object nodes
    # without allowed_answers, which let irrelevant text mutate canonical state.
    if answer_type in {"structured_object", "object"} and not isinstance(parsed, dict):
        return False
    if answer_type == "list" and not isinstance(parsed, list):
        return False
    if answer_type == "confirmation" and not isinstance(parsed, (dict, bool)):
        return False

    if isinstance(parsed, dict):
        if expected:
            return all(k in parsed and parsed.get(k) not in (None, "") for k in expected)
        if answer_type == "confirmation":
            return any(v is True for v in parsed.values())
    allowed = node.get("allowed_answers")
    if not allowed:
        return parsed not in (None, "", [])
    if isinstance(parsed, bool):
        return parsed in allowed or str(parsed).lower() in {str(x).lower() for x in allowed}
    return str(answer).lower() in {str(x).lower() for x in allowed}


def _load_runtime_package(package_path: str | Path) -> tuple[Path, dict[str, Any], dict[str, Any]]:
    # Runtime Mode must use compiled IR as source of truth. If compiled IR is not
    # available yet in a dev package, fall back to load_package so legacy authoring
    # tests can still expose the underlying runtime-status failure through helpers.
    try:
        root, manifest, source, _ir = load_runtime_source(package_path)
        return root, manifest, source
    except Exception:
        root, manifest, source, _tests = load_package(package_path)
        source = dict(source)
        source.setdefault("runtime_source", "source_yaml")
        return root, manifest, source


def _load_state_for_submit(root: Path, source: dict[str, Any], state_path: str | Path | None) -> tuple[dict[str, Any], str | None, dict[str, Any]]:
    state = initial_state(source)
    env_report = root / "reports" / "environment_capability_report.json"
    try:
        env_data = json.loads(env_report.read_text(encoding="utf-8")) if env_report.exists() else {}
    except Exception:
        env_data = {}
    state["execution_environment_ready"] = env_data.get("status") == "passed"
    if state_path:
        loaded = load_yaml(Path(state_path))
        state.update(_state_from_loaded_mapping(loaded))
        return state, str(state_path), {}
    live = _load_live_session(root)
    live_state = _state_from_loaded_mapping(live)
    if live_state:
        state.update(live_state)
        return state, _rel(root, _live_session_path(root)), live
    return state, None, {}


def _rel(root: Path, path: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path)


def _state_from_loaded_mapping(loaded: Any) -> dict[str, Any]:
    if not isinstance(loaded, dict):
        return {}
    embedded = loaded.get("state")
    if isinstance(embedded, dict):
        return embedded
    return loaded


def _live_session_path(root: Path) -> Path:
    return root / "runtime" / "live_session_state.json"


def _load_live_session(root: Path) -> dict[str, Any]:
    path = _live_session_path(root)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _write_live_session_state(
    root: Path,
    *,
    run_id: str,
    state: dict[str, Any],
    current_node: str,
    last_closed_node: str,
    last_snapshot: str,
    last_snapshot_hash: str,
    last_evidence_report: str,
    last_evidence_digest: dict[str, Any] | None,
    last_trace_path: str = "",
    last_trace_digest: str = "",
    last_trace_step: int | None = None,
) -> str:
    doc = {
        "status": "completed" if current_node == "T_COMPLETED" else ("active" if current_node else "complete_or_gate_ready"),
        "mode": "m59_4_live_runtime_session_state",
        "run_id": run_id,
        "current_node": current_node or "",
        "last_closed_node": last_closed_node,
        "state": state,
        "last_snapshot": last_snapshot,
        "last_snapshot_hash": last_snapshot_hash,
        "last_evidence_report": last_evidence_report,
        "last_evidence_digest": last_evidence_digest or {},
        "last_trace_path": last_trace_path,
        "last_trace_digest": last_trace_digest,
        "last_trace_step": last_trace_step,
        "terminal_proof": state.get("terminal_transition", {}),
        "package_version": state.get("package_version", ""),
        "updated_at": utc_now(),
        "resume_policy": "If --state is omitted, runtime helpers may resume from runtime/live_session_state.json.",
    }
    target = _live_session_path(root)
    write_json(target, doc)
    # RC12 canonical state mirror used by all final validators.
    write_json(root / "runtime" / "run_state.json", doc)
    return _rel(root, target)


def submit_intake_node(
    package_path: str | Path,
    *,
    node_id: str,
    answer: Any,
    state_path: str | Path | None = None,
    out: str | Path | None = None,
) -> dict[str, Any]:
    root, manifest, source = _load_runtime_package(package_path)
    runtime_dir = root / "runtime"
    snapshots_dir = runtime_dir / "state_snapshots"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    snapshots_dir.mkdir(parents=True, exist_ok=True)

    # Mandatory preflight before the first intake mutation.
    if not _live_session_path(root).exists():
        target_preflight = verify_targets(root, out=root / "reports" / "preflight_target_verification_report.json")
        if target_preflight.get("status") != "passed":
            report = {"status": "blocked", "mode": "runtime_incremental_intake_submit",
                      "node_id": node_id, "issues": [{"severity":"error","code":"ORDO-INTAKE-PREFLIGHT-001",
                      "message":"target verification failed before first intake","location":"compiled/targets.manifest.json"}],
                      "preflight_target_report":"reports/preflight_target_verification_report.json"}
            target = Path(out).resolve() if out else root / "reports" / "intake_submit_report.json"
            write_json(target, attach_report_digest(report))
            return report
        session_preflight = verify_session(root, out=root / "reports" / "preflight_session_verification_report.json")
        if session_preflight.get("status") != "passed":
            report = {"status": "blocked", "mode": "runtime_incremental_intake_submit",
                      "node_id": node_id, "issues": [{"severity":"error","code":"ORDO-INTAKE-PREFLIGHT-002",
                      "message":"session verification failed before first intake","location":"runtime/session.ordo.trace"}],
                      "preflight_session_report":"reports/preflight_session_verification_report.json"}
            target = Path(out).resolve() if out else root / "reports" / "intake_submit_report.json"
            write_json(target, attach_report_digest(report))
            return report

    state, input_state_file, live_session = _load_state_for_submit(root, source, state_path)
    # RC15: canonical runtime state always carries the package manifest version.
    state["package_version"] = str(manifest.get("version") or source.get("package_version") or "")
    nodes = {n.get("id"): n for n in source.get("nodes", []) or []}
    node = nodes.get(node_id)
    run_id = str(live_session.get("run_id") or f"LIVE-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}")

    if not has_chain_snapshots(root):
        write_session_snapshot(root, state, node_id="000_initial", action="initial_state", status="passed")

    checkpoint_before = build_checkpoint_report(source, state)
    state_before_submit = copy.deepcopy(state)
    # Branch-aware incremental runtime sessions resume from
    # runtime/live_session_state.json. In that specific persisted runtime
    # context, `current_node` is the authoritative next submit target.
    # For arbitrary user-supplied state files we keep the older checkpoint
    # discipline: earliest incomplete mandatory node wins.
    live_current = ((live_session.get("current_node") if isinstance(live_session, dict) else None) or state.get("current_node"))
    expected_node = str(live_current) if live_current else (checkpoint_before.get("earliest_incomplete_node") or (node_id if node else ""))
    issues: list[dict[str, Any]] = []
    status = "passed"
    next_target: str | None = None
    diff: dict[str, Any] = {}
    matched = False

    if not node:
        status = "blocked"
        issues.append({"severity": "error", "code": "ORDO-INTAKE-001", "message": f"node not found: {node_id}", "location": node_id})
    elif expected_node and node_id != expected_node:
        status = "blocked"
        issues.append({"severity": "error", "code": "ORDO-INTAKE-002", "message": "submit attempted for a node other than earliest incomplete node", "location": node_id, "expected_node": expected_node})
    else:
        matched = _is_answer_matched(node, answer)
        system_ok, system_gaps = _validate_system_action(root, node_id)
        if matched and not system_ok:
            matched = False
            issues.append({"severity":"error","code":"ORDO-INTAKE-ARTIFACT-001","message":"system action evidence is incomplete","location":node_id,"gaps":system_gaps})
        if not matched:
            status = "blocked"
            issues.append({"severity": "error", "code": "ORDO-INTAKE-003", "message": "answer did not match node contract", "location": node_id, "allowed_answers": node.get("allowed_answers") or []})
        else:
            next_target, diff = _apply_node_answer(node, answer, state)
            answered = state.setdefault("answered_questions", [])
            if isinstance(answered, list):
                answered.append({"node": node_id, "answer": _parse_answer(answer, node.get("answer_type")), "closed_at": utc_now()})
            # Runtime, not the submitted answer, derives artifact/package status.
            if node_id == "N11D_GENERATE_DOCUMENT_1": state.setdefault("document_status", {})["D1"] = "valid"
            if node_id == "N17D_GENERATE_DOCUMENT_2": state.setdefault("document_status", {})["D2"] = "valid"
            if node_id == "N20D_GENERATE_DOCUMENT_3": state.setdefault("document_status", {})["D3"] = "valid"
            if node_id == "N20V_VALIDATE_FINAL_PACKAGE":
                state["package_validation_completed"] = True
                state["final_package_ready"] = True
            state["last_closed_node"] = node_id
            _sync_derived_control_state(source, state, next_target)

    checkpoint_after = build_checkpoint_report(source, state)
    # A successful answer may not advance while its own node contract remains open.
    if status == "passed" and node_id in (checkpoint_after.get("checkpoint_table") or {}):
        own_status = checkpoint_after["checkpoint_table"][node_id].get("status")
        if own_status not in {"closed", "not_applicable"}:
            status = "blocked"
            issues.append({"severity":"error","code":"ORDO-INTAKE-004","message":"node contract remained incomplete after answer; forward transition denied","location":node_id,"node_status":own_status})
            state = state_before_submit
            next_target = None
            diff = {}
            checkpoint_after = build_checkpoint_report(source, state)
    # Terminal completion requires global closure and a validated final package.
    if status == "passed" and next_target == "T_COMPLETED":
        if checkpoint_after.get("earliest_incomplete_node") or not state.get("final_package_ready"):
            status = "blocked"
            issues.append({"severity":"error","code":"ORDO-INTAKE-TERMINAL-001","message":"terminal transition denied until global state and final package are valid","location":"T_COMPLETED","earliest_incomplete_node":checkpoint_after.get("earliest_incomplete_node", "")})
            state = state_before_submit
            next_target = None
            diff = {}
            checkpoint_after = build_checkpoint_report(source, state)
    state = enrich_state_with_checkpoint(state, checkpoint_after)
    if status == "passed" and next_target == "T_COMPLETED":
        state["runtime_status"] = "completed"
        state["terminal_node"] = "T_COMPLETED"
        state["terminal_transition"] = {
            "from_node": node_id,
            "to_node": "T_COMPLETED",
            "package_validation_completed": bool(state.get("package_validation_completed")),
            "final_package_ready": bool(state.get("final_package_ready")),
            "recorded_at": utc_now(),
        }

    # Rejected submissions are diagnostic only: they must not mutate snapshots,
    # evidence chain, session trace, or live state.
    if status != "passed":
        report = {
            "status": status,
            "mode": "runtime_incremental_intake_submit",
            "runtime_source": source.get("runtime_source", "compiled_ir"),
            "run_id": run_id,
            "input": {"state_file": input_state_file or "", "submitted_node": node_id},
            "node_id": node_id,
            "answer": _parse_answer(answer, node.get("answer_type") if node else None),
            "matched": matched,
            "next_node": "",
            "state": state,
            "checkpoint": checkpoint_after,
            "evidence_report": "",
            "session_trace": {},
            "live_session_state": "",
            "snapshot": "",
            "session_chain": {},
            "issues": issues,
            "mutation_policy": "rejected_submit_no_runtime_mutation",
            "human_output_policy": "Correct the submission and retry; rejected attempts do not enter the deterministic session chain.",
        }
        report = attach_report_digest(report)
        target = Path(out).resolve() if out else root / "reports" / "intake_submit_report.json"
        write_json(target, report)
        return report

    # Successful submissions enter the deterministic evidence chain.
    snapshot_path, chained_state, chain_meta = write_session_snapshot(
        root, state, node_id=node_id, action="intake_submit",
        answer=_parse_answer(answer, node.get("answer_type") if node else None),
        status=status, extra={"run_id": run_id},
    )
    state = chained_state
    evidence = write_node_evidence(
        root, run_id=run_id, step_index=(len(__import__("ordo.session_trace", fromlist=["parse_session_trace"]).parse_session_trace(root).get("steps", [])) + 1), node_id=node_id, action="intake_submit",
        status=status, state=state, state_diff=diff,
        answer=_parse_answer(answer, node.get("answer_type") if node else None),
        next_node=next_target, checkpoint=checkpoint_after, snapshot_path=_rel(root, snapshot_path),
        extra={"issues": issues, "matched": matched, "expected_node": expected_node},
    )
    trace = append_session_trace_step(
        root, run_id=run_id, node_id=node_id, action="intake_submit", status=status,
        answer=_parse_answer(answer, node.get("answer_type") if node else None),
        next_node=next_target, evidence_path=str(evidence.get("evidence_path") or ""),
        snapshot_path=_rel(root, snapshot_path), snapshot_hash=str(chain_meta.get("snapshot_hash") or ""),
    )
    if evidence.get("evidence_path"):
        evidence_file = root / str(evidence.get("evidence_path"))
        if evidence_file.exists():
            evidence_doc = json.loads(evidence_file.read_text(encoding="utf-8"))
            evidence_doc["session_trace"] = {
                "path": trace.get("path"), "format": trace.get("format"),
                "step_index": trace.get("step_index"), "step_id": trace.get("step_id"),
                "trace_digest": trace.get("digest"), "trace_fragment": trace.get("fragment"),
            }
            evidence_doc["evidence_digest"] = {
                "algorithm": "sha256", "scope": "canonical_json_without_evidence_digest",
                "value": canonical_sha256({k: v for k, v in evidence_doc.items() if k != "evidence_digest"}),
            }
            write_json(evidence_file, evidence_doc)
            evidence_doc["evidence_path"] = str(evidence.get("evidence_path"))
            evidence = evidence_doc

    # Incremental benchmark logs are updated after every accepted answer.
    logs_dir = root / "runtime" / "benchmark_logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    parsed_answer = _parse_answer(answer, node.get("answer_type") if node else None)
    with (logs_dir / "dialogue.jsonl").open("a", encoding="utf-8") as fh:
        fh.write(json.dumps({"run_id": run_id, "node": node_id, "question": node.get("question", ""),
                             "answer": parsed_answer, "next_node": next_target, "timestamp_utc": utc_now()}, ensure_ascii=False) + "\n")
    if isinstance(parsed_answer, dict):
        prov = state.setdefault("attribute_provenance", {})
        for key, value in parsed_answer.items():
            prov[key] = {"source_type": "user_simulator_answer", "source_node": node_id,
                         "source_question": node.get("question", ""), "value": value}
    state.setdefault("execution_trace", []).append({"node": node_id, "status": "closed",
                                                      "next_node": next_target, "timestamp_utc": utc_now()})
    write_json(logs_dir / "collected_attributes.json", state.get("attribute_provenance", {}))
    live_session_file = ""
    if status == "passed":
        live_session_file = _write_live_session_state(
            root,
            run_id=run_id,
            state=state,
            current_node=next_target or "",
            last_closed_node=node_id,
            last_snapshot=_rel(root, snapshot_path),
            last_snapshot_hash=str(chain_meta.get("snapshot_hash") or ""),
            last_evidence_report=str(evidence.get("evidence_path") or ""),
            last_evidence_digest=evidence.get("evidence_digest") if isinstance(evidence.get("evidence_digest"), dict) else {},
            last_trace_path=str(trace.get("path") or ""),
            last_trace_digest=str(trace.get("digest") or ""),
            last_trace_step=int(trace.get("step_index") or 0),
        )

    report = {
        "status": status,
        "mode": "runtime_incremental_intake_submit",
        "runtime_source": source.get("runtime_source", "source_yaml"),
        "run_id": run_id,
        "input": {"state_file": input_state_file, "submitted_node": node_id},
        "node_id": node_id,
        "answer": _parse_answer(answer, node.get("answer_type") if node else None),
        "matched": matched,
        "next_node": next_target or "",
        "state": state,
        "state_diff": diff,
        "checkpoint_before": checkpoint_before,
        "checkpoint": checkpoint_after,
        "evidence_report": evidence.get("evidence_path"),
        "evidence_digest": evidence.get("evidence_digest"),
        "session_trace": {
            "path": trace.get("path"),
            "format": trace.get("format"),
            "step_index": trace.get("step_index"),
            "step_id": trace.get("step_id"),
            "trace_digest": trace.get("digest"),
            "trace_fragment": trace.get("fragment"),
        },
        "live_session_state": live_session_file,
        "snapshot": _rel(root, snapshot_path),
        "session_chain": chain_meta,
        "issues": issues,
        "human_output_policy": "AI must report evidence_report path and SHA-256 digest before asking the next question.",
    }
    report = attach_report_digest(report)
    target = Path(out).resolve() if out else root / "reports" / "intake_submit_report.json"
    write_json(target, report)
    return report


def guided_intake(
    package_path: str | Path,
    answers_path: str | Path | None = None,
    start_node: str | None = None,
    non_interactive: bool = False,
) -> dict[str, Any]:
    root, manifest, source = _load_runtime_package(package_path)
    runtime_dir = root / "runtime"
    snapshots_dir = runtime_dir / "state_snapshots"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    snapshots_dir.mkdir(parents=True, exist_ok=True)

    answers = load_yaml(Path(answers_path)) if answers_path else {}

    # M60.3.2 runtime automation safety: a bare guided intake without
    # --answers/--non-interactive must not block indefinitely on input() when
    # stdin is not a TTY, which is the common subprocess/agent execution mode.
    if not answers_path and not non_interactive and not sys.stdin.isatty():
        report = {
            "status": "failed",
            "mode": "guided_intake_fail_fast",
            "reason": "no_answers_and_not_interactive_and_no_tty",
            "input": {
                "answers_file": None,
                "start_node": start_node,
                "non_interactive": non_interactive,
                "stdin_isatty": False,
            },
            "issues": [
                {
                    "severity": "error",
                    "code": "ORDO-INTAKE-004",
                    "message": "Bare intake requires --answers, --non-interactive, or a TTY for interactive prompting.",
                    "location": "intake",
                }
            ],
            "automation_policy": "Runtime automation must use intake --submit, or guided intake with --answers --non-interactive. Bare interactive intake is only valid in a TTY.",
        }
        report = attach_report_digest(report)
        write_json(root / "reports" / "intake_report.json", report)
        return report

    state = initial_state(source)
    env_report = root / "reports" / "environment_capability_report.json"
    try:
        env_data = json.loads(env_report.read_text(encoding="utf-8")) if env_report.exists() else {}
    except Exception:
        env_data = {}
    state["execution_environment_ready"] = env_data.get("status") == "passed"
    nodes = {n.get("id"): n for n in source.get("nodes", []) or []}
    if not nodes:
        raise ValueError("No nodes defined in package source")
    current_node = start_node or (source.get("nodes") or [])[0].get("id")

    run_id = f"INTAKE-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    trace: dict[str, Any] = {
        "run_id": run_id,
        "mode": "guided_intake",
        "execution_mode": ((source.get("ordo") or {}).get("execution_mode")),
        "trace_source": "runtime_enforced",
        "started_at": utc_now(),
        "input": {
            "answers_file": str(answers_path) if answers_path else None,
            "start_node": current_node,
            "non_interactive": non_interactive,
        },
        "events": [],
        "state_snapshots": [],
    }

    visited_steps = 0
    max_steps = 100
    gate_results: list[dict[str, Any]] = []

    initial_snapshot, initial_state_chained, initial_chain = write_session_snapshot(root, state, node_id="000_initial", action="initial_state", status="passed", extra={"run_id": run_id})
    state = initial_state_chained
    trace["state_snapshots"].append(str(initial_snapshot.relative_to(root)).replace("\\", "/"))
    trace["session_chain_start"] = initial_chain

    while current_node and visited_steps < max_steps:
        visited_steps += 1
        if current_node.startswith("G_"):
            # Evaluate all gates to keep output dependency status consistent, then log selected gate.
            all_gate_results = evaluate_gates(source, state)
            gate_results = all_gate_results
            selected = next((g for g in all_gate_results if g.get("id") == current_node), None)
            snapshot_path, chained_state, chain_meta = write_session_snapshot(
                root,
                state,
                node_id=current_node,
                action="gate_evaluated",
                status="passed" if selected and selected.get("status") == "passed" else "blocked",
                extra={"run_id": run_id},
            )
            state = chained_state
            evidence = write_node_evidence(
                root,
                run_id=run_id,
                step_index=visited_steps,
                node_id=current_node,
                action="gate_evaluated",
                status="passed" if selected and selected.get("status") == "passed" else "blocked",
                state=state,
                gate=selected,
                next_node="",
                snapshot_path=str(snapshot_path.relative_to(root)).replace("\\", "/"),
            )
            trace["events"].append({"type": "gate_evaluated", "gate": current_node, "result": selected, "evidence_report": evidence.get("evidence_path"), "evidence_digest": evidence.get("evidence_digest"), "session_chain": chain_meta})
            trace["state_snapshots"].append(str(snapshot_path.relative_to(root)).replace("\\", "/"))
            break

        if current_node.startswith("STOP"):
            trace["events"].append({"type": "stopped", "target": current_node})
            break

        node = nodes.get(current_node)
        if not node:
            trace["events"].append({"type": "error", "error": "node_not_found", "node": current_node})
            break

        max_attempts = int(((node.get("on_unmatched_input") or {}).get("max_attempts") or 0))
        attempt = 0
        answer = None
        matched = False
        while attempt <= max_attempts:
            found, scripted = _answer_from_map(answers, current_node, attempt)
            if found:
                answer = scripted
            elif non_interactive:
                trace["events"].append({"type": "missing_answer", "node": current_node, "action": "block"})
                current_node = None
                break
            else:
                answer = _prompt_for_answer(node, attempt)
            matched = _is_answer_matched(node, answer)
            if matched:
                break
            trace["events"].append({
                "type": "clarify_requested",
                "op": "CLARIFY.REQUEST",
                "node": current_node,
                "attempt": attempt + 1,
                "answer": answer,
                "on_unmatched_input": node.get("on_unmatched_input"),
            })
            attempt += 1
        if current_node is None:
            break
        if not matched:
            exhausted = ((node.get("on_unmatched_input") or {}).get("on_exhausted") or {})
            trace["events"].append({
                "type": "clarify_exhausted",
                "node": current_node,
                "attempts": attempt,
                "action": exhausted.get("action", "escalate_to_human"),
                "reason": exhausted.get("reason"),
            })
            break

        node_id_for_event = current_node
        next_target, diff = _apply_node_answer(node, answer, state)
        answered = state.setdefault("answered_questions", [])
        if isinstance(answered, list):
            answered.append({"node": node_id_for_event, "answer": _parse_answer(answer, node.get("answer_type")), "closed_at": utc_now()})
        state["last_closed_node"] = node_id_for_event
        state["current_node"] = next_target or ""
        snapshot_path, chained_state, chain_meta = write_session_snapshot(
            root,
            state,
            node_id=node_id_for_event,
            action="node_answered",
            answer=_parse_answer(answer, node.get("answer_type")),
            status="passed",
            extra={"run_id": run_id},
        )
        state = chained_state
        evidence = write_node_evidence(
            root,
            run_id=run_id,
            step_index=visited_steps,
            node_id=node_id_for_event,
            action="node_answered",
            status="passed",
            state=state,
            state_diff=diff,
            answer=_parse_answer(answer, node.get("answer_type")),
            next_node=next_target,
            snapshot_path=str(snapshot_path.relative_to(root)).replace("\\", "/"),
        )
        trace["events"].append({
            "type": "node_answered",
            "node": node_id_for_event,
            "answer": _parse_answer(answer, node.get("answer_type")),
            "next": next_target,
            "state_diff": diff,
            "evidence_report": evidence.get("evidence_path"),
            "evidence_digest": evidence.get("evidence_digest"),
            "session_chain": chain_meta,
        })
        trace["state_snapshots"].append(str(snapshot_path.relative_to(root)).replace("\\", "/"))
        current_node = next_target

    if not gate_results:
        gate_results = evaluate_gates(source, state)
    assertion_results = evaluate_assertions(source, state, gate_results)
    outputs = allowed_outputs(source, gate_results)
    trace.update({
        "finished_at": utc_now(),
        "state": state,
        "gate_report": gate_results,
        "assertion_report": assertion_results,
        "outputs": outputs,
        "violations": [a for a in assertion_results if a.get("status") == "violation"],
        "blocked_outputs": [o for o in outputs if not o.get("allowed")],
        "status": "passed" if not [a for a in assertion_results if a.get("status") == "violation"] else "failed",
    })
    trace = attach_report_digest(trace)
    write_json(runtime_dir / "intake_trace_log.json", trace)
    write_json(root / "reports" / "intake_report.json", trace)
    return trace
