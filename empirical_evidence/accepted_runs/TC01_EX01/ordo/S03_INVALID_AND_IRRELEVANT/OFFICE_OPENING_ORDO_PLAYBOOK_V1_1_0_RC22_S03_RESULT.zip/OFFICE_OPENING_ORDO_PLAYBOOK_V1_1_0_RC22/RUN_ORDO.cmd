@echo off
py -3 "%~dp0RUN_ORDO.py" %*
if errorlevel 1 python "%~dp0RUN_ORDO.py" %*
