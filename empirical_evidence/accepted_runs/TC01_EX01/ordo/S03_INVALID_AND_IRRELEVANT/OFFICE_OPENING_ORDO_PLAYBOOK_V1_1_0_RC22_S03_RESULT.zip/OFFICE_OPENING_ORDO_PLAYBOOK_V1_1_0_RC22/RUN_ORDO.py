#!/usr/bin/env python3
"""Portable Ordo launcher. Run with any available Python 3 interpreter.
Does not require executable permission on cli_embedded/ordo.
"""
from __future__ import annotations
import runpy, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
ENTRY = ROOT / "cli_embedded" / "ordo"
if not ENTRY.is_file():
    print(f"ORDO_LAUNCH_ERROR: missing {ENTRY}", file=sys.stderr)
    raise SystemExit(127)
sys.argv = [str(ENTRY), *sys.argv[1:]]
try:
    runpy.run_path(str(ENTRY), run_name="__main__")
except ModuleNotFoundError as exc:
    print(f"ORDO_LAUNCH_ERROR: missing Python dependency: {exc.name}", file=sys.stderr)
    print("Install the missing dependency or classify the environment as PYTHON_DEPENDENCY_MISSING.", file=sys.stderr)
    raise SystemExit(126)
