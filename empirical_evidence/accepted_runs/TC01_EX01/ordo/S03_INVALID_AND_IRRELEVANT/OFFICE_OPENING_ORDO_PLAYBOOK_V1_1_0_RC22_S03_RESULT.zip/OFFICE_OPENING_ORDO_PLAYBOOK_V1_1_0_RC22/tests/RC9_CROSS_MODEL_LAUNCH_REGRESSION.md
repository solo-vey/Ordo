# RC9 regression

- Python launcher works without executable permission on cli_embedded/ordo.
- Direct launcher remains supported.
- Environment blocked only after available launcher ladder attempts.
- Diagnostic package is machine-readable and cannot contain business placeholders.
- Final go/no-go includes verify-session.
