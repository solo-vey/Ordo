from pathlib import Path
import sys, yaml
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'cli_embedded/ordo_pkg'))
from ordo.checkpoints import _present
from ordo.intake import _resolve_answer_ref

boolean_fields=['legal_entity_required','visa_support_required','server_room_required','location_search_completed','location_screening_passed','lease_negotiation_succeeded','legal_entity_branch_completed','critical_supplier_replacement_required','readiness_blocking_defects','pilot_completed','final_package_ready']
for field in boolean_fields:
    assert _resolve_answer_ref(f'$answer.{field}',{field:True}) is True
    assert _resolve_answer_ref(f'$answer.{field}',{field:False}) is False
    assert _resolve_answer_ref(f'$answer.{field}',{field:None}) is None
assert _present(True) is True
assert _present(False) is True
assert _present(None) is False
print(f'passed: tri-state mapping for {len(boolean_fields)} boolean fields')
