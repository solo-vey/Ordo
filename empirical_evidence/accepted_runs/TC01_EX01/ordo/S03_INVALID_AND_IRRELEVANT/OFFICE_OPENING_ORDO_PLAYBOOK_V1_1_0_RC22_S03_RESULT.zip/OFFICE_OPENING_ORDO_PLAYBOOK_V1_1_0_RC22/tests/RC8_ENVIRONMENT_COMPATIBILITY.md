# RC8 Environment Compatibility Regression

- verify-environment must pass with executable embedded CLI, readable answers and writable directories.
- runtime-status and runtime-entry must block without a passed environment report.
- blocked environments may emit diagnostic-only packages, never final business outputs.
- validate-output must reject heading-only/placeholder artifacts.
