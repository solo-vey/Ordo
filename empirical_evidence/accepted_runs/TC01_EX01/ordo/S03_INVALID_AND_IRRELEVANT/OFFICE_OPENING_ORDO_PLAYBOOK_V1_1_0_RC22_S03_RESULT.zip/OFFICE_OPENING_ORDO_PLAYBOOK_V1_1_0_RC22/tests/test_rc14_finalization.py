from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_version_sync():
    import yaml
    manifest=yaml.safe_load((ROOT/'ordo.yml').read_text())
    source=yaml.safe_load((ROOT/'source/program.ordo.yaml').read_text())
    assert manifest['version'] == source['ordo']['package_version']

def test_preterminal_output_validation_contract():
    text=(ROOT/'cli_embedded/ordo_pkg/ordo/output_validator.py').read_text()
    assert 'N20V_VALIDATE_FINAL_PACKAGE' in text
    assert 'doc_status' in text

def test_terminal_submit_sets_readiness_and_validation():
    text=(ROOT/'cli_embedded/ordo_pkg/ordo/intake.py').read_text()
    assert 'state["package_validation_completed"] = True' in text
    assert 'state["final_package_ready"] = True' in text

def test_branch_history_is_structured():
    text=(ROOT/'cli_embedded/ordo_pkg/ordo/intake.py').read_text()
    for token in ['decision_node','selected_branch','rejoin_node','accepted_transition']:
        assert token in text
