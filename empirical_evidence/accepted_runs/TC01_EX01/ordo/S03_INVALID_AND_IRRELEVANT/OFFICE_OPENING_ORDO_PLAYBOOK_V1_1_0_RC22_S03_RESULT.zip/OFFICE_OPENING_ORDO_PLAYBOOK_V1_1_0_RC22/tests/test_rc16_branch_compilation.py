import json
from pathlib import Path

def test_branch_rules_survive_compilation():
    root=Path(__file__).resolve().parents[1]
    ir=json.loads((root/'compiled/program.ir.json').read_text())
    nodes={op.get('source_local_id'):op for op in ir['ops'] if op.get('op')=='NODE.DEF'}
    for node in ['N07_LEGAL_AND_REGULATORY_MODEL','N15_CONTRACTORS_AND_SUPPLIERS','N18_READINESS_TEST']:
        assert nodes[node].get('branch_rules'), node
