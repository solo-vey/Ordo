import json, subprocess, tempfile, shutil
from pathlib import Path

def test_valid_explicit_scenario_selection():
    root=Path(__file__).resolve().parents[1]
    p=subprocess.run(['python3','tools/select_scenario.py','.', '--scenario','S02_BRANCH_HEAVY'],cwd=root,text=True,capture_output=True)
    assert p.returncode==0, p.stderr
    data=json.loads((root/'runtime/selected_scenario.json').read_text())
    assert data['scenario_id']=='S02_BRANCH_HEAVY'
    assert data['default_used'] is False

def test_invalid_scenario_is_blocked():
    root=Path(__file__).resolve().parents[1]
    p=subprocess.run(['python3','tools/select_scenario.py','.', '--scenario','S99_UNKNOWN'],cwd=root,text=True,capture_output=True)
    assert p.returncode==2
    assert 'SCENARIO_ID_INVALID' in p.stdout

def test_no_prompt_declares_default_s01():
    root=Path(__file__).resolve().parents[1]
    text=(root/'START_PROMPT_RUNTIME_MODE.md').read_text()
    assert 'There is no default scenario' in text
    assert 'never infer `S01_CLEAN_CONTROL`' in text
