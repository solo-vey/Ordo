from ordo.checkpoints import build_checkpoint_report, _get_path


def _source(field):
    return {"nodes": [{"id": "DOC", "required_fields": [field]}]}


def test_get_path_resolves_nested_document_status():
    state = {"document_status": {"D1": "valid", "D2": "final", "D3": None}}
    assert _get_path(state, "document_status.D1") == "valid"
    assert _get_path(state, "document_status.D2") == "final"
    assert _get_path(state, "document_status.D3") is None
    assert _get_path(state, "document_status.D4") is None


def test_nested_required_field_closes_document_nodes():
    for doc in ("D1", "D2", "D3"):
        report = build_checkpoint_report(_source(f"document_status.{doc}"), {"document_status": {doc: "valid"}})
        assert report["checkpoint_table"]["DOC"]["status"] == "closed"
        assert report["earliest_incomplete_node"] == ""

def test_missing_nested_required_field_remains_open():
    report = build_checkpoint_report(_source("document_status.D1"), {"document_status": {}})
    assert report["checkpoint_table"]["DOC"]["status"] == "open"
    assert report["earliest_incomplete_node"] == "DOC"
