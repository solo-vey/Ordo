# RC5 Artifact Quality Regression

- confirmed artifact contracts for D1-D3
- validate-artifacts fails on zero checked artifacts
- consistency fails on zero consistency fields
- required sections enforced
- D1 provenance appendix forbidden
- collected attributes requires P01-P50
- conditional-open table requires five columns and four rows
- required facts/sections reference is semantic, not exact wording
