# RC7 regression

- validate-output must fail unless all seven expected output artifacts exist.
- `07_MODEL_IDENTITY.json` must contain the required non-empty identity fields.
- branch_history must contain the N07 branch decision.
- model identity is benchmark provenance and must be copied into the result manifest/final state.
