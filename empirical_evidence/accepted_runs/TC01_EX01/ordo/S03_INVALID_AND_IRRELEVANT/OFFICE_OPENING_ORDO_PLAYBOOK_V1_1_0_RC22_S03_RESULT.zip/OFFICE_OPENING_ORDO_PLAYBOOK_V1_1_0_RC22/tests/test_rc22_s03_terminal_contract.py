from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]

def test_s03_catalog_has_non_terminal_scenario_completion():
    data = yaml.safe_load((ROOT/'scenario_suite/SCENARIO_CATALOG.yaml').read_text(encoding='utf-8'))
    s03 = next(x for x in data['scenarios'] if x['id']=='S03_INVALID_AND_IRRELEVANT')
    tc = s03['terminal_condition']
    assert tc['status']=='scenario_passed'
    assert tc['runtime_current_node']=='N02_GEOGRAPHY_AND_TARGET_DATE'
    assert tc['requires_t_completed'] is False
    assert tc['requires_go_no_go'] is False

def test_s03_prompt_forbids_continuation():
    text=(ROOT/'scenario_suite/START_PROMPT_S03_INVALID_AND_IRRELEVANT.md').read_text(encoding='utf-8')
    assert 'stop immediately' in text
    assert 'do NOT continue beyond N02' in text
    assert 'do NOT require T_COMPLETED' in text
