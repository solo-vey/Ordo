from cli_embedded.ordo_pkg.ordo.intake import _is_answer_matched

NODE = {
    "id": "N01_BUSINESS_INITIATION",
    "answer_type": "structured_object",
    "expected_fields": [
        "company_legal_name", "company_brand_name", "company_industry",
        "company_headquarters_country", "company_size_employees", "office_business_goal",
    ],
}


def test_irrelevant_prose_is_rejected_for_structured_object():
    assert not _is_answer_matched(NODE, "Сьогодні гарна погода, і я люблю каву.")


def test_partial_mapping_is_rejected():
    assert not _is_answer_matched(NODE, {"company_legal_name": "Only name"})


def test_complete_mapping_is_accepted():
    answer = {key: "x" for key in NODE["expected_fields"]}
    assert _is_answer_matched(NODE, answer)
