from pathlib import Path
import json, subprocess, tempfile, shutil
ROOT=Path(__file__).resolve().parents[1]
CLI=ROOT/'cli_embedded/ordo'

def run(*args):
    return subprocess.run([str(CLI),*args],cwd=ROOT,text=True,capture_output=True)

def test_vacuum_artifact_validation_fails():
    with tempfile.TemporaryDirectory() as td:
        r=run('validate-artifacts','.', '--artifacts',td,'--state','run_inputs/full_success_state.yaml','--out',str(Path(td)/'r.json'))
        assert r.returncode != 0
        rep=json.loads((Path(td)/'r.json').read_text())
        assert rep['status']=='failed'

def test_contracts_are_confirmed():
    import yaml
    d=yaml.safe_load((ROOT/'source/program.ordo.yaml').read_text())
    assert all(c['status']=='confirmed' for c in d['contracts'])
    assert len(d['artifact_requirements'])>=3
