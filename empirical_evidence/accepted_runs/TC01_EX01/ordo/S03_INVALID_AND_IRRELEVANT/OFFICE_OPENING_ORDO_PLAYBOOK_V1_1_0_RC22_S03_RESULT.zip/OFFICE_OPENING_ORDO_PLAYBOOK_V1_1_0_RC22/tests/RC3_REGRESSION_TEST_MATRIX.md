# RC3 Regression Test Matrix

1. Boolean propagation for `true`, `false`, and `null` on every boolean state field.
2. N09 `location_screening_passed=true` must close N09; `false` must route to N08; `null` must be rejected.
3. A node may not advance if its own required fields remain open.
4. T_COMPLETED is forbidden until global checkpoint closure and `final_package_ready=true`.
5. `completed_steps`, `current_step`, and `branch_history` are derived from accepted runtime events.
6. Document status is set by verified file existence, not trusted answer text.
7. Final package readiness requires all five artifacts and passed output/artifact/consistency reports.
8. Full-path N01→N20V regression checks final state, gates, session integrity, and terminal eligibility.
