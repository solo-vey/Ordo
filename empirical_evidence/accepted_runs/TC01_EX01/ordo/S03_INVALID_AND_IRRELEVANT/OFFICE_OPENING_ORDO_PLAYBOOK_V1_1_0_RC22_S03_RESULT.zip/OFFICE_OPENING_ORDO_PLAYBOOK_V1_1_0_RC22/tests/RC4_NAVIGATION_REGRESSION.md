# RC4 Navigation Regression

Required sequence after N07:

```text
N07_LEGAL_AND_REGULATORY_MODEL
→ N07B_LEGAL_ENTITY_REGISTRATION
→ N08_CANDIDATE_LOCATION_SEARCH
→ N09_PRELIMINARY_LOCATION_SCREENING
→ N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION
```

Assertions:

1. `next-step` returns persisted `current_node` after each accepted intake.
2. Mandatory action/branch nodes without ordinary state fields remain open until accepted.
3. `N08` cannot be skipped while `location_search_completed != true`.
4. `N09` cannot be skipped while `location_screening_passed` is unset.
5. `next-step` cannot suggest a node whose prerequisite process-rail transition was not accepted.
6. Rejected future-node submission does not mutate session evidence.
