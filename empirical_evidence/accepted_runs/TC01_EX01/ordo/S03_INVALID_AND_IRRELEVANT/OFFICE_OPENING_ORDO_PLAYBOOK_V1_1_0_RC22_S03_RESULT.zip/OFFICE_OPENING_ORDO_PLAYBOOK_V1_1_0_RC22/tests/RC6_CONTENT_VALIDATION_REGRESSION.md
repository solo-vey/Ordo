# RC6 Regression

- validate-artifacts without --state fails
- unresolved confirmed field fails
- model_assisted_outputs_checked must equal 3
- execution trace node sequence enforced
- dialogue log full question/answer pairs enforced
- rendered service instructions forbidden by templates and prompt
- mechanical conditional phrases removed
