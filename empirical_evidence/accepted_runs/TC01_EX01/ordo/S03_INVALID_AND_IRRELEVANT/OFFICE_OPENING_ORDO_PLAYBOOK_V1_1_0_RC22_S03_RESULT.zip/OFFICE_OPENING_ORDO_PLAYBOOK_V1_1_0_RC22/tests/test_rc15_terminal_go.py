from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_version_synced():
    import yaml
    manifest=yaml.safe_load((ROOT/'ordo.yml').read_text())
    source=yaml.safe_load((ROOT/'source/program.ordo.yaml').read_text())
    assert manifest['version'] == source['ordo']['package_version']

def test_runtime_injects_package_version():
    text=(ROOT/'cli_embedded/ordo_pkg/ordo/intake.py').read_text()
    assert 'state["package_version"] = str(manifest.get("version")' in text

def test_go_no_go_reads_trace_fields():
    text=(ROOT/'cli_embedded/ordo_pkg/ordo/go_no_go.py').read_text()
    assert 'last_step.get("fields")' in text

def test_ukrainian_response_requirement():
    text=(ROOT/'START_PROMPT_RUNTIME_MODE.md').read_text()
    assert 'must be written in Ukrainian' in text
