from ordo.intake import _apply_node_answer
from ordo.runtime_restore import _classify_correction_intent

def test_correction_intents_are_distinct():
    assert _classify_correction_intent('User changed work model assumptions') == 'change_decision'
    assert _classify_correction_intent('correct prior answer') == 'correct_answer'
    assert _classify_correction_intent('undo last action') == 'undo_last_action'
    assert _classify_correction_intent('what-if scenario') == 'what_if'

def test_branch_rejoin_is_explicitly_confirmed():
    node={'id':'N12','on_answer':{'update_state':{},'next':'N13'},'answer_type':'object'}
    state={'branch_history':[{'decision_node':'N15','selected_branch':'N12','rejoin_node':'N12'}]}
    _apply_node_answer(node, {'ok':True}, state)
    assert state['branch_history'][0]['rejoin_confirmed'] is True
    assert state['branch_history'][0]['rejoined_at_node']=='N12'
