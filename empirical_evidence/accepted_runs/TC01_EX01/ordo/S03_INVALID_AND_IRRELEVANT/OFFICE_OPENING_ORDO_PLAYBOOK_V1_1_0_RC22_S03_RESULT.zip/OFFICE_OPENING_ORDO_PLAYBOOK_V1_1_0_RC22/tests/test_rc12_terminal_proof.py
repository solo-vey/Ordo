from pathlib import Path

def test_terminal_contract_source_present():
    root=Path(__file__).resolve().parents[1]
    text=(root/'cli_embedded/ordo_pkg/ordo/go_no_go.py').read_text()
    for token in ['ORDO-GNG-TERMINAL-002','ORDO-GNG-FIXTURE-001','ORDO-GNG-TRACE-002','N20V_VALIDATE_FINAL_PACKAGE','T_COMPLETED']:
        assert token in text

def test_version_synced():
    root=Path(__file__).resolve().parents[1]
    import yaml
    manifest=yaml.safe_load((root/'ordo.yml').read_text())
    source=yaml.safe_load((root/'source/program.ordo.yaml').read_text())
    assert manifest['version'] == source['ordo']['package_version']
