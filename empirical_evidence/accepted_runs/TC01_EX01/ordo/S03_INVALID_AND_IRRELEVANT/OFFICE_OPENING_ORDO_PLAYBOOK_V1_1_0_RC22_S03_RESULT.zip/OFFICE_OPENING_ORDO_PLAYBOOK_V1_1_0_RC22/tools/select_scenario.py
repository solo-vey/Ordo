#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import yaml

VALID={"S01_CLEAN_CONTROL","S02_BRANCH_HEAVY","S03_INVALID_AND_IRRELEVANT","S04_BACKTRACK_AND_CORRECT","S05_INCOMPLETE_HARD_STOP"}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('package', nargs='?', default='.')
    ap.add_argument('--scenario', required=True)
    args=ap.parse_args()
    root=Path(args.package).resolve()
    sid=args.scenario.strip()
    if sid not in VALID:
        print(json.dumps({"status":"blocked","reason_code":"SCENARIO_ID_INVALID","scenario_id":sid,"valid":sorted(VALID)},ensure_ascii=False,indent=2))
        raise SystemExit(2)
    catalog=yaml.safe_load((root/'scenario_suite/SCENARIO_CATALOG.yaml').read_text(encoding='utf-8'))
    spec=next((x for x in catalog.get('scenarios',[]) if x.get('id')==sid),None)
    if not spec:
        print(json.dumps({"status":"blocked","reason_code":"SCENARIO_NOT_IN_CATALOG","scenario_id":sid},ensure_ascii=False,indent=2))
        raise SystemExit(2)
    runtime=root/'runtime'; runtime.mkdir(exist_ok=True)
    out=runtime/'selected_scenario.json'
    payload={"schema":"ordo.benchmark.selected_scenario.v1","status":"selected","scenario_id":sid,"scenario":spec,"selection_method":"explicit_cli_argument","default_used":False}
    out.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(payload,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
