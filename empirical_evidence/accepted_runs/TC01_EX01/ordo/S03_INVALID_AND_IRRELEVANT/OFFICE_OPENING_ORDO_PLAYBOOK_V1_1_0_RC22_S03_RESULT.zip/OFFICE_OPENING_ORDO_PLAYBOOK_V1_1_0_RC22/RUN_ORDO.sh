#!/usr/bin/env sh
exec python3 "$(dirname "$0")/RUN_ORDO.py" "$@"
