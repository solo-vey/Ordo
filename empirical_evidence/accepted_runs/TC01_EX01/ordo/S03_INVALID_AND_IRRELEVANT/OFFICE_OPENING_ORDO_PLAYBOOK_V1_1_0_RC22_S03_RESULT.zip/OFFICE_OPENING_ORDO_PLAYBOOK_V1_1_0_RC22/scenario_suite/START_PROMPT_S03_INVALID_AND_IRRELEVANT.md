# Start Prompt — Office Opening Ordo RC22 — S03_INVALID_AND_IRRELEVANT

SCENARIO_ID: `S03_INVALID_AND_IRRELEVANT`

Extract the package, enter its root, and read:

- `START_HERE_RUNTIME_MODE.md`
- `scenario_suite/SCENARIO_EXECUTION_CONTRACT.md`
- `scenario_suite/SCENARIO_CATALOG.yaml`
- `scenario_suite/README.md`

Record the scenario:

```bash
python3 tools/select_scenario.py . --scenario S03_INVALID_AND_IRRELEVANT
```

Run the normal preflight. Then execute exactly these events in order:

1. submit a partial N01 structured answer — it must be `blocked`;
2. submit an answer for future node N03 — it must be `blocked`;
3. submit irrelevant prose to N01 — it must be `blocked`;
4. after each rejection, prove canonical state did not change;
5. submit the corrected complete N01 structured answer — it must be `accepted`;
6. verify the current node is `N02_GEOGRAPHY_AND_TARGET_DATE`;
7. verify session chain is `intact`.

When these conditions pass, stop immediately and report:

```text
scenario_status: scenario_passed
terminal_condition: S03_VALIDATION_COMPLETE_AT_N02
```

For this scenario, do NOT continue beyond N02, do NOT generate documents, do NOT run final GO_NO_GO, and do NOT require T_COMPLETED.

All user-facing text must be Ukrainian. Keep technical identifiers unchanged.
