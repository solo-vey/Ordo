# RC2 Runtime Repair Report

## Trigger

The first external runtime run stopped after N08 because target hashes were stale, session verification failed, N07B conflicted with checkpoint routing, and rejected submits mutated the evidence chain.

## Repairs

1. Final compilation regenerates synchronized IR, code view, target manifest and pristine trace.
2. Pristine empty runtime sessions pass `verify-session`.
3. First intake enforces `verify-targets` and `verify-session` preflight.
4. `$answer.<field>` references resolve to actual answer values.
5. Structured branch rules evaluate boolean and scalar conditions.
6. `N07B` accepts structured confirmation and is authoritative when selected.
7. Rejected submissions produce reports but no snapshots, evidence or trace mutation.
8. Accepted submissions update incremental dialogue, provenance and execution logs.

## Controlled validation

- path N01 through N08 including N07B: passed;
- actual company value persisted instead of placeholder: passed;
- session verification after path: passed;
- intentional wrong-node submit did not change trace/snapshot counts: passed;
- session verification after rejected submit: passed.
