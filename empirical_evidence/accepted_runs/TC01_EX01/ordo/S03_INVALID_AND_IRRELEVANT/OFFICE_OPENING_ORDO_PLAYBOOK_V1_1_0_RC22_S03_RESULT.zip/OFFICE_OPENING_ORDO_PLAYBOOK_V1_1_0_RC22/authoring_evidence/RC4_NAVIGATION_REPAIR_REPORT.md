# RC4 Navigation Repair Report

RC4 makes the accepted runtime transition authoritative for `next-step` in persisted sessions and adds checkpoint semantics for mandatory action/branch nodes. This closes the RC3 defect that skipped N07B/N08/N09 and suggested N10 while G_STEP_08_COMPLETE was blocked.
