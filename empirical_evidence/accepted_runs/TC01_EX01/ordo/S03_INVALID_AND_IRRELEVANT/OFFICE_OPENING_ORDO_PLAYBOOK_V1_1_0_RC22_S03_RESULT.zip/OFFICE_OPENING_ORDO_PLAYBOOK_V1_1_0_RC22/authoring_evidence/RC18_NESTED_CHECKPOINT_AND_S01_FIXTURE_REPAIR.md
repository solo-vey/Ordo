# RC18 Nested Checkpoint and S01 Fixture Repair

## Baseline

Targeted patch over RC17. The process tree, node IDs, gates, attributes and business semantics were not rebuilt.

## Repairs

- Added generic dotted-path resolution for checkpoint required fields.
- `document_status.D1`, `document_status.D2`, and `document_status.D3` now resolve from nested canonical state.
- Added regressions for present and missing nested values.
- Replaced stale clean-control document fixtures with artifacts aligned to the canonical Northstar scenario state.
- Synchronized package version to `1.1.0-rc.3`.

## Expected effect

Document nodes close after validated physical artifacts are present and intake derives nested document status. No manual canonical-state edit is required.
