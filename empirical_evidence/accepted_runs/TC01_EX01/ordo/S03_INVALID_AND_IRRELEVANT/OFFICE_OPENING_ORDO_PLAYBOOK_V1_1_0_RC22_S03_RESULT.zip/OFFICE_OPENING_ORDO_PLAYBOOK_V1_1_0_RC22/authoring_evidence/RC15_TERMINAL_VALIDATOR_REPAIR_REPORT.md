# RC15 Terminal Validator Repair Report

Targeted patch over RC14; the process graph and business semantics were not rebuilt.

Changes:
- canonical state receives manifest `package_version` on every accepted runtime intake;
- final go/no-go reads parsed trace attributes from `step.fields`;
- terminal proof remains structured through `state.terminal_transition`;
- branch history logic from RC14 is retained;
- user-facing responses are required in Ukrainian.
