# RC12 Clean-Room Validation

Validated on fresh package copies with the Python launcher.

Required sequence:

1. verify-environment
2. verify-targets
3. verify-session
4. runtime-status
5. runtime-entry
6. check-gate G_EXECUTION_ENVIRONMENT_READY
7. repeat verify-targets and verify-session
8. verify SHA256SUMS

Expected result: all passed/ready and N01 selected.
