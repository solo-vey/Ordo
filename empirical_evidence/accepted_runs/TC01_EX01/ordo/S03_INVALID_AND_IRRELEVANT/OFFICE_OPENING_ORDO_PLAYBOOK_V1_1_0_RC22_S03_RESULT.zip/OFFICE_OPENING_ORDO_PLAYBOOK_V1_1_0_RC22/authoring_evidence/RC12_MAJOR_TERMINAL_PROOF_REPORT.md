# RC12 Major Terminal-Proof Repair

Adds strict canonical-state, version, fixture-exclusion, trace-count, snapshot-count and terminal-transition requirements. GO cannot be issued for synthetic validation fixtures or incomplete session evidence.
