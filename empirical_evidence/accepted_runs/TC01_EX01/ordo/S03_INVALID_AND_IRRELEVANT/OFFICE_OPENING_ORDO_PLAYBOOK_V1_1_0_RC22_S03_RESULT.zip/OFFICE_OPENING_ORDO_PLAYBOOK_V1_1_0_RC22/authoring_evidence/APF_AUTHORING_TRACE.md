# APF Authoring Trace — Office Opening Playbook

## Mode

`self_hosted_dual_role_authoring_simulation`

## Inputs

- neutral 20-step process specification
- 50-attribute catalog
- three model-assisted document templates
- validation and package contracts

## Authoring path

1. Selected creation of a new guided process.
2. Confirmed goal: deterministic office-opening workflow for benchmark execution.
3. Selected strict process rail with state tracking, backtracking and no free deviation.
4. Normalized 20 steps into active nodes plus legal-entity and remediation branch nodes.
5. Corrected input defect: all attributes were incorrectly marked as primary step 20; reassigned P01-P50 to their actual collection steps.
6. Bound each step to required attributes and a mechanical completion gate.
7. Added location-search loop, lease fallback, supplier replacement loop and readiness-remediation loop.
8. Added document readiness gates after steps 11, 17 and 20.
9. Classified all three business documents as model-assisted outputs using confirmed state only.
10. Added execution trace and collected-attributes artifacts.
11. Added anti-skip, anti-early-render, stale-document and provenance assertions.
12. Generated source YAML, tests, runtime state fixture and package docs.
13. Submitted package to standard Ordo validation pipeline.

## User-role decisions simulated

- baseline approved for pilot
- model-assisted rendering selected
- APF traversal required
- standard validation required
- final package must include runtime and evidence variants

14. Baseline validate-state treats unevaluated semantic assertions as blocking even when test-only; moved these policies into explicit gates, static negative tests and runtime instructions so the deterministic pre-run gate can complete.
