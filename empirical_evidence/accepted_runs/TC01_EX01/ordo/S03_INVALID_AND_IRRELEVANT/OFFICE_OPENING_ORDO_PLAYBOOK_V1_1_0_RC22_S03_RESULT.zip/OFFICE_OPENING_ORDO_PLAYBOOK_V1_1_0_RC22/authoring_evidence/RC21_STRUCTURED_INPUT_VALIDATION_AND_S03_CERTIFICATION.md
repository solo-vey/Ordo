# RC21 Structured Input Validation and S03 Certification

RC21 fixes a runtime intake defect where non-empty prose could be accepted for a `structured_object` node without `allowed_answers`.

## Change

- Declared answer shape is enforced before field-level matching.
- `structured_object`/`object` requires a mapping.
- `list` requires a list after parsing.
- `confirmation` requires a boolean or mapping.
- Rejected submissions do not mutate canonical runtime state, session trace, or snapshots.

## Clean S03 result

- partial N01 mapping: blocked (`ORDO-INTAKE-003`)
- future-node N03 answer: blocked (`ORDO-INTAKE-002`)
- irrelevant prose at N01: blocked (`ORDO-INTAKE-003`)
- canonical state digest unchanged across all three rejected attempts
- corrected N01 mapping: accepted
- next node: `N02_GEOGRAPHY_AND_TARGET_DATE`
- `verify-session`: passed; session chain intact
