# RC12 Target and Gate Repair Report

- Replaced unsupported `reports.*` mechanical gate condition with `state.execution_environment_ready is true`.
- Runtime state bootstraps the flag only from a passed environment capability report.
- Recompiled canonical IR and regenerated Ordo view and targets manifest.
- Regenerated SHA256SUMS after all mutations.
- Clean-room preflight is required before release.
