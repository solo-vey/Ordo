# RC22 — S03 scenario terminal contract

RC22 changes only scenario orchestration, not the Office Opening business runtime.

`S03_INVALID_AND_IRRELEVANT` now has an explicit scenario terminal:
`scenario_passed` at `N02_GEOGRAPHY_AND_TARGET_DATE` after three rejected inputs preserve canonical state and a corrected N01 answer is accepted.

S03 explicitly does not require documents, GO_NO_GO, or T_COMPLETED.
