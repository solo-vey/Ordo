# Playbook Validation Summary

## Candidate

`OFFICE_OPENING_ORDO_PLAYBOOK_V0_1_0`

## Results

- `lint_report.json`: `passed`
- `compile_report.json`: `passed`
- `test_report.json`: `passed`
- `coverage_report.json`: `passed`
- `state_validation_report.json`: `passed`
- `runtime_entry_report.json`: `ready`
- `runtime_status_report.json`: `ready`
- `output_generation_report.json`: `blocked`
- `output_validation_report.json`: `failed`
- `artifact_validation_report.json`: `failed`
- `CONSISTENCY_CHECK_REPORT.json`: `failed`
- `GO_NO_GO_REPORT.json`: `no_go_requires_artifact_fix`

## Current acceptance status

`runtime_ready_but_output_handoff_not_closed`

## Blocking issue

The baseline helper run completed with blocks before model-assisted artifact handoff. Therefore `generate-output`, final output validation and go/no-go are not yet green. Structural source, compilation, tests, coverage, full-state validation and runtime entry are green.

## Next correction

Add the APF-compatible model-assisted output handoff node/state contract and a runtime validation fixture that closes the three document-generation nodes before final go/no-go.