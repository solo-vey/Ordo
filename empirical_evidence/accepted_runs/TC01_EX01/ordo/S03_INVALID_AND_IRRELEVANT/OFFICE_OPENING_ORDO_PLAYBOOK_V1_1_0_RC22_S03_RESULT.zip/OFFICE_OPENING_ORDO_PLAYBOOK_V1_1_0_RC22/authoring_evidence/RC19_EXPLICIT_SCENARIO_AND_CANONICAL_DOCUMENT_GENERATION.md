# RC19 targeted change evidence

Baseline: RC18.

Changes are limited to explicit scenario selection and external artifact-generation discipline. The process tree, node IDs, gates, business fields, and branch semantics were not rebuilt.

- Added mandatory explicit `SCENARIO_ID` selection.
- Added five scenario-specific start prompts.
- Prohibited implicit S01 selection.
- Marked baseline fixtures as internal regression-only.
- Required D1/D2/D3 generation from canonical runtime state with immediate validation.
