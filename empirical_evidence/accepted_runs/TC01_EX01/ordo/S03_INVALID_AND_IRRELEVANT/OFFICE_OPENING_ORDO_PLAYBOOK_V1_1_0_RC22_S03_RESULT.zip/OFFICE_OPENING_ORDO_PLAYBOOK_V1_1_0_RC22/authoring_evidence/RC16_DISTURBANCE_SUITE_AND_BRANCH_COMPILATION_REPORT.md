# RC16 Disturbance Suite and Branch Compilation Report

## Baseline

RC15 (`1.0.0-rc.3`) was patched in place. The process was not rebuilt from scratch.

## Targeted changes

- Preserved `branch_rules`, `expected_fields`, `required_fields`, `step_contract`, `optional`, `terminal`, and `outcome` in compiled `NODE.DEF` operations.
- Preserved the same fields when reconstructing the runtime source from compiled IR.
- Added five disturbance scenarios and an isolated scenario runner.
- Added known-good document fixtures solely for deterministic control-flow regression tests.

## Defect discovered

Before RC16, alternative branch metadata existed in source YAML but was dropped from compiled IR/runtime reconstruction. A `legal_entity_required=false` answer therefore incorrectly followed the default N07B path.

## Verified results

- Alternative legal branch: `N07 -> N08` passed and produced structured branch history.
- Invalid partial answer: blocked without state mutation.
- Future-node submission: blocked without changing the current node.
- Corrected current-node answer: accepted and continued to N02.
- Existing terminal, artifact, session and output regressions: 13 passed.
- Target set and pristine session chain: consistent/intact after recompilation.

## Scenario catalog

- S01 clean control
- S02 branch-heavy loops
- S03 invalid and irrelevant answers
- S04 backtrack and correction
- S05 incomplete hard stop

Long branch/remediation and restore scenarios are included for external execution. The isolated subprocess harness is intentionally conservative and may run longer than a single chat tool timeout; timeout is not treated as a semantic pass.

## Readiness decision

RC16 is ready for cross-model scenario execution. Clean path behavior remains inherited from accepted RC15; branch and invalid-input coverage are materially improved.
