# Toolchain Scoped Repair

The pinned baseline `flow_reuse_validation.detect_reuse_candidates` recursively embedded full successor signatures during its bounded fixed-point pass. On cyclic or moderately sized graphs this caused exponential string growth and lint timeout.

Scoped local repair: canonical node signatures are SHA-256 hashed at each iteration. Structural equality semantics are preserved; only representation size changes. No playbook validation rule was removed or weakened.
