# RC17 Rollback and Rejoin Hardening

Targeted patch over RC16; process tree and business contracts were not rebuilt.

Changes:
- Structured correction-intent classification for restore operations.
- Explicit rollback transaction evidence: START, STATE.DIFF, IMPACT.ANALYZE, INVALIDATE, REVALIDATE, COMMIT.
- Restore impact metadata records changed/removed state fields and downstream revalidation requirement.
- Branch history explicitly records canonical rejoin confirmation when the rejoin node is accepted.
- Runtime stale-IR mtime tolerance hardened for ZIP timestamp granularity.

Validation:
- S04 rollback/correction scenario: passed.
- S03 invalid/future-node recovery: passed.
- S05 incomplete hard-stop: passed.
- Targeted rollback/rejoin + prior terminal/branch regressions: 13/13 passed.
- Long S02 branch-heavy subprocess suite remains a performance limitation of the monolithic harness; branch compilation and rejoin semantics are covered by targeted regressions.
