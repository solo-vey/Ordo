# Collected Attributes

| ID | Attribute | Value | Status | Source |
|---|---|---|---|---|
| P01 | company_legal_name | Northstar Analytics GmbH | confirmed | N01_BUSINESS_INITIATION |
| P02 | company_brand_name | Northstar | confirmed | N01_BUSINESS_INITIATION |
| P03 | company_industry | B2B SaaS / аналітика ланцюгів постачання | confirmed | N01_BUSINESS_INITIATION |
| P04 | company_headquarters_country | Німеччина | confirmed | N01_BUSINESS_INITIATION |
| P05 | company_size_employees | 420 | confirmed | N01_BUSINESS_INITIATION |
| P06 | office_business_goal | Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі | confirmed | N01_BUSINESS_INITIATION |
| P07 | target_country | Польща | confirmed | N02_GEOGRAPHY_AND_TARGET_DATE |
| P08 | target_city | Краків | confirmed | N02_GEOGRAPHY_AND_TARGET_DATE |
| P09 | target_opening_date | 2027-03-15 | confirmed | N02_GEOGRAPHY_AND_TARGET_DATE |
| P10 | initial_budget | 2 400 000 EUR | confirmed | N03_INITIAL_BUDGET |
| P11 | planned_headcount_year1 | 85 | confirmed | N04_HEADCOUNT_PLANNING |
| P12 | planned_headcount_year3 | 180 | confirmed | N04_HEADCOUNT_PLANNING |
| P13 | work_model | hybrid | confirmed | N05_WORK_MODEL_AND_SPACE |
| P14 | required_workspace_count | 110 | confirmed | N05_WORK_MODEL_AND_SPACE |
| P15 | required_meeting_rooms | 8 | confirmed | N05_WORK_MODEL_AND_SPACE |
| P16 | special_space_requirements | Серверна кімната, дві phone-booth зони, training room на 30 осіб | confirmed | N05_WORK_MODEL_AND_SPACE |
| P17 | location_priority | Транспортна доступність і близькість до talent hub | confirmed | N06_LOCATION_SEARCH_CRITERIA |
| P18 | maximum_commute_target | 45 хвилин для 80% працівників | confirmed | N06_LOCATION_SEARCH_CRITERIA |
| P19 | candidate_location_count | 5 | confirmed | N06_LOCATION_SEARCH_CRITERIA |
| P20 | preferred_lease_term_months | 60 | confirmed | N06_LOCATION_SEARCH_CRITERIA |
| P21 | maximum_monthly_rent | 58 000 EUR без комунальних витрат | confirmed | N06_LOCATION_SEARCH_CRITERIA |
| P22 | legal_entity_required | False | confirmed | N07_LEGAL_AND_REGULATORY_MODEL |
| P23 | regulatory_constraints | Дотримання польського трудового законодавства, GDPR, пожежних норм і локальних вимог охорони праці | confirmed | N07_LEGAL_AND_REGULATORY_MODEL |
| P24 | tax_model | Польська Sp. z o.o. як локальна операційна компанія з transfer-pricing agreement із материнською компанією | confirmed | N07_LEGAL_AND_REGULATORY_MODEL |
| P25 | employment_model | Пряме локальне працевлаштування через польську юридичну особу | confirmed | N07_LEGAL_AND_REGULATORY_MODEL |
| P26 | visa_support_required | True | confirmed | N07_LEGAL_AND_REGULATORY_MODEL |
| P27 | data_residency_requirement | Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі | confirmed | N07_LEGAL_AND_REGULATORY_MODEL |
| P28 | accessibility_standard | Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця | confirmed | N07_LEGAL_AND_REGULATORY_MODEL |
| P29 | selected_location_address | Mogilska 35, 31-545 Kraków, Poland | confirmed | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P30 | backup_location_address | Pawia 23, 31-154 Kraków, Poland | confirmed | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P31 | usable_area_sqm | 1 850 м² | confirmed | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P32 | technical_readiness_score | 82 зі 100 | confirmed | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION |
| P33 | renovation_scope | Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні | confirmed | N12_RENOVATION_AND_FIT_OUT_DESIGN |
| P34 | renovation_budget | 740 000 EUR | confirmed | N12_RENOVATION_AND_FIT_OUT_DESIGN |
| P35 | fitout_deadline | 2027-02-12 | confirmed | N12_RENOVATION_AND_FIT_OUT_DESIGN |
| P36 | network_capacity_requirement | Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання | confirmed | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P37 | server_room_required | True | confirmed | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P38 | physical_security_level | Підвищений | confirmed | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P39 | access_control_model | Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком | confirmed | N13_IT_AND_PHYSICAL_SECURITY_DESIGN |
| P40 | furniture_standard | Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце | confirmed | N14_WORKPLACE_STANDARD |
| P41 | primary_general_contractor | BuildCore Polska Sp. z o.o. | confirmed | N15_CONTRACTORS_AND_SUPPLIERS |
| P42 | critical_supplier_count | 6 | confirmed | N15_CONTRACTORS_AND_SUPPLIERS |
| P43 | local_hiring_target | 65 нових працівників у перший рік | confirmed | N16_PEOPLE_PLAN |
| P44 | relocation_target | 20 працівників із Німеччини, Чехії та України | confirmed | N16_PEOPLE_PLAN |
| P45 | local_hr_owner | Anna Kowalska, Head of People Poland | confirmed | N16_PEOPLE_PLAN |
| P46 | local_it_owner | Marek Zieliński, Regional IT Manager | confirmed | N17_OPERATIONAL_OWNERS |
| P47 | local_facilities_owner | Katarzyna Nowak, Workplace Operations Lead | confirmed | N17_OPERATIONAL_OWNERS |
| P48 | readiness_test_date | 2027-02-22 | confirmed | N18_READINESS_TEST |
| P49 | pilot_day_participants | 24 | confirmed | N19_PILOT_DAY |
| P50 | final_opening_decision | conditional open | confirmed | N20_FINAL_DECISION_AND_PACKAGE |
| P51 | opening_condition_fire_safety | Fire-safety certification | confirmed | N20_FINAL_DECISION_AND_PACKAGE |
| P52 | opening_condition_backup_internet | Backup internet connection | confirmed | N20_FINAL_DECISION_AND_PACKAGE |
| P53 | opening_condition_accessibility | Accessibility observations | confirmed | N20_FINAL_DECISION_AND_PACKAGE |
| P54 | opening_condition_relocation_visas | Relocation visas | confirmed | N20_FINAL_DECISION_AND_PACKAGE |
