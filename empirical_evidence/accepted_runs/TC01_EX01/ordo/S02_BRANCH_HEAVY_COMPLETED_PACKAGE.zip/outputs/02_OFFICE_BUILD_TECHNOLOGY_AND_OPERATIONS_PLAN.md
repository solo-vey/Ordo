# Office Build, Technology & Operations Plan

**Company:** Northstar Analytics GmbH  
**Brand:** Northstar  
**Location:** Mogilska 35, 31-545 Kraków, Poland  
**Target opening:** 2027-03-15

## 1. Facility and fit-out plan

The company will establish the new office in a facility with **1 850 м²** of usable area. The selected location has a **technical readiness score of 82 зі 100**.

The fit-out scope is:

**Середній fit-out: перепланування переговорних, нова кабельна система, акустичні панелі та оновлення кухні**

The approved renovation budget is **740 000 EUR**, with fit-out completion required by **2027-02-12**.

The office furniture and workstation standard is:

**Регульовані столи, ергономічні крісла, два монітори 27 дюймів на стандартне робоче місце**

## 2. Technology infrastructure

The network-capacity requirement is:

**Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання**

The office requires a dedicated server room.


A dedicated server-room implementation block must cover controlled access, environmental monitoring, power resilience and operational ownership.


The applicable data-residency requirement is:

**Персональні дані працівників зберігаються в ЄС; production customer data не зберігається локально в офісі**

The regional technology workstream is owned by **Marek Zieliński, Regional IT Manager**.

## 3. Physical security and access

The required physical-security level is **Підвищений**.

The access-control model is:

**Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком**


A dedicated security implementation plan must cover restricted zones, visitor handling, access logging and review responsibilities.


The facility must also comply with the accessibility standard:

**Безбар’єрний доступ, ліфт, адаптований санвузол і щонайменше 4 доступні робочі місця**

## 4. Contractors and critical suppliers

The primary general contractor is **BuildCore Polska Sp. z o.o.**.

The programme has **6 critical suppliers**.


A supplier dependency register must be maintained for every supplier whose delivery can affect the opening date, cost or readiness status.


If a critical supplier cannot meet the agreed deadline or budget, the supplier must be replaced and the impact on renovation scope, budget and fit-out deadline reassessed.

## 5. People and operating model

The company plans to hire **65 нових працівників у перший рік** and relocate **20 працівників із Німеччини, Чехії та України**.


A dedicated relocation workstream must cover visa support, arrival scheduling, employment onboarding and coordination with the local legal entity.


The local people workstream is owned by **Anna Kowalska, Head of People Poland**. Technology operations are owned by **Marek Zieliński, Regional IT Manager**. Workplace and facilities readiness are owned by **Katarzyna Nowak, Workplace Operations Lead**.

These owners form the operational-readiness group and are responsible for resolving cross-functional dependencies before the formal readiness test.

## 6. Delivery controls

The programme will use the following control points:

- fit-out complete by **2027-02-12**;
- renovation spend maintained within **740 000 EUR**;
- network and security infrastructure available before readiness testing;
- all **6** critical supplier dependencies reviewed regularly;
- server-room controls validated before operational use;
- relocation activities coordinated with HR, immigration and onboarding owners;
- unresolved blocking defects routed back to the responsible workstream.

The formal readiness test is scheduled for **2027-02-22**.

Any blocking defect identified during this test must create a remediation action with an owner and deadline. The affected workstream must be revalidated before pilot operation.

## 7. Operational readiness summary

The current plan must be assessed against the selected location, approved renovation scope, infrastructure requirements, supplier dependencies and operating-owner assignments.

Final opening approval is outside this document and must be recorded in the Office Readiness & Opening Decision Report.
