# Execution Trace

| Step | Node | Status | Transition |
|---:|---|---|---|
| 1 | N01_BUSINESS_INITIATION | accepted | canonical runtime transition |
| 2 | N02_GEOGRAPHY_AND_TARGET_DATE | accepted | canonical runtime transition |
| 3 | N03_INITIAL_BUDGET | accepted | canonical runtime transition |
| 4 | N04_HEADCOUNT_PLANNING | accepted | canonical runtime transition |
| 5 | N05_WORK_MODEL_AND_SPACE | accepted | canonical runtime transition |
| 6 | N06_LOCATION_SEARCH_CRITERIA | accepted | canonical runtime transition |
| 7 | N07_LEGAL_AND_REGULATORY_MODEL | accepted | canonical runtime transition |
| 8 | N07B_LEGAL_ENTITY_REGISTRATION | not_applicable | skipped because legal_entity_required=false |
| 9 | N08_CANDIDATE_LOCATION_SEARCH | accepted | canonical runtime transition |
| 10 | N09_PRELIMINARY_LOCATION_SCREENING | accepted | canonical runtime transition |
| 11 | N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION | accepted | canonical runtime transition |
| 12 | N11_LEASE_NEGOTIATION | accepted | canonical runtime transition |
| 13 | N11D_GENERATE_DOCUMENT_1 | accepted | canonical runtime transition |
| 14 | N12_RENOVATION_AND_FIT_OUT_DESIGN | accepted | canonical runtime transition |
| 15 | N13_IT_AND_PHYSICAL_SECURITY_DESIGN | accepted | canonical runtime transition |
| 16 | N14_WORKPLACE_STANDARD | accepted | canonical runtime transition |
| 17 | N15_CONTRACTORS_AND_SUPPLIERS | accepted | canonical runtime transition |
| 18 | N12_RENOVATION_AND_FIT_OUT_DESIGN | accepted | canonical runtime transition |
| 19 | N13_IT_AND_PHYSICAL_SECURITY_DESIGN | accepted | canonical runtime transition |
| 20 | N14_WORKPLACE_STANDARD | accepted | canonical runtime transition |
| 21 | N15_CONTRACTORS_AND_SUPPLIERS | accepted | canonical runtime transition |
| 22 | N16_PEOPLE_PLAN | accepted | canonical runtime transition |
| 23 | N17_OPERATIONAL_OWNERS | accepted | canonical runtime transition |
| 24 | N17D_GENERATE_DOCUMENT_2 | accepted | canonical runtime transition |
| 25 | N18_READINESS_TEST | accepted | canonical runtime transition |
| 26 | N18B_REMEDIATION_ROUTER | accepted | canonical runtime transition |
| 27 | N12_RENOVATION_AND_FIT_OUT_DESIGN | accepted | canonical runtime transition |
| 28 | N13_IT_AND_PHYSICAL_SECURITY_DESIGN | accepted | canonical runtime transition |
| 29 | N14_WORKPLACE_STANDARD | accepted | canonical runtime transition |
| 30 | N15_CONTRACTORS_AND_SUPPLIERS | accepted | canonical runtime transition |
| 31 | N16_PEOPLE_PLAN | accepted | canonical runtime transition |
| 32 | N17_OPERATIONAL_OWNERS | accepted | canonical runtime transition |
| 33 | N17D_GENERATE_DOCUMENT_2 | accepted | canonical runtime transition |
| 34 | N18_READINESS_TEST | accepted | canonical runtime transition |
| 35 | N18B_REMEDIATION_ROUTER | accepted | canonical runtime transition |
| 36 | N12_RENOVATION_AND_FIT_OUT_DESIGN | accepted | canonical runtime transition |
| 37 | N13_IT_AND_PHYSICAL_SECURITY_DESIGN | accepted | canonical runtime transition |
| 38 | N14_WORKPLACE_STANDARD | accepted | canonical runtime transition |
| 39 | N15_CONTRACTORS_AND_SUPPLIERS | accepted | canonical runtime transition |
| 40 | N16_PEOPLE_PLAN | accepted | canonical runtime transition |
| 41 | N17_OPERATIONAL_OWNERS | accepted | canonical runtime transition |
| 42 | N17D_GENERATE_DOCUMENT_2 | accepted | canonical runtime transition |
| 43 | N18_READINESS_TEST | accepted | canonical runtime transition |
| 44 | N19_PILOT_DAY | accepted | canonical runtime transition |
| 45 | N20_FINAL_DECISION_AND_PACKAGE | accepted | canonical runtime transition |
| 46 | N20D_GENERATE_DOCUMENT_3 | accepted | canonical runtime transition |
| pending | N20V_VALIDATE_FINAL_PACKAGE | current | validation gate |
| target | T_COMPLETED | expected | terminal transition after GO |
