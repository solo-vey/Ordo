# Office Readiness & Opening Decision Report

**Company:** Northstar Analytics GmbH  
**Brand:** Northstar  
**Office:** Mogilska 35, 31-545 Kraków, Poland  
**Target opening date:** 2027-03-15  
**Final decision:** **conditional open**

## 1. Executive readiness assessment

The office programme supports the following business objective:

**Створити регіональний центр розробки та підтримки клієнтів у Центральній Європі**

The programme operates within an initial budget envelope of **2 400 000 EUR** and targets formal opening on **2027-03-15**.

The selected office received a technical readiness score of **82 зі 100**.

The final readiness decision is:

> **conditional open**




## 2. Facility and delivery readiness

The primary office location is **Mogilska 35, 31-545 Kraków, Poland**.

The backup location is **Pawia 23, 31-154 Kraków, Poland**.

The approved renovation budget is **740 000 EUR**, with fit-out completion planned for **2027-02-12**. The primary general contractor is **BuildCore Polska Sp. z o.o.**.

The delivery programme depends on **6 critical suppliers**.

The formal readiness test is scheduled for **2027-02-22**.

## 3. Technology and security readiness

The office technology and network requirement is:

**Два незалежні канали по 2 Гбіт/с, корпоративний Wi-Fi 6E, резервування ключового мережевого обладнання**

A dedicated server room is required and included in the readiness scope.

The required physical-security level is **Підвищений**, using the following access-control model:

**Іменні картки, зональний доступ, журналювання входів і гостьові перепустки з обмеженим строком**

Technology readiness is owned by **Marek Zieliński, Regional IT Manager**. Workplace and facilities readiness are owned by **Katarzyna Nowak, Workplace Operations Lead**.

## 4. People and operating readiness

The office programme targets **65 нових працівників у перший рік** and relocation of **20 працівників із Німеччини, Чехії та України**.

The people workstream is owned by **Anna Kowalska, Head of People Poland**.

Visa support remains part of the people-readiness scope.


Outstanding visa cases must be tracked and must not result in employees beginning work without the required legal status.


## 5. Pilot day result

A pilot working day was conducted with **24 participants**.

Pilot coverage included workplace access, network availability, core collaboration tools, visitor handling, and facilities support. The remediated power issue was rechecked; no blocking defect remained, and the pilot supports the conditional opening decision.

## 6. Opening conditions and blockers


| Condition | Responsible owner | Deadline | Required evidence | Status |
|---|---|---|---|---|
| Fire-safety certification | Katarzyna Nowak, Workplace Operations Lead | Before 2027-03-15 | Final certification and archived evidence | Open |
| Backup internet connection | Marek Zieliński, Regional IT Manager | Before 2027-03-15 | Activation and failover test evidence | Open |
| Accessibility observations | Katarzyna Nowak, Workplace Operations Lead | Before full-readiness declaration | Remediation and accessibility recheck | Open |
| Relocation visas | Anna Kowalska, Head of People Poland | Before affected employees start work | Completed visa documentation | Open |




## 7. Decision

The opening decision is:

> **conditional open**

The decision must be interpreted against the readiness-test result, pilot-day findings, supplier dependencies, people readiness, technology readiness and unresolved opening conditions.

## 8. Final package status

This report is the final readiness and decision component of `OFFICE_OPENING_PACKAGE`.

It must be packaged together with:

1. `01_OFFICE_OPENING_BUSINESS_AND_LOCATION_BRIEF.md`
2. `02_OFFICE_BUILD_TECHNOLOGY_AND_OPERATIONS_PLAN.md`
3. `03_OFFICE_READINESS_AND_OPENING_DECISION_REPORT.md`
