# Result Summary

- RUN_ID: `RUN_04`
- terminal actually reached: `T_COMPLETED`
- CONTROL: `END_RUN`
- received_event_count: 32
- accepted_event_count: 31
- blocked_event_count: 1
- Driver contaminated: false
- final_opening_decision: `conditional open`
