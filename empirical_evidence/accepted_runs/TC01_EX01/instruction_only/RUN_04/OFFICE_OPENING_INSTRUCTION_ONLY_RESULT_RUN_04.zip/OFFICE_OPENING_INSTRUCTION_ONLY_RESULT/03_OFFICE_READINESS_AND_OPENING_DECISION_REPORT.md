# Office Readiness & Opening Decision Report

## 1. Підсумкова оцінка
Тест готовності проведено **2027-02-22**, результат: **passed**. Пілотний день завершено: True; учасників: 24.

## 2. Рішення
Фінальне рішення: **conditional open**.

## 3. Умови відкриття
| Condition | Responsible owner | Deadline | Required evidence | Status |
|---|---|---|---|---|
| Fire-safety certification | Katarzyna Nowak, Workplace Operations Lead | До 2027-03-15 | Final certification and archived evidence | Open |
| Backup internet connection | Marek Zieliński, Regional IT Manager | До 2027-03-15 | Activation and failover test evidence | Open |
| Accessibility observations | Katarzyna Nowak, Workplace Operations Lead | До повної декларації готовності | Remediation and accessibility recheck | Open |
| Relocation visas | Anna Kowalska, Head of People Poland | До початку роботи відповідних працівників | Completed visa documentation | Open |

## 4. Статус пакета
Фінальний пакет готовий: **True**. Фактичний термінал процесу: **T_COMPLETED**.
