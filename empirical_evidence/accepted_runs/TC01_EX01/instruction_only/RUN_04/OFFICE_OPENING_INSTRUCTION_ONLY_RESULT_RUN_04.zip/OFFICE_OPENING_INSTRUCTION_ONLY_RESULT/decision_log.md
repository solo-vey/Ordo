# Decision Log

## E01
- delivery_step: `N01_BUSINESS_INITIATION`
- submit_to: `N01_BUSINESS_INITIATION`
- occurrence: `1`
- classification: `accepted`
- result_step: `N02_GEOGRAPHY_AND_TARGET_DATE`
- rationale: Вхід відповідає активному кроку.

## E02
- delivery_step: `N02_GEOGRAPHY_AND_TARGET_DATE`
- submit_to: `N02_GEOGRAPHY_AND_TARGET_DATE`
- occurrence: `1`
- classification: `accepted`
- result_step: `N03_INITIAL_BUDGET`
- rationale: Вхід відповідає активному кроку.

## E03
- delivery_step: `N03_INITIAL_BUDGET`
- submit_to: `N03_INITIAL_BUDGET`
- occurrence: `1`
- classification: `accepted`
- result_step: `N04_HEADCOUNT_PLANNING`
- rationale: Вхід відповідає активному кроку.

## E04
- delivery_step: `N04_HEADCOUNT_PLANNING`
- submit_to: `N04_HEADCOUNT_PLANNING`
- occurrence: `1`
- classification: `accepted`
- result_step: `N05_WORK_MODEL_AND_SPACE`
- rationale: Вхід відповідає активному кроку.

## E05
- delivery_step: `N05_WORK_MODEL_AND_SPACE`
- submit_to: `N05_WORK_MODEL_AND_SPACE`
- occurrence: `1`
- classification: `accepted`
- result_step: `N06_LOCATION_SEARCH_CRITERIA`
- rationale: Вхід відповідає активному кроку.

## E06
- delivery_step: `N06_LOCATION_SEARCH_CRITERIA`
- submit_to: `N06_LOCATION_SEARCH_CRITERIA`
- occurrence: `1`
- classification: `accepted`
- result_step: `N07_LEGAL_AND_REGULATORY_MODEL`
- rationale: Вхід відповідає активному кроку.

## E07
- delivery_step: `N07_LEGAL_AND_REGULATORY_MODEL`
- submit_to: `N07_LEGAL_AND_REGULATORY_MODEL`
- occurrence: `1`
- classification: `accepted`
- result_step: `N07B_LEGAL_ENTITY_REGISTRATION`
- rationale: Вхід відповідає активному кроку.

## E08
- delivery_step: `N07B_LEGAL_ENTITY_REGISTRATION`
- submit_to: `N07B_LEGAL_ENTITY_REGISTRATION`
- occurrence: `1`
- classification: `accepted`
- result_step: `N08_CANDIDATE_LOCATION_SEARCH`
- rationale: Вхід відповідає активному кроку.

## E09
- delivery_step: `N08_CANDIDATE_LOCATION_SEARCH`
- submit_to: `N08_CANDIDATE_LOCATION_SEARCH`
- occurrence: `1`
- classification: `accepted`
- result_step: `N09_PRELIMINARY_LOCATION_SCREENING`
- rationale: Вхід відповідає активному кроку.

## E10
- delivery_step: `N09_PRELIMINARY_LOCATION_SCREENING`
- submit_to: `N09_PRELIMINARY_LOCATION_SCREENING`
- occurrence: `1`
- classification: `accepted`
- result_step: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- rationale: Вхід відповідає активному кроку.

## E11
- delivery_step: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- submit_to: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- occurrence: `1`
- classification: `accepted`
- result_step: `N11_LEASE_NEGOTIATION`
- rationale: Вхід відповідає активному кроку.

## E12
- delivery_step: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- submit_to: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- occurrence: `2`
- classification: `blocked`
- result_step: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- rationale: Відсутні обов’язкові поля: selected_location_address, backup_location_address, usable_area_sqm, technical_readiness_score

## E13
- delivery_step: `N05_WORK_MODEL_AND_SPACE`
- submit_to: `N05_WORK_MODEL_AND_SPACE`
- occurrence: `2`
- classification: `accepted`
- result_step: `N05_WORK_MODEL_AND_SPACE`
- rationale: Вхід відповідає активному кроку.

## E14
- delivery_step: `N06_LOCATION_SEARCH_CRITERIA`
- submit_to: `N06_LOCATION_SEARCH_CRITERIA`
- occurrence: `2`
- classification: `accepted`
- result_step: `N06_LOCATION_SEARCH_CRITERIA`
- rationale: Вхід відповідає активному кроку.

## E15
- delivery_step: `N07_LEGAL_AND_REGULATORY_MODEL`
- submit_to: `N07_LEGAL_AND_REGULATORY_MODEL`
- occurrence: `2`
- classification: `accepted`
- result_step: `N07_LEGAL_AND_REGULATORY_MODEL`
- rationale: Вхід відповідає активному кроку.

## E16
- delivery_step: `N07B_LEGAL_ENTITY_REGISTRATION`
- submit_to: `N07B_LEGAL_ENTITY_REGISTRATION`
- occurrence: `2`
- classification: `accepted`
- result_step: `N07B_LEGAL_ENTITY_REGISTRATION`
- rationale: Вхід відповідає активному кроку.

## E17
- delivery_step: `N08_CANDIDATE_LOCATION_SEARCH`
- submit_to: `N08_CANDIDATE_LOCATION_SEARCH`
- occurrence: `2`
- classification: `accepted`
- result_step: `N08_CANDIDATE_LOCATION_SEARCH`
- rationale: Вхід відповідає активному кроку.

## E18
- delivery_step: `N09_PRELIMINARY_LOCATION_SCREENING`
- submit_to: `N09_PRELIMINARY_LOCATION_SCREENING`
- occurrence: `2`
- classification: `accepted`
- result_step: `N09_PRELIMINARY_LOCATION_SCREENING`
- rationale: Вхід відповідає активному кроку.

## E19
- delivery_step: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- submit_to: `N10_PRIMARY_AND_BACKUP_LOCATION_SELECTION`
- occurrence: `3`
- classification: `accepted`
- result_step: `N11_LEASE_NEGOTIATION`
- rationale: Вхід відповідає активному кроку.

## E20
- delivery_step: `N11_LEASE_NEGOTIATION`
- submit_to: `N11_LEASE_NEGOTIATION`
- occurrence: `1`
- classification: `accepted`
- result_step: `N12_RENOVATION_AND_FIT_OUT_DESIGN`
- rationale: Вхід відповідає активному кроку.

## E21
- delivery_step: `N11D_GENERATE_DOCUMENT_1`
- submit_to: `N11D_GENERATE_DOCUMENT_1`
- occurrence: `1`
- classification: `accepted`
- result_step: `N11D_GENERATE_DOCUMENT_1`
- rationale: Вхід відповідає активному кроку.

## E22
- delivery_step: `N12_RENOVATION_AND_FIT_OUT_DESIGN`
- submit_to: `N12_RENOVATION_AND_FIT_OUT_DESIGN`
- occurrence: `1`
- classification: `accepted`
- result_step: `N12_RENOVATION_AND_FIT_OUT_DESIGN`
- rationale: Вхід відповідає активному кроку.

## E23
- delivery_step: `N13_IT_AND_PHYSICAL_SECURITY_DESIGN`
- submit_to: `N13_IT_AND_PHYSICAL_SECURITY_DESIGN`
- occurrence: `1`
- classification: `accepted`
- result_step: `N13_IT_AND_PHYSICAL_SECURITY_DESIGN`
- rationale: Вхід відповідає активному кроку.

## E24
- delivery_step: `N14_WORKPLACE_STANDARD`
- submit_to: `N14_WORKPLACE_STANDARD`
- occurrence: `1`
- classification: `accepted`
- result_step: `N14_WORKPLACE_STANDARD`
- rationale: Вхід відповідає активному кроку.

## E25
- delivery_step: `N15_CONTRACTORS_AND_SUPPLIERS`
- submit_to: `N15_CONTRACTORS_AND_SUPPLIERS`
- occurrence: `1`
- classification: `accepted`
- result_step: `N15_CONTRACTORS_AND_SUPPLIERS`
- rationale: Вхід відповідає активному кроку.

## E26
- delivery_step: `N16_PEOPLE_PLAN`
- submit_to: `N16_PEOPLE_PLAN`
- occurrence: `1`
- classification: `accepted`
- result_step: `N16_PEOPLE_PLAN`
- rationale: Вхід відповідає активному кроку.

## E27
- delivery_step: `N17_OPERATIONAL_OWNERS`
- submit_to: `N17_OPERATIONAL_OWNERS`
- occurrence: `1`
- classification: `accepted`
- result_step: `N17_OPERATIONAL_OWNERS`
- rationale: Вхід відповідає активному кроку.

## E28
- delivery_step: `N17D_GENERATE_DOCUMENT_2`
- submit_to: `N17D_GENERATE_DOCUMENT_2`
- occurrence: `1`
- classification: `accepted`
- result_step: `N17D_GENERATE_DOCUMENT_2`
- rationale: Вхід відповідає активному кроку.

## E29
- delivery_step: `N18_READINESS_TEST`
- submit_to: `N18_READINESS_TEST`
- occurrence: `1`
- classification: `accepted`
- result_step: `N19_PILOT_DAY`
- rationale: Payload містить readiness_test_date і readiness_status; подію прийнято.

## E30
- delivery_step: `N19_PILOT_DAY`
- submit_to: `N19_PILOT_DAY`
- occurrence: `1`
- classification: `accepted`
- result_step: `N20_FINAL_DECISION_AND_PACKAGE`
- rationale: Вхід відповідає активному кроку.

## E31
- delivery_step: `N20_FINAL_DECISION_AND_PACKAGE`
- submit_to: `N20_FINAL_DECISION_AND_PACKAGE`
- occurrence: `1`
- classification: `accepted`
- result_step: `N20D_GENERATE_DOCUMENT_3`
- rationale: Вхід відповідає активному кроку.

## E32
- delivery_step: `N20D_GENERATE_DOCUMENT_3`
- submit_to: `N20D_GENERATE_DOCUMENT_3`
- occurrence: `1`
- classification: `accepted`
- result_step: `T_COMPLETED`
- rationale: Документ 3 і фінальний пакет підтверджено.
