# Manual QA package — RECORD_PROCESSING_STATE_CHANGED

## 1. Status and runtime-value capture
Status: `blocked_missing_binding`; live execution: `not_run`.
Capture `${BASE_URL}` from the approved test environment deployment record, `${AUTH_HEADERS}` from the approved secret-injection/runbook output without exposing secrets, and `${DATABASE_NAME}` from the approved runner configuration. No other runtime placeholders are permitted.

## 2. QA/dev data index
| Case | changeId | documentId | field/status | old/new | expected |
|---|---|---|---|---|---|
| MQA-01 | RUN02-MQA01-CHG | RUN02-MQA01-DOC | item.processingState/modified | null/approved | 1 event |
| MQA-02 | RUN02-MQA02-CHG | RUN02-MQA02-DOC | item.processingState/modified | missing/empty | 0 events |
| MQA-03 | RUN02-MQA03-CHG | RUN02-MQA03-DOC | item.name/modified | A/B | 0 target events |
| MQA-04 | RUN02-MQA04-CHG | RUN02-MQA04-DOC | item.processingState/added | null/approved | 0 events |

## 3. Compact test index
TC-01→MQA-01; TC-02→MQA-02; TC-03→MQA-03; TC-04→MQA-04.

## 4. Test cases

## MQA-01 — Meaningful transition
Functional TC: TC-01
execution_level: operational
evidence_status: blocked_missing_evidence
authoritative_binding: runtime/CASE_STATUS_REGISTRY.yaml
blocker_source: executable runner endpoint and database binding
blocked_reason: live operational execution cannot start without validated runtime bindings
missing_capability: executable endpoint, database, collection, authentication, and runner binding
required_evidence: validated runner configuration naming each binding and successful preflight output
### Goal
Verify null→approved produces exactly one event with exact payload.
### Preconditions and exact case-local data
Use IDs above; source baseline has `item.processingState:null`.
### Step 0. Preflight baseline
`mongosh "${DATABASE_NAME}" --eval 'db.source_records.find({document_id:"RUN02-MQA01-DOC"},{_id:0,document_id:1,"item.processingState":1}).toArray()'`; assert count=1 and value null. Restore via approved source mutation binding if different.
### Step 1. Source lookup before action
Repeat query; assert count=1 and null.
### Step 2. REST action
`curl -sS -X POST "${BASE_URL}/api/test/database-change/publish" ${AUTH_HEADERS} -H 'Content-Type: application/json' -d '{"changeId":"RUN02-MQA01-CHG","documentId":"RUN02-MQA01-DOC","recordKey":"RUN02-MQA01-REC","operationStatus":"modified","fieldPath":"item.processingState","oldValue":null,"newValue":"approved"}'`; assert HTTP 200.
### Step 3. Source state after action
Query source by documentId; assert one record and new state approved only if authoritative endpoint mutates source; otherwise assert unchanged per binding.
### Step 4. ChangeRecord lookup
Query `change_records` by changeId; assert count=1 and exact operationStatus, fieldPath, oldValue null, newValue approved.
### Step 5. Processor invocation
POST `${BASE_URL}/api/database-change/process` with `{"changeId":"RUN02-MQA01-CHG","ruleId":"RULE_RECORD_PROCESSING_STATE_CHANGED"}`; assert HTTP 200.
### Step 6. Generated event assertion
Query `generated_events` by changeId and event_type; assert count=1, type exact, values key set exactly oldValue/newValue, oldValue null, newValue approved.
### Step 7. Error assertion
Query `change_errors` by changeId/rule; assert count=0.
### Step 8. Source rollback
Use approved mutation binding to restore null; blocked until DEP-01 closes.
### Step 9. Source state after rollback
Query source; assert count=1 and null.
### Final expected result
One event, zero errors.
### Diagnostics
Capture HTTP bodies and query outputs only after main assertions.

## MQA-02 — Normalized empty no-op
Functional TC: TC-02
execution_level: operational
evidence_status: blocked_missing_evidence
authoritative_binding: runtime/CASE_STATUS_REGISTRY.yaml
blocker_source: executable runner endpoint and database binding
blocked_reason: live operational execution cannot start without validated runtime bindings
missing_capability: executable endpoint, database, collection, authentication, and runner binding
required_evidence: validated runner configuration naming each binding and successful preflight output
### Goal
Verify missing old value and empty new value produce no event.
### Preconditions and exact case-local data
IDs above; oldValue omitted, newValue empty.
### Step 0. Preflight baseline
Query source by documentId; assert one record and processingState absent.
### Step 1. Source lookup before action
Repeat exact query and assertion.
### Step 2. REST action
POST publish with complete body except intentionally omitted oldValue: `{"changeId":"RUN02-MQA02-CHG","documentId":"RUN02-MQA02-DOC","recordKey":"RUN02-MQA02-REC","operationStatus":"modified","fieldPath":"item.processingState","newValue":""}`; assert 200 only after omission binding is confirmed.
### Step 3. Source state after action
Assert source cardinality one and processingState absent/empty according to binding.
### Step 4. ChangeRecord lookup
Assert the authoritative lifecycle: either one persisted change with omission preserved or zero changes; exact branch is blocked until binding evidence.
### Step 5. Processor invocation
If change exists, invoke processor with exact changeId/ruleId; otherwise Not applicable because no change exists.
### Step 6. Generated event assertion
Query target event by changeId/type; assert count=0.
### Step 7. Error assertion
Query errors; assert count=0.
### Step 8. Source rollback
Not applicable when no mutation; otherwise restore absent baseline using approved binding.
### Step 9. Source state after rollback
Assert one source record and absent baseline.
### Final expected result
Zero target events and zero errors.
### Diagnostics
Capture branch evidence; do not treat ambiguity as pass.

## MQA-03 — Unrelated field no-op
Functional TC: TC-03
execution_level: operational
evidence_status: blocked_missing_evidence
authoritative_binding: runtime/CASE_STATUS_REGISTRY.yaml
blocker_source: executable runner endpoint and database binding
blocked_reason: live operational execution cannot start without validated runtime bindings
missing_capability: executable endpoint, database, collection, authentication, and runner binding
required_evidence: validated runner configuration naming each binding and successful preflight output
### Goal
Verify `item.name` does not create the target event.
### Preconditions and exact case-local data
oldValue=A, newValue=B, modified.
### Step 0. Preflight baseline
Query source; assert one record and item.name=A.
### Step 1. Source lookup before action
Repeat.
### Step 2. REST action
POST complete publish payload with changeId RUN02-MQA03-CHG, fieldPath item.name, A→B; assert 200.
### Step 3. Source state after action
Assert authoritative source result.
### Step 4. ChangeRecord lookup
Assert count=1 and exact unrelated field mapping.
### Step 5. Processor invocation
POST exact changeId/ruleId; assert 200.
### Step 6. Generated event assertion
Query target event type; assert count=0.
### Step 7. Error assertion
Assert count=0.
### Step 8. Source rollback
Restore item.name=A using approved binding.
### Step 9. Source state after rollback
Assert item.name=A.
### Final expected result
Zero target events, zero errors.
### Diagnostics
Capture outputs.

## MQA-04 — Non-modified no-op
Functional TC: TC-04
execution_level: operational
evidence_status: blocked_missing_evidence
authoritative_binding: runtime/CASE_STATUS_REGISTRY.yaml
blocker_source: executable runner endpoint and database binding
blocked_reason: live operational execution cannot start without validated runtime bindings
missing_capability: executable endpoint, database, collection, authentication, and runner binding
required_evidence: validated runner configuration naming each binding and successful preflight output
### Goal
Verify `added` status does not create the target event.
### Preconditions and exact case-local data
null→approved, status added.
### Step 0. Preflight baseline
Query source; assert one record and null.
### Step 1. Source lookup before action
Repeat.
### Step 2. REST action
POST complete payload with RUN02-MQA04-CHG and operationStatus added; assert 200.
### Step 3. Source state after action
Assert authoritative source result.
### Step 4. ChangeRecord lookup
Assert authoritative lifecycle and exact status if persisted.
### Step 5. Processor invocation
Invoke only if persisted; otherwise Not applicable.
### Step 6. Generated event assertion
Assert target event count=0.
### Step 7. Error assertion
Assert count=0.
### Step 8. Source rollback
Restore null if mutation occurred.
### Step 9. Source state after rollback
Assert null.
### Final expected result
Zero target events, zero errors.
### Diagnostics
Capture outputs.

## 5. Blocking gates
All four cases are specification-complete but blocked from live execution until DEP-01 closure evidence is supplied. Generated-record deletion is not required without an authoritative delete operation; unique IDs isolate evidence.
