# Record Change Passport — RECORD_PROCESSING_STATE_CHANGED

## 1. Статус документа
| Поле | Значення |
|---|---|
| Alias | `RECORD_PROCESSING_STATE_CHANGED` |
| Contract ID | `RULE_RECORD_PROCESSING_STATE_CHANGED` |
| Version | `1.0.0` |
| Document status | `candidate` |
| Evidence status | `mixed` |
| Confirmation source | `RUN_02 Driver-confirmed facts` |

## 2. Ідентичність правила
| Поле | Значення | Evidence |
|---|---|---|
| Alias | `RECORD_PROCESSING_STATE_CHANGED` | analyst-confirmed |
| Business name | Processing state changed | expected |
| Business meaning | Document a state-change contract that distinguishes meaningful changes from normalized no-op inputs. | analyst-confirmed |
| Event/output type | `RECORD_PROCESSING_STATE_CHANGED` | analyst-confirmed |

## 3. Обрана process branch та intake
| Крок | Підтверджене значення |
|---|---|
| Scenario | `RUN_02` |
| Source branch | fixed internal-record-change branch |
| Change kind/operation | `modified` |
| Target source path | `item.processingState` |
| Allowed operation/status values | create evaluation only for `modified`; other statuses are no-op |

## 4. Source record contract
| Поле | Значення | Evidence |
|---|---|---|
| Collection role | Open question; not confirmed by Driver | open question |
| Stable identifiers | Open question; not confirmed by Driver | open question |
| Target source path | `item.processingState` | analyst-confirmed |
| Baseline value | `null` | analyst-confirmed |
| Changed value | `approved` | analyst-confirmed |

## 5. Change record contract
| Поле | Значення | Evidence/source |
|---|---|---|
| Change ID | Open question | open question |
| Operation/status | `modified` | analyst-confirmed |
| Field path | `item.processingState` | analyst-confirmed |
| Old value source | Driver-confirmed old value: `null`; exact record location is open | mixed |
| New value source | Driver-confirmed new value: `approved`; exact record location is open | mixed |
| Occurred-at/date source | Open question | open question |
| Root/source identifiers | Open question | open question |

## 6. Порядок аналізу та decision contract
1. Validate that operation/status is `modified`; otherwise return no-op.
2. Validate that the changed field is `item.processingState`; an unrelated field is no-op.
3. Resolve required identifiers and date; unavailable mandatory mappings block creation.
4. Normalize old/new for comparison only: `null`, missing, and empty string become `""`; do not trim whitespace and do not change case.
5. If both normalized values are empty, return no-op.
6. If normalized values differ, build the output candidate.
7. Apply duplicate identity only when its confirmed contract becomes available; until then duplicate identity is open and blocks final-ready status.
8. Return create/no-op/blocked/error with an observable reason.

## 7. Derived event/output contract
| Output field | Value/source | Evidence/status |
|---|---|---|
| Type | `RECORD_PROCESSING_STATE_CHANGED` | analyst-confirmed |
| Identity/dedup key | Open question | open question |
| Source identifiers | Open question | open question |
| Field path | `item.processingState` | analyst-confirmed |
| Old value | `null` for positive reference | analyst-confirmed |
| New value | `approved` for positive reference | analyst-confirmed |
| Event date | Open question | open question |
| Values object | exactly `oldValue`, `newValue` | analyst-confirmed |

## 8. Exact mapping matrix
| Target | Source | Transformation | Missing behavior |
|---|---|---|---|
| `type` | confirmed event mapping | none | block |
| `values.oldValue` | old processing-state value | comparison normalization is not stored-display transformation | explicit `null` allowed in confirmed positive reference |
| `values.newValue` | new processing-state value | comparison normalization is not stored-display transformation | block if unavailable |
| field path decision | changed field path | exact equality to `item.processingState` | no-op |
| operation decision | change status | exact equality to `modified` | no-op |

## 9. Values shape та exact keys
| Key | Source | Stored semantics | Display semantics | Used by UI |
|---|---|---|---|---|
| `oldValue` | old processing-state value | raw confirmed value; comparison uses normalization | not confirmed | open |
| `newValue` | new processing-state value | raw confirmed value; comparison uses normalization | not confirmed | open |

No additional keys are permitted in the values object.

## 10. Normalization, trigger, no-op, missing-data та duplicate behavior
| Concern | Rule | Observable result |
|---|---|---|
| Comparison normalization | map `null`, missing, and `""` to `""`; do not trim and do not change case | deterministic normalized pair |
| Trigger | `status=modified`, field=`item.processingState`, normalized values differ | create candidate |
| No-op | both normalized values empty; unrelated field; status other than `modified` | no event and explicit reason |
| Missing required mapping | unavailable mandatory identifiers/date/output source | blocked and diagnostic |
| Duplicate | identity rule not confirmed | final-ready blocked; do not invent behavior |

## 11. UI / localization
Not confirmed for RUN_02. Localization strings and placeholders remain open questions and are not required to demonstrate the state-change/no-op contract.

## 12. Observability contract
| Decision | Required observable evidence |
|---|---|
| Created | one event candidate with type and exact two-key values object |
| No-op | reason identifies normalized-empty pair, unrelated field, or non-`modified` status |
| Blocked | missing mandatory mapping is named |
| Duplicate | open question; no unsupported assertion |
| Error | validator/runtime diagnostic with non-zero result |

## 13. Exclusions / out of scope
| Item | Reason |
|---|---|
| Unconfirmed runner compatibility | automation is only ready for runner validation; live-run status is `not_run` |
| Invented endpoint, database, collection, or credentials | not confirmed by Driver |
| Case-folding or whitespace trimming | explicitly forbidden by normalization contract |

## 14. Functional test contract
| ID | Назва | Requirement/rule | Preconditions/input | Action | Expected decision/output | Manual QA | Automation |
|---|---|---|---|---|---|---|---|
| `TC-01` | Meaningful state change | modified; target field; normalized values differ | field=`item.processingState`, old=`null`, new=`approved`, status=`modified` | evaluate contract | create one `RECORD_PROCESSING_STATE_CHANGED`; values exactly `{oldValue:null,newValue:"approved"}` | `MQA-01` covers the same lifecycle because it validates exact create cardinality | `AUTO-01` covers the behavior because it validates exact type and values; status `blocked_missing_binding` per registry  closure evidence: provide validated runner binding to unblock |
| `TC-02` | Normalized empty no-op | missing and empty normalize equally | old missing, new=`""`, status=`modified`, target field | evaluate contract | no event; reason normalized no-op | `MQA-02` covers the behavior because it validates zero event cardinality | `AUTO-02` covers normalization because it validates missing/empty equality; status `blocked_missing_binding` per registry  closure evidence: provide validated runner binding to unblock |
| `TC-03` | Unrelated field no-op | field-path filter | status=`modified`, field not `item.processingState` | evaluate contract | no event; reason unrelated field | `MQA-03` covers field filtering because it validates no target event | `AUTO-03` covers the same behavior because it asserts zero event cardinality; status `blocked_missing_binding` per registry  closure evidence: provide validated runner binding to unblock |
| `TC-04` | Non-modified no-op | operation/status filter | status other than `modified`, target field | evaluate contract | no event; reason unsupported status | `MQA-04` covers status filtering because it validates no event | `AUTO-04` covers the same lifecycle because it asserts zero event cardinality; status `blocked_missing_binding` per registry  closure evidence: provide validated runner binding to unblock |

## 15. Unit/provider test contract
| ID | Компонент/правило | Covered behavior | Fixture fields | Fixture values | Invocation target/input | Exact assertions | Negative assertions | Evidence |
|---|---|---|---|---|---|---|---|---|
| UNIT-01 | operation filter | only `modified` enters field comparison | status, field | `added`, `item.processingState` | contract decision function with fixture | decision=`NO_OP`; reason=`status_not_modified`; event count=0 | no event payload | analyst-confirmed |
| UNIT-02 | field filter | unrelated field is no-op | status, field | `modified`, `item.name` | contract decision function with fixture | decision=`NO_OP`; reason=`unrelated_field`; event count=0 | no processing-state event | analyst-confirmed |
| UNIT-03 | null normalization | oldValue null normalizes to empty before comparison | oldValue, event count | `null`, count=0 before decision | normalization provider input oldValue=null | oldValue normalized=`""`; comparison input count=1 | no event type created by normalization alone | analyst-confirmed |
| UNIT-04 | missing normalization | missing oldValue normalizes to empty before comparison | oldValue presence, field path | missing, fieldPath=`item.processingState` | normalization provider with absent oldValue | oldValue normalized=`""`; normalized value count=1 | no synthetic `approved` oldValue | analyst-confirmed |
| UNIT-05 | empty normalization | empty newValue remains empty before comparison | newValue, operationStatus | `""`, operationStatus=`modified` | normalization provider input newValue=`""` | newValue normalized=`""`; normalized value count=1 | no `approved` placeholder insertion | analyst-confirmed |
| UNIT-06 | no trimming | whitespace oldValue is preserved for comparison | oldValue, newValue | `" "`, `approved` | normalization pair provider | oldValue remains `" "`; newValue remains `approved`; count=2 | oldValue must not become empty | analyst-confirmed |
| UNIT-07 | no case folding | case is preserved | oldValue,newValue | `approved`,`APPROVED` | normalization pair | values remain different | must not collapse by case | analyst-confirmed |
| UNIT-08 | normalized-empty no-op | missing and empty pair is no-op | old presence,newValue,status,field | missing,`""`,`modified`,`item.processingState` | decision function with fixture | decision=`NO_OP`; event count=0 | no values payload | analyst-confirmed |
| UNIT-09 | meaningful change | null to approved creates candidate | oldValue,newValue,status,field | `null`,`approved`,`modified`,`item.processingState` | decision function with fixture | decision=`CREATE`; type exact; event count=1 | no additional event type | analyst-confirmed |
| UNIT-10 | exact values shape | output has only two keys | output values | old=`null`,new=`approved` | build candidate | key set exactly `{oldValue,newValue}` | no third key | analyst-confirmed |
| UNIT-11 | required mapping block | missing date mapping blocks event creation | event date, event type | missing date, `RECORD_PROCESSING_STATE_CHANGED` | mapping validator input event date missing | decision=`BLOCKED`; event count=0; diagnostic names event date | no fabricated event date or created event | expected |
| UNIT-12 | duplicate identity | duplicate event type identity remains blocked until binding | changeId, event type | `REC-1`, `RECORD_PROCESSING_STATE_CHANGED` | duplicate provider dependency with same changeId twice | decision=`BLOCKED`; event count=0; missing identity binding named | no invented duplicate create cardinality | open question |

## 16. Functional ↔ unit/provider traceability
| Functional ID | Behavior under test | Covered rules | Unit/provider IDs | Coverage rationale |
|---|---|---|---|---|
| `TC-01` | meaningful null-to-approved transition | operation, field, normalization, mapping, exact values | `UNIT-03`,`UNIT-09`,`UNIT-10` | proves create path and exact payload |
| `TC-02` | normalized no-op | missing/empty normalization and no-op | `UNIT-04`,`UNIT-05`,`UNIT-08` | proves equality after normalization |
| `TC-03` | unrelated field no-op | field filter | UNIT-02 | isolates target-field rule |
| `TC-04` | non-modified no-op | status filter | UNIT-01 | isolates operation rule |

## 17. QA reference data
| Datum | Value | Evidence |
|---|---|---|
| Positive old | `null` | analyst-confirmed |
| Positive new | `approved` | analyst-confirmed |
| Positive status | `modified` | analyst-confirmed |
| Positive field | `item.processingState` | analyst-confirmed |
| Negative old | missing | analyst-confirmed |
| Negative new | `""` | analyst-confirmed |
| Automation state | ready for runner validation; live-run `not_run` | analyst-confirmed |

## 18. Acceptance criteria
- Meaningful `null → approved` change creates exactly one event candidate.
- Values object contains exactly `oldValue` and `newValue`.
- Missing/empty pair is no-op after comparison normalization.
- Unrelated field and non-`modified` status are no-op.
- Normalization neither trims whitespace nor changes case.
- Runner compatibility remains unconfirmed and live-run status remains `not_run`.

## 19. Open questions
| Питання | Impact | Owner | Blocks final-ready |
|---|---|---|---|
| Exact source/change record locations for old/new values | exact executable mapping | source contract owner | yes |
| Stable identifiers and event date source | complete output mapping | source contract owner | yes |
| Duplicate identity and behavior | idempotency | product/implementation owner | yes |
| Runtime endpoint/database/collection bindings | live execution | runner owner | no for specification; yes for live run |
| UI/localization requirements | display behavior | product owner | no for core state-change contract |

## 20. Artifact-specific validation
This candidate must be validated by the Driver authoritative passport validator. Approval is forbidden without a current Driver-generated PASS receipt bound to this exact version and SHA-256.


## 21. Cross-artifact status authority
The authoritative behavior allocation and blocked-status closure evidence are maintained in `runtime/CASE_STATUS_REGISTRY.yaml`. Each automation case is blocked only for the exact missing runner binding; provide the required endpoint/database/runner binding evidence to unblock it.
