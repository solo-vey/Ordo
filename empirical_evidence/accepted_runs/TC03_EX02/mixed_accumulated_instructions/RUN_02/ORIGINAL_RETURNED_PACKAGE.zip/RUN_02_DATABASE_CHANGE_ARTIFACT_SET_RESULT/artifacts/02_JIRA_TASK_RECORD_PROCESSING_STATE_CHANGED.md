# Jira Task — RECORD_PROCESSING_STATE_CHANGED

## Summary and business context
- Summary: Implement the confirmed processing-state change contract and normalized no-op behavior.
- Business outcome / consumer: emit one `RECORD_PROCESSING_STATE_CHANGED` candidate only for a meaningful `item.processingState` modification.
- Operational value: prevents false events for normalized empty inputs, unrelated fields, and non-modified statuses.
- Passport reference/version: `01_RECORD_CHANGE_PASSPORT_RECORD_PROCESSING_STATE_CHANGED.md`, version 1.0.0, Driver-approved SHA-256 `2917115ee4ebbaad333dead808b33b4a6dd25c4e5cc2b8ccdf973161a2ee1a4e`.

## Confirmed contract summary
| Concern | Confirmed value/behavior | Authoritative source |
|---|---|---|
| Rule/alias | `RECORD_PROCESSING_STATE_CHANGED` | Passport §§1-2 |
| Target field/operation | `item.processingState`, `modified` | Passport §§3-5 |
| Normalization/no-op | null, missing, empty → `""`; no trim/case-fold; equal empty pair, unrelated field, or non-modified status → no-op | Passport §10 |
| Output | event type exact; values keys exactly `oldValue`,`newValue` | Passport §§7-9 |
| Positive reference | old=`null`, new=`approved` | Passport §17 |
| Runtime status | automation ready for runner validation; live run `not_run` | Passport §§13,17 |

## Scope and exclusions
### In scope
Operation filter, field filter, comparison normalization, no-op decision, exact payload mapping, diagnostics, QA and automation handoff.
### Out of scope
Invented repository symbols, endpoints, database/collection bindings, credentials, live-run claims, unconfirmed duplicate/date mapping.

## Delivery requirements
| Delivery ID | Concern/component | Concrete expected output | Source | Dependency/blocker | Completion evidence | Status |
|---|---|---|---|---|---|---|
| DEL-01 | operation filter | implement rule handler validation so only `modified` reaches `item.processingState` event evaluation and all other statuses return no-op | Passport §10 | none | UNIT-01 | planned |
| DEL-02 | target field filter | validate `item.processingState` in the rule handler and skip unrelated fields with zero target events | Passport §10 | none | UNIT-02 | planned |
| DEL-03 | normalization | implement processingState comparison mapper: null/missing/empty map to `""`, while whitespace and case remain unchanged | Passport §10 | none | UNIT-03..UNIT-07 | planned |
| DEL-04 | create/no-op | emit exactly one processingState event for null→approved and return no-op with zero events for normalized empty pairs | Passport §§14-17 | none | TC-01, TC-02 | planned |
| DEL-05 | mapper | values key set exactly `{oldValue,newValue}` | Passport §§7-9 | none | UNIT-10 | planned |
| DEL-06 | runtime binding | bind verified endpoint/database/collection/runner without inventing values | CASE_STATUS_REGISTRY | DEP-01 | validated binding evidence | blocked |
| DEL-07 | duplicate/date | block the processingState event mapper implementation until authoritative duplicate identity and event date mapping are supplied | Passport §19 | DEP-02 | contract evidence | blocked |
| DEL-08 | handoff | create Manual QA and automation artifacts that validate the processingState rule and retain blocked status until runner binding exists | Passport §17 | none | approved QA/AUTO artifacts | planned |

## Acceptance criteria
| AC ID | Concern | Given/input | When | Then | Evidence | Blocker |
|---|---|---|---|---|---|---|
| AC-01 | creation | modified, target field, null→approved | evaluate | one event candidate, exact type and exact two-key values | TC-01/AUTO-01 | runtime execution DEP-01 |
| AC-02 | normalized no-op | modified, target field, missing→empty | evaluate | zero events, explicit normalized no-op reason | TC-02/AUTO-02 | runtime execution DEP-01 |
| AC-03 | unrelated field | modified, `item.name` | evaluate | zero target events | TC-03/AUTO-03 | runtime execution DEP-01 |
| AC-04 | status filter | Given operationStatus=`added` and fieldPath=`item.processingState` | When the rule handler evaluates the input | Then zero `RECORD_PROCESSING_STATE_CHANGED` events are created | TC-04/AUTO-04 | runtime execution DEP-01 |
| AC-05 | exact mapping | Given oldValue=`null`, newValue=`approved`, operationStatus=`modified` | When the event mapper creates output | Then exactly one event is created with only oldValue/newValue and no error | UNIT-10 | none |
| AC-06 | no unsupported semantics | Given oldValue=`approved`, newValue=`APPROVED` and operationStatus=`modified` | When normalization runs | Then one meaningful difference remains; values must not be case-folded or trimmed | UNIT-06/07 | none |

## Functional delivery coverage
| Functional ID | Requirement/result | Delivery IDs | Manual QA | Automation | Status/blocker |
|---|---|---|---|---|---|
| TC-01 | meaningful transition creates one candidate | DEL-01..05 | MQA-01 | AUTO-01 | blocked_missing_binding |
| TC-02 | normalized empty pair creates none | DEL-03..04 | MQA-02 | AUTO-02 | blocked_missing_binding |
| TC-03 | unrelated field creates none | DEL-02,04 | MQA-03 | AUTO-03 | blocked_missing_binding |
| TC-04 | non-modified status creates none | DEL-01,04 | MQA-04 | AUTO-04 | blocked_missing_binding |

## Dependencies, open questions, and closure criteria
| ID | Missing evidence | Affected | Impact | Owner/action | Closure criterion | Work allowed | Blocks |
|---|---|---|---|---|---|---|---|
| DEP-01 | executable endpoint, database, collection, auth, runner binding | live MQA/AUTO | no live execution | runner owner captures validated configuration | evidence names all bindings and successful preflight | specification and unit work | live verification |
| DEP-02 | authoritative date source and duplicate identity | duplicate/date delivery | incomplete production mapping | contract owner supplies schema/binding | Driver-confirmed contract plus tests | core state/no-op work | final production readiness |

## Definition of Done
All unblocked delivery rows implemented and evidenced; blocked rows retain exact closure criteria; QA and automation handoffs approved; cross-artifact and package gates pass; no live-run claim while status is `not_run`.

## External references
- Passport: local artifact above
- Jira issue: Not provided
- URLs: Not provided

## Change log
| Date | Source | Change | Reason |
|---|---|---|---|
| 2026-07-17 | RUN_02 Driver | initial candidate | confirmed route contract |
