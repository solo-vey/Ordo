# Jira Task — PROCESSING_STATE_CHANGED

## Summary and business context
Implement and verify historical event `RECORD_PROCESSING_STATE_CHANGED` for the confirmed source-record transition `item.processingState: pending → approved`. The delivery must be self-contained and measurable for `DOC-74291`, `REC-184`, and `CHG-2026-0001`.

## Confirmed contract
- Eligible change: `operationStatus=modified`, `fieldPath=item.processingState`.
- Exact event output: one `RECORD_PROCESSING_STATE_CHANGED` with `eventDate` copied from change occurrence time and `values={oldValue: pending, newValue: approved}`.
- No-op outputs: zero target events for equal values, unrelated fields, or unsupported statuses.
- Duplicate output: final target-event cardinality remains one after the same change/event identity is processed twice.
- Missing mandatory mapping output: zero partial events and one diagnostic bound to `RULE_PROCESSING_STATE_CHANGED`.

## Delivery requirements
| ID | Concrete implementation output | Required evidence |
|---|---|---|
| DEL-01 | Implement the database-change rule eligibility filter that accepts `operationStatus=modified` and `fieldPath=item.processingState`, and returns no-op with zero target events for `operationStatus=created` or `fieldPath=item.name`. | Unit evidence for exact status/field inputs and event count=0 on rejection. |
| DEL-02 | Create the event mapper that persists exactly one `RECORD_PROCESSING_STATE_CHANGED` event for `DOC-74291`, `REC-184`, `CHG-2026-0001`, mapping `oldValue=pending`, `newValue=approved`, and `eventDate` from occurrence time. | Payload assertion proving one event, exact identifiers, exact two-key values object, and zero errors. |
| DEL-03 | Handle equal values by returning an explicit no-op when `oldValue=pending` and `newValue=pending`, with zero event and zero error records. | Decision evidence and cardinality assertions for TC-02. |
| DEL-04 | Prevent duplicate persistence for the same `changeId=CHG-2026-0001-DUP` and event type, returning a duplicate/no-op on the second processing cycle and preserving exactly one event. | Two-cycle execution proof with count=1 after each cycle and no second side effect. |
| DEL-05 | Validate mandatory mapping fields and block event creation when occurrence time or an identifier is absent, emitting one rule-bound diagnostic and zero partial events. | Fail-closed evidence naming the missing field, diagnostic count=1, and event count=0. |
| DEL-06 | Create executable Manual QA cases for the database-change lifecycle, including source setup, publish/process calls, Mongo queries, exact event/error cardinalities, and inverse rollback where mutation occurs. | MQA-01 through MQA-06 rendered with concrete commands or explicit blocked evidence. |
| DEL-07 | Create runner-bound Automation cases that execute or explicitly block each behavior, validate event/error outputs, isolate change IDs, and preserve source state through rollback or documented no-mutation handling. | AUTO-01 through AUTO-06 plus current Driver validation receipts. |

## Acceptance criteria
| ID | Independently verifiable criterion |
|---|---|
| AC-01 | Given `operationStatus=modified`, `fieldPath=item.processingState`, `oldValue=pending`, and `newValue=approved`, when the database change is processed, then exactly one `RECORD_PROCESSING_STATE_CHANGED` event is persisted with `DOC-74291`, `REC-184`, `CHG-2026-0001`, exact occurrence-time `eventDate`, exactly `oldValue=pending` and `newValue=approved`, and zero errors. |
| AC-02 | Given `oldValue=pending` and `newValue=pending`, when the change is processed, then zero target events and zero errors are created. |
| AC-03 | Given either `fieldPath=item.name` with `operationStatus=modified` or `fieldPath=item.processingState` with `operationStatus=created`, when processing completes, then zero `RECORD_PROCESSING_STATE_CHANGED` events are created. |
| AC-04 | Given the required occurrence time is omitted, when the change is processed under the authoritative omission binding, then zero events and exactly one diagnostic bound to `RULE_PROCESSING_STATE_CHANGED` are created. |
| AC-05 | Given `changeId=CHG-2026-0001-DUP` is published and processed twice, when the second cycle completes, then exactly one target event remains and no second event or side effect is created. |

## Cross-artifact delivery matrix
| Functional behavior | Linked delivery and independently verifiable outcome | Manual QA | Automation | Authoritative status |
|---|---|---|---|---|
| TC-01 | DEL-01 DEL-02 AC-01 — Implement the database-change event mapper; given `modified` target-field `pending`→`approved`, when processed, exactly one event is persisted and zero errors are created. | MQA-01 | AUTO-01 | runnable |
| TC-02 | DEL-03 AC-02 — Implement equal-value no-op handling in the database-change rule; given `pending`→`pending`, when processed, zero events and zero errors are created. | MQA-02 | AUTO-02 | runnable |
| TC-03 | DEL-01 AC-03 — Implement the field-path filter in the database-change rule; given `item.name`, when processed, zero target events are created. | MQA-03 | AUTO-03 | runnable |
| TC-04 | DEL-01 AC-03 — Implement the operation-status filter in the database-change rule; given `operationStatus=created`, when processed, zero target events are created. | MQA-04 | AUTO-04 | runnable |
| TC-05 | DEL-04 AC-05 — Prevent duplicate event persistence; given the same change identity twice, when the second cycle completes, exactly one event remains and no second event is created. | MQA-05 | AUTO-05 | runnable |
| TC-06 | DEL-05 AC-04 — Validate required occurrence-time mapping and block the event mapper; given occurrence time omitted, when processed under the required binding, zero events and one diagnostic are created. | MQA-06 | AUTO-06 | blocked_missing_binding |

## Dependencies and limits
`BASE_URL`, `AUTH_HEADERS`, and `DATABASE_NAME` are runtime bindings and do not block specification. AUTO-06 remains blocked because the authoritative runner request-field schema for omitting occurrence time is unavailable; no live result is claimed.

## Definition of Done
All delivery outputs are implemented and linked to current evidence. Every acceptance criterion has a current validator report or execution proof. The AUTO-06 blocker is closed only when the authoritative omission binding/schema is provided and captured evidence proves zero events plus one diagnostic. Passport, Manual QA, Automation, and Jira consistency checks pass. Driver-generated validation and approval receipts are bound to current artifact hashes, and cross-artifact plus package gates pass.
