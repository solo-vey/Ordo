# Record Change Passport — PROCESSING_STATE_CHANGED

## Document status
- Run: `RUN_01`
- Rule ID: `RULE_PROCESSING_STATE_CHANGED`
- Version: `1.0.0`
- Status: final-ready
- Evidence: analyst-confirmed through Driver

## Business meaning
A meaningful change of `item.processingState` from `pending` to `approved` must create a historical event that lets a user see the previous and new processing state. Equal values, unrelated fields, and unsupported operation statuses are no-op.

## Source and change contract
| Concern | Confirmed value |
|---|---|
| document_id | `DOC-74291` |
| record_key | `REC-184` |
| change_id | `CHG-2026-0001` |
| operation status | `modified` |
| field path | `item.processingState` |
| old value | `pending` |
| new value | `approved` |
| event type | `RECORD_PROCESSING_STATE_CHANGED` |
| event date | change occurrence time |
| values shape | exactly `oldValue`, `newValue` |

## Decision and mapping contract
1. Accept only operation status `modified`.
2. Accept only field path `item.processingState`.
3. Resolve `document_id`, `record_key`, `change_id`, and change occurrence time.
4. Compare old/new values without changing stored display values.
5. Return no-op for equal values, unrelated fields, or unsupported operation status.
6. Create one event with `eventType=RECORD_PROCESSING_STATE_CHANGED`, source identifiers, `eventDate` from occurrence time, and `values={oldValue:"pending",newValue:"approved"}`.
7. Reprocessing the same change identity must not create a second event.
8. Missing mandatory mapping data blocks creation and emits diagnostic evidence; it must not create a partial event.

## Exact mapping
| Target | Source | Transformation | Missing behavior |
|---|---|---|---|
| `documentId` | source/change `document_id` | none | blocked |
| `recordKey` | source/change `record_key` | none | blocked |
| `changeId` | change `change_id` | none | blocked |
| `eventType` | rule constant | none | blocked |
| `eventDate` | change occurrence time | none | blocked |
| `values.oldValue` | change old value | none | blocked |
| `values.newValue` | change new value | none | blocked |

## Observability
Created: exactly one matching event and zero matching error records. No-op: zero matching events with a recorded no-op reason. Blocked/error: zero partial events and one diagnostic bound to the change/rule. Duplicate: event cardinality remains one.

## Functional tests and cross-artifact rationale
Authoritative status is maintained in `runtime/CASE_STATUS_REGISTRY.yaml`.

| ID | Behavior | Input | Exact expected result | Manual QA / Automation rationale and authoritative status |
|---|---|---|---|---|
| TC-01 | successful creation | `modified`, `item.processingState`, `pending`→`approved` | one exact event; zero errors | `MQA-01` covers the operational mutation/query lifecycle and `AUTO-01` validates the same lifecycle because both assert `RECORD_PROCESSING_STATE_CHANGED`, `oldValue=pending`, `newValue=approved`, and count=1; authoritative status `runnable`. |
| TC-02 | equal-value no-op | `modified`, `item.processingState`, `pending`→`pending` | zero events | `MQA-02` covers the no-mutation no-op and `AUTO-02` validates the same lifecycle because both assert target event count=0 for equal values; authoritative status `runnable`. |
| TC-03 | unrelated-field no-op | `modified`, `item.name`, `A`→`B` | zero target events | `MQA-03` covers the unrelated-field behavior and `AUTO-03` validates the same lifecycle because both assert `RECORD_PROCESSING_STATE_CHANGED` count=0; authoritative status `runnable`. |
| TC-04 | unsupported-status no-op | `created`, `item.processingState`, `pending`→`approved` | zero target events | `MQA-04` covers the unsupported operation behavior and `AUTO-04` validates the same lifecycle because both assert target event count=0 for `operationStatus=created`; authoritative status `runnable`. |
| TC-05 | duplicate prevention | `CHG-2026-0001-DUP` processed twice | one event after second cycle | `MQA-05` covers two causal cycles and `AUTO-05` validates the same lifecycle because both assert count=1 after each processing cycle and no second side effect; authoritative status `runnable`. |
| TC-06 | missing occurrence time | omit `occurrence_time` | zero events; one rule-bound diagnostic | `MQA-06` covers the fail-closed outcome; `AUTO-06` is `blocked_missing_binding` because the authoritative omission binding/schema for `occurrence_time` is unavailable. Closure evidence must provide the runner request-field binding that can omit `occurrence_time` and a captured run proving event count=0 and diagnostic count=1. |

## Unit/provider specifications
| ID | Atomic behavior | Fixture | Invocation | Exact assertions | Negative assertions |
|---|---|---|---|---|---|
| UNIT-01 | supported operation-status filter | `operationStatus=modified`, `fieldPath=item.processingState`, `oldValue=pending`, `newValue=approved` | evaluate `RULE_PROCESSING_STATE_CHANGED` | behavior accepts `operationStatus=modified`; eligibility=true; event construction count=0 at filter stage | no event type emitted before mapping; no error count increase |
| UNIT-02 | unsupported operation-status rejection | `operationStatus=created`, `fieldPath=item.processingState`, `oldValue=pending`, `newValue=approved` | evaluate `RULE_PROCESSING_STATE_CHANGED` | behavior returns no-op for `created`; target event count=0 | no `RECORD_PROCESSING_STATE_CHANGED`; no error record |
| UNIT-03 | target field filter | `operationStatus=modified`, `fieldPath=item.processingState`, `oldValue=pending`, `newValue=approved` | evaluate field predicate | behavior accepts exact field path `item.processingState`; eligibility=true | no mapping of `item.name`; event count=0 at predicate stage |
| UNIT-04 | unrelated field independence | `operationStatus=modified`, `fieldPath=item.name`, `oldValue=A`, `newValue=B`, unchanged `item.processingState=pending` | evaluate `RULE_PROCESSING_STATE_CHANGED` | behavior returns no-op for `item.name`; target event count=0; error count=0 | no target event; no mutation of `item.processingState` |
| UNIT-05 | comparison normalization and equal-value no-op | `oldValue=pending`, `newValue=pending`; boundary pairs `null/null`, missing/missing, empty/empty | compare values | behavior normalizes only for comparison; equal pairs produce explicit no-op and event count=0 | no error; no stored/display value rewrite |
| UNIT-06 | exact payload mapping | `document_id=DOC-74291`, `record_key=REC-184`, `change_id=CHG-2026-0001`, `oldValue=pending`, `newValue=approved` | map event payload | event type=`RECORD_PROCESSING_STATE_CHANGED`; values contain exactly `oldValue=pending` and `newValue=approved`; cardinality count=1 | no extra values keys; error count=0 |
| UNIT-07 | exact date mapping | `change_id=CHG-2026-0001`, `occurrence_time=2026-07-17T10:15:30Z`, `event type=RECORD_PROCESSING_STATE_CHANGED` | map `eventDate` | behavior maps `eventDate=2026-07-17T10:15:30Z` exactly from occurrence time; event count=1 | no processing-time substitution; no missing date |
| UNIT-08 | missing required mapping block | omit `document_id`; retain `record_key=REC-184`, `change_id=CHG-2026-0001`, `operationStatus=modified` | map event payload | behavior is blocked; diagnostic names missing `document_id`; event count=0; diagnostic count=1 | no partial `RECORD_PROCESSING_STATE_CHANGED` event |
| UNIT-09 | duplicate identity | invoke twice with `changeId=CHG-2026-0001`, event type=`RECORD_PROCESSING_STATE_CHANGED`, rule=`RULE_PROCESSING_STATE_CHANGED` | process same identity twice | first invocation creates count=1; second returns duplicate/no-op; final event cardinality count=1 | no second event; no second side effect |
| UNIT-10 | empty display fallback boundary | `oldValue=` empty, `newValue=approved`, `fieldPath=item.processingState` | map display payload | behavior preserves exact raw mapping and uses the contract fallback only in display payload; values relation remains `oldValue`→`newValue`; event count=1 | no comparison-value mutation; no invented localized text |
| UNIT-11 | localization placeholder consistency | event type=`RECORD_PROCESSING_STATE_CHANGED`, placeholders=`oldValue,newValue`; localized template binding unavailable | validate template/provider boundary | behavior is dependency-blocked until exact template key and placeholder schema are supplied; required placeholder set is exactly `oldValue,newValue`; event mapping count unaffected | no invented translation; no extra placeholder |

## QA reference data
Use the supplied source record and change record: `DOC-74291`, `REC-184`, `CHG-2026-0001`, `item.processingState`, `pending`→`approved`, status `modified`.

## Open runtime bindings
`BASE_URL`, `AUTH_HEADERS`, and `DATABASE_NAME` are runtime placeholders. They do not block executable specifications. A live automation result remains unavailable unless a compatible runner is actually available.
