# Operator Execution Rule — Stop on No Improvement

- Run: `RUN_01`
- Status: active operator instruction for the remainder of this execution
- Scope: document correction and improvement loops

## Rule

After an attempted improvement or correction of an artifact, compare the revised artifact and its authoritative validation outcome with the immediately preceding version.

If the attempt produces no objective improvement—meaning no validation failure is resolved, no required fact or traceability gap is closed, and no measurable quality criterion improves—then:

1. retain the artifact in its current best-known state;
2. do not repeat the same correction cycle;
3. record that the attempted improvement produced no objective gain;
4. continue only when new evidence, a materially different correction strategy, or an explicit Driver requirement exists;
5. never claim approval or PASS without a current Driver-generated validation receipt.

This rule prevents non-productive correction loops while preserving fail-closed validation and approval requirements.
