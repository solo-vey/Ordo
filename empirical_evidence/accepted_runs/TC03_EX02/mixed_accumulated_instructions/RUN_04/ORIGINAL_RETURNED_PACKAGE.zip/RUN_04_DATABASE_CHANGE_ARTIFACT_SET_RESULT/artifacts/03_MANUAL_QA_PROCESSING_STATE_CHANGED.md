# Manual QA — PROCESSING_STATE_CHANGED

Runtime placeholders: `BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME`. No live execution is claimed.

## MQA-01 — creates exact processing-state event
Functional TC: TC-01

### Step 0. Purpose
Verify creates exact processing-state event for `item.processingState`.

### Step 1. Environment
```bash
: "${BASE_URL:?required}" "${AUTH_HEADERS:?required}" "${DATABASE_NAME:?required}"
```

### Step 2. Source precondition
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r) throw new Error("missing source");
```

### Step 3. Input values
`changeId=CHG-2026-0004`, `operationStatus=modified`, `fieldPath=item.processingState`, `oldValue=pending`, `newValue=reviewed`.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"reviewed"}'
```
### Step 5. Verify change record
Expected cardinality: 1
```javascript
const n=db.getSiblingDB(DATABASE_NAME).change_records.countDocuments({change_id:"CHG-2026-0004"}); if(n!==1) throw new Error("change cardinality");
const d=db.getSiblingDB(DATABASE_NAME).change_records.findOne({change_id:"CHG-2026-0004"}); if(!d||d.change_id!=="CHG-2026-0004"||d.document_id!=="DOC-11990"||d.record_key!=="REC-220"||d.field_path!=="item.processingState"||d.old_value!=="pending"||d.new_value!=="reviewed"||d.operation_status!=="modified") throw new Error("exact change payload");
```

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Verify generated event
Expected cardinality: 1
```javascript
const n=db.getSiblingDB(DATABASE_NAME).generated_events.countDocuments({change_id:"CHG-2026-0004",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(n!==1) throw new Error("event cardinality");
const e=db.getSiblingDB(DATABASE_NAME).generated_events.findOne({change_id:"CHG-2026-0004",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(!e||e.event_type!=="RECORD_PROCESSING_STATE_CHANGED"||!e.event_date||e.record_key!=="REC-220"||e.field_path!=="item.processingState"||e.values.oldValue!=="pending"||e.values.newValue!=="reviewed"||e.rule_id!=="RULE_PROCESSING_STATE_CHANGED") throw new Error("exact event payload");
```

### Step 8. Verify errors
Expected cardinality: 0
```javascript
const x=db.getSiblingDB(DATABASE_NAME).change_errors.countDocuments({change_id:"CHG-2026-0004",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(x!==0) throw new Error("error cardinality");
```

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-ROLLBACK","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"reviewed","newValue":"pending"}'
```
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r) throw new Error("missing source after rollback");
```

```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r||r.item.processingState!=="pending") throw new Error("rollback exact restoration");
```
### Final expected result
The exact cardinalities and payload assertions above pass.

## MQA-02 — equal-value no-op
Functional TC: TC-02

### Step 0. Purpose
Verify equal-value no-op for `item.processingState`.

### Step 1. Environment
```bash
: "${BASE_URL:?required}" "${AUTH_HEADERS:?required}" "${DATABASE_NAME:?required}"
```

### Step 2. Source precondition
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r) throw new Error("missing source");
```

### Step 3. Input values
`changeId=CHG-2026-0004-NOOP`, `operationStatus=modified`, `fieldPath=item.processingState`, `oldValue=reviewed`, `newValue=reviewed`.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-NOOP","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"reviewed","newValue":"reviewed"}'
```
### Step 5. Verify change record
Expected cardinality: 1
```javascript
const n=db.getSiblingDB(DATABASE_NAME).change_records.countDocuments({change_id:"CHG-2026-0004-NOOP"}); if(n!==1) throw new Error("change cardinality");
const d=db.getSiblingDB(DATABASE_NAME).change_records.findOne({change_id:"CHG-2026-0004-NOOP"}); if(!d||d.change_id!=="CHG-2026-0004-NOOP"||d.document_id!=="DOC-11990"||d.record_key!=="REC-220"||d.field_path!=="item.processingState"||d.old_value!=="reviewed"||d.new_value!=="reviewed"||d.operation_status!=="modified") throw new Error("exact change payload");
```

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-NOOP","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Verify generated event
Expected cardinality: 0
```javascript
const e=db.getSiblingDB(DATABASE_NAME).generated_events.countDocuments({change_id:"CHG-2026-0004-NOOP",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(e!==0) throw new Error("event cardinality");
```

### Step 8. Verify errors
Expected cardinality: 0
```javascript
const x=db.getSiblingDB(DATABASE_NAME).change_errors.countDocuments({change_id:"CHG-2026-0004-NOOP",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(x!==0) throw new Error("error cardinality");
```

### Step 9. Rollback and post-rollback verification
Rollback not required; verify exact unchanged source state.
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r||r.item.processingState!=="reviewed") throw new Error("rollback exact restoration");
```


### Final expected result
The exact cardinalities and payload assertions above pass.

## MQA-03 — unrelated field no-op
Functional TC: TC-03

### Step 0. Purpose
Verify unrelated field no-op for `item.other`.

### Step 1. Environment
```bash
: "${BASE_URL:?required}" "${AUTH_HEADERS:?required}" "${DATABASE_NAME:?required}"
```

### Step 2. Source precondition
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r) throw new Error("missing source");
```

### Step 3. Input values
`changeId=CHG-2026-0004-OTHER`, `operationStatus=modified`, `fieldPath=item.other`, `oldValue=A`, `newValue=B`.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-OTHER","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.other","oldValue":"A","newValue":"B"}'
```
### Step 5. Verify change record
Expected cardinality: 1
```javascript
const n=db.getSiblingDB(DATABASE_NAME).change_records.countDocuments({change_id:"CHG-2026-0004-OTHER"}); if(n!==1) throw new Error("change cardinality");
const d=db.getSiblingDB(DATABASE_NAME).change_records.findOne({change_id:"CHG-2026-0004-OTHER"}); if(!d||d.change_id!=="CHG-2026-0004-OTHER"||d.document_id!=="DOC-11990"||d.record_key!=="REC-220"||d.field_path!=="item.other"||d.old_value!=="A"||d.new_value!=="B"||d.operation_status!=="modified") throw new Error("exact change payload");
```

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-OTHER","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Verify generated event
Expected cardinality: 0
```javascript
const e=db.getSiblingDB(DATABASE_NAME).generated_events.countDocuments({change_id:"CHG-2026-0004-OTHER",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(e!==0) throw new Error("event cardinality");
```

### Step 8. Verify errors
Expected cardinality: 0
```javascript
const x=db.getSiblingDB(DATABASE_NAME).change_errors.countDocuments({change_id:"CHG-2026-0004-OTHER",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(x!==0) throw new Error("error cardinality");
```

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-OTHER-ROLLBACK","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.other","oldValue":"B","newValue":"A"}'
```
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r) throw new Error("missing source after rollback");
```

```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r||r.item.processingState!=="A") throw new Error("rollback exact restoration");
```
### Final expected result
The exact cardinalities and payload assertions above pass.

## MQA-04 — unsupported status no-op
Functional TC: TC-04

### Step 0. Purpose
Verify unsupported status no-op for `item.processingState`.

### Step 1. Environment
```bash
: "${BASE_URL:?required}" "${AUTH_HEADERS:?required}" "${DATABASE_NAME:?required}"
```

### Step 2. Source precondition
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r) throw new Error("missing source");
```

### Step 3. Input values
`changeId=CHG-2026-0004-STATUS`, `operationStatus=unsupported`, `fieldPath=item.processingState`, `oldValue=pending`, `newValue=reviewed`.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-STATUS","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"unsupported","fieldPath":"item.processingState","oldValue":"pending","newValue":"reviewed"}'
```
### Step 5. Verify change record
Expected cardinality: 1
```javascript
const n=db.getSiblingDB(DATABASE_NAME).change_records.countDocuments({change_id:"CHG-2026-0004-STATUS"}); if(n!==1) throw new Error("change cardinality");
const d=db.getSiblingDB(DATABASE_NAME).change_records.findOne({change_id:"CHG-2026-0004-STATUS"}); if(!d||d.change_id!=="CHG-2026-0004-STATUS"||d.document_id!=="DOC-11990"||d.record_key!=="REC-220"||d.field_path!=="item.processingState"||d.old_value!=="pending"||d.new_value!=="reviewed"||d.operation_status!=="unsupported") throw new Error("exact change payload");
```

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-STATUS","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Verify generated event
Expected cardinality: 0
```javascript
const e=db.getSiblingDB(DATABASE_NAME).generated_events.countDocuments({change_id:"CHG-2026-0004-STATUS",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(e!==0) throw new Error("event cardinality");
```

### Step 8. Verify errors
Expected cardinality: 0
```javascript
const x=db.getSiblingDB(DATABASE_NAME).change_errors.countDocuments({change_id:"CHG-2026-0004-STATUS",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(x!==0) throw new Error("error cardinality");
```

### Step 9. Rollback and post-rollback verification
Rollback not required; verify exact unchanged source state.
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r||r.item.processingState!=="pending") throw new Error("rollback exact restoration");
```


### Final expected result
The exact cardinalities and payload assertions above pass.

## MQA-05 — duplicate replay idempotency
Functional TC: TC-05

### Step 0. Purpose
Verify duplicate replay idempotency for `item.processingState`.

### Step 1. Environment
```bash
: "${BASE_URL:?required}" "${AUTH_HEADERS:?required}" "${DATABASE_NAME:?required}"
```

### Step 2. Source precondition
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r) throw new Error("missing source");
```

### Step 3. Input values
`changeId=CHG-2026-0004-DUP`, `operationStatus=modified`, `fieldPath=item.processingState`, `oldValue=pending`, `newValue=reviewed`.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-DUP","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"reviewed"}'
```
### Step 5. Verify change record after cycle 1
Expected cardinality: 1
```javascript
const n=db.getSiblingDB(DATABASE_NAME).change_records.countDocuments({change_id:"CHG-2026-0004-DUP"}); if(n!==1) throw new Error("change cardinality");
const d=db.getSiblingDB(DATABASE_NAME).change_records.findOne({change_id:"CHG-2026-0004-DUP"}); if(!d||d.change_id!=="CHG-2026-0004-DUP"||d.document_id!=="DOC-11990"||d.record_key!=="REC-220"||d.field_path!=="item.processingState"||d.old_value!=="pending"||d.new_value!=="reviewed"||d.operation_status!=="modified") throw new Error("exact change payload");
```

### Step 6. Process cycle 1
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-DUP","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Verify event after cycle 1
Expected cardinality: 1
```javascript
const n=db.getSiblingDB(DATABASE_NAME).generated_events.countDocuments({change_id:"CHG-2026-0004-DUP",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(n!==1) throw new Error("event cardinality");
const e=db.getSiblingDB(DATABASE_NAME).generated_events.findOne({change_id:"CHG-2026-0004-DUP",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(!e||e.event_type!=="RECORD_PROCESSING_STATE_CHANGED"||!e.event_date||e.record_key!=="REC-220"||e.field_path!=="item.processingState"||e.values.oldValue!=="pending"||e.values.newValue!=="reviewed"||e.rule_id!=="RULE_PROCESSING_STATE_CHANGED") throw new Error("exact event payload");
```

### Step 8. Verify errors after cycle 1
Expected cardinality: 0
```javascript
const x=db.getSiblingDB(DATABASE_NAME).change_errors.countDocuments({change_id:"CHG-2026-0004-DUP",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(x!==0) throw new Error("unexpected error");
```

### Step 9. Duplicate cycle and rollback
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-DUP","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"reviewed"}'
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-DUP","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Expected cardinality: 1
Expected cardinality: 1
Final cardinality is 1 for the change record and 1 for the event after cycle 2; no second event or mutation is created.
```javascript
const chg=db.getSiblingDB(DATABASE_NAME).change_records.countDocuments({change_id:"CHG-2026-0004-DUP"}); const evt=db.getSiblingDB(DATABASE_NAME).generated_events.countDocuments({change_id:"CHG-2026-0004-DUP",event_type:"RECORD_PROCESSING_STATE_CHANGED"}); if(chg!==1||evt!==1) throw new Error("duplicate created second side effect");
```
Rollback uses the exact inverse fixture after this assertion.
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" -H 'Content-Type: application/json' --data '{"changeId":"CHG-2026-0004-DUP-ROLLBACK","documentId":"DOC-11990","recordKey":"REC-220","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"reviewed","newValue":"pending"}'
```
```javascript
const r=db.getSiblingDB(DATABASE_NAME).source_records.findOne({document_id:"DOC-11990",record_key:"REC-220"}); if(!r||r.item.processingState!=="pending") throw new Error("rollback exact restoration");
```


### Final expected result
The exact cardinalities and payload assertions above pass.
