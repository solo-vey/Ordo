# Record Change Passport — PROCESSING_STATE_CHANGED

## Document status
- Run: `RUN_04`
- Rule ID: `RULE_PROCESSING_STATE_CHANGED`
- Version: `1.0.0`
- Status: `candidate`
- Evidence: Driver-confirmed unless explicitly marked unavailable.

## Business meaning
Document and verify a source-record processing-state change so the change journal shows `RECORD_PROCESSING_STATE_CHANGED (`Processing state changed`)` with exact prior and new state values.

## Confirmed contract
| Concern | Value |
|---|---|
| Source branch | fixed internal-record-change branch |
| Source identifier | `document_id=DOC-11990`, `record_key=REC-220` |
| Change identifier | `change_id=CHG-2026-0004` |
| Operation status | `modified` |
| Field path | `item.processingState` |
| Previous value | `pending` |
| New value | `reviewed` (corrected value; `approved` is superseded) |
| Event type | `RECORD_PROCESSING_STATE_CHANGED` |
| Values keys | `oldValue`, `newValue` |

## Decision and mapping
1. Accept only `operationStatus=modified` for `item.processingState`.
2. Compare normalized old/new values.
3. Return no-op for equal normalized values, unrelated fields, or unsupported statuses.
4. Create one event for a supported actual transition.
5. Map `oldValue` from the change old value and `newValue` from the change new value.
6. Use `change_id + rule_id + event_type` as the proposed deterministic duplicate identity; repository confirmation is unavailable and therefore implementation binding remains blocked.

| Output field | Source / exact value |
|---|---|
| `eventType` | `RECORD_PROCESSING_STATE_CHANGED` |
| `documentId` | `DOC-11990` |
| `recordKey` | `REC-220` |
| `changeId` | `CHG-2026-0004` |
| `fieldPath` | `item.processingState` |
| `values.oldValue` | `pending` |
| `values.newValue` | `reviewed` |

## No-op and failure behavior
- Equal normalized values: no event.
- Unrelated field: no event.
- Unsupported operation status: no event.
- Missing mandatory identifiers or mapping values: blocked with diagnostic; do not invent defaults.
- Duplicate stimulus: no second event or other second side effect.

## Functional tests
| ID | Case | Exact expected result | Manual QA | Automation |
|---|---|---|---|---|
| TC-01 | `pending` → `reviewed` on target field | exactly one event with exact mapped values; MQA-01 and AUTO-01 cover the same event-created lifecycle because both validate exact persisted mapping | MQA-01 | AUTO-01 |
| TC-02 | normalized values equal | zero target events; MQA-02 and AUTO-02 cover no-op behavior because both assert event cardinality 0 | MQA-02 | AUTO-02 |
| TC-03 | unrelated field | zero target events; MQA-03 and AUTO-03 validate field-path filtering behavior | MQA-03 | AUTO-03 |
| TC-04 | unsupported operation status | zero target events; MQA-04 and AUTO-04 validate operationStatus filtering behavior | MQA-04 | AUTO-04 |
| TC-05 | duplicate replay | still exactly one event after second cycle; MQA-05 and AUTO-05 cover the same duplicate lifecycle because both execute two cycles and assert cardinality 1 | MQA-05 | AUTO-05 |

## Unit/provider specifications
| ID | Atomic behavior | Fixture | Invocation dependency | Exact assertions |
|---|---|---|---|---|
| UNIT-01 | `operationStatus` filter | `operationStatus=modified` versus `operationStatus=unsupported` for `DOC-11990` | repository-discovery dependency | `modified` continues to mapping; unsupported produces event cardinality 0 |
| UNIT-02 | `fieldPath` filter | `fieldPath=item.processingState` versus `fieldPath=item.other`, values `pending`/`reviewed` | repository-discovery dependency | target path continues; unrelated path produces event cardinality 0 |
| UNIT-03 | normalization no-op relation | `oldValue=reviewed`, `newValue=reviewed`, `fieldPath=item.processingState` | repository-discovery dependency | normalized comparison is equal and event cardinality 0 |
| UNIT-04 | exact payload mapping | `DOC-11990`, `REC-220`, `CHG-2026-0004`, `pending`, `reviewed` | repository-discovery dependency | event type `RECORD_PROCESSING_STATE_CHANGED`; exact `oldValue=pending`, `newValue=reviewed`, field path, and cardinality 1 |
| UNIT-05 | required mapping blocking | missing `document_id` with `operationStatus=modified`, `fieldPath=item.processingState`, `oldValue=pending`, `newValue=reviewed` | repository-discovery dependency | blocked diagnostic references document ID; event cardinality 0 |
| UNIT-06 | duplicate identity | same `CHG-2026-0004`, `RULE_PROCESSING_STATE_CHANGED`, event type, `oldValue=pending`, `newValue=reviewed` invoked twice | repository-discovery dependency | final event cardinality 1 and no second side effect |

## Mapping rationale and cross-artifact traceability
Manual and automation IDs are paired by functional behavior, not by document proximity. Event-created, no-op, filtering, and duplicate lifecycles use the same literals and exact cardinality assertions. Authoritative statuses and closure evidence are maintained in `runtime/CASE_STATUS_REGISTRY.yaml`.

## QA reference data
The stable supplied values are `DOC-11990`, `REC-220`, `CHG-2026-0004`, `pending`, and `reviewed`. Runtime `BASE_URL`, `AUTH_HEADERS`, and `DATABASE_NAME` are placeholders and do not claim a live environment.

## Open implementation bindings
Processor/class names, repository paths, event-date source, localization text, and authoritative delete cleanup capability are unavailable. These block production implementation claims, but not contract-bound QA and automation specifications.
