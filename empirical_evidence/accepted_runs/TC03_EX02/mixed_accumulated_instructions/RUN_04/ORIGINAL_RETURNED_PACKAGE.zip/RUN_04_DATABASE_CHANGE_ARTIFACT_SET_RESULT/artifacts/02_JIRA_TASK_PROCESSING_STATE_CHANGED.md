# Jira Task — PROCESSING_STATE_CHANGED

## Summary and business context
Deliver rule `RULE_PROCESSING_STATE_CHANGED` for the fixed internal-record-change branch. A `modified` change on `item.processingState` from `pending` to `reviewed` must produce `RECORD_PROCESSING_STATE_CHANGED (`Processing state changed`)` for `DOC-11990` / `REC-220` / `CHG-2026-0004`.

## Delivery requirements
| ID | Concrete delivery output | Dependency | Completion evidence | Status |
|---|---|---|---|---|
| DEL-01 | Implement the database change rule to validate `operationStatus`; `modified` continues and unsupported status returns no-op with exactly zero target events | repository binding unavailable | UNIT-01 validation evidence | blocked for implementation |
| DEL-02 | Implement the rule handler to validate exact `item.processingState`; unrelated field returns no-op with exactly zero target events | repository binding unavailable | UNIT-02 validation evidence | blocked for implementation |
| DEL-03 | Map and emit exactly one `RECORD_PROCESSING_STATE_CHANGED` event with exact IDs, field path, `oldValue=pending`, and `newValue=reviewed` | confirmed contract | UNIT-04 and TC-01 evidence | planned |
| DEL-04 | Prevent event persistence when normalized values are equal, when field path is unrelated, or when operation status is unsupported; return no-op and zero events | confirmed contract | UNIT-01..03 evidence | planned |
| DEL-05 | Deduplicate the event by confirmed business identity so a second publish/process cycle creates no second event or mutation and final cardinality is one | authoritative repository identity binding unavailable | UNIT-06, MQA-05, AUTO-05 evidence | blocked for implementation |
| DEL-06 | Create and validate the database change Manual QA package and Automation event specification with exact executable requests, database assertions, rollback, and no live-run claim | package contracts | current Driver-generated validation receipts | planned |

## Acceptance criteria
| ID | Given / When | Then |
|---|---|---|
| AC-01 | target `modified` change `pending`→`reviewed` | exactly one event with exact IDs, field path, type, `oldValue=pending`, `newValue=reviewed` |
| AC-02 | Given `oldValue=reviewed` and `newValue=reviewed`, when the modified target change is processed | exactly zero target events and exactly zero error records |
| AC-03 | Given `fieldPath=item.other`, when a modified change is processed | exactly zero `RECORD_PROCESSING_STATE_CHANGED` events |
| AC-04 | Given `operationStatus=unsupported`, when the target field change is evaluated | exactly zero target events and exactly zero error records |
| AC-05 | Given the duplicate payload with `pending` to `reviewed`, when publish and process are executed twice | exactly one final event and no second event or mutation |
| AC-06 | Given a modified target change with mandatory `documentId` missing, when mapping is attempted | processing is blocked, exactly zero events are created, and a diagnostic is returned |

## Scope
In scope: semantic rule, mapping, no-op behavior, duplicate expectation, unit/provider specifications, Manual QA, and automation specification. Out of scope: invented class names, repository paths, live environment execution, and unsupported cleanup operations.

## Test coverage
TC-01..TC-05 map to MQA-01..MQA-05 and AUTO-01..AUTO-05. Unit/provider specifications are UNIT-01..UNIT-06 in Passport v1.0.0.

## Dependencies and closure
| ID | Missing evidence | Owner/action | Closure criterion | Blocks |
|---|---|---|---|---|
| DEP-01 | processor/class and repository binding | developer repository discovery | concrete code symbols and paths confirmed | production implementation |
| DEP-02 | authoritative event-date mapping | analyst/developer contract lookup | exact source field confirmed | final production mapping |
| DEP-03 | live runtime values | QA environment capture | BASE_URL, AUTH_HEADERS, DATABASE_NAME captured | live execution only |

## Definition of Done
All blockers have closure evidence and are resolved or explicitly remain blocked. Driver-generated validation receipts, reports, and logs prove the current hashes. Cross-artifact consistency between Passport, Manual QA, and Automation passes before closure; exact semantic cases pass; no stale approval survives a correction; no live execution is claimed unless evidence exists.
