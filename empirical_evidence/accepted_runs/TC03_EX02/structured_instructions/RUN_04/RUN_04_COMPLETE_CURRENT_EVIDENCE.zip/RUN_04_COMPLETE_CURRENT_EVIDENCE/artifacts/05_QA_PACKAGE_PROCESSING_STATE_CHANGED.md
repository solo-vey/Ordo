# Manual QA Package — PROCESSING_STATE_CHANGED

No live execution is claimed. Capture BASE_URL, AUTH_HEADERS and DATABASE_NAME from the deployed test environment.
## MQA-001 — Meaningful supported change creates one event
Functional TC: TC-001

### Step 0. Case identity
Case-local identifiers: MQA-001, TC-001, changeId=CHG-2026-0004-MQA-001.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/1/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-001", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-001"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-001","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-001",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1||a[0].event_type!=="RECORD_PROCESSING_STATE_CHANGED"||a[0].event_date!=="2026-07-15T11:00:00Z"||a[0].record_key!=="REC-220"||a[0].field_path!=="item.processingState"||a[0].old_value!=="pending"||a[0].new_value!=="reviewed"||a[0].rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-001",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-001-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=1, errors=0; exact case behavior is preserved.

## MQA-002 — Equal normalized values are no-op
Functional TC: TC-002

### Step 0. Case identity
Case-local identifiers: MQA-002, TC-002, changeId=CHG-2026-0004-MQA-002.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/0/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-002", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-002"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-002","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-002",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-002",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-002-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=0, errors=0; exact case behavior is preserved.

## MQA-003 — Unrelated field is no-op
Functional TC: TC-003

### Step 0. Case identity
Case-local identifiers: MQA-003, TC-003, changeId=CHG-2026-0004-MQA-003.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/0/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.name", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-003", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-003"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-003","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-003",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-003",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.name", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-003-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=0, errors=0; exact case behavior is preserved.

## MQA-004 — Unsupported operation status is no-op
Functional TC: TC-004

### Step 0. Case identity
Case-local identifiers: MQA-004, TC-004, changeId=CHG-2026-0004-MQA-004.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/0/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "created", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-004", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-004"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-004","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-004",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-004",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-004-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=0, errors=0; exact case behavior is preserved.

## MQA-005
Functional TC: TC-005
status: blocked_missing_binding
evidence_status: blocked
blocked_reason: Confirmed publish schema requires documentId, so an omitted-field stimulus cannot be rendered authoritatively.
missing_capability: authoritative omission-capable publish binding
required_evidence: request schema and runner action confirming documentId may be omitted

## MQA-006 — Duplicate identity creates no second event
Functional TC: TC-006

### Step 0. Case identity
Case-local identifiers: MQA-006, TC-006, changeId=CHG-2026-0004-MQA-006.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/1/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-006", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-006"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-006","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-006",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1||a[0].event_type!=="RECORD_PROCESSING_STATE_CHANGED"||a[0].event_date!=="2026-07-15T11:00:00Z"||a[0].record_key!=="REC-220"||a[0].field_path!=="item.processingState"||a[0].old_value!=="pending"||a[0].new_value!=="reviewed"||a[0].rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-006",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Duplicate second cycle and rollback
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-006", "occurredAt": "2026-07-15T11:00:00Z"}'
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-006","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
mongosh "$DATABASE_NAME" --quiet --eval 'if(db.generated_events.countDocuments({change_id:"CHG-2026-0004-MQA-006",event_type:"RECORD_PROCESSING_STATE_CHANGED"})!==1) quit(1)'
Expected cardinality: 1
Expected cardinality: 1
No second event or change record is created; final cardinality remains 1.
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-006-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=1, errors=0; exact case behavior is preserved.

## MQA-007 — Null missing and empty normalize to empty string
Functional TC: TC-007

### Step 0. Case identity
Case-local identifiers: MQA-007, TC-007, changeId=CHG-2026-0004-MQA-007.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/0/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": null, "newValue": "", "changeId": "CHG-2026-0004-MQA-007", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-007"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-007","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-007",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-007",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "", "newValue": null, "changeId": "CHG-2026-0004-MQA-007-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=0, errors=0; exact case behavior is preserved.

## MQA-008 — Case and whitespace are preserved for comparison
Functional TC: TC-008

### Step 0. Case identity
Case-local identifiers: MQA-008, TC-008, changeId=CHG-2026-0004-MQA-008.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/1/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-008", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-008"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-008","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-008",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1||a[0].event_type!=="RECORD_PROCESSING_STATE_CHANGED"||a[0].event_date!=="2026-07-15T11:00:00Z"||a[0].record_key!=="REC-220"||a[0].field_path!=="item.processingState"||a[0].old_value!=="pending"||a[0].new_value!=="reviewed"||a[0].rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-008",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-008-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=1, errors=0; exact case behavior is preserved.

## MQA-009 — Event date maps from occurredAt
Functional TC: TC-009

### Step 0. Case identity
Case-local identifiers: MQA-009, TC-009, changeId=CHG-2026-0004-MQA-009.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/1/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-009", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-009"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-009","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-009",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1||a[0].event_type!=="RECORD_PROCESSING_STATE_CHANGED"||a[0].event_date!=="2026-07-15T11:00:00Z"||a[0].record_key!=="REC-220"||a[0].field_path!=="item.processingState"||a[0].old_value!=="pending"||a[0].new_value!=="reviewed"||a[0].rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-009",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-009-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=1, errors=0; exact case behavior is preserved.

## MQA-010 — Payload uses exact oldValue and newValue keys
Functional TC: TC-010

### Step 0. Case identity
Case-local identifiers: MQA-010, TC-010, changeId=CHG-2026-0004-MQA-010.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/1/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-010", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-010"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-010","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-010",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1||a[0].event_type!=="RECORD_PROCESSING_STATE_CHANGED"||a[0].event_date!=="2026-07-15T11:00:00Z"||a[0].record_key!=="REC-220"||a[0].field_path!=="item.processingState"||a[0].old_value!=="pending"||a[0].new_value!=="reviewed"||a[0].rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-010",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-010-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=1, errors=0; exact case behavior is preserved.

## MQA-011 — Unrelated source fields do not affect decision
Functional TC: TC-011

### Step 0. Case identity
Case-local identifiers: MQA-011, TC-011, changeId=CHG-2026-0004-MQA-011.

### Step 1. Capture environment
```bash
export BASE_URL="<runtime>"; export AUTH_HEADERS="<runtime>"; export DATABASE_NAME="<runtime>"
```

### Step 2. Verify source baseline
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.record_key!=="REC-220") quit(1)'
```

### Step 3. Record exact expected lifecycle
Expected change/event/error counts are 1/1/0.

### Step 4. Publish stimulus
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "pending", "newValue": "reviewed", "changeId": "CHG-2026-0004-MQA-011", "occurredAt": "2026-07-15T11:00:00Z"}'
```

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004-MQA-011"}).toArray(); if(a.length!==1||a[0].change_id==null||a[0].document_id!=="DOC-11990"||a[0].record_key!=="REC-220"||a[0].field_path==null||!("old_value" in a[0])||!("new_value" in a[0])||a[0].operation_status==null) quit(1)'
```
Expected cardinality: 1
Negative assertion: no additional change record with this case-local changeId.

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"changeId":"CHG-2026-0004-MQA-011","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```

### Step 7. Assert generated event
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004-MQA-011",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1||a[0].event_type!=="RECORD_PROCESSING_STATE_CHANGED"||a[0].event_date!=="2026-07-15T11:00:00Z"||a[0].record_key!=="REC-220"||a[0].field_path!=="item.processingState"||a[0].old_value!=="pending"||a[0].new_value!=="reviewed"||a[0].rule_id!=="RULE_PROCESSING_STATE_CHANGED") quit(1)'
```
Expected cardinality: 1
Negative assertion: no event beyond expected cardinality and no unrelated event type.

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --quiet --eval 'const a=db.change_errors.find({change_id:"CHG-2026-0004-MQA-011",rule_id:"RULE_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1)'
```
Expected cardinality: 0
Negative assertion: no error beyond expected cardinality.

### Step 9. Rollback and post-rollback verification
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "Content-Type: application/json" -H "Authorization: Bearer <runtime token>" --data '{"documentId": "DOC-11990", "recordKey": "REC-220", "operationStatus": "modified", "fieldPath": "item.processingState", "oldValue": "reviewed", "newValue": "pending", "changeId": "CHG-2026-0004-MQA-011-ROLLBACK", "occurredAt": "2026-07-15T11:05:00Z"}'
mongosh "$DATABASE_NAME" --quiet --eval 'const d=db.source_records.findOne({document_id:"DOC-11990"}); if(!d||d.item.processingState!=="pending") quit(1)'
```

### Final expected result
change=1, event=1, errors=0; exact case behavior is preserved.
