# Record Change Passport — PROCESSING_STATE_CHANGED

## 1. Статус документа
| Поле | Значення |
|---|---|
| Alias | `PROCESSING_STATE_CHANGED` |
| Contract ID | `RULE_PROCESSING_STATE_CHANGED` |
| Version | `v3` |
| Document status | `final-ready` |
| Evidence status | `mixed: analyst-confirmed and expected` |
| Confirmation source | `RUN_04 selected-run input` |

## 2. Ідентичність правила
| Поле | Значення | Evidence |
|---|---|---|
| Business name | Processing state reviewed | analyst-confirmed |
| Business meaning | Document and verify a processing-state change. | analyst-confirmed |
| Event/output type | `RECORD_PROCESSING_STATE_CHANGED` | analyst-confirmed |

## 3. Обрана process branch та intake
| Крок | Підтверджене значення |
|---|---|
| Scenario | `RUN_04: Backtrack and Correct` |
| Source branch | fixed internal-record-change |
| Change kind/operation | `modified` |
| Target source path | `item.processingState` |
| Allowed operation/status values | `modified`; other statuses are no-op |

## 4. Source record contract
| Поле | Значення | Evidence |
|---|---|---|
| Database type | MongoDB | analyst-confirmed |
| Collection role | `source_records` | analyst-confirmed |
| Stable identifiers | `document_id=DOC-11990`, `record_key=REC-220` | analyst-confirmed |
| Target source path | `item.processingState` | analyst-confirmed |
| Baseline / changed value | `pending` → `reviewed` | analyst-confirmed |

## 5. Change record contract
| Поле | Значення | Evidence/source |
|---|---|---|
| Change ID | `CHG-2026-0004` | analyst-confirmed |
| Operation/status | `modified` | analyst-confirmed |
| Field path | `item.processingState` | analyst-confirmed |
| Old / new value source | `oldValue=pending`, `newValue=reviewed` | request body |
| Occurred-at/date source | `occurredAt=2026-07-15T11:00:00Z` | request body |
| Root/source identifiers | `documentId=DOC-11990`, `recordKey=REC-220` | request body |

## 6. Порядок аналізу та decision contract
1. Accept only `operationStatus=modified`.
2. Accept only `fieldPath=item.processingState`.
3. Require documentId, recordKey, changeId, occurredAt, oldValue and newValue keys.
4. Normalize null, missing and empty string to empty string for comparison; preserve case and whitespace.
5. Equal normalized values are no-op.
6. Build output using the exact mapping below.
7. Reject an existing `(changeId,eventType)` identity without a second side effect.
8. Return create, no-op, blocked or error with an observable reason.

## 7. Derived event/output contract
| Output field | Value/source | Evidence/status |
|---|---|---|
| eventType | `RECORD_PROCESSING_STATE_CHANGED` | confirmed |
| identity/dedup key | `(CHG-2026-0004, RECORD_PROCESSING_STATE_CHANGED)` | confirmed |
| documentId / recordKey | `DOC-11990` / `REC-220` | confirmed |
| fieldPath | `item.processingState` | confirmed |
| oldValue / newValue | `pending` / `approved` | confirmed |
| eventDate | `2026-07-15T11:00:00Z` from occurredAt | confirmed |
| ruleId | `RULE_PROCESSING_STATE_CHANGED` | confirmed |
| values | `{oldValue: pending, newValue: reviewed}` | exact keys confirmed |

## 8. Exact mapping matrix
| Target | Source | Transformation | Missing behavior |
|---|---|---|---|
| eventType | rule contract | none | block |
| documentId | change.documentId | none | block |
| recordKey | change.recordKey | none | block |
| fieldPath | change.fieldPath | none | block |
| oldValue | change.oldValue | preserve raw | block when key absent |
| newValue | change.newValue | preserve raw | block when key absent |
| eventDate | change.occurredAt | ISO-8601 pass-through | block |
| values.oldValue | change.oldValue | display fallback `-` only when empty | block when key absent |
| values.newValue | change.newValue | display fallback `-` only when empty | block when key absent |

## 9. Values shape та exact keys
| Key | Source | Stored semantics | Display semantics | Used by UI |
|---|---|---|---|---|
| oldValue | change.oldValue | raw scalar/null | empty renders `-` | yes |
| newValue | change.newValue | raw scalar/null | empty renders `-` | yes |

## 10. Normalization, trigger, no-op, missing-data та duplicate behavior
| Concern | Rule | Observable result |
|---|---|---|
| Comparison normalization | null, missing and empty → empty; preserve case/whitespace | deterministic comparison |
| Trigger | supported path + modified + unequal normalized values | exactly one event |
| No-op | equal normalized, unrelated field, unsupported status | no event and reason |
| Missing required mapping | missing mandatory data | blocked + diagnostic in change_errors |
| Duplicate | same changeId and eventType | reject; event total remains one |

## 11. UI / localization
| Поле | Значення | Placeholder set |
|---|---|---|
| Display name en | Processing state reviewed | oldValue,newValue |
| Display name uk | Стан обробки переглянуто | oldValue,newValue |
| Text template en | Processing state reviewed from `{oldValue}` to `{newValue}`. | oldValue,newValue |
| Text template uk | Стан обробки переглянуто з `{oldValue}` на `{newValue}`. | oldValue,newValue |

## 12. Observability contract
| Decision | Required observable evidence |
|---|---|
| Created | one change record, one exact event, zero errors |
| No-op | change record present, event count zero, zero errors, reason logged/returned |
| Blocked | no event, one diagnostic tied to changeId and ruleId |
| Duplicate | second explicit cycle; final event cardinality remains one |
| Error | error record exposes ruleId, changeId and reason without partial event |

## 13. Exclusions / out of scope
| Item | Reason |
|---|---|
| Repository mutation | implementation module unavailable; instructions only |
| Live execution claim | runner contract forbids it |
| Generated-record deletion | no authoritative delete operation; unique IDs isolate cases |

## 14. Functional test contract
| ID | Назва | Requirement/rule | Preconditions/input | Action | Expected decision/output | Manual QA | Automation |
|---|---|---|---|---|---|---|---|
| `TC-001` | Meaningful supported change creates one event | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=1, errors=0 | `MQA-001` | `AUTO-001` because this allocation validates the same lifecycle behavior |
| `TC-002` | Equal normalized values are no-op | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=0, errors=0 | `MQA-002` | `AUTO-002` because this allocation validates the same lifecycle behavior |
| `TC-003` | Unrelated field is no-op | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=0, errors=0 | `MQA-003` | `AUTO-003` because this allocation validates the same lifecycle behavior |
| `TC-004` | Unsupported operation status is no-op | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=0, errors=0 | `MQA-004` | `AUTO-004` because this allocation validates the same lifecycle behavior |
| `TC-005` | Missing mandatory documentId blocks processing | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=0, event=0, errors=1 | `MQA-005` | `AUTO-005` because this allocation validates the same lifecycle behavior |
| `TC-006` | Duplicate identity creates no second event | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=1, errors=0 | `MQA-006` | `AUTO-006` because this allocation validates the same lifecycle behavior |
| `TC-007` | Null missing and empty normalize to empty string | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=0, errors=0 | `MQA-007` | `AUTO-007` because this allocation validates the same lifecycle behavior |
| `TC-008` | Case and whitespace are preserved for comparison | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=1, errors=0 | `MQA-008` | `AUTO-008` because this allocation validates the same lifecycle behavior |
| `TC-009` | Event date maps from occurredAt | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=1, errors=0 | `MQA-009` | `AUTO-009` because this allocation validates the same lifecycle behavior |
| `TC-010` | Payload uses exact oldValue and newValue keys | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=1, errors=0 | `MQA-010` | `AUTO-010` because this allocation validates the same lifecycle behavior |
| `TC-011` | Unrelated source fields do not affect decision | confirmed rule | DOC-11990 / REC-220 with case-specific changeId | publish then process | change=1, event=1, errors=0 | `MQA-011` | `AUTO-011` because this allocation validates the same lifecycle behavior |

## 15. Unit/provider test contract
| ID | Компонент/правило | Covered behavior | Fixture fields | Fixture values | Invocation target/input | Exact assertions | Negative assertions | Evidence |
|---|---|---|---|---|---|---|---|---|
| UNIT-001 | operation/status filter | modified accepted; unsupported status no-op | operationStatus | modified / created | decision evaluator with source fixture | decision=create for modified | no event for unsupported | analyst-confirmed/expected |
| UNIT-002 | field-path filter | only item.processingState is supported | fieldPath | item.processingState / item.name | field matcher with path fixture | supported=true for exact path | no event for unrelated path | analyst-confirmed/expected |
| UNIT-003 | normalization | null missing and empty normalize to empty | oldValue,newValue | pending / empty string | normalizer with null-empty fixture | normalized values equal empty string | no mutation of stored raw values | analyst-confirmed/expected |
| UNIT-004 | no-op decision | equal normalized values create no event | oldValue,newValue | pending / pending | decision evaluator with source fixture | decision=no-op; event count 0 | no error | analyst-confirmed/expected |
| UNIT-005 | empty-display fallback | empty display uses hyphen fallback | oldValue,newValue | null / approved | payload renderer with display fixture | old display value = - | stored oldValue not replaced | analyst-confirmed/expected |
| UNIT-006 | required mapping blocking | missing mandatory documentId blocks oldValue/newValue mapping | documentId, oldValue, newValue | DOC-11990 absent / pending / reviewed | mapping validator with missing-key fixture | decision=blocked; one diagnostic | no event | analyst-confirmed/expected |
| UNIT-007 | exact payload mapping | map exact event fields and values keys | fieldPath, oldValue, newValue, event type | item.processingState / pending / reviewed / RECORD_PROCESSING_STATE_CHANGED | event builder with mapped fixture | all fields equal fixture; values keys oldValue,newValue | no extra values keys | analyst-confirmed/expected |
| UNIT-008 | date mapping | eventDate equals occurredAt with event type cardinality count 1 | occurredAt, event type | 2026-07-15T11:00:00Z / RECORD_PROCESSING_STATE_CHANGED | event builder with mapped fixture | eventDate exact equality | no current-time substitution | analyst-confirmed/expected |
| UNIT-009 | duplicate identity | same changeId and event type rejected | changeId,eventType | CHG-2026-0004 | dedup provider with repeated identity fixture | second cycle event total remains 1 | no second side effect | analyst-confirmed/expected |
| UNIT-010 | localized placeholders | both locale templates use same placeholders | oldValue,newValue | pending / reviewed | text renderer with locale fixture | placeholder sets identical | no missing placeholder | analyst-confirmed/expected |
| UNIT-011 | unrelated-field independence | unrelated fieldPath item.name leaves oldValue/newValue event cardinality unchanged | fieldPath, oldValue, newValue | item.name / pending / reviewed | decision evaluator with source fixture | decision unchanged | no payload contamination | analyst-confirmed/expected |

## 16. Functional ↔ unit/provider traceability
| Functional ID | Behavior under test | Covered rules | Unit/provider IDs | Coverage rationale |
|---|---|---|---|---|
| `TC-001` | Meaningful supported change creates one event | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-002` | Equal normalized values are no-op | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-003` | Unrelated field is no-op | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-004` | Unsupported operation status is no-op | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-005` | Missing mandatory documentId blocks processing | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-006` | Duplicate identity creates no second event | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-007` | Null missing and empty normalize to empty string | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-008` | Case and whitespace are preserved for comparison | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-009` | Event date maps from occurredAt | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-010` | Payload uses exact oldValue and newValue keys | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |
| `TC-011` | Unrelated source fields do not affect decision | operation, path, normalization, mapping, dedup as applicable | UNIT-001–`UNIT-011 | Atomic units collectively cover the exact decision and persisted effects. |

## 17. QA reference data
| Datum | Value | Evidence |
|---|---|---|
| documentId | DOC-11990 | confirmed |
| recordKey | REC-220 | confirmed |
| changeId | CHG-2026-0004 (case-specific suffixes for isolation) | confirmed/derived |
| fieldPath | item.processingState | confirmed |
| old/new | pending / reviewed | confirmed |
| occurredAt | 2026-07-15T11:00:00Z | confirmed |
| endpoints | POST /api/test/database-change/publish; POST /api/database-change/process | operational contract |

## 18. Acceptance criteria
- Exact supported change creates one event and zero errors.
- All no-op paths create no event.
- Missing mandatory data fails closed.
- Duplicate second cycle has no second side effect.
- All functional IDs have Manual QA and Automation allocation.

## 19. Open questions
None. Runtime placeholders BASE_URL, AUTH_HEADERS and DATABASE_NAME are captured at execution time and do not block specification generation.

## 20. Artifact-specific validation
All required sections, functional IDs, unit IDs, mapping, traceability, negative assertions and allocation are complete. No candidate facts are promoted and no live execution is claimed.

## 21. Canonical TC/MQA/AUTO status traceability
Authoritative registry reference: `runtime/CASE_STATUS_REGISTRY.yaml` (materialized current-run copy: `CASE_STATUS_REGISTRY.yaml`).
| TC | MQA | AUTO | Status | Rationale / closure |
|---|---|---|---|---|
| TC-001 | MQA-001 | AUTO-001 | runnable | MQA-001 validates the same lifecycle behavior because it uses the authoritative TC-001 fixture; AUTO-001 covers the same behavior and status. |
| TC-002 | MQA-002 | AUTO-002 | runnable | MQA-002 validates the same lifecycle behavior because it uses the authoritative TC-002 fixture; AUTO-002 covers the same behavior and status. |
| TC-003 | MQA-003 | AUTO-003 | runnable | MQA-003 validates the same lifecycle behavior because it uses the authoritative TC-003 fixture; AUTO-003 covers the same behavior and status. |
| TC-004 | MQA-004 | AUTO-004 | runnable | MQA-004 validates the same lifecycle behavior because it uses the authoritative TC-004 fixture; AUTO-004 covers the same behavior and status. |
| TC-005 | MQA-005 | AUTO-005 | blocked_missing_binding | Required authoritative omission transport binding is absent; closure evidence is request schema supporting omission of mandatory documentId to unblock generation. |
| TC-006 | MQA-006 | AUTO-006 | runnable | MQA-006 validates the same lifecycle behavior because it uses the authoritative TC-006 fixture; AUTO-006 covers the same behavior and status. |
| TC-007 | MQA-007 | AUTO-007 | runnable | MQA-007 validates the same lifecycle behavior because it uses the authoritative TC-007 fixture; AUTO-007 covers the same behavior and status. |
| TC-008 | MQA-008 | AUTO-008 | runnable | MQA-008 validates the same lifecycle behavior because it uses the authoritative TC-008 fixture; AUTO-008 covers the same behavior and status. |
| TC-009 | MQA-009 | AUTO-009 | runnable | MQA-009 validates the same lifecycle behavior because it uses the authoritative TC-009 fixture; AUTO-009 covers the same behavior and status. |
| TC-010 | MQA-010 | AUTO-010 | runnable | MQA-010 validates the same lifecycle behavior because it uses the authoritative TC-010 fixture; AUTO-010 covers the same behavior and status. |
| TC-011 | MQA-011 | AUTO-011 | runnable | MQA-011 validates the same lifecycle behavior because it uses the authoritative TC-011 fixture; AUTO-011 covers the same behavior and status. |
