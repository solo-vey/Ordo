# QA Automation README — PROCESSING_STATE_CHANGED

## Purpose
Run the declarative specification in `08_QA_AUTOMATION_SPEC_PROCESSING_STATE_CHANGED.yaml` without claiming execution in this package.

## Runner prerequisites
A runner conforming to `contracts/DATABASE_CHANGE_AUTOMATION_RUNNER_CONTRACT.yaml`, access to MongoDB and both confirmed HTTP endpoints.

## Runner contract evidence
Runner type `declarative_database_change_runner`; supported actions are mongo_find, http_post, poll_until and exact assertions.

## How test discovery works
Discover root `test_cases`; each case has one lifecycle profile and stable functional/manual references.

## How to run one test
Supply BASE_URL, AUTH_HEADERS and DATABASE_NAME, then invoke the conforming runner with the spec path and case id. Exact CLI syntax is runner-specific and must be taken from the installed runner, not invented here.

## How to run the full specification
Invoke the same conforming runner for all test_cases after capturing the three runtime values.

## Structure-validation status
Pending authoritative Driver validation for v1.

## Runner-discovery status
Contract confirmed; concrete executable location is runtime-discovered.

## Live-run status
Not run; no live execution claim.

## No-op handling
No-op profiles assert exact zero event cardinality.

## Troubleshooting
Check endpoint reachability, credentials, database selection, polling timeout and exact fixture isolation.

## Generated reports
Preserve runner command, stdout, stderr, return code and case results when executed externally.

## Limitations
AUTO-005 remains blocked until an authoritative omission-capable publish binding exists. Generated-record deletion is omitted because no authoritative delete operation is supplied.
