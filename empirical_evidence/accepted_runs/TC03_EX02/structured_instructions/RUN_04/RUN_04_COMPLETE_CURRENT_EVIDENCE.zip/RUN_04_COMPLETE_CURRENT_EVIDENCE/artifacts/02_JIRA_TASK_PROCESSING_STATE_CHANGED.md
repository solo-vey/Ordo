# Jira Task — PROCESSING_STATE_CHANGED

## Summary
Implement RULE_PROCESSING_STATE_CHANGED for item.processingState with exact database-change outcomes.

## Delivery requirements
DEL-001: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 1 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-002: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 0 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-003: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 0 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-004: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 0 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-005: Implement database change processor behavior for item.processingState and persist exactly 0 change record(s), emit exactly 0 event(s), and create exactly 1 error record(s), preventing unrelated mutation.
DEL-006: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 1 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-007: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 0 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-008: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 1 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-009: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 1 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-010: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 1 event(s), and create exactly 0 error record(s), preventing unrelated mutation.
DEL-011: Implement database change processor behavior for item.processingState and persist exactly 1 change record(s), emit exactly 1 event(s), and create exactly 0 error record(s), preventing unrelated mutation.

## Acceptance criteria
AC-001: Given operationStatus modified with oldValue pending and newValue reviewed, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 1 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-002: Given operationStatus modified with oldValue pending and newValue pending, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 0 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-003: Given operationStatus modified for unrelated fieldPath item.name, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 0 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-004: Given unsupported operationStatus created for item.processingState, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 0 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-005: Given a missing mandatory documentId request when an authoritative omission binding becomes available, when the processor handles the fixture, it creates exactly 0 change record(s), exactly 0 event(s), exactly 1 error record(s), and no second or unrelated mutation.
AC-006: Given duplicate publish and process cycles with the same changeId and event type, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 1 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-007: Given operationStatus modified with oldValue pending and newValue reviewed, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 0 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-008: Given operationStatus modified with oldValue pending and newValue reviewed, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 1 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-009: Given operationStatus modified with oldValue pending and newValue reviewed, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 1 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-010: Given operationStatus modified with oldValue pending and newValue reviewed, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 1 event(s), exactly 0 error record(s), and no second or unrelated mutation.
AC-011: Given operationStatus modified with oldValue pending and newValue reviewed, when the processor handles the fixture, it creates exactly 1 change record(s), exactly 1 event(s), exactly 0 error record(s), and no second or unrelated mutation.

## Stable QA reference data
DOC-11990, REC-220, item.processingState, pending, approved, CHG-2026-0004, 2026-07-15T11:00:00Z, RULE_PROCESSING_STATE_CHANGED, RECORD_PROCESSING_STATE_CHANGED.

## Definition of Done
- Evidence: attach Driver validator reports, immutable logs, return codes and artifact SHA-256.
- Blocker closure: every blocker identifies the missing capability and closure evidence and is resolved or explicitly unblocked before approval.
- Cross-artifact consistency: verify Passport, Manual QA and Automation use the same TC/MQA/AUTO mappings and literals.
