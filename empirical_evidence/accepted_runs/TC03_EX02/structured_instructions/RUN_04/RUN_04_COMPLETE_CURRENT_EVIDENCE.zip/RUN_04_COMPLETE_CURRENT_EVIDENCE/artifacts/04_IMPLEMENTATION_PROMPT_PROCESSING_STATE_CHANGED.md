# Implementation Prompt — PROCESSING_STATE_CHANGED

## Objective
Implement `RULE_PROCESSING_STATE_CHANGED` so a meaningful `item.processingState` change produces exactly one `RECORD_PROCESSING_STATE_CHANGED`.

## Canonical contract
Use `01_RECORD_CHANGE_PASSPORT_PROCESSING_STATE_CHANGED.md v3` as source of truth. The implementation module is unavailable in this package, so first discover actual repository paths and symbols; do not invent them.

## Required code discovery
Locate the database-change entrypoint, rule registry, source/change/event repositories, duplicate provider, diagnostics path, locale templates and nearest analogous tests. Record discovered paths before editing.

## Source and change contracts
MongoDB source collection role `source_records`; identity `DOC-11990` / `REC-220`; operationStatus `modified`; fieldPath `item.processingState`; old/new `pending`/`approved`; changeId `CHG-2026-0004`; occurredAt `2026-07-15T11:00:00Z`.

## Derived event contract
Create `RECORD_PROCESSING_STATE_CHANGED` with exact documentId, recordKey, fieldPath, oldValue, newValue, ruleId and eventDate from occurredAt. Values object must contain exactly `oldValue` and `newValue`.

## Exact mapping
Follow Passport §8. Preserve raw stored values. Apply `-` only as empty display fallback.

## Trigger, no-op and error rules
Create only for modified + exact path + unequal normalized values. Null, missing and empty normalize to empty for comparison; preserve case/whitespace. Equal normalized, unrelated path and unsupported status are no-op. Missing mandatory mapping blocks and emits a diagnostic without an event.

## Duplicate and versioning behavior
Deduplicate by `(changeId,eventType)`. Execute a two-cycle test and assert final event count remains one. Avoid unrelated schema/version changes.

## Required tests
Implement atomic `UNIT-001`–`UNIT-011` and functional `TC-001`–`TC-011`. Assertions must cover exact field values, cardinalities and forbidden side effects.

## Documentation updates
Update discovered rule/event documentation and localized template references while preserving placeholder parity.

## Architecture preservation constraints
Use existing abstractions, transaction boundaries, persistence conventions and test infrastructure discovered in repository.

## Forbidden unrelated changes
No broad refactor, dependency upgrade, endpoint invention, cleanup API invention, live execution claim or fixture weakening.

## Self-validation before handoff
Run targeted unit/provider tests, functional tests and repository-required lint/type/static checks. Attach commands and actual results in the implementation PR; this specification itself makes no run claim.

## Expected change-impact classification
Localized rule/event processing change with persistence, duplicate, diagnostics, localization and test impacts; exact files depend on repository discovery.
