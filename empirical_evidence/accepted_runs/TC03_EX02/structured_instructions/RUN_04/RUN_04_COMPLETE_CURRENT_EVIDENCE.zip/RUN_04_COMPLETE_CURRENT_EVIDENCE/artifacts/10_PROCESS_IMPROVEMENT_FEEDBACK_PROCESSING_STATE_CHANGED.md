# Process Improvement Feedback — PROCESSING_STATE_CHANGED

## Observed issue
Late corrections require explicit invalidation of dependent approvals and metadata.
## Scope classification
Process-control and cross-artifact consistency.
## Root cause
A corrected canonical fact can leave stale downstream references unless dependency invalidation is enforced.
## Affected process steps
Passport validation/presentation, Jira and QA derivation, metadata regeneration and package gate.
## Affected templates and gates
Passport, Jira, Manual QA, Automation, consistency and package approval ledgers.
## Rule propagation matrix
Canonical correction → Passport → Jira/Implementation/QA/Automation → metadata → cross-artifact gate → package gate.
## Recommended correction
Invalidate all dependent receipts and approvals, regenerate current versions, rerun Driver validation, then re-present.
## Regression prevention
Hash-bind receipts to artifact version and reject stale approval hashes.
## Status
Applied as the required RUN_04 correction workflow.
