# QA Automation README

Runner type: `declarative_database_change_runner`. Use runtime-captured `BASE_URL`, `AUTH_HEADERS`, and `DATABASE_NAME`. Execute `05_QA_AUTOMATION_SPEC.yaml` only with a compatible runner. This package is an executable specification and does not claim a live run. Cases AUTO-001..007 map one-to-one to TC-001..007 and MQA-001..007.
