# Record Change Passport — PROCESSING_STATE_CHANGED

## 1. Статус документа
| Поле | Значення |
|---|---|
| Alias | `PROCESSING_STATE_CHANGED` |
| Contract ID | `RULE_PROCESSING_STATE_CHANGED` |
| Version | `v1` |
| Document status | `final-ready` |
| Evidence status | `analyst-confirmed` |
| Confirmation source | `RUN_01 selected-run input` |

## 2. Ідентичність правила
Подія `RECORD_PROCESSING_STATE_CHANGED` (“Processing state changed”) фіксує значущу зміну `item.processingState` для запису `REC-184` у документі `DOC-74291`.

## 3. Обрана process branch та intake
Fixed internal-record-change branch; operation `modified`; source collection `source_records`; target path `item.processingState`.

## 4. Source record contract
| Поле | Значення | Evidence |
|---|---|---|
| Collection role | `source_records` | analyst-confirmed |
| Stable identifiers | `document_id=DOC-74291`, `record_key=REC-184` | analyst-confirmed |
| Target source path | `item.processingState` | analyst-confirmed |
| Baseline value | `pending` | exact fixture |
| Changed value | `approved` | exact fixture |

## 5. Change record contract
| Поле | Значення | Evidence/source |
|---|---|---|
| Change ID | `CHG-2026-0001` | exact fixture |
| Operation/status | `modified` | exact fixture |
| Field path | `item.processingState` | exact fixture |
| Old value source | `oldValue=pending` | exact fixture |
| New value source | `newValue=approved` | exact fixture |
| Occurred-at/date source | `occurredAt=2026-07-15T09:30:00Z` | exact fixture |
| Root/source identifiers | `DOC-74291`, `REC-184` | exact fixture |

## 6. Порядок аналізу та decision contract
Validate operation, field path, identifiers and timestamp; normalize comparison values; apply no-op; map exact output; reject duplicate identity; return create/no-op/blocked with reason.

## 7. Derived event/output contract
| Output field | Value/source | Evidence/status |
|---|---|---|
| event_type | `RECORD_PROCESSING_STATE_CHANGED` | confirmed |
| rule_id | `RULE_PROCESSING_STATE_CHANGED` | confirmed |
| change_id | `CHG-2026-0001` | confirmed |
| record_key | `REC-184` | confirmed |
| field_path | `item.processingState` | confirmed |
| event_date | `2026-07-15T09:30:00Z` from occurredAt | confirmed |
| values | exactly `{oldValue: pending, newValue: approved}` | confirmed |
| identity/dedup key | `(change_id,event_type)` | confirmed |

## 8. Exact mapping matrix
| Target | Source | Transformation | Missing behavior |
|---|---|---|---|
| event_type | contract event type | none | block |
| rule_id | contract rule id | none | block |
| change_id | change.changeId | none | block |
| record_key | change.recordKey | none | block |
| field_path | change.fieldPath | none | block |
| event_date | change.occurredAt | ISO-8601 identity mapping | block |
| values.oldValue | change.oldValue | stored as supplied; display fallback `-` only when empty | block |
| values.newValue | change.newValue | stored as supplied; display fallback `-` only when empty | block |

## 9. Values shape та exact keys
Exactly two keys: `oldValue`, `newValue`. Stored values preserve case and whitespace. UI display uses `-` only for normalized empty display.

## 10. Normalization, trigger, no-op, missing-data та duplicate behavior
| Concern | Rule | Observable result |
|---|---|---|
| Comparison normalization | null, missing and empty string become empty string; no trim/case conversion | deterministic comparison |
| Trigger | relevant field, supported operation, normalized values differ | exactly one event |
| No-op | equal values, unrelated field, unsupported operation | zero events and zero errors |
| Missing required mapping | mandatory source/change/mapping/identifier absent | blocked, zero events, one diagnostic error |
| Duplicate | same change_id + event_type | reject second side effect; final event count remains one |

## 11. UI / localization
English display name: `Processing state changed`. Ukrainian display name: `Стан обробки змінено`. Both templates use placeholders `{oldValue}` and `{newValue}` consistently.

## 12. Observability contract
Created: change count 1, event count 1, errors 0. No-op: event count 0. Blocked: event count 0 and diagnostic in `change_errors`. Duplicate: second cycle creates no additional event.

## 13. Exclusions / out of scope
Code modification and live execution are out of scope because implementation module/runtime bindings are unavailable. No invented URLs, repository paths or delete operations.

## 14. Functional test contract
| ID | Назва | Requirement/rule | Preconditions/input | Action | Expected decision/output | Manual QA | Automation | Status and mapping rationale |
|---|---|---|---|---|---|---|---|---|
| TC-001 | Positive state change | trigger and exact mapping | pending→approved, modified, target field | publish then process | 1 change, 1 exact event, 0 errors | MQA-001 | AUTO-001 | runnable because both validate the same event-created lifecycle behavior |
| TC-002 | Same-value no-op | normalized equality | approved→approved | publish then process | 1 change, 0 events, 0 errors | MQA-002 | AUTO-002 | runnable because both cover the same no-op lifecycle behavior |
| TC-003 | Unrelated-field no-op | field filter | item.otherField | publish then process | 1 change, 0 events, 0 errors | MQA-003 | AUTO-003 | runnable because both validate unrelated-field no-op behavior |
| TC-004 | Unsupported-operation no-op | operation filter | operation `created` | publish then process | 1 change, 0 events, 0 errors | MQA-004 | AUTO-004 | runnable because both cover unsupported operation no-op behavior |
| TC-005 | Missing mandatory data | fail closed | missing recordKey | publish/process | blocked, 0 events, diagnostic error | MQA-005 | AUTO-005 | runnable because required schema omission validates fail-closed behavior and closure evidence is the diagnostic query |
| TC-006 | Duplicate identity | dedup | same payload and change ID twice | two publish/process cycles | final event count 1, no second side effect | MQA-006 | AUTO-006 | runnable because both validate the same two-cycle duplicate behavior |
| TC-007 | Null/empty normalization | normalization | null→empty string | publish/process | normalized equality, 0 events | MQA-007 | AUTO-007 | runnable because both cover null/empty normalization behavior |

## 15. Unit/provider test contract
| ID | Компонент/правило | Covered behavior | Fixture fields | Fixture values | Invocation target/input | Exact assertions | Negative assertions | Evidence |
|---|---|---|---|---|---|---|---|---|
| UNIT-001 | operation filter | accepts modified | operationStatus | modified | rule evaluator fixture | decision=create | not no-op | confirmed |
| UNIT-002 | field filter | accepts exact path | fieldPath | item.processingState | rule evaluator fixture | target=true | no unrelated match | confirmed |
| UNIT-003 | normalization | oldValue/newValue null and empty equivalence | oldValue,newValue | oldValue=null; newValue=empty; count=0 | normalizer input for item.processingState | oldValue and newValue normalize to empty; event count=0 | no trim/case change | confirmed |
| UNIT-004 | equality no-op | equal normalized values | oldValue,newValue | approved,approved | decision fixture | decision=no-op | no event candidate | confirmed |
| UNIT-005 | display fallback | oldValue/newValue empty display behavior | oldValue,newValue | oldValue=empty; newValue=approved; count=1 | formatter for RECORD_PROCESSING_STATE_CHANGED | oldValue display='-' and newValue='approved' | stored oldValue remains empty | confirmed |
| UNIT-006 | missing mapping | missing recordKey blocks oldValue/newValue mapping | recordKey,fieldPath | recordKey missing; fieldPath=item.processingState; event count=0 | validator input operationStatus=modified | blocked and error count=1 | no event count=0 | confirmed |
| UNIT-007 | payload mapping | exact two-key values | oldValue,newValue | pending,approved | mapper fixture | exact values object | no extra keys | confirmed |
| UNIT-008 | date mapping | fieldPath event date mapping | occurredAt,fieldPath | occurredAt=2026-07-15T09:30:00Z; fieldPath=item.processingState | mapper input RULE_PROCESSING_STATE_CHANGED | event_date exact and event count=1 | no current-time substitution | confirmed |
| UNIT-009 | duplicate identity | event type and changeId composite count | changeId,event type | CHG-2026-0001,RECORD_PROCESSING_STATE_CHANGED | dedup input count=2 cycles | final event count=1 | no second event | confirmed |
| UNIT-010 | localization | oldValue/newValue placeholders consistent | oldValue,newValue,event type | pending,approved,RECORD_PROCESSING_STATE_CHANGED | renderer input count=1 | both locales contain oldValue and newValue | no missing placeholder | expected |
| UNIT-011 | unrelated independence | unrelated fieldPath does not affect oldValue/newValue | fieldPath,oldValue,newValue | fieldPath=item.otherField; oldValue=pending; newValue=approved | evaluator input operationStatus=modified | event count=0 | no payload leakage | confirmed |

## 16. Functional ↔ unit/provider traceability
TC-001 → UNIT-001, UNIT-002, UNIT-007, UNIT-008. TC-002 → UNIT-003, UNIT-004. TC-003 → UNIT-002. TC-004 → UNIT-001. TC-005 → UNIT-006. TC-006 → UNIT-009. TC-007 → UNIT-003, UNIT-005.

## 17. QA reference data
Use exact source fixture `DOC-74291` / `REC-184` / `pending` and exact change fixture `CHG-2026-0001`, `modified`, `item.processingState`, `pending→approved`, `2026-07-15T09:30:00Z`.

## 18. Acceptance criteria
All seven functional cases and eleven atomic unit/provider specifications are represented; exact mapping, normalization, missing-data, duplicate, Manual QA and Automation allocations are consistent.

## 19. Open questions
None. Runtime-only placeholders `BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME` do not block executable specifications.

## 20. Artifact-specific validation
Required sections complete; no candidate values promoted; no live execution claimed.

Authoritative traceability registry: `runtime/CASE_STATUS_REGISTRY.yaml`.
