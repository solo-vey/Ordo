# Manual QA Execution Specification

Runtime placeholders: `BASE_URL`, `AUTH_HEADERS`, `DATABASE_NAME`. No live execution is claimed.
## MQA-001 — Positive target-field change
Functional TC: TC-001

### Step 0. Capture runtime values
Capture BASE_URL from deployed service configuration, AUTH_HEADERS from authorized test credentials, and DATABASE_NAME from the active MongoDB connection.

### Step 1. Verify source fixture
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.record_key!="REC-184") quit(1)'
```

### Step 2. Verify pre-state
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```

### Step 3. Record exact stimulus
operationStatus=modified; fieldPath=item.processingState; oldValue=pending; newValue=approved; changeId=CHG-2026-0001.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved","changeId":"CHG-2026-0001","occurredAt":"2026-07-15T09:30:00Z"}'
```
Expected HTTP status: 200.

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.change_records.find({change_id:"CHG-2026-0001"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].change_id==null || a[0].document_id==null || a[0].record_key==null || a[0].field_path==null || !('old_value' in a[0]) || !('new_value' in a[0]) || a[0].operation_status==null)) quit(1); if(a.length===1 && (a[0].field_path!=="item.processingState" || a[0].record_key!=="REC-184")) quit(1)'
```
Expected cardinality: 1

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0001","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200.

### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0001",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].event_type==null || a[0].event_date==null || a[0].record_key==null || a[0].field_path==null || a[0].values.oldValue==null || a[0].values.newValue==null || a[0].rule_id==null)) quit(1); if(a.length===1 && (a[0].record_key!=="REC-184" || a[0].field_path!=="item.processingState" || a[0].event_date!=="2026-07-15T09:30:00Z" || a[0].values.oldValue!=="pending" || a[0].values.newValue!=="approved")) quit(1)'
```
Expected cardinality: 1

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0001",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(n!==0) quit(1)'
```
Expected cardinality: 0

### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending","changeId":"CHG-2026-0001-RB","occurredAt":"2026-07-15T09:31:00Z"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```
fieldPath=item.processingState oldValue=approved newValue=pending

### Final expected result
Change cardinality 1; event cardinality 1; error cardinality 0; rollback restores the exact pre-stimulus value.

## MQA-002 — Same-value no-op
Functional TC: TC-002

### Step 0. Capture runtime values
Capture BASE_URL from deployed service configuration, AUTH_HEADERS from authorized test credentials, and DATABASE_NAME from the active MongoDB connection.

### Step 1. Verify source fixture
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.record_key!="REC-184") quit(1)'
```

### Step 2. Verify pre-state
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```

### Step 3. Record exact stimulus
operationStatus=modified; fieldPath=item.processingState; oldValue=approved; newValue=approved; changeId=CHG-2026-0002.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"approved","changeId":"CHG-2026-0002","occurredAt":"2026-07-15T09:30:00Z"}'
```
Expected HTTP status: 200.

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.change_records.find({change_id:"CHG-2026-0002"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].change_id==null || a[0].document_id==null || a[0].record_key==null || a[0].field_path==null || !('old_value' in a[0]) || !('new_value' in a[0]) || a[0].operation_status==null)) quit(1); if(a.length===1 && (a[0].field_path!=="item.processingState" || a[0].record_key!=="REC-184")) quit(1)'
```
Expected cardinality: 1

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0002","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200.

### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0002",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1); '
```
Expected cardinality: 0

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0002",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(n!==0) quit(1)'
```
Expected cardinality: 0

### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"approved","changeId":"CHG-2026-0002-RB","occurredAt":"2026-07-15T09:31:00Z"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```
fieldPath=item.processingState oldValue=approved newValue=approved

### Final expected result
Change cardinality 1; event cardinality 0; error cardinality 0; rollback restores the exact pre-stimulus value.

## MQA-003 — Unrelated-field no-op
Functional TC: TC-003

### Step 0. Capture runtime values
Capture BASE_URL from deployed service configuration, AUTH_HEADERS from authorized test credentials, and DATABASE_NAME from the active MongoDB connection.

### Step 1. Verify source fixture
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.record_key!="REC-184") quit(1)'
```

### Step 2. Verify pre-state
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```

### Step 3. Record exact stimulus
operationStatus=modified; fieldPath=item.otherField; oldValue=x; newValue=y; changeId=CHG-2026-0003.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.otherField","oldValue":"x","newValue":"y","changeId":"CHG-2026-0003","occurredAt":"2026-07-15T09:30:00Z"}'
```
Expected HTTP status: 200.

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.change_records.find({change_id:"CHG-2026-0003"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].change_id==null || a[0].document_id==null || a[0].record_key==null || a[0].field_path==null || !('old_value' in a[0]) || !('new_value' in a[0]) || a[0].operation_status==null)) quit(1); if(a.length===1 && (a[0].field_path!=="item.otherField" || a[0].record_key!=="REC-184")) quit(1)'
```
Expected cardinality: 1

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0003","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200.

### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0003",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1); '
```
Expected cardinality: 0

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0003",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(n!==0) quit(1)'
```
Expected cardinality: 0

### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.otherField","oldValue":"y","newValue":"x","changeId":"CHG-2026-0003-RB","occurredAt":"2026-07-15T09:31:00Z"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```
fieldPath=item.otherField oldValue=y newValue=x

### Final expected result
Change cardinality 1; event cardinality 0; error cardinality 0; rollback restores the exact pre-stimulus value.

## MQA-004 — Unsupported-operation no-op
Functional TC: TC-004

### Step 0. Capture runtime values
Capture BASE_URL from deployed service configuration, AUTH_HEADERS from authorized test credentials, and DATABASE_NAME from the active MongoDB connection.

### Step 1. Verify source fixture
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.record_key!="REC-184") quit(1)'
```

### Step 2. Verify pre-state
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```

### Step 3. Record exact stimulus
operationStatus=created; fieldPath=item.processingState; oldValue=pending; newValue=approved; changeId=CHG-2026-0004.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"created","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved","changeId":"CHG-2026-0004","occurredAt":"2026-07-15T09:30:00Z"}'
```
Expected HTTP status: 200.

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.change_records.find({change_id:"CHG-2026-0004"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].change_id==null || a[0].document_id==null || a[0].record_key==null || a[0].field_path==null || !('old_value' in a[0]) || !('new_value' in a[0]) || a[0].operation_status==null)) quit(1); if(a.length===1 && (a[0].field_path!=="item.processingState" || a[0].record_key!=="REC-184")) quit(1)'
```
Expected cardinality: 1

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0004","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200.

### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0004",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1); '
```
Expected cardinality: 0

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0004",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(n!==0) quit(1)'
```
Expected cardinality: 0

### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending","changeId":"CHG-2026-0004-RB","occurredAt":"2026-07-15T09:31:00Z"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```
fieldPath=item.processingState oldValue=approved newValue=pending

### Final expected result
Change cardinality 1; event cardinality 0; error cardinality 0; rollback restores the exact pre-stimulus value.

## MQA-006 — Duplicate stimulus is deduplicated
Functional TC: TC-006

### Step 0. Capture runtime values
Capture BASE_URL from deployed service configuration, AUTH_HEADERS from authorized test credentials, and DATABASE_NAME from the active MongoDB connection.

### Step 1. Verify source fixture
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.record_key!="REC-184") quit(1)'
```

### Step 2. Verify pre-state
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```

### Step 3. Record exact stimulus
operationStatus=modified; fieldPath=item.processingState; oldValue=pending; newValue=approved; changeId=CHG-2026-0006.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved","changeId":"CHG-2026-0006","occurredAt":"2026-07-15T09:30:00Z"}'
```
Expected HTTP status: 200.

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.change_records.find({change_id:"CHG-2026-0006"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].change_id==null || a[0].document_id==null || a[0].record_key==null || a[0].field_path==null || !('old_value' in a[0]) || !('new_value' in a[0]) || a[0].operation_status==null)) quit(1); if(a.length===1 && (a[0].field_path!=="item.processingState" || a[0].record_key!=="REC-184")) quit(1)'
```
Expected cardinality: 1

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0006","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200.

### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0006",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].event_type==null || a[0].event_date==null || a[0].record_key==null || a[0].field_path==null || a[0].values.oldValue==null || a[0].values.newValue==null || a[0].rule_id==null)) quit(1); if(a.length===1 && (a[0].record_key!=="REC-184" || a[0].field_path!=="item.processingState" || a[0].event_date!=="2026-07-15T09:30:00Z" || a[0].values.oldValue!=="pending" || a[0].values.newValue!=="approved")) quit(1)'
```
Expected cardinality: 1

Second duplicate cycle:
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"pending","newValue":"approved","changeId":"CHG-2026-0006","occurredAt":"2026-07-15T09:30:00Z"}'
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0006","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Assert final event cardinality remains 1 and no second side effect exists.
Expected cardinality: 1
Expected cardinality: 1

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0006",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(n!==0) quit(1)'
```
Expected cardinality: 0

### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"approved","newValue":"pending","changeId":"CHG-2026-0006-RB","occurredAt":"2026-07-15T09:31:00Z"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```
fieldPath=item.processingState oldValue=approved newValue=pending

### Final expected result
Change cardinality 1; event cardinality 1; error cardinality 0; rollback restores the exact pre-stimulus value.

## MQA-007 — Null and empty normalize to no-op
Functional TC: TC-007

### Step 0. Capture runtime values
Capture BASE_URL from deployed service configuration, AUTH_HEADERS from authorized test credentials, and DATABASE_NAME from the active MongoDB connection.

### Step 1. Verify source fixture
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.record_key!="REC-184") quit(1)'
```

### Step 2. Verify pre-state
```bash
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```

### Step 3. Record exact stimulus
operationStatus=modified; fieldPath=item.processingState; oldValue=None; newValue=; changeId=CHG-2026-0007.

### Step 4. Publish change
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":null,"newValue":"","changeId":"CHG-2026-0007","occurredAt":"2026-07-15T09:30:00Z"}'
```
Expected HTTP status: 200.

### Step 5. Assert change record
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.change_records.find({change_id:"CHG-2026-0007"}).toArray(); if(a.length!==1) quit(1); if(a.length===1 && (a[0].change_id==null || a[0].document_id==null || a[0].record_key==null || a[0].field_path==null || !('old_value' in a[0]) || !('new_value' in a[0]) || a[0].operation_status==null)) quit(1); if(a.length===1 && (a[0].field_path!=="item.processingState" || a[0].record_key!=="REC-184")) quit(1)'
```
Expected cardinality: 1

### Step 6. Invoke processor
```bash
curl -X POST "$BASE_URL/api/database-change/process" -H "$AUTH_HEADERS" --data '{"changeId":"CHG-2026-0007","ruleId":"RULE_PROCESSING_STATE_CHANGED"}'
```
Expected HTTP status: 200.

### Step 7. Assert generated events
```bash
mongosh "$DATABASE_NAME" --eval 'const a=db.generated_events.find({change_id:"CHG-2026-0007",event_type:"RECORD_PROCESSING_STATE_CHANGED"}).toArray(); if(a.length!==0) quit(1); '
```
Expected cardinality: 0

### Step 8. Assert errors
```bash
mongosh "$DATABASE_NAME" --eval 'const n=db.change_errors.countDocuments({change_id:"CHG-2026-0007",rule_id:"RULE_PROCESSING_STATE_CHANGED"}); if(n!==0) quit(1)'
```
Expected cardinality: 0

### Step 9. Rollback and verify
```bash
curl -X POST "$BASE_URL/api/test/database-change/publish" -H "$AUTH_HEADERS" --data '{"documentId":"DOC-74291","recordKey":"REC-184","operationStatus":"modified","fieldPath":"item.processingState","oldValue":"","newValue":null,"changeId":"CHG-2026-0007-RB","occurredAt":"2026-07-15T09:31:00Z"}'
mongosh "$DATABASE_NAME" --eval 'const x=db.source_records.findOne({document_id:"DOC-74291"}); if(!x||x.item.processingState!="pending") quit(1)'
```
fieldPath=item.processingState oldValue= newValue=None

### Final expected result
Change cardinality 1; event cardinality 0; error cardinality 0; rollback restores the exact pre-stimulus value.

## MQA-005 — Missing mandatory recordKey
Functional TC: TC-005
status: blocked_missing_binding
blocked_reason: Executable omission behavior requires an authoritative omission binding for the publish endpoint.
missing_capability: confirmed omission binding for mandatory recordKey
required_evidence: endpoint evidence showing whether the request is rejected before change persistence and the exact HTTP/error contract
