# Implementation Prompt — PROCESSING_STATE_CHANGED

## Objective
Implement `RULE_PROCESSING_STATE_CHANGED` exactly as defined by Passport v1.
## Canonical contract
Use the Passport and selected-run contracts; do not infer missing repository bindings.
## Required code discovery
Locate the actual database-change processor, rule registry, event mapper, persistence/dedup adapter, diagnostics sink and repository-native tests. Record exact paths and symbols before editing. If not found, stop implementation as blocked.
## Source and change contracts
MongoDB collection `source_records`; document `DOC-74291`; record `REC-184`; target `item.processingState`. Change fields: documentId, recordKey, operationStatus, fieldPath, oldValue, newValue, changeId, occurredAt.
## Derived event contract
Create `RECORD_PROCESSING_STATE_CHANGED` only for operation `modified`, exact target field, and differing normalized values. Map rule_id, change_id, record_key, field_path, event_date and exactly values.oldValue/values.newValue.
## Exact mapping
`event_date=occurredAt`; dedup identity `(changeId,event_type)`; display fallback `-` is presentation-only.
## Trigger, no-op and error rules
Equal normalized values, unrelated fields and unsupported operations are no-op. Missing mandatory data blocks and creates a diagnostic; never emit partial event.
## Duplicate and versioning behavior
Second same composite identity creates no additional event or side effect.
## Required tests
Implement atomic UNIT-001..011 and functional TC-001..007, including duplicate two-cycle and exact cardinality/field assertions.
## Documentation updates
Update rule documentation and traceability without inventing URLs.
## Architecture preservation constraints
Use existing abstractions, transaction boundaries and naming. No unrelated refactor.
## Forbidden unrelated changes
No hard-coded BASE_URL/AUTH_HEADERS/DATABASE_NAME, no delete operation invention, no live-result claim.
## Self-validation before handoff
Run repository-native formatter, lint, type checks and tests after discovery; report exact commands, return codes and changed files.
## Expected change-impact classification
Behavioral rule + mapping + tests + documentation; production implementation remains blocked until repository binding is discovered.
