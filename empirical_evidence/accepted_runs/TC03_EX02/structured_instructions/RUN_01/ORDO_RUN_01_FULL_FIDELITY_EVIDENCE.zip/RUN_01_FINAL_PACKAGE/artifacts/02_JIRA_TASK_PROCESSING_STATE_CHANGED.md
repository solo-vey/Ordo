# Jira Task — PROCESSING_STATE_CHANGED

## Summary and business context
Deliver the confirmed processing-state-change behavior from Passport v2.

## Delivery requirements
| ID | Concrete delivery output | Evidence |
|---|---|---|
| DEL-01 | Discover and record the actual database change processor, event mapper, diagnostic writer and test targets; return concrete repository paths and symbols or a blocked result. | Discovery record |
| DEL-02 | Implement the processor filter for operationStatus `modified` and field `item.processingState`; create exactly one event for `pending` to `approved`. | Unit and functional tests |
| DEL-03 | Map the change record into the event mapper and persist exactly `rule_id`, `change_id`, `record_key`, `field_path`, `event_date`, `values.oldValue`, and `values.newValue`. | Mapping test report |
| DEL-04 | Validate mandatory identifiers and block the database change processor when recordKey or mapping data is absent; create zero events and one error record. | Negative test log |
| DEL-05 | Deduplicate the event by `(changeId,event_type)` and reject a second identical publish/process cycle; persist one event and no second side effect. | Two-cycle test log |
| DEL-06 | Update the database change processor documentation and test-event artifacts so each TC has one MQA and AUTO case; validate and return one cross-artifact consistency report. | Driver validator logs |

## Acceptance criteria
| ID | Independently verifiable criterion |
|---|---|
| AC-01 | Given operationStatus `modified`, fieldPath `item.processingState`, oldValue `pending`, and newValue `approved`, processing creates exactly one event and zero errors. |
| AC-02 | Given oldValue `approved` and newValue `approved`, processing creates zero events. |
| AC-03 | Given fieldPath `item.otherField`, processing creates zero events. |
| AC-04 | Given unsupported operationStatus `created`, processing creates zero events. |
| AC-05 | Given a request missing mandatory recordKey, processing is blocked, creates zero events, and creates one error record. |
| AC-06 | Given two cycles with the same changeId and event type, the second cycle creates no second event and final event count is one. |

## Scope and exclusions
In scope: filtering, normalization, mapping, fail-closed behavior, deduplication, diagnostics and tests. Out of scope: live deployment, invented repository paths, unrelated refactors and unsupported delete operations.

## Dependencies
DEP-01: implementation module binding is unavailable. Closure requires exact repository paths, symbols and native test commands. Specification work may proceed; code modification is blocked.

## Definition of Done
Evidence includes code review links or logs, test reports, and Driver validation logs. DEP-01 is resolved or explicitly remains blocked with closure evidence. Passport, Manual QA and Automation consistency validation passes before handoff.
