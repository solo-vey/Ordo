# Technical Contract: RECORD_PROCESSING_STATE_CHANGED

## Trigger

An existing `source_records` record contains a `modified` change for `item.processingState`.

## Comparison

Convert `null`, missing, and empty string to the empty string. Compare the normalized strings exactly. Do not trim and do not change case.

## Creation

Create the event when normalized old and new values differ. The benchmark positive transition is empty to `approved`.

## Output

- Type: `RECORD_PROCESSING_STATE_CHANGED`
- Values: exactly `oldValue`, `newValue`
- Deduplication: `(change_id, event type)`

## Suppression

Suppress this event for normalized empty-to-empty, unrelated-field changes, and statuses other than `modified`.

## Confirmed reference

`source_records`, `DOC-88310`, `REC-902`, `CHG-2026-0002`, `2026-07-15T10:15:00Z`.
