# QA Package: RECORD_PROCESSING_STATE_CHANGED

## Readiness

The positive reference uses confirmed data. A second negative reference is confirmed conceptually: old value missing and new value empty. Environment-specific rollback is not confirmed and must not be invented.

## Standard request

Use:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
```

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "DOC-88310",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "processingState",
      "value": "approved"
    }
  ]
}
```

The operation path is relative to `item`.

## Manual QA cases

### QA-01 — Create the event

Verify the source record is `DOC-88310` with record key `REC-902`. Publish the patch, run processing, and locate the resulting change. Confirm status `modified`, field `item.processingState`, and change identifier `CHG-2026-0002` for the benchmark reference. Confirm exactly one event type `RECORD_PROCESSING_STATE_CHANGED` with exactly `oldValue` and `newValue`; expected values are `""` and `"approved"`.

### QA-02 — Normalized empty-to-empty no-op

Use the confirmed negative reference where the old value is missing and the new value is empty. Confirm that no `RECORD_PROCESSING_STATE_CHANGED` event is created.

### QA-03 — Unrelated field no-op

Change an unrelated field and confirm that no event of this type is created.

### QA-04 — Non-modified status no-op

Process an input whose status is not `modified` and confirm that no event of this type is created.

### QA-05 — Deduplication

Reprocess the same change and confirm that a second event with `(CHG-2026-0002, RECORD_PROCESSING_STATE_CHANGED)` is not persisted.

## MongoDB Compass verification

Use filters based on the confirmed `document_id`, the change record found during execution, and its change identifier. Do not substitute the source document ID for the `_id` or identifier of a generated change record.
