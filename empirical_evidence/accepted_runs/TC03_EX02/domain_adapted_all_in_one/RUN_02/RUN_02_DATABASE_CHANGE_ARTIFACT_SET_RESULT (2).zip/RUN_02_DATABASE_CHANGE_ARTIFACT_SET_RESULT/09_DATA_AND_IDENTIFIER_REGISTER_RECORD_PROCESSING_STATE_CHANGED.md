# Data and Identifier Register: RECORD_PROCESSING_STATE_CHANGED

| Field | Status | Value |
|---|---|---|
| Collection | Confirmed | `source_records` |
| Document ID | Confirmed | `DOC-88310` |
| Record key | Confirmed | `REC-902` |
| Field path | Confirmed | `item.processingState` |
| Old value | Confirmed | `null` |
| New value | Confirmed | `approved` |
| Change status | Confirmed | `modified` |
| Change ID | Confirmed | `CHG-2026-0002` |
| Occurred at | Confirmed | `2026-07-15T10:15:00Z` |
| Event type | Confirmed | `RECORD_PROCESSING_STATE_CHANGED` |
| Values keys | Confirmed | `oldValue`, `newValue` |
| Negative reference | Confirmed | old missing, new empty |
| Rollback procedure | Missing | Not confirmed |
| Implementation source | Missing | Unavailable |

Fixture-only values must not be used to fill any missing environment or rollback details.
