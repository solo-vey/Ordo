# Traceability Matrix: RECORD_PROCESSING_STATE_CHANGED

| Requirement | Processor test | Manual QA |
|---|---|---|
| Match `item.processingState` | UT-01 | QA-01 |
| Require `modified` status | UT-02 | QA-04 |
| Normalize null/missing/empty | UT-03, UT-04 | QA-01, QA-02 |
| Preserve whitespace and case | UT-05, UT-06 | Covered by automation specification |
| Exact `oldValue`/`newValue` shape | UT-07 | QA-01 |
| Unrelated field is a no-op | UT-08 | QA-03 |
| Deduplicate by change ID and event type | UT-09 | QA-05 |
| Use confirmed identifiers consistently | Fixture assertion | QA-01 |
