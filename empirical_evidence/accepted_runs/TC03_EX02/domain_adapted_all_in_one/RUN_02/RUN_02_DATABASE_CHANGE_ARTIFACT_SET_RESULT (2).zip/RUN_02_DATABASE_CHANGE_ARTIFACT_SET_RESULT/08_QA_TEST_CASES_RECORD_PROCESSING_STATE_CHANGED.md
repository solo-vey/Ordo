# QA Test Cases: RECORD_PROCESSING_STATE_CHANGED

## Approved manual set

1. Positive change from normalized empty to `approved`.
2. Missing old value and empty new value is a normalized no-op.
3. Unrelated field does not create this event type.
4. Status other than `modified` does not create this event type.
5. Reprocessing does not create a duplicate for the same change ID and event type.

## Expected positive event

```json
{
  "eventType": "RECORD_PROCESSING_STATE_CHANGED",
  "values": {
    "oldValue": "",
    "newValue": "approved"
  },
  "change_id": "CHG-2026-0002"
}
```

Any additional event created by an unrelated rule is outside this event-specific assertion; the test checks absence or presence of `RECORD_PROCESSING_STATE_CHANGED` specifically.
