# Automation Specification: RECORD_PROCESSING_STATE_CHANGED

## Automated cases

| ID | Input | Expected result |
|---|---|---|
| UT-01 | `null` to `approved`, status `modified`, target field | One event |
| UT-02 | Target field with status other than `modified` | No event |
| UT-03 | Missing to empty | No event |
| UT-04 | Empty to `approved` | One event |
| UT-05 | `approved` to ` approved` | One event; whitespace is preserved |
| UT-06 | `approved` to `APPROVED` | One event; case is preserved |
| UT-07 | Positive change | Values contain exactly `oldValue` and `newValue` |
| UT-08 | Unrelated field change | No event of this type |
| UT-09 | Same change ID and event type processed twice | Only one persisted event |

## Assertions

The positive benchmark fixture uses `DOC-88310`, `REC-902`, `CHG-2026-0002`, and `2026-07-15T10:15:00Z`. Tests must not infer additional fields from fixtures. The specification is implementation-agnostic because source code was unavailable.
