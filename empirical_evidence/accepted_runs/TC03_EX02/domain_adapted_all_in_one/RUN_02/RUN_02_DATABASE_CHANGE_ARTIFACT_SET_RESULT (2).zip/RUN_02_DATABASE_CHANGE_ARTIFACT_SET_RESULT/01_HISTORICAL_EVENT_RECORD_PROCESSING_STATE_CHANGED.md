# Historical Event for RECORD_PROCESSING_STATE_CHANGED: processing state changed

## Business purpose

Create a historical event when an existing internal source record has a meaningful change to `item.processingState`.

## Source contract

| Item | Confirmed value |
|---|---|
| Collection | `source_records` |
| Document ID | `DOC-88310` |
| Record key | `REC-902` |
| Field path | `item.processingState` |
| Change status | `modified` |
| Change ID | `CHG-2026-0002` |
| Occurred at | `2026-07-15T10:15:00Z` |
| Old source value | `null` |
| New source value | `approved` |

## Event contract

- Event type: `RECORD_PROCESSING_STATE_CHANGED`
- Values keys: exactly `oldValue` and `newValue`
- Positive example: `oldValue` is the normalized empty string and `newValue` is `approved`
- Deduplication key: `(change_id, event type)`

## Normalization and creation rules

`null`, a missing value, and an empty string normalize to the empty string for comparison. Whitespace is not trimmed and case is not changed. A normalized empty old value followed by `approved` is meaningful and creates the event.

No event of this type is created when both normalized values are empty, when only an unrelated field changes, or when the change status is not `modified`.

## Scope boundary

Implementation source code was not available. This document defines behavior and implementation expectations without asserting class or file names.
