# Jira Task: Add RECORD_PROCESSING_STATE_CHANGED

## Objective

Support a historical event for meaningful changes to `item.processingState` on existing records in `source_records`.

## Requirements

1. Process only changes whose status is `modified`.
2. Match the exact field path `item.processingState`.
3. Normalize `null`, missing, and empty string to an empty string for comparison.
4. Do not trim whitespace and do not alter case.
5. Create `RECORD_PROCESSING_STATE_CHANGED` when normalized old and new values differ.
6. Write a values object containing exactly `oldValue` and `newValue`.
7. Suppress the event when both normalized values are empty, an unrelated field changed, or status is not `modified`.
8. Deduplicate using `(change_id, event type)`.

## Acceptance example

For `DOC-88310` / `REC-902`, change `CHG-2026-0002` at `2026-07-15T10:15:00Z` changes `item.processingState` from `null` to `approved`. Exactly one `RECORD_PROCESSING_STATE_CHANGED` event is produced with `oldValue=""` and `newValue="approved"`.

## Delivery constraint

The implementation module is unavailable. Implementers must map this contract to the current codebase without changing shared mechanisms unless code analysis proves that such a change is required.
