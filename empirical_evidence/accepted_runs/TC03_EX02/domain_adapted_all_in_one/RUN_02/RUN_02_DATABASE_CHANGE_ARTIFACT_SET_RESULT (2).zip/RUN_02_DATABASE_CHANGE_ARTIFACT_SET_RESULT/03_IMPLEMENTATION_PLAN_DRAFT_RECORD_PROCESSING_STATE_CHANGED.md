# Implementation Plan Draft: RECORD_PROCESSING_STATE_CHANGED

## Production work

Add or update the existing internal source-record event rule so it recognizes the `modified` change for `item.processingState`, compares normalized values, and maps the result to `RECORD_PROCESSING_STATE_CHANGED`.

## Event mapping

Populate exactly:

```json
{
  "oldValue": "",
  "newValue": "approved"
}
```

for the confirmed positive example. Preserve non-empty source strings exactly; do not trim whitespace or change case.

## Deduplication

Use the existing event persistence mechanism to prevent a second event with the same `change_id` and event type.

## Tests

Add processor or rule tests for the positive case, normalization cases, unrelated fields, non-`modified` status, whitespace and case preservation, exact values shape, and duplicate processing.

## Limitations

No production, test, or documentation file paths are asserted because implementation source was unavailable. Shared processor contracts and unrelated event rules are out of scope unless code inspection later demonstrates a necessary change.
