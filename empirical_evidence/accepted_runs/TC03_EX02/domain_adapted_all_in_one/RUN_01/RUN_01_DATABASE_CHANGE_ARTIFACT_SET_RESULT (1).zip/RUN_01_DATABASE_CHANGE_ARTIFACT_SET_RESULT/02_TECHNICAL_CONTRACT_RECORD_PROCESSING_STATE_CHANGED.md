# Technical Contract: RECORD_PROCESSING_STATE_CHANGED

## Identity
- Processor branch: internal existing-record change
- Source collection: `source_records`
- Event type: `RECORD_PROCESSING_STATE_CHANGED`
- Logical operation status: `modified`

## Trigger
A change record for `DOC-74291` / `REC-184` reports a meaningful transition at `item.processingState` from `pending` to `approved`.

## Source of truth
Use the previous and current values represented by the confirmed change record. Do not derive absent identifiers or values from fixtures.

## Output mapping

| Output key | Source |
|---|---|
| `oldValue` | normalized previous `item.processingState` |
| `newValue` | normalized current `item.processingState` |

The values object must contain no additional business keys.

## Normalization
Normalize null, missing, and empty string to `""`. Preserve whitespace and letter case for non-empty strings.

## No-op conditions
- normalized old and new values are equal;
- the changed path is not `item.processingState`;
- operation status is unsupported for this rule.

## Idempotency
Use the compound identity `(change_id, event type)`, specifically `CHG-2026-0001` and `RECORD_PROCESSING_STATE_CHANGED` for the confirmed reference change.

## Errors and boundaries
Malformed inputs that cannot satisfy the surrounding processor contract remain governed by existing module error handling. This change does not introduce a new processor, alter shared change-record contracts, or define unrelated events.
