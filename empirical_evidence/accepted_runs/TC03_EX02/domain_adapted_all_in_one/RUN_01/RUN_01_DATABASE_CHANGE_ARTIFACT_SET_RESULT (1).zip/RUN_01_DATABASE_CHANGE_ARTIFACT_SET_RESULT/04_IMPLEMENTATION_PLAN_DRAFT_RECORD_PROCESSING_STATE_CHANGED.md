# Draft Implementation Plan: RECORD_PROCESSING_STATE_CHANGED

## Current status
Analytical plan approved; implementation source archive unavailable.

## Planned changes

| Area | Planned action |
|---|---|
| Existing internal source-record routing | Register or route `item.processingState` to a standard event rule. |
| Event rule | Compare normalized old/new values and build `RECORD_PROCESSING_STATE_CHANGED`. |
| Values mapping | Emit exactly `oldValue` and `newValue`. |
| Deduplication | Reuse existing event persistence guard with `(change_id, event type)`. |
| Unit/processor tests | Add positive, no-op, normalization, preservation, and idempotency coverage. |
| Documentation | Add/update event passport and supported-event documentation. |

## Files intentionally not named
No production, test, or documentation path is invented because the current module source was not provided.

## Do not change
Shared `ChangeRecord` contracts, global processor behavior, unrelated event types, deployment configuration, and external monitoring.

## Implementation checkpoint
Before code changes, inspect the current module, replace this draft with concrete file paths, and obtain approval for any departure from the standard-rule approach.
