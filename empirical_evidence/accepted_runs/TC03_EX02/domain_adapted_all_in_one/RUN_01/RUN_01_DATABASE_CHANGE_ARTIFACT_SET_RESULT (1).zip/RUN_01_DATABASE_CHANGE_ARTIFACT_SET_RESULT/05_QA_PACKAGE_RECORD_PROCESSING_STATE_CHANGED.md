# Manual QA Package: RECORD_PROCESSING_STATE_CHANGED

## Readiness
Ready for execution using the confirmed reference source and change records. The reference data is approved for this scenario; no substitute fixture identifiers may be introduced.

## Reference data
- Collection: `source_records`
- Document ID: `DOC-74291`
- Record key: `REC-184`
- Change ID: `CHG-2026-0001`
- Field path: `item.processingState`
- Transition: `pending` → `approved`
- Occurred at: `2026-07-15T09:30:00Z`

## TC-M01 — Emit the processing-state event
1. In MongoDB Compass, verify the approved reference source record in `source_records` using filter `{"document_id":"DOC-74291"}` and confirm record key `REC-184`.
2. Publish the update with:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
Content-Type: application/json
```

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "DOC-74291",
  "preview": false,
  "gzip": true,
  "operations": [
    {"path": "processingState", "value": "approved"}
  ]
}
```

3. Start processing with `POST /api/record-change-events/process` and body `{"operation":"start"}`.
4. In `changes`, locate `CHG-2026-0001` and confirm status `modified`, path `item.processingState`, old `pending`, new `approved`, and occurred-at timestamp.
5. In `events`, filter by `change_id` and event type.

Expected: exactly one `RECORD_PROCESSING_STATE_CHANGED` event with values `{"oldValue":"pending","newValue":"approved"}` and the confirmed source identifiers.

## TC-M02 — Verify idempotency
Repeat processing without creating a new change. Expected: no second event for `(CHG-2026-0001, RECORD_PROCESSING_STATE_CHANGED)`.

## TC-M03 — Verify no-op boundaries
Using approved controlled data only, verify that equal normalized values, an unrelated field path, or an unsupported operation status does not create this event type. Other event types or processor errors are outside this event-specific assertion.

## Evidence to capture
Request/response, Compass filters, the matching change record, the matching event record, duplicate count, and any processing error associated with the reference change.

## Rollback and safety
Restore `processingState` only through an approved controlled update. If a safe rollback record is not available in the environment, do not improvise one; document that rollback was not executed.
