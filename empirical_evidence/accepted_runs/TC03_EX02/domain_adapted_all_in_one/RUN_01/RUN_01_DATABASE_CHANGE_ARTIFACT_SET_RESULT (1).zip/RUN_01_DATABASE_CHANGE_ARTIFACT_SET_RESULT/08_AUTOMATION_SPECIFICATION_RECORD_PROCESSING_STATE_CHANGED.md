# Automation Specification: RECORD_PROCESSING_STATE_CHANGED

## Purpose
Automate regression verification of the standard processing-state change rule without relying on mutable manual fixtures.

## Test data model
Build isolated change records with explicit collection, document ID, record key, path, old/new values, status, change ID, and occurred-at values. The confirmed reference data may be represented as a named test fixture, but fixture values must not be treated as evidence of production state.

## Assertions
- event type equals `RECORD_PROCESSING_STATE_CHANGED`;
- values keys are exactly `oldValue` and `newValue`;
- normalization applies only to null, missing, and empty string;
- case and whitespace remain unchanged;
- no event for equal normalized values, unrelated paths, or unsupported statuses;
- two processing attempts for one `(change_id, event type)` produce one event.

## Recommended layers
Rule-level tests for comparison and mapping; processor-level tests for routing and metadata; persistence-level or integration coverage for deduplication where the existing test architecture supports it.

## Non-goals
No new test framework, no production endpoint dependency for unit tests, and no assumptions about implementation filenames before source inspection.
