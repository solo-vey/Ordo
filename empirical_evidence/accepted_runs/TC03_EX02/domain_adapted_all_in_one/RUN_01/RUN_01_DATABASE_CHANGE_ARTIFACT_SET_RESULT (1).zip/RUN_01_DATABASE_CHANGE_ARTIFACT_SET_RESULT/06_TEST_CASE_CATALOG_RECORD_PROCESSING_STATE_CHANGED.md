# Test Case Catalog: RECORD_PROCESSING_STATE_CHANGED

## Unit and processor scenarios

| ID | Scenario | Expected result |
|---|---|---|
| UT-01 | `pending` → `approved`, status `modified`, target path | One event with exact values shape. |
| UT-02 | Equal non-empty values | No event. |
| UT-03 | Null → missing | Both normalize to empty; no event. |
| UT-04 | Empty → `approved` | Event with `oldValue:""`, `newValue:"approved"`. |
| UT-05 | Case-only change | Event; case is preserved and compared. |
| UT-06 | Whitespace-only difference | Event; values are not trimmed. |
| UT-07 | Unrelated field path | No `RECORD_PROCESSING_STATE_CHANGED`. |
| UT-08 | Unsupported operation status | No `RECORD_PROCESSING_STATE_CHANGED`. |
| UT-09 | Same change processed twice | One persisted event by compound deduplication key. |
| UT-10 | Values object construction | Exactly `oldValue` and `newValue`; no extra business keys. |

## Manual QA scenarios
- M01: confirmed `pending` → `approved` reference change.
- M02: repeat processing to verify idempotency.
- M03: controlled no-op boundary checks when suitable approved records exist.

Manual QA does not replace the broader unit/processor normalization matrix.
