# Historical Event: RECORD_PROCESSING_STATE_CHANGED

## Status
Approved analytical definition, version 1.0.

## Business outcome
Create a historical event when the processing state of an existing internal source record meaningfully changes.

## Confirmed source and change facts

| Attribute | Confirmed value |
|---|---|
| Source collection | `source_records` |
| Document ID | `DOC-74291` |
| Record key | `REC-184` |
| Field path | `item.processingState` |
| Previous value | `pending` |
| New value | `approved` |
| Operation status | `modified` |
| Change ID | `CHG-2026-0001` |
| Occurred at | `2026-07-15T09:30:00Z` |
| Event type | `RECORD_PROCESSING_STATE_CHANGED` |

## Event contract
The event values object contains exactly:

```json
{
  "oldValue": "pending",
  "newValue": "approved"
}
```

Null, missing, and empty-string field values normalize to the empty string. Values are not trimmed and case is not changed.

## Creation and suppression rules
Create the event only for a supported `modified` change affecting `item.processingState` when normalized old and new values differ. Equal values, unrelated fields, and unsupported operation statuses are no-op for this event type. Deduplicate by `(change_id, event type)`.

## Scope
This package defines the analytical and verification contract. Implementation source code was not supplied, so concrete production file paths are not asserted.
