# Jira Task: Add RECORD_PROCESSING_STATE_CHANGED

## Objective
Implement a standard internal existing-record rule that emits `RECORD_PROCESSING_STATE_CHANGED` for meaningful changes to `item.processingState`.

## Acceptance criteria
1. A supported `modified` change from `pending` to `approved` emits one event.
2. The event references `DOC-74291`, `REC-184`, `CHG-2026-0001`, and `2026-07-15T09:30:00Z` according to existing event metadata contracts.
3. `values` contains exactly `oldValue` and `newValue`.
4. Null, missing, and empty string normalize to empty string; non-empty strings retain whitespace and case.
5. Equal normalized values, unrelated paths, and unsupported statuses do not emit this event type.
6. Reprocessing the same `(change_id, event type)` does not create a duplicate.
7. Unit/processor tests and event documentation are added or updated.

## Implementation constraints
Use the existing internal source-record processor and rule pattern. Do not change shared processor contracts, introduce a new comparison framework, or modify unrelated event types. Actual code paths must be confirmed from the current module before implementation.

## Definition of done
Production behavior, automated tests, documentation, traceability, and manual QA evidence agree with this approved contract.
