# Automation Specification: RECORD_PROCESSING_STATE_CHANGED

## Approved version
v1

## Automated scenarios
- **UT-01 Positive mapping:** `modified` change of `item.processingState` from `pending` to `reviewed` emits one event.
- **UT-02 Metadata:** event type is `RECORD_PROCESSING_STATE_CHANGED`; display name is `Processing state changed`.
- **UT-03 Values shape:** keys are exactly `oldValue` and `newValue` with the confirmed values.
- **UT-04 Field gating:** another field does not emit this event type.
- **UT-05 Status gating:** a non-`modified` operation does not emit this event type.
- **UT-06 Propagation:** `DOC-11990`, `REC-220`, `CHG-2026-0004`, and `2026-07-15T11:00:00Z` are preserved.
- **UT-07 Idempotency:** duplicate processing creates no second event for the same `(change_id, event type)`.
- **UT-08 Correction regression:** output does not contain `approved` or `Processing state reviewed`.

## Implementation note
Framework, class, and fixture names must be adapted to the actual module after source code becomes available.
