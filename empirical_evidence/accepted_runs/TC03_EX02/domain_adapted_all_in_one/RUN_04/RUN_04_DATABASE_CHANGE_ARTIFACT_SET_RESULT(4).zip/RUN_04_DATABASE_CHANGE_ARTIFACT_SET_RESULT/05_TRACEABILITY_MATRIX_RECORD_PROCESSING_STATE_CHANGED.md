# Traceability Matrix: RECORD_PROCESSING_STATE_CHANGED

| Requirement | Unit/processor coverage | Manual QA coverage | Evidence |
|---|---|---|---|
| Exact field path `item.processingState` | UT-01 positive; UT-04 other-field negative | TC-M01; TC-M03 | Contract and Jira |
| `modified` operation status | UT-01; UT-05 unsupported-status negative | TC-M01 | Contract and Jira |
| Transition `pending` → `reviewed` | UT-01 | TC-M01 | Corrected passport v3 |
| Event type and display name | UT-01; UT-02 | TC-M01 | Approved artifacts |
| `oldValue` / `newValue` mapping | UT-01; UT-03 | TC-M01 | Approved artifacts |
| Identifier and timestamp propagation | UT-06 | TC-M01 | Confirmed Driver facts |
| Deduplication by `(change_id, event type)` | UT-07 | TC-M02 | Approved automation spec |
| No event for unrelated field | UT-04 | TC-M03 | Negative requirement |
| Superseded semantics absent | UT-08 | TC-M01 expected absence | Correction history |
