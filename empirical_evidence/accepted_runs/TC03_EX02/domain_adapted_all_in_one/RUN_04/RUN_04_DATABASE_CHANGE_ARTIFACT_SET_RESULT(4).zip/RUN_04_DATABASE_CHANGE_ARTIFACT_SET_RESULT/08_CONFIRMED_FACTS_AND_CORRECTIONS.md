# Confirmed Facts and Corrections

## Confirmed canonical facts
- Branch: internal existing-record change.
- Collection: `source_records`.
- `document_id`: `DOC-11990`.
- `record_key`: `REC-220`.
- Field path: `item.processingState`.
- Old value: `pending`.
- Corrected new value: `reviewed`.
- Operation status: `modified`.
- `change_id`: `CHG-2026-0004`.
- `occurred_at`: `2026-07-15T11:00:00Z`.
- Event type: `RECORD_PROCESSING_STATE_CHANGED`.
- Display name: Processing state changed.
- Values keys: `oldValue`, `newValue`.
- Deduplication: `(change_id, event type)`.
- Implementation mode: instructions only; module unavailable.

## Superseded facts
- New value `approved` — invalidated.
- Display name `Processing state reviewed` — invalidated.
