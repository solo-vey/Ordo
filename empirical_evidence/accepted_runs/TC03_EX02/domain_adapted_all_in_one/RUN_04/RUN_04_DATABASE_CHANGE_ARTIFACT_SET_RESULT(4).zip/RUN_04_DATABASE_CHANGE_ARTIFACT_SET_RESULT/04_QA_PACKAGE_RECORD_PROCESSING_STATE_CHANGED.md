# QA Package: RECORD_PROCESSING_STATE_CHANGED

## Readiness
Ready for the confirmed fixture record and relative internal test endpoints. A physical environment base URL and access credentials remain environment-specific.

## Confirmed test data
| Field | Value |
|---|---|
| Collection | `source_records` |
| document_id | `DOC-11990` |
| record_key | `REC-220` |
| Initial state | `pending` |
| Target state | `reviewed` |
| Expected change_id | `CHG-2026-0004` |
| Expected occurred_at | `2026-07-15T11:00:00Z` |

## TC-M01 — Processing state changes from pending to reviewed
1. Confirm the selected `source_records` document is `DOC-11990` / `REC-220` and currently has `item.processingState=pending`.
2. Publish the patch:

```http
POST /internal/api/test/product-queue/publish-source-record-patch
Content-Type: application/json
```

```json
{
  "operation": "append",
  "collection": "source_records",
  "document_id": "DOC-11990",
  "preview": false,
  "gzip": true,
  "operations": [
    {
      "path": "processingState",
      "value": "reviewed"
    }
  ]
}
```

3. Start record-change processing:

```http
POST /api/record-change-events/process
Content-Type: application/json
```

```json
{"operation":"start"}
```

4. In MongoDB Compass, inspect `changes` for `change_id=CHG-2026-0004` and confirm status `modified`, the exact source identifiers, field path, and timestamp.
5. Inspect `events` for `change_id=CHG-2026-0004` and `item.eventType=RECORD_PROCESSING_STATE_CHANGED`.
6. Confirm exactly one event exists and contains display name `Processing state changed`, `values.oldValue=pending`, and `values.newValue=reviewed`.

## TC-M02 — Duplicate processing
Run processing again without a new source change. Confirm no second event exists for `(CHG-2026-0004, RECORD_PROCESSING_STATE_CHANGED)`.

## TC-M03 — Unrelated field
Change a field other than `item.processingState`. Confirm that no `RECORD_PROCESSING_STATE_CHANGED` event is created for that change. Other event types or technical outcomes are outside this assertion.

## Expected absence
No event with the superseded value `approved` or display name `Processing state reviewed` may be present for the canonical case.
