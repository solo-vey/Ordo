# Implementation Plan Draft: RECORD_PROCESSING_STATE_CHANGED

## Mode
Implementation instructions only. The implementation module was confirmed unavailable.

## Production guidance
- Add or update the existing internal source-record event rule for `item.processingState`.
- Require `change.status=modified`.
- Emit event type `RECORD_PROCESSING_STATE_CHANGED` and display name `Processing state changed`.
- Read the old and new field values from the existing change inputs and write them as `oldValue` and `newValue`.
- Apply idempotency using `(change_id, event type)`.

## Test guidance
Add processor/unit coverage for positive mapping, exact keys, exact identifiers and timestamp propagation, field-path gating, operation-status gating, and duplicate suppression.

## Documentation guidance
Update the repository event documentation only when the current module is available and its established file locations are verified.

## Files
Concrete class names and repository paths are intentionally not asserted because source code was unavailable.
