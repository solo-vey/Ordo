# Jira Task: Add RECORD_PROCESSING_STATE_CHANGED handling

## Objective
Document and implement the standard internal existing-record change rule for a processing-state update.

## Scope
When a `source_records` change has status `modified` and changes `item.processingState`, emit `RECORD_PROCESSING_STATE_CHANGED` with display name **Processing state changed**.

## Confirmed example
- `document_id`: `DOC-11990`
- `record_key`: `REC-220`
- `change_id`: `CHG-2026-0004`
- `occurred_at`: `2026-07-15T11:00:00Z`
- transition: `pending` → `reviewed`
- values: `oldValue=pending`, `newValue=reviewed`

## Implementation requirements
1. Gate the rule by source collection, `modified` operation status, and exact field path.
2. Map the previous and new states without renaming the output keys.
3. Preserve the confirmed record and change identifiers and timestamp.
4. Deduplicate by `(change_id, event type)`.
5. Do not emit this event for unrelated field changes or unsupported operation statuses.
6. Implementation source code is unavailable in this run; provide implementation instructions rather than code changes.

## Acceptance criteria
- The confirmed transition emits exactly one matching event.
- The event type and display name are exact.
- `values.oldValue` is `pending`; `values.newValue` is `reviewed`.
- Reprocessing the same change does not create a duplicate.
- Negative gating scenarios do not create this event type.
