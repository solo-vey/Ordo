# Historical Event: RECORD_PROCESSING_STATE_CHANGED

## Status
Approved canonical analytical document, passport version v3.

## Business description
Create a record-change event when an existing internal source record changes its processing state. For the confirmed case, the processing state changes from `pending` to `reviewed`.

## Event contract

| Attribute | Confirmed value |
|---|---|
| Source collection | `source_records` |
| Document identifier | `DOC-11990` |
| Record key | `REC-220` |
| Field path | `item.processingState` |
| Operation status | `modified` |
| Previous value | `pending` |
| New value | `reviewed` |
| Change identifier | `CHG-2026-0004` |
| Occurred at | `2026-07-15T11:00:00Z` |
| Event type | `RECORD_PROCESSING_STATE_CHANGED` |
| Display name | Processing state changed |
| Values mapping | `oldValue=pending`, `newValue=reviewed` |
| Deduplication | `(change_id, event type)` |

## Trigger and output
The event is created only for a `modified` existing-record change whose exact changed field is `item.processingState`. The resulting event contains the confirmed source identifiers, `change_id`, occurrence timestamp, event type, display name, and the exact `oldValue` and `newValue` keys.

## Exclusions
Changes to other fields, non-`modified` operations, and reprocessing of the same `(change_id, event type)` must not create another `RECORD_PROCESSING_STATE_CHANGED` event.

## Correction history
The initially supplied new value `approved` is superseded and invalid. The canonical new value is `reviewed`. The initially suggested display name “Processing state reviewed” is superseded; the canonical display name is “Processing state changed.”
