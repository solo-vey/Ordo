# Implementation Prompt — RUN_01

Use the approved Passport and Jira. First close DEP-001 by repository discovery; do not invent paths or symbols. Then implement DEL-001 through DEL-005 only in confirmed boundaries, add unit/integration tests for AC-001 through AC-005, and preserve exact locked facts. This document is an instruction, not implementation evidence.
