# Jira Task — RUN_01 processing-state change

## Authoritative fact lock

| Locked field | Exact authoritative value | Source | Verified in all Jira sections |
|---|---|---|---|
| `document_id` | `DOC-74291` | `01_SELECTED_RUN.yaml` | yes |
| `record_key` | `REC-184` | `01_SELECTED_RUN.yaml` | yes |
| `field_path` | `item.processingState` | `01_SELECTED_RUN.yaml` | yes |
| `old_value` | `pending` | `01_SELECTED_RUN.yaml` | yes |
| `new_value` | `approved` | `01_SELECTED_RUN.yaml` | yes |
| `operation_status` | `modified` | `01_SELECTED_RUN.yaml` | yes |
| `event_type` | `RECORD_PROCESSING_STATE_CHANGED` | `01_SELECTED_RUN.yaml` | yes |
| `change_id` | `CHG-2026-0001` | `01_SELECTED_RUN.yaml` | yes |
| `occurred_at` | `2026-07-15T09:30:00Z` | `01_SELECTED_RUN.yaml` | yes |

## Summary and business context

Реалізувати обробку зміни `item.processingState` з `pending` на `approved` для операції `modified`, створюючи рівно одну подію `RECORD_PROCESSING_STATE_CHANGED` і не створюючи подій для no-op випадків. Точні repository/module/class/function bindings авторитетно не надані; вони мають бути закриті через discovery dependency перед зміною коду.

## Confirmed contract summary

| Concern | Confirmed value/behavior | Source |
|---|---|---|
| Source identity | `source_records`, `DOC-74291`, `REC-184` | Driver RUN_01 |
| Target change | `item.processingState`: `pending` → `approved`; `modified` | Driver RUN_01 |
| Event mapping | `RECORD_PROCESSING_STATE_CHANGED`, `CHG-2026-0001`, `2026-07-15T09:30:00Z` | Driver RUN_01 |
| Normalization | null, missing and empty string normalize to empty string; no trim/case mutation | Driver RUN_01 |
| No-op | equal values, unrelated fields and unsupported statuses | Driver RUN_01 |
| Deduplication | `change_id` + `event_type` | Driver RUN_01 |

## Scope and exclusions

In scope: matching, normalization, no-op gating, event payload/date mapping, duplicate suppression, diagnostics, unit/integration verification. Out of scope: invented repository symbols, production deployment, live execution claims, credentials, and release completion.

## Product implementation requirements

| Delivery ID | Target component/domain object | Implementation action | Concrete output or prohibited side effect | Measurable behavior | Binding status | Owner/discovery action | Closure condition | Completion evidence | Status |
|---|---|---|---|---|---|---|---|---|---|
| DEL-001 | database-change operation gate | implement validation of operation status | accept `modified`; skip unsupported statuses without change/event/error records | unsupported status yields exactly zero change records, zero events, zero errors | unavailable / to-discover | Discovery owner: implementation technical lead; discovery action: identify processor gate in repository | Closure evidence: repository discovery report records path and symbol, reviewer acknowledged | diff plus unit test | blocked by DEP-001 |
| DEL-002 | field-path matcher and value normalizer | implement target-field matching and comparison | match only `item.processingState`; normalize null/missing/empty to empty string; do not trim or change case | equal normalized values and unrelated fields yield exactly zero events | unavailable / to-discover | Discovery owner: implementation technical lead; discovery action: identify matcher/normalizer symbols | Closure evidence: confirmed path/symbol and test seam | diff plus unit tests | blocked by DEP-001 |
| DEL-003 | change-to-event mapper | implement mapping for meaningful `pending` to `approved` change | emit exactly one payload with `record_key=REC-184`, `field_path=item.processingState`, old/new values, event type, and `event_date=2026-07-15T09:30:00Z`; must not use processing time | one qualifying change produces exactly one event and zero errors | unavailable / to-discover | Discovery owner: implementation technical lead; discovery action: locate mapper/event registration | Closure evidence: repository evidence confirms mapper and event definition | diff plus unit/integration tests | blocked by DEP-001 |
| DEL-004 | duplicate guard/persistence boundary | implement deduplication by `change_id` plus `event_type` | repeated `CHG-2026-0001` + `RECORD_PROCESSING_STATE_CHANGED` must not create a second event | after two identical cycles final event cardinality remains exactly one | unavailable / to-discover | Discovery owner: implementation technical lead; discovery action: locate uniqueness or duplicate guard | Closure evidence: index/guard path and behavior test recorded | diff plus duplicate-cycle test | blocked by DEP-001 |
| DEL-005 | required-data validator and diagnostics boundary | implement fail-closed handling for missing mandatory mapping data | produce no event; create only the contract-authorized diagnostic once exact omission binding is confirmed; no partial payload | missing-data case remains blocked until request-schema binding exists; no success claim before closure | unavailable / to-discover | Discovery owner: API/schema owner; discovery action: confirm legal omitted-field request and diagnostic contract | Closure evidence: schema/fixture and expected diagnostic approved | validation test and observability evidence | blocked by DEP-002 |

## Verification deliverables

| Delivery ID | Verification target | Required test/check | Exact expected result | Linked product DEL IDs | Completion evidence | Status |
|---|---|---|---|---|---|---|
| DEL-V01 | positive mapping | unit plus integration case MQA-001 / AUTO-001 | exactly 1 change, 1 event, 0 errors with locked payload/date | linked: DEL-001, DEL-002, DEL-003 | test command, exit status, assertions | specified, not executed |
| DEL-V02 | no-op boundaries | | exactly zero events for equal normalized values, unrelated field, unsupported status | linked: DEL-001, DEL-002 | test evidence | specified, not executed |
| DEL-V03 | duplicate replay | | final event cardinality exactly one after identical second cycle | linked: DEL-004 | test evidence | specified, not executed |
| DEL-V04 | missing data | | blocked until omission binding; once closed, fail-closed exact behavior verified | linked: DEL-005 | approved fixture and test evidence | blocked by DEP-002 |

## Evidence and package requirements

| Delivery ID | Evidence object | Required content | Linked DEL/AC IDs | Completion evidence | Status |
|---|---|---|---|---|---|
| DEL-E01 | validation receipts | commands, exit codes, validator output and SHA-256 | DEL-001–DEL-005 / AC-001–AC-005 | files under `validation/` | complete for design artifacts |
| DEL-E02 | traceability matrix | complete semantically aligned DEL ↔ AC mapping | DEL-001–DEL-005 / AC-001–AC-005 | this Jira section | complete |
| DEL-E03 | package manifest | truthful package scope, hashes, unresolved dependencies | all | `MANIFEST.json` and `SHA256SUMS.txt` | complete |

## Acceptance criteria

| AC ID | Linked DEL IDs | Given / input | When / action | Then / exact observable result | Verification/evidence | Blocker applicability |
|---|---|---|---|---|---|---|
| AC-001 | linked: DEL-001 | operation status is not `modified` | processor evaluates the change | Given unsupported operation status, exactly 0 change records, exactly 0 generated events, and exactly 0 errors | MQA-004 / AUTO-004 | DEP-001 for code binding |
| AC-002 | linked: DEL-002 | field is unrelated or normalized old/new values are equal | matcher and normalizer evaluate input | Given equal or unrelated input, exactly 0 generated events and no mapped candidate | , MQA-002, MQA-003 / AUTO-002, AUTO-003 | DEP-001 for code binding |
| AC-003 | linked: DEL-003 | locked `DOC-74291` / `REC-184` change `pending` → `approved` at `2026-07-15T09:30:00Z` | qualifying `modified` change is processed | Given pending to approved modified input, exactly 1 `RECORD_PROCESSING_STATE_CHANGED` event with exact payload/date and exactly 0 errors | MQA-001 / AUTO-001 | DEP-001 for code binding |
| AC-004 | linked: DEL-004 | identical `CHG-2026-0001` and event type are replayed | second processing cycle completes | Given duplicate replay, total matching event count remains exactly 1 and no second event is created | MQA-005 / AUTO-005 | DEP-001 for code binding |
| AC-005 | linked: DEL-005 | a mandatory mapping field is omitted using an authoritative legal fixture | required-data validator runs | Given an omitted mandatory field, exactly 0 partial events are emitted and the authorized diagnostic is observed | MQA-006 / AUTO-006 | DEP-002 blocks execution until fixture exists |

## DEL ↔ AC traceability

| Delivery ID | Acceptance criteria | Semantic alignment statement |
|---|---|---|
| Product DEL-001 | Criterion AC-001 | same operation gate and zero-side-effect result |
| Product DEL-002 | Criterion AC-002 | same field/normalization decision and event absence |
| Product DEL-003 | Criterion AC-003 | same qualifying transition and exact event payload/cardinality |
| Product DEL-004 | Criterion AC-004 | same duplicate identity and final cardinality one |
| Product DEL-005 | Criterion AC-005 | same missing-data fail-closed behavior and blocker |

## Functional delivery coverage

| Functional ID | Requirement and exact expected result | Product DEL IDs | AC IDs | Manual QA | Automation | Status/blocker |
|---|---|---|---|---|---|---|
| TC-001 | meaningful change creates 1/1/0 change/event/error | linked: DEL-001, DEL-002, DEL-003 | linked: AC-003 | MQA-001 | AUTO-001 | runnable |
| TC-002 | equal normalized values create zero events | linked: DEL-002 | linked: AC-002 | MQA-002 | AUTO-002 | runnable |
| TC-003 | unrelated field creates zero events | linked: DEL-002 | linked: AC-002 | MQA-003 | AUTO-003 | runnable |
| TC-004 | unsupported status creates zero records/events/errors | linked: DEL-001 | linked: AC-001 | MQA-004 | AUTO-004 | runnable |
| TC-005 | duplicate cycle keeps one event | linked: DEL-004 | linked: AC-004 | MQA-005 | AUTO-005 | runnable |
| TC-006 | omitted required field is blocked pending fixture | linked: DEL-005 | linked: AC-005 | MQA-006 | AUTO-006 | blocked_missing_binding |

## Dependencies, open questions, and closure criteria

| ID | Missing evidence/capability or question | Affected DEL/AC | Impact | Owner/discovery action | Closure criterion | Work allowed while open | Blocks |
|---|---|---|---|---|---|---|---|
| DEP-001 | exact repository/module/class/function binding unavailable | DEL-001–DEL-004 / AC-001–AC-004 | code change cannot be safely targeted | implementation technical lead inspects repository and records processor, matcher, mapper, guard and test paths | reviewed discovery report with exact paths/symbols and test seams | design review and test specification | implementation and execution |
| DEP-002 | authoritative omission request schema and diagnostic binding unavailable | DEL-005 / AC-005 | missing-data case cannot be runnable without invention | API/schema owner confirms omission-capable fixture and diagnostic contract | approved fixture body, expected status/error object and query | keep case explicitly blocked | TC-006 execution |

## Delivery checklist

- [x] Product, verification, and evidence deliverables are separated.
- [x] Every product DEL names component boundary, action, output, measurable behavior and binding status.
- [x] Each unresolved binding has discovery owner, action, closure evidence and allowed pre-closure work.
- [x] Every product DEL maps to at least one semantically aligned AC, and every AC maps to a DEL.
- [x] Authoritative facts were reloaded immediately before generation.
- [ ] Repository discovery closed.
- [ ] Product implementation and test execution completed.

## Definition of Done

- DEP-001 is closed with exact reviewed component/code bindings before code modification.
- Code-change boundaries for gate, matcher/normalizer, mapper, duplicate guard and validator are identified.
- Unit and integration tests prove AC-001 through AC-004; AC-005 is executed only after DEP-002 closure.
- Backward compatibility is demonstrated by no-op behavior for unrelated fields, equal normalized values and unsupported statuses.
- Error handling and observability are verified without partial events or invented diagnostics.
- Every AC has measurable cardinality/payload evidence and all current validators pass.
- Cross-artifact consistency evidence confirms Passport, Jira, Manual QA, Automation, and case registry alignment.
- Verification and package evidence remain separate from product implementation and do not substitute for it.

## External references

- Repository: Not provided
- Jira URL: Not provided
- Live environment: Not provided
