# Unresolved blockers

- DEP-001: exact repository/module/class/function bindings are unavailable. Closure requires a reviewed repository discovery report.
- DEP-002: exact omission-capable request schema and authorized diagnostic contract are unavailable. TC-006 remains blocked.

These blockers do not invalidate the analysis-handoff package; they prevent claims of implementation, test execution, or release completion.
